// ============================================================================
//
// Copyright (c) 2006-2015, Talend SA
//
// Ce code source a été automatiquement généré par_Talend Open Studio for Data Integration
// / Soumis à la Licence Apache, Version 2.0 (la "Licence") ;
// votre utilisation de ce fichier doit respecter les termes de la Licence.
// Vous pouvez obtenir une copie de la Licence sur
// http://www.apache.org/licenses/LICENSE-2.0
// 
// Sauf lorsqu'explicitement prévu par la loi en vigueur ou accepté par écrit, le logiciel
// distribué sous la Licence est distribué "TEL QUEL",
// SANS GARANTIE OU CONDITION D'AUCUNE SORTE, expresse ou implicite.
// Consultez la Licence pour connaître la terminologie spécifique régissant les autorisations et
// les limites prévues par la Licence.


package alimentation_si_ope.c_alim_si_ope_api_0_1;

import routines.Numeric;
import routines.DataOperation;
import routines.TalendDataGenerator;
import routines.TalendStringUtil;
import routines.TalendString;
import routines.StringHandling;
import routines.Relational;
import routines.TalendDate;
import routines.Mathematical;
import routines.system.*;
import routines.system.api.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.math.BigDecimal;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.util.Comparator;
 




	//the import part of tJava_1
	//import java.util.List;

	//the import part of tJava_2
	//import java.util.List;


@SuppressWarnings("unused")

/**
 * Job: C_ALIM_SI_OPE_API Purpose: Job pour alimenter les tables par API<br>
 * Description: Job pour alimenter les tables par API <br>
 * @author user@talend.com
 * @version 8.0.1.20211109_1610
 * @status 
 */
public class C_ALIM_SI_OPE_API implements TalendJob {

protected static void logIgnoredError(String message, Throwable cause) {
       System.err.println(message);
       if (cause != null) {
               cause.printStackTrace();
       }

}


	public final Object obj = new Object();

	// for transmiting parameters purpose
	private Object valueObject = null;

	public Object getValueObject() {
		return this.valueObject;
	}

	public void setValueObject(Object valueObject) {
		this.valueObject = valueObject;
	}
	
	private final static String defaultCharset = java.nio.charset.Charset.defaultCharset().name();

	
	private final static String utf8Charset = "UTF-8";
	//contains type for every context property
	public class PropertiesWithType extends java.util.Properties {
		private static final long serialVersionUID = 1L;
		private java.util.Map<String,String> propertyTypes = new java.util.HashMap<>();
		
		public PropertiesWithType(java.util.Properties properties){
			super(properties);
		}
		public PropertiesWithType(){
			super();
		}
		
		public void setContextType(String key, String type) {
			propertyTypes.put(key,type);
		}
	
		public String getContextType(String key) {
			return propertyTypes.get(key);
		}
	}
	
	// create and load default properties
	private java.util.Properties defaultProps = new java.util.Properties();
	// create application properties with default
	public class ContextProperties extends PropertiesWithType {

		private static final long serialVersionUID = 1L;

		public ContextProperties(java.util.Properties properties){
			super(properties);
		}
		public ContextProperties(){
			super();
		}

		public void synchronizeContext(){
			
		}
		
		//if the stored or passed value is "<TALEND_NULL>" string, it mean null
		public String getStringValue(String key) {
			String origin_value = this.getProperty(key);
			if(NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY.equals(origin_value)) {
				return null;
			}
			return origin_value;
		}

	}
	protected ContextProperties context = new ContextProperties(); // will be instanciated by MS.
	public ContextProperties getContext() {
		return this.context;
	}
	private final String jobVersion = "0.1";
	private final String jobName = "C_ALIM_SI_OPE_API";
	private final String projectName = "ALIMENTATION_SI_OPE";
	public Integer errorCode = null;
	private String currentComponent = "";
	
		private final java.util.Map<String, Object> globalMap = new java.util.HashMap<String, Object>();
        private final static java.util.Map<String, Object> junitGlobalMap = new java.util.HashMap<String, Object>();
	
		private final java.util.Map<String, Long> start_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Long> end_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Boolean> ok_Hash = new java.util.HashMap<String, Boolean>();
		public  final java.util.List<String[]> globalBuffer = new java.util.ArrayList<String[]>();
	

private RunStat runStat = new RunStat();

	// OSGi DataSource
	private final static String KEY_DB_DATASOURCES = "KEY_DB_DATASOURCES";
	
	private final static String KEY_DB_DATASOURCES_RAW = "KEY_DB_DATASOURCES_RAW";

	public void setDataSources(java.util.Map<String, javax.sql.DataSource> dataSources) {
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		for (java.util.Map.Entry<String, javax.sql.DataSource> dataSourceEntry : dataSources.entrySet()) {
			talendDataSources.put(dataSourceEntry.getKey(), new routines.system.TalendDataSource(dataSourceEntry.getValue()));
		}
		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}
	
	public void setDataSourceReferences(List serviceReferences) throws Exception{
		
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		java.util.Map<String, javax.sql.DataSource> dataSources = new java.util.HashMap<String, javax.sql.DataSource>();
		
		for (java.util.Map.Entry<String, javax.sql.DataSource> entry : BundleUtils.getServices(serviceReferences,  javax.sql.DataSource.class).entrySet()) {
                    dataSources.put(entry.getKey(), entry.getValue());
                    talendDataSources.put(entry.getKey(), new routines.system.TalendDataSource(entry.getValue()));
		}

		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}

	StatCatcherUtils tStatCatcher_1 = new StatCatcherUtils("_pnAloKN2Ee6lL7SUTfKp3g", "0.1");

private final java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
private final java.io.PrintStream errorMessagePS = new java.io.PrintStream(new java.io.BufferedOutputStream(baos));

public String getExceptionStackTrace() {
	if ("failure".equals(this.getStatus())) {
		errorMessagePS.flush();
		return baos.toString();
	}
	return null;
}

private Exception exception;

public Exception getException() {
	if ("failure".equals(this.getStatus())) {
		return this.exception;
	}
	return null;
}

private class TalendException extends Exception {

	private static final long serialVersionUID = 1L;

	private java.util.Map<String, Object> globalMap = null;
	private Exception e = null;
	private String currentComponent = null;
	private String virtualComponentName = null;
	
	public void setVirtualComponentName (String virtualComponentName){
		this.virtualComponentName = virtualComponentName;
	}

	private TalendException(Exception e, String errorComponent, final java.util.Map<String, Object> globalMap) {
		this.currentComponent= errorComponent;
		this.globalMap = globalMap;
		this.e = e;
	}

	public Exception getException() {
		return this.e;
	}

	public String getCurrentComponent() {
		return this.currentComponent;
	}

	
    public String getExceptionCauseMessage(Exception e){
        Throwable cause = e;
        String message = null;
        int i = 10;
        while (null != cause && 0 < i--) {
            message = cause.getMessage();
            if (null == message) {
                cause = cause.getCause();
            } else {
                break;          
            }
        }
        if (null == message) {
            message = e.getClass().getName();
        }   
        return message;
    }

	@Override
	public void printStackTrace() {
		if (!(e instanceof TalendException || e instanceof TDieException)) {
			if(virtualComponentName!=null && currentComponent.indexOf(virtualComponentName+"_")==0){
				globalMap.put(virtualComponentName+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			}
			globalMap.put(currentComponent+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			System.err.println("Exception in component " + currentComponent + " (" + jobName + ")");
		}
		if (!(e instanceof TDieException)) {
			if(e instanceof TalendException){
				e.printStackTrace();
			} else {
				e.printStackTrace();
				e.printStackTrace(errorMessagePS);
				C_ALIM_SI_OPE_API.this.exception = e;
			}
		}
		if (!(e instanceof TalendException)) {
		try {
			for (java.lang.reflect.Method m : this.getClass().getEnclosingClass().getMethods()) {
				if (m.getName().compareTo(currentComponent + "_error") == 0) {
					m.invoke(C_ALIM_SI_OPE_API.this, new Object[] { e , currentComponent, globalMap});
					break;
				}
			}

			if(!(e instanceof TDieException)){
			}
		} catch (Exception e) {
			this.e.printStackTrace();
		}
		}
	}
}

			public void tStatCatcher_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tStatCatcher_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tStatCatcher_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBRow_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
							tStatCatcher_1.addMessage("failure",errorComponent, end_Hash.get(errorComponent)-start_Hash.get(errorComponent));
							tStatCatcher_1Process(globalMap);
							
				status = "failure";
				
					tDBRow_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBInput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
							tStatCatcher_1.addMessage("failure",errorComponent, end_Hash.get(errorComponent)-start_Hash.get(errorComponent));
							tStatCatcher_1Process(globalMap);
							
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFlowToIterate_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
							tStatCatcher_1.addMessage("failure",errorComponent, end_Hash.get(errorComponent)-start_Hash.get(errorComponent));
							tStatCatcher_1Process(globalMap);
							
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
							tStatCatcher_1.addMessage("failure",errorComponent, end_Hash.get(errorComponent)-start_Hash.get(errorComponent));
							tStatCatcher_1Process(globalMap);
							
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tRESTClient_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
							tStatCatcher_1.addMessage("failure",errorComponent, end_Hash.get(errorComponent)-start_Hash.get(errorComponent));
							tStatCatcher_1Process(globalMap);
							
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tExtractJSONFields_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
							tStatCatcher_1.addMessage("failure",errorComponent, end_Hash.get(errorComponent)-start_Hash.get(errorComponent));
							tStatCatcher_1Process(globalMap);
							
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
							tStatCatcher_1.addMessage("failure",errorComponent, end_Hash.get(errorComponent)-start_Hash.get(errorComponent));
							tStatCatcher_1Process(globalMap);
							
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBRow_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
							tStatCatcher_1.addMessage("failure",errorComponent, end_Hash.get(errorComponent)-start_Hash.get(errorComponent));
							tStatCatcher_1Process(globalMap);
							
				status = "failure";
				
					tDBRow_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBInput_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
							tStatCatcher_1.addMessage("failure",errorComponent, end_Hash.get(errorComponent)-start_Hash.get(errorComponent));
							tStatCatcher_1Process(globalMap);
							
				status = "failure";
				
					tDBInput_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFlowToIterate_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
							tStatCatcher_1.addMessage("failure",errorComponent, end_Hash.get(errorComponent)-start_Hash.get(errorComponent));
							tStatCatcher_1Process(globalMap);
							
				status = "failure";
				
					tDBInput_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
							tStatCatcher_1.addMessage("failure",errorComponent, end_Hash.get(errorComponent)-start_Hash.get(errorComponent));
							tStatCatcher_1Process(globalMap);
							
				status = "failure";
				
					tDBInput_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tRESTClient_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
							tStatCatcher_1.addMessage("failure",errorComponent, end_Hash.get(errorComponent)-start_Hash.get(errorComponent));
							tStatCatcher_1Process(globalMap);
							
				status = "failure";
				
					tDBInput_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tExtractJSONFields_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
							tStatCatcher_1.addMessage("failure",errorComponent, end_Hash.get(errorComponent)-start_Hash.get(errorComponent));
							tStatCatcher_1Process(globalMap);
							
				status = "failure";
				
					tDBInput_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
							tStatCatcher_1.addMessage("failure",errorComponent, end_Hash.get(errorComponent)-start_Hash.get(errorComponent));
							tStatCatcher_1Process(globalMap);
							
				status = "failure";
				
					tDBInput_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tStatCatcher_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBRow_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBInput_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBRow_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBInput_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
	






public static class row5Struct implements routines.system.IPersistableRow<row5Struct> {
    final static byte[] commonByteArrayLock_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API = new byte[0];
    static byte[] commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API = new byte[0];

	
			    public java.util.Date moment;

				public java.util.Date getMoment () {
					return this.moment;
				}
				
			    public String pid;

				public String getPid () {
					return this.pid;
				}
				
			    public String father_pid;

				public String getFather_pid () {
					return this.father_pid;
				}
				
			    public String root_pid;

				public String getRoot_pid () {
					return this.root_pid;
				}
				
			    public Long system_pid;

				public Long getSystem_pid () {
					return this.system_pid;
				}
				
			    public String project;

				public String getProject () {
					return this.project;
				}
				
			    public String job;

				public String getJob () {
					return this.job;
				}
				
			    public String job_repository_id;

				public String getJob_repository_id () {
					return this.job_repository_id;
				}
				
			    public String job_version;

				public String getJob_version () {
					return this.job_version;
				}
				
			    public String context;

				public String getContext () {
					return this.context;
				}
				
			    public String origin;

				public String getOrigin () {
					return this.origin;
				}
				
			    public String message_type;

				public String getMessage_type () {
					return this.message_type;
				}
				
			    public String message;

				public String getMessage () {
					return this.message;
				}
				
			    public Long duration;

				public Long getDuration () {
					return this.duration;
				}
				



	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API.length == 0) {
   					commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API.length == 0) {
   					commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API) {

        	try {

        		int length = 0;
		
					this.moment = readDate(dis);
					
					this.pid = readString(dis);
					
					this.father_pid = readString(dis);
					
					this.root_pid = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.system_pid = null;
           				} else {
           			    	this.system_pid = dis.readLong();
           				}
					
					this.project = readString(dis);
					
					this.job = readString(dis);
					
					this.job_repository_id = readString(dis);
					
					this.job_version = readString(dis);
					
					this.context = readString(dis);
					
					this.origin = readString(dis);
					
					this.message_type = readString(dis);
					
					this.message = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.duration = null;
           				} else {
           			    	this.duration = dis.readLong();
           				}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API) {

        	try {

        		int length = 0;
		
					this.moment = readDate(dis);
					
					this.pid = readString(dis);
					
					this.father_pid = readString(dis);
					
					this.root_pid = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.system_pid = null;
           				} else {
           			    	this.system_pid = dis.readLong();
           				}
					
					this.project = readString(dis);
					
					this.job = readString(dis);
					
					this.job_repository_id = readString(dis);
					
					this.job_version = readString(dis);
					
					this.context = readString(dis);
					
					this.origin = readString(dis);
					
					this.message_type = readString(dis);
					
					this.message = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.duration = null;
           				} else {
           			    	this.duration = dis.readLong();
           				}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// java.util.Date
				
						writeDate(this.moment,dos);
					
					// String
				
						writeString(this.pid,dos);
					
					// String
				
						writeString(this.father_pid,dos);
					
					// String
				
						writeString(this.root_pid,dos);
					
					// Long
				
						if(this.system_pid == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.system_pid);
		            	}
					
					// String
				
						writeString(this.project,dos);
					
					// String
				
						writeString(this.job,dos);
					
					// String
				
						writeString(this.job_repository_id,dos);
					
					// String
				
						writeString(this.job_version,dos);
					
					// String
				
						writeString(this.context,dos);
					
					// String
				
						writeString(this.origin,dos);
					
					// String
				
						writeString(this.message_type,dos);
					
					// String
				
						writeString(this.message,dos);
					
					// Long
				
						if(this.duration == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.duration);
		            	}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// java.util.Date
				
						writeDate(this.moment,dos);
					
					// String
				
						writeString(this.pid,dos);
					
					// String
				
						writeString(this.father_pid,dos);
					
					// String
				
						writeString(this.root_pid,dos);
					
					// Long
				
						if(this.system_pid == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.system_pid);
		            	}
					
					// String
				
						writeString(this.project,dos);
					
					// String
				
						writeString(this.job,dos);
					
					// String
				
						writeString(this.job_repository_id,dos);
					
					// String
				
						writeString(this.job_version,dos);
					
					// String
				
						writeString(this.context,dos);
					
					// String
				
						writeString(this.origin,dos);
					
					// String
				
						writeString(this.message_type,dos);
					
					// String
				
						writeString(this.message,dos);
					
					// Long
				
						if(this.duration == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.duration);
		            	}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("moment="+String.valueOf(moment));
		sb.append(",pid="+pid);
		sb.append(",father_pid="+father_pid);
		sb.append(",root_pid="+root_pid);
		sb.append(",system_pid="+String.valueOf(system_pid));
		sb.append(",project="+project);
		sb.append(",job="+job);
		sb.append(",job_repository_id="+job_repository_id);
		sb.append(",job_version="+job_version);
		sb.append(",context="+context);
		sb.append(",origin="+origin);
		sb.append(",message_type="+message_type);
		sb.append(",message="+message);
		sb.append(",duration="+String.valueOf(duration));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row5Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tStatCatcher_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tStatCatcher_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row5Struct row5 = new row5Struct();




	
	/**
	 * [tDBOutput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_1", false);
		start_Hash.put("tDBOutput_1", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_1";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row5");
					}
				
		int tos_count_tDBOutput_1 = 0;
		





String dbschema_tDBOutput_1 = null;
	dbschema_tDBOutput_1 = "dsid_liv_met";
	

String tableName_tDBOutput_1 = null;
if(dbschema_tDBOutput_1 == null || dbschema_tDBOutput_1.trim().length() == 0) {
	tableName_tDBOutput_1 = ("JOB_STATS");
} else {
	tableName_tDBOutput_1 = dbschema_tDBOutput_1 + "\".\"" + ("JOB_STATS");
}


int nb_line_tDBOutput_1 = 0;
int nb_line_update_tDBOutput_1 = 0;
int nb_line_inserted_tDBOutput_1 = 0;
int nb_line_deleted_tDBOutput_1 = 0;
int nb_line_rejected_tDBOutput_1 = 0;

int deletedCount_tDBOutput_1=0;
int updatedCount_tDBOutput_1=0;
int insertedCount_tDBOutput_1=0;
int rowsToCommitCount_tDBOutput_1=0;
int rejectedCount_tDBOutput_1=0;

boolean whetherReject_tDBOutput_1 = false;

java.sql.Connection conn_tDBOutput_1 = null;
String dbUser_tDBOutput_1 = null;

	
    java.lang.Class.forName("org.postgresql.Driver");
    
        String url_tDBOutput_1 = "jdbc:postgresql://"+""+":"+"5432"+"/"+"postgres";
    dbUser_tDBOutput_1 = "dsid_cc2_tos_rw";
 
	final String decryptedPassword_tDBOutput_1 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:NKxYZfJPbX9/HZE7ICMshwwzdEpFNIeDBGYRJmxq5LA=");

    String dbPwd_tDBOutput_1 = decryptedPassword_tDBOutput_1;

    conn_tDBOutput_1 = java.sql.DriverManager.getConnection(url_tDBOutput_1,dbUser_tDBOutput_1,dbPwd_tDBOutput_1);
	
	resourceMap.put("conn_tDBOutput_1", conn_tDBOutput_1);
        conn_tDBOutput_1.setAutoCommit(false);
        int commitEvery_tDBOutput_1 = 10000;
        int commitCounter_tDBOutput_1 = 0;


   int batchSize_tDBOutput_1 = 10000;
   int batchSizeCounter_tDBOutput_1=0;

int count_tDBOutput_1=0;
                                java.sql.DatabaseMetaData dbMetaData_tDBOutput_1 = conn_tDBOutput_1.getMetaData();
                                boolean whetherExist_tDBOutput_1 = false;
                                try (java.sql.ResultSet rsTable_tDBOutput_1 = dbMetaData_tDBOutput_1.getTables(null, null, null, new String[]{"TABLE"})) {
                                    String defaultSchema_tDBOutput_1 = "public";
                                    if(dbschema_tDBOutput_1 == null || dbschema_tDBOutput_1.trim().length() == 0) {
                                        try(java.sql.Statement stmtSchema_tDBOutput_1 = conn_tDBOutput_1.createStatement();
                                            java.sql.ResultSet rsSchema_tDBOutput_1 = stmtSchema_tDBOutput_1.executeQuery("select current_schema() ")) {
                                            while(rsSchema_tDBOutput_1.next()){
                                                defaultSchema_tDBOutput_1 = rsSchema_tDBOutput_1.getString("current_schema");
                                            }
                                        }
                                    }
                                    while(rsTable_tDBOutput_1.next()) {
                                        String table_tDBOutput_1 = rsTable_tDBOutput_1.getString("TABLE_NAME");
                                        String schema_tDBOutput_1 = rsTable_tDBOutput_1.getString("TABLE_SCHEM");
                                        if(table_tDBOutput_1.equals(("JOB_STATS"))
                                            && (schema_tDBOutput_1.equals(dbschema_tDBOutput_1) || ((dbschema_tDBOutput_1 ==null || dbschema_tDBOutput_1.trim().length() ==0) && defaultSchema_tDBOutput_1.equals(schema_tDBOutput_1)))) {
                                            whetherExist_tDBOutput_1 = true;
                                            break;
                                        }
                                    }
                                }
                                if(!whetherExist_tDBOutput_1) {
                                    try (java.sql.Statement stmtCreate_tDBOutput_1 = conn_tDBOutput_1.createStatement()) {
                                        stmtCreate_tDBOutput_1.execute("CREATE TABLE \"" + tableName_tDBOutput_1 + "\"(\"moment\" TIMESTAMP(0)  ,\"pid\" VARCHAR(20)  ,\"father_pid\" VARCHAR(20)  ,\"root_pid\" VARCHAR(20)  ,\"system_pid\" INT8 ,\"project\" VARCHAR(50)  ,\"job\" VARCHAR(255)  ,\"job_repository_id\" VARCHAR(255)  ,\"job_version\" VARCHAR(255)  ,\"context\" VARCHAR(50)  ,\"origin\" VARCHAR(255)  ,\"message_type\" VARCHAR(255)  ,\"message\" VARCHAR(255)  ,\"duration\" INT8 )");
                                    }
                                }
	    String insert_tDBOutput_1 = "INSERT INTO \"" + tableName_tDBOutput_1 + "\" (\"moment\",\"pid\",\"father_pid\",\"root_pid\",\"system_pid\",\"project\",\"job\",\"job_repository_id\",\"job_version\",\"context\",\"origin\",\"message_type\",\"message\",\"duration\") VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
	    
	    java.sql.PreparedStatement pstmt_tDBOutput_1 = conn_tDBOutput_1.prepareStatement(insert_tDBOutput_1);
	    resourceMap.put("pstmt_tDBOutput_1", pstmt_tDBOutput_1);
	    

 



/**
 * [tDBOutput_1 begin ] stop
 */



	
	/**
	 * [tStatCatcher_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tStatCatcher_1", false);
		start_Hash.put("tStatCatcher_1", System.currentTimeMillis());
		
	
	currentComponent="tStatCatcher_1";

	
		int tos_count_tStatCatcher_1 = 0;
		

	for (StatCatcherUtils.StatCatcherMessage scm : tStatCatcher_1.getMessages()) {
		row5.pid = pid;
		row5.root_pid = rootPid;
		row5.father_pid = fatherPid;	
    	row5.project = projectName;
    	row5.job = jobName;
    	row5.context = contextStr;
		row5.origin = (scm.getOrigin()==null || scm.getOrigin().length()<1 ? null : scm.getOrigin());
		row5.message = scm.getMessage();
		row5.duration = scm.getDuration();
		row5.moment = scm.getMoment();
		row5.message_type = scm.getMessageType();
		row5.job_version = scm.getJobVersion();
		row5.job_repository_id = scm.getJobId();
		row5.system_pid = scm.getSystemPid();

 



/**
 * [tStatCatcher_1 begin ] stop
 */
	
	/**
	 * [tStatCatcher_1 main ] start
	 */

	

	
	
	currentComponent="tStatCatcher_1";

	

 


	tos_count_tStatCatcher_1++;

/**
 * [tStatCatcher_1 main ] stop
 */
	
	/**
	 * [tStatCatcher_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tStatCatcher_1";

	

 



/**
 * [tStatCatcher_1 process_data_begin ] stop
 */

	
	/**
	 * [tDBOutput_1 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row5"
						
						);
					}
					



        whetherReject_tDBOutput_1 = false;
                    if(row5.moment != null) {
pstmt_tDBOutput_1.setTimestamp(1, new java.sql.Timestamp(row5.moment.getTime()));
} else {
pstmt_tDBOutput_1.setNull(1, java.sql.Types.TIMESTAMP);
}

                    if(row5.pid == null) {
pstmt_tDBOutput_1.setNull(2, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(2, row5.pid);
}

                    if(row5.father_pid == null) {
pstmt_tDBOutput_1.setNull(3, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(3, row5.father_pid);
}

                    if(row5.root_pid == null) {
pstmt_tDBOutput_1.setNull(4, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(4, row5.root_pid);
}

                    if(row5.system_pid == null) {
pstmt_tDBOutput_1.setNull(5, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_1.setLong(5, row5.system_pid);
}

                    if(row5.project == null) {
pstmt_tDBOutput_1.setNull(6, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(6, row5.project);
}

                    if(row5.job == null) {
pstmt_tDBOutput_1.setNull(7, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(7, row5.job);
}

                    if(row5.job_repository_id == null) {
pstmt_tDBOutput_1.setNull(8, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(8, row5.job_repository_id);
}

                    if(row5.job_version == null) {
pstmt_tDBOutput_1.setNull(9, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(9, row5.job_version);
}

                    if(row5.context == null) {
pstmt_tDBOutput_1.setNull(10, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(10, row5.context);
}

                    if(row5.origin == null) {
pstmt_tDBOutput_1.setNull(11, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(11, row5.origin);
}

                    if(row5.message_type == null) {
pstmt_tDBOutput_1.setNull(12, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(12, row5.message_type);
}

                    if(row5.message == null) {
pstmt_tDBOutput_1.setNull(13, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(13, row5.message);
}

                    if(row5.duration == null) {
pstmt_tDBOutput_1.setNull(14, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_1.setLong(14, row5.duration);
}

			
    		pstmt_tDBOutput_1.addBatch();
    		nb_line_tDBOutput_1++;
    		  
    		  
    		  batchSizeCounter_tDBOutput_1++;
    		  
    			if ((batchSize_tDBOutput_1 > 0) && (batchSize_tDBOutput_1 <= batchSizeCounter_tDBOutput_1)) {
                try {
						int countSum_tDBOutput_1 = 0;
						    
						for(int countEach_tDBOutput_1: pstmt_tDBOutput_1.executeBatch()) {
							countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
						}
				    	rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
				    	
				    		insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
				    	
            	    	batchSizeCounter_tDBOutput_1 = 0;
                }catch (java.sql.BatchUpdateException e_tDBOutput_1){
globalMap.put("tDBOutput_1_ERROR_MESSAGE",e_tDBOutput_1.getMessage());
				    	java.sql.SQLException ne_tDBOutput_1 = e_tDBOutput_1.getNextException(),sqle_tDBOutput_1=null;
				    	String errormessage_tDBOutput_1;
						if (ne_tDBOutput_1 != null) {
							// build new exception to provide the original cause
							sqle_tDBOutput_1 = new java.sql.SQLException(e_tDBOutput_1.getMessage() + "\ncaused by: " + ne_tDBOutput_1.getMessage(), ne_tDBOutput_1.getSQLState(), ne_tDBOutput_1.getErrorCode(), ne_tDBOutput_1);
							errormessage_tDBOutput_1 = sqle_tDBOutput_1.getMessage();
						}else{
							errormessage_tDBOutput_1 = e_tDBOutput_1.getMessage();
						}
				    	
				    	int countSum_tDBOutput_1 = 0;
						for(int countEach_tDBOutput_1: e_tDBOutput_1.getUpdateCounts()) {
							countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
						}
						rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
						
				    		insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
				    	
				    	System.err.println(errormessage_tDBOutput_1);
				    	
					}
    			}
    		
    		    commitCounter_tDBOutput_1++;
                if(commitEvery_tDBOutput_1 <= commitCounter_tDBOutput_1) {
                if ((batchSize_tDBOutput_1 > 0) && (batchSizeCounter_tDBOutput_1 > 0)) {
                try {
                		int countSum_tDBOutput_1 = 0;
                		    
						for(int countEach_tDBOutput_1: pstmt_tDBOutput_1.executeBatch()) {
							countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
						}
            	    	rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
            	    	
            	    		insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
            	    	
                batchSizeCounter_tDBOutput_1 = 0;
               }catch (java.sql.BatchUpdateException e_tDBOutput_1){
globalMap.put("tDBOutput_1_ERROR_MESSAGE",e_tDBOutput_1.getMessage());
			    	java.sql.SQLException ne_tDBOutput_1 = e_tDBOutput_1.getNextException(),sqle_tDBOutput_1=null;
			    	String errormessage_tDBOutput_1;
					if (ne_tDBOutput_1 != null) {
						// build new exception to provide the original cause
						sqle_tDBOutput_1 = new java.sql.SQLException(e_tDBOutput_1.getMessage() + "\ncaused by: " + ne_tDBOutput_1.getMessage(), ne_tDBOutput_1.getSQLState(), ne_tDBOutput_1.getErrorCode(), ne_tDBOutput_1);
						errormessage_tDBOutput_1 = sqle_tDBOutput_1.getMessage();
					}else{
						errormessage_tDBOutput_1 = e_tDBOutput_1.getMessage();
					}
			    	
			    	int countSum_tDBOutput_1 = 0;
					for(int countEach_tDBOutput_1: e_tDBOutput_1.getUpdateCounts()) {
						countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
					}
					rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
					
			    		insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
			    	
			    	System.err.println(errormessage_tDBOutput_1);
			    	
				}
            }
                    if(rowsToCommitCount_tDBOutput_1 != 0){
                    	
                    }
                    conn_tDBOutput_1.commit();
                    if(rowsToCommitCount_tDBOutput_1 != 0){
                    	
                    	rowsToCommitCount_tDBOutput_1 = 0;
                    }
                    commitCounter_tDBOutput_1=0;
                }

 


	tos_count_tDBOutput_1++;

/**
 * [tDBOutput_1 main ] stop
 */
	
	/**
	 * [tDBOutput_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";

	

 



/**
 * [tDBOutput_1 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";

	

 



/**
 * [tDBOutput_1 process_data_end ] stop
 */



	
	/**
	 * [tStatCatcher_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tStatCatcher_1";

	

 



/**
 * [tStatCatcher_1 process_data_end ] stop
 */
	
	/**
	 * [tStatCatcher_1 end ] start
	 */

	

	
	
	currentComponent="tStatCatcher_1";

	

	}


 

ok_Hash.put("tStatCatcher_1", true);
end_Hash.put("tStatCatcher_1", System.currentTimeMillis());




/**
 * [tStatCatcher_1 end ] stop
 */

	
	/**
	 * [tDBOutput_1 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";

	



	    try {
				int countSum_tDBOutput_1 = 0;
				if (pstmt_tDBOutput_1 != null && batchSizeCounter_tDBOutput_1 > 0) {
						
					for(int countEach_tDBOutput_1: pstmt_tDBOutput_1.executeBatch()) {
						countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
					}
					rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
						
				}
		    	
		    		insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
		    	
	    }catch (java.sql.BatchUpdateException e_tDBOutput_1){
globalMap.put("tDBOutput_1_ERROR_MESSAGE",e_tDBOutput_1.getMessage());
	    	java.sql.SQLException ne_tDBOutput_1 = e_tDBOutput_1.getNextException(),sqle_tDBOutput_1=null;
	    	String errormessage_tDBOutput_1;
			if (ne_tDBOutput_1 != null) {
				// build new exception to provide the original cause
				sqle_tDBOutput_1 = new java.sql.SQLException(e_tDBOutput_1.getMessage() + "\ncaused by: " + ne_tDBOutput_1.getMessage(), ne_tDBOutput_1.getSQLState(), ne_tDBOutput_1.getErrorCode(), ne_tDBOutput_1);
				errormessage_tDBOutput_1 = sqle_tDBOutput_1.getMessage();
			}else{
				errormessage_tDBOutput_1 = e_tDBOutput_1.getMessage();
			}
	    	
	    	int countSum_tDBOutput_1 = 0;
			for(int countEach_tDBOutput_1: e_tDBOutput_1.getUpdateCounts()) {
				countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
			}
			rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
			
	    		insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
	    	
	    	System.err.println(errormessage_tDBOutput_1);
	    	
		}
	    
        if(pstmt_tDBOutput_1 != null) {
        		
            pstmt_tDBOutput_1.close();
            resourceMap.remove("pstmt_tDBOutput_1");
        }
    resourceMap.put("statementClosed_tDBOutput_1", true);
			if(rowsToCommitCount_tDBOutput_1 != 0){
				
			}
			conn_tDBOutput_1.commit();
			if(rowsToCommitCount_tDBOutput_1 != 0){
				
				rowsToCommitCount_tDBOutput_1 = 0;
			}
			commitCounter_tDBOutput_1 = 0;
		
    	conn_tDBOutput_1 .close();
    	
    	resourceMap.put("finish_tDBOutput_1", true);
    	

	nb_line_deleted_tDBOutput_1=nb_line_deleted_tDBOutput_1+ deletedCount_tDBOutput_1;
	nb_line_update_tDBOutput_1=nb_line_update_tDBOutput_1 + updatedCount_tDBOutput_1;
	nb_line_inserted_tDBOutput_1=nb_line_inserted_tDBOutput_1 + insertedCount_tDBOutput_1;
	nb_line_rejected_tDBOutput_1=nb_line_rejected_tDBOutput_1 + rejectedCount_tDBOutput_1;
	
        globalMap.put("tDBOutput_1_NB_LINE",nb_line_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_UPDATED",nb_line_update_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_DELETED",nb_line_deleted_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_1);
    

	


				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row5");
			  	}
			  	
 

ok_Hash.put("tDBOutput_1", true);
end_Hash.put("tDBOutput_1", System.currentTimeMillis());




/**
 * [tDBOutput_1 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tStatCatcher_1 finally ] start
	 */

	

	
	
	currentComponent="tStatCatcher_1";

	

 



/**
 * [tStatCatcher_1 finally ] stop
 */

	
	/**
	 * [tDBOutput_1 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";

	



    try {
    if (resourceMap.get("statementClosed_tDBOutput_1") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_1 = null;
                if ((pstmtToClose_tDBOutput_1 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_1")) != null) {
                    pstmtToClose_tDBOutput_1.close();
                }
    }
    } finally {
        if(resourceMap.get("finish_tDBOutput_1") == null){
            java.sql.Connection ctn_tDBOutput_1 = null;
            if((ctn_tDBOutput_1 = (java.sql.Connection)resourceMap.get("conn_tDBOutput_1")) != null){
                try {
                    ctn_tDBOutput_1.close();
                } catch (java.sql.SQLException sqlEx_tDBOutput_1) {
                    String errorMessage_tDBOutput_1 = "failed to close the connection in tDBOutput_1 :" + sqlEx_tDBOutput_1.getMessage();
                    System.err.println(errorMessage_tDBOutput_1);
                }
            }
        }
    }
 



/**
 * [tDBOutput_1 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tStatCatcher_1_SUBPROCESS_STATE", 1);
	}
	

public void tDBRow_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBRow_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tDBRow_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBRow_1", false);
		start_Hash.put("tDBRow_1", System.currentTimeMillis());
		
				tStatCatcher_1.addMessage("begin","tDBRow_1");
				tStatCatcher_1Process(globalMap);
			
	
	currentComponent="tDBRow_1";

	
		int tos_count_tDBRow_1 = 0;
		

	java.sql.Connection conn_tDBRow_1 = null;
	String query_tDBRow_1 = "";
	boolean whetherReject_tDBRow_1 = false;
			String driverClass_tDBRow_1 = "oracle.jdbc.OracleDriver";
		    java.lang.Class jdbcclazz_tDBRow_1 = java.lang.Class.forName(driverClass_tDBRow_1);
		
			String url_tDBRow_1 = null;
				url_tDBRow_1 = "jdbc:oracle:thin:@(description=(address=(protocol=tcp)(host=" + "" + ")(port=" + "1521" + "))(connect_data=(service_name=" + "XEPDB1" + ")))";
					String dbUser_tDBRow_1 = "DSID_LIV_OPE";
	        
            		
            		
            		 
	final String decryptedPassword_tDBRow_1 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:lbZoEh+nh0JALkG3IBP0KuMwcI9EYSUWop1b9s9Pq4k=");
        		   	
        	        String dbPwd_tDBRow_1 = decryptedPassword_tDBRow_1;
	        
					
			conn_tDBRow_1 = java.sql.DriverManager.getConnection(url_tDBRow_1,dbUser_tDBRow_1,dbPwd_tDBRow_1);
		
        resourceMap.put("conn_tDBRow_1", conn_tDBRow_1);
					if(conn_tDBRow_1.getAutoCommit()) {
						
				conn_tDBRow_1.setAutoCommit(false);
			
					}        
					int commitEvery_tDBRow_1 = 10000;
					int commitCounter_tDBRow_1 = 0;
				
        java.sql.Statement stmt_tDBRow_1 = conn_tDBRow_1.createStatement();
        resourceMap.put("stmt_tDBRow_1", stmt_tDBRow_1);

 



/**
 * [tDBRow_1 begin ] stop
 */
	
	/**
	 * [tDBRow_1 main ] start
	 */

	

	
	
	currentComponent="tDBRow_1";

	

query_tDBRow_1 = "TRUNCATE TABLE  DSID_LIV_OPE.ADRESSE_NORMALISEE_CLIENT";
whetherReject_tDBRow_1 = false;
globalMap.put("tDBRow_1_QUERY",query_tDBRow_1);
try {
		stmt_tDBRow_1.execute(query_tDBRow_1);
		
	} catch (java.lang.Exception e) {
globalMap.put("tDBRow_1_ERROR_MESSAGE",e.getMessage());
		whetherReject_tDBRow_1 = true;
		
				System.err.print(e.getMessage());
				
	}
	
	if(!whetherReject_tDBRow_1) {
		
	}
	
		commitCounter_tDBRow_1++;
		if(commitEvery_tDBRow_1 <= commitCounter_tDBRow_1) {
			
			conn_tDBRow_1.commit();
			
			commitCounter_tDBRow_1=0;
		}
		

 


	tos_count_tDBRow_1++;

/**
 * [tDBRow_1 main ] stop
 */
	
	/**
	 * [tDBRow_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBRow_1";

	

 



/**
 * [tDBRow_1 process_data_begin ] stop
 */
	
	/**
	 * [tDBRow_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBRow_1";

	

 



/**
 * [tDBRow_1 process_data_end ] stop
 */
	
	/**
	 * [tDBRow_1 end ] start
	 */

	

	
	
	currentComponent="tDBRow_1";

	

	
        stmt_tDBRow_1.close();
        resourceMap.remove("stmt_tDBRow_1");
    resourceMap.put("statementClosed_tDBRow_1", true);
		if(commitEvery_tDBRow_1>commitCounter_tDBRow_1){

			
			conn_tDBRow_1.commit();
			
	
			commitCounter_tDBRow_1=0;
	
		}
			conn_tDBRow_1.close();
			
			if("com.mysql.cj.jdbc.Driver".equals((String)globalMap.get("driverClass_"))
			    && routines.system.BundleUtils.inOSGi()) {
			        Class.forName("com.mysql.cj.jdbc.AbandonedConnectionCleanupThread").
			            getMethod("checkedShutdown").invoke(null, (Object[]) null);
			}
			
    resourceMap.put("finish_tDBRow_1", true);

 

ok_Hash.put("tDBRow_1", true);
end_Hash.put("tDBRow_1", System.currentTimeMillis());

tStatCatcher_1.addMessage("end","tDBRow_1", end_Hash.get("tDBRow_1")-start_Hash.get("tDBRow_1"));
tStatCatcher_1Process(globalMap);
				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk3", 0, "ok");
				}
				tDBInput_1Process(globalMap);



/**
 * [tDBRow_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBRow_1 finally ] start
	 */

	

	
	
	currentComponent="tDBRow_1";

	

try {
    if (resourceMap.get("statementClosed_tDBRow_1") == null) {
            java.sql.Statement stmtToClose_tDBRow_1 = null;
            if ((stmtToClose_tDBRow_1 = (java.sql.Statement) resourceMap.remove("stmt_tDBRow_1")) != null) {
                stmtToClose_tDBRow_1.close();
            }
    }
} finally {
        if(resourceMap.get("finish_tDBRow_1") == null){
            java.sql.Connection ctn_tDBRow_1 = null;
            if((ctn_tDBRow_1 = (java.sql.Connection)resourceMap.get("conn_tDBRow_1")) != null){
                try {
                    ctn_tDBRow_1.close();
                } catch (java.sql.SQLException sqlEx_tDBRow_1) {
                    String errorMessage_tDBRow_1 = "failed to close the connection in tDBRow_1 :" + sqlEx_tDBRow_1.getMessage();
                    System.err.println(errorMessage_tDBRow_1);
                }
            }
        }
    }
 



/**
 * [tDBRow_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBRow_1_SUBPROCESS_STATE", 1);
	}
	


public static class row8Struct implements routines.system.IPersistableRow<row8Struct> {
    final static byte[] commonByteArrayLock_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API = new byte[0];
    static byte[] commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public BigDecimal ID_ADRESSE_NORM_CLIENT;

				public BigDecimal getID_ADRESSE_NORM_CLIENT () {
					return this.ID_ADRESSE_NORM_CLIENT;
				}
				
			    public BigDecimal ID_ADRESSE_CLIENT;

				public BigDecimal getID_ADRESSE_CLIENT () {
					return this.ID_ADRESSE_CLIENT;
				}
				
			    public String NUMERO_VOIE;

				public String getNUMERO_VOIE () {
					return this.NUMERO_VOIE;
				}
				
			    public String NOM_VOIE;

				public String getNOM_VOIE () {
					return this.NOM_VOIE;
				}
				
			    public String CODE_POSTAL;

				public String getCODE_POSTAL () {
					return this.CODE_POSTAL;
				}
				
			    public String NOM_VILLE;

				public String getNOM_VILLE () {
					return this.NOM_VILLE;
				}
				
			    public String LONGITUDE;

				public String getLONGITUDE () {
					return this.LONGITUDE;
				}
				
			    public String LATITUDE;

				public String getLATITUDE () {
					return this.LATITUDE;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
						result = prime * result + ((this.ID_ADRESSE_NORM_CLIENT == null) ? 0 : this.ID_ADRESSE_NORM_CLIENT.hashCode());
					
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row8Struct other = (row8Struct) obj;
		
						if (this.ID_ADRESSE_NORM_CLIENT == null) {
							if (other.ID_ADRESSE_NORM_CLIENT != null)
								return false;
						
						} else if (!this.ID_ADRESSE_NORM_CLIENT.equals(other.ID_ADRESSE_NORM_CLIENT))
						
							return false;
					

		return true;
    }

	public void copyDataTo(row8Struct other) {

		other.ID_ADRESSE_NORM_CLIENT = this.ID_ADRESSE_NORM_CLIENT;
	            other.ID_ADRESSE_CLIENT = this.ID_ADRESSE_CLIENT;
	            other.NUMERO_VOIE = this.NUMERO_VOIE;
	            other.NOM_VOIE = this.NOM_VOIE;
	            other.CODE_POSTAL = this.CODE_POSTAL;
	            other.NOM_VILLE = this.NOM_VILLE;
	            other.LONGITUDE = this.LONGITUDE;
	            other.LATITUDE = this.LATITUDE;
	            
	}

	public void copyKeysDataTo(row8Struct other) {

		other.ID_ADRESSE_NORM_CLIENT = this.ID_ADRESSE_NORM_CLIENT;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API.length == 0) {
   					commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API.length == 0) {
   					commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API) {

        	try {

        		int length = 0;
		
						this.ID_ADRESSE_NORM_CLIENT = (BigDecimal) dis.readObject();
					
						this.ID_ADRESSE_CLIENT = (BigDecimal) dis.readObject();
					
					this.NUMERO_VOIE = readString(dis);
					
					this.NOM_VOIE = readString(dis);
					
					this.CODE_POSTAL = readString(dis);
					
					this.NOM_VILLE = readString(dis);
					
					this.LONGITUDE = readString(dis);
					
					this.LATITUDE = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API) {

        	try {

        		int length = 0;
		
						this.ID_ADRESSE_NORM_CLIENT = (BigDecimal) dis.readObject();
					
						this.ID_ADRESSE_CLIENT = (BigDecimal) dis.readObject();
					
					this.NUMERO_VOIE = readString(dis);
					
					this.NOM_VOIE = readString(dis);
					
					this.CODE_POSTAL = readString(dis);
					
					this.NOM_VILLE = readString(dis);
					
					this.LONGITUDE = readString(dis);
					
					this.LATITUDE = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// BigDecimal
				
       			    	dos.writeObject(this.ID_ADRESSE_NORM_CLIENT);
					
					// BigDecimal
				
       			    	dos.writeObject(this.ID_ADRESSE_CLIENT);
					
					// String
				
						writeString(this.NUMERO_VOIE,dos);
					
					// String
				
						writeString(this.NOM_VOIE,dos);
					
					// String
				
						writeString(this.CODE_POSTAL,dos);
					
					// String
				
						writeString(this.NOM_VILLE,dos);
					
					// String
				
						writeString(this.LONGITUDE,dos);
					
					// String
				
						writeString(this.LATITUDE,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// BigDecimal
				
       			    	dos.writeObject(this.ID_ADRESSE_NORM_CLIENT);
					
					// BigDecimal
				
       			    	dos.writeObject(this.ID_ADRESSE_CLIENT);
					
					// String
				
						writeString(this.NUMERO_VOIE,dos);
					
					// String
				
						writeString(this.NOM_VOIE,dos);
					
					// String
				
						writeString(this.CODE_POSTAL,dos);
					
					// String
				
						writeString(this.NOM_VILLE,dos);
					
					// String
				
						writeString(this.LONGITUDE,dos);
					
					// String
				
						writeString(this.LATITUDE,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("ID_ADRESSE_NORM_CLIENT="+String.valueOf(ID_ADRESSE_NORM_CLIENT));
		sb.append(",ID_ADRESSE_CLIENT="+String.valueOf(ID_ADRESSE_CLIENT));
		sb.append(",NUMERO_VOIE="+NUMERO_VOIE);
		sb.append(",NOM_VOIE="+NOM_VOIE);
		sb.append(",CODE_POSTAL="+CODE_POSTAL);
		sb.append(",NOM_VILLE="+NOM_VILLE);
		sb.append(",LONGITUDE="+LONGITUDE);
		sb.append(",LATITUDE="+LATITUDE);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row8Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.ID_ADRESSE_NORM_CLIENT, other.ID_ADRESSE_NORM_CLIENT);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row4Struct implements routines.system.IPersistableRow<row4Struct> {
    final static byte[] commonByteArrayLock_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API = new byte[0];
    static byte[] commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API = new byte[0];

	
			    public Integer statusCode;

				public Integer getStatusCode () {
					return this.statusCode;
				}
				
			    public routines.system.Document body;

				public routines.system.Document getBody () {
					return this.body;
				}
				
			    public String string;

				public String getString () {
					return this.string;
				}
				


	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API.length == 0) {
   					commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API.length == 0) {
   					commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API) {

        	try {

        		int length = 0;
		
						this.statusCode = readInteger(dis);
					
						this.body = (routines.system.Document) dis.readObject();
					
					this.string = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API) {

        	try {

        		int length = 0;
		
						this.statusCode = readInteger(dis);
					
						this.body = (routines.system.Document) dis.readObject();
					
					this.string = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Integer
				
						writeInteger(this.statusCode,dos);
					
					// Document
				
       			    	dos.writeObject(this.body);
					
					// String
				
						writeString(this.string,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// Integer
				
						writeInteger(this.statusCode,dos);
					
					// Document
				
       			    	dos.writeObject(this.body);
					
					// String
				
						writeString(this.string,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("statusCode="+String.valueOf(statusCode));
		sb.append(",body="+String.valueOf(body));
		sb.append(",string="+string);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row4Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row2Struct implements routines.system.IPersistableRow<row2Struct> {
    final static byte[] commonByteArrayLock_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API = new byte[0];
    static byte[] commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API = new byte[0];

	
			    public routines.system.Document body;

				public routines.system.Document getBody () {
					return this.body;
				}
				
			    public String string;

				public String getString () {
					return this.string;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API.length == 0) {
   					commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API.length == 0) {
   					commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API) {

        	try {

        		int length = 0;
		
						this.body = (routines.system.Document) dis.readObject();
					
					this.string = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API) {

        	try {

        		int length = 0;
		
						this.body = (routines.system.Document) dis.readObject();
					
					this.string = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Document
				
       			    	dos.writeObject(this.body);
					
					// String
				
						writeString(this.string,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// Document
				
       			    	dos.writeObject(this.body);
					
					// String
				
						writeString(this.string,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("body="+String.valueOf(body));
		sb.append(",string="+string);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row2Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row1Struct implements routines.system.IPersistableRow<row1Struct> {
    final static byte[] commonByteArrayLock_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API = new byte[0];
    static byte[] commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public BigDecimal ID_ADRESSE_CLIENT;

				public BigDecimal getID_ADRESSE_CLIENT () {
					return this.ID_ADRESSE_CLIENT;
				}
				
			    public String ADRESSE_CLIENT;

				public String getADRESSE_CLIENT () {
					return this.ADRESSE_CLIENT;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
						result = prime * result + ((this.ID_ADRESSE_CLIENT == null) ? 0 : this.ID_ADRESSE_CLIENT.hashCode());
					
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row1Struct other = (row1Struct) obj;
		
						if (this.ID_ADRESSE_CLIENT == null) {
							if (other.ID_ADRESSE_CLIENT != null)
								return false;
						
						} else if (!this.ID_ADRESSE_CLIENT.equals(other.ID_ADRESSE_CLIENT))
						
							return false;
					

		return true;
    }

	public void copyDataTo(row1Struct other) {

		other.ID_ADRESSE_CLIENT = this.ID_ADRESSE_CLIENT;
	            other.ADRESSE_CLIENT = this.ADRESSE_CLIENT;
	            
	}

	public void copyKeysDataTo(row1Struct other) {

		other.ID_ADRESSE_CLIENT = this.ID_ADRESSE_CLIENT;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API.length == 0) {
   					commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API.length == 0) {
   					commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API) {

        	try {

        		int length = 0;
		
						this.ID_ADRESSE_CLIENT = (BigDecimal) dis.readObject();
					
					this.ADRESSE_CLIENT = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API) {

        	try {

        		int length = 0;
		
						this.ID_ADRESSE_CLIENT = (BigDecimal) dis.readObject();
					
					this.ADRESSE_CLIENT = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// BigDecimal
				
       			    	dos.writeObject(this.ID_ADRESSE_CLIENT);
					
					// String
				
						writeString(this.ADRESSE_CLIENT,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// BigDecimal
				
       			    	dos.writeObject(this.ID_ADRESSE_CLIENT);
					
					// String
				
						writeString(this.ADRESSE_CLIENT,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("ID_ADRESSE_CLIENT="+String.valueOf(ID_ADRESSE_CLIENT));
		sb.append(",ADRESSE_CLIENT="+ADRESSE_CLIENT);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row1Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.ID_ADRESSE_CLIENT, other.ID_ADRESSE_CLIENT);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tDBInput_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBInput_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row1Struct row1 = new row1Struct();
row2Struct row2 = new row2Struct();
row4Struct row4 = new row4Struct();
row8Struct row8 = new row8Struct();




	
	/**
	 * [tFlowToIterate_1 begin ] start
	 */

				
			int NB_ITERATE_tJava_1 = 0; //for statistics
			

	
		
		ok_Hash.put("tFlowToIterate_1", false);
		start_Hash.put("tFlowToIterate_1", System.currentTimeMillis());
		
				tStatCatcher_1.addMessage("begin","tFlowToIterate_1");
				tStatCatcher_1Process(globalMap);
			
	
	currentComponent="tFlowToIterate_1";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row1");
					}
				
		int tos_count_tFlowToIterate_1 = 0;
		

int nb_line_tFlowToIterate_1 = 0;
int counter_tFlowToIterate_1 = 0;

 



/**
 * [tFlowToIterate_1 begin ] stop
 */



	
	/**
	 * [tDBInput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBInput_1", false);
		start_Hash.put("tDBInput_1", System.currentTimeMillis());
		
				tStatCatcher_1.addMessage("begin","tDBInput_1");
				tStatCatcher_1Process(globalMap);
			
	
	currentComponent="tDBInput_1";

	
		int tos_count_tDBInput_1 = 0;
		
	


	
		    int nb_line_tDBInput_1 = 0;
		    java.sql.Connection conn_tDBInput_1 = null;
				String driverClass_tDBInput_1 = "oracle.jdbc.OracleDriver";
				java.lang.Class.forName(driverClass_tDBInput_1);
				
			String url_tDBInput_1 = null;
				url_tDBInput_1 = "jdbc:oracle:thin:@(description=(address=(protocol=tcp)(host=" + "" + ")(port=" + "1521" + "))(connect_data=(service_name=" + "XEPDB1" + ")))";

				String dbUser_tDBInput_1 = "DSID_LIV_OPE";

				

				 
	final String decryptedPassword_tDBInput_1 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:dpGbn8i75KptHxONv99yTLp+C7DkDdGRE/E6AFOtrjw=");

				String dbPwd_tDBInput_1 = decryptedPassword_tDBInput_1;

				
					conn_tDBInput_1 = java.sql.DriverManager.getConnection(url_tDBInput_1,dbUser_tDBInput_1,dbPwd_tDBInput_1);
				java.sql.Statement stmtGetTZ_tDBInput_1 = conn_tDBInput_1.createStatement();
				java.sql.ResultSet rsGetTZ_tDBInput_1 = stmtGetTZ_tDBInput_1.executeQuery("select sessiontimezone from dual");
				String sessionTimezone_tDBInput_1 = java.util.TimeZone.getDefault().getID();
				while (rsGetTZ_tDBInput_1.next()) {
					sessionTimezone_tDBInput_1 = rsGetTZ_tDBInput_1.getString(1);
				}
                                if (!(conn_tDBInput_1 instanceof oracle.jdbc.OracleConnection) &&
                                        conn_tDBInput_1.isWrapperFor(oracle.jdbc.OracleConnection.class)) {
                                    if (conn_tDBInput_1.unwrap(oracle.jdbc.OracleConnection.class) != null) {
                                        ((oracle.jdbc.OracleConnection)conn_tDBInput_1.unwrap(oracle.jdbc.OracleConnection.class)).setSessionTimeZone(sessionTimezone_tDBInput_1);
                                    }
                                } else {
                                    ((oracle.jdbc.OracleConnection)conn_tDBInput_1).setSessionTimeZone(sessionTimezone_tDBInput_1);
                                }
		    
			java.sql.Statement stmt_tDBInput_1 = conn_tDBInput_1.createStatement();

		    String dbquery_tDBInput_1 = "SELECT \n  DSID_LIV_OPE.ADRESSE_CLIENT.ID_ADRESSE_CLIENT, \n  DSID_LIV_OPE.ADRESSE_CLIENT.ADRESSE_CLIENT\nFROM DSID_LIV_OP"
+"E.ADRESSE_CLIENT";
		    

            	globalMap.put("tDBInput_1_QUERY",dbquery_tDBInput_1);
		    java.sql.ResultSet rs_tDBInput_1 = null;

		    try {
		    	rs_tDBInput_1 = stmt_tDBInput_1.executeQuery(dbquery_tDBInput_1);
		    	java.sql.ResultSetMetaData rsmd_tDBInput_1 = rs_tDBInput_1.getMetaData();
		    	int colQtyInRs_tDBInput_1 = rsmd_tDBInput_1.getColumnCount();

		    String tmpContent_tDBInput_1 = null;
		    
		    
		    while (rs_tDBInput_1.next()) {
		        nb_line_tDBInput_1++;
		        
							if(colQtyInRs_tDBInput_1 < 1) {
								row1.ID_ADRESSE_CLIENT = null;
							} else {
		                          
					if(rs_tDBInput_1.getObject(1) != null) {
						row1.ID_ADRESSE_CLIENT = rs_tDBInput_1.getBigDecimal(1);
					} else {
				
 	                	throw new RuntimeException("Null value in non-Nullable column");
					}
		                    }
							if(colQtyInRs_tDBInput_1 < 2) {
								row1.ADRESSE_CLIENT = null;
							} else {
	                         		
        	row1.ADRESSE_CLIENT = routines.system.JDBCUtil.getString(rs_tDBInput_1, 2, false);
		                    }
					




 



/**
 * [tDBInput_1 begin ] stop
 */
	
	/**
	 * [tDBInput_1 main ] start
	 */

	

	
	
	currentComponent="tDBInput_1";

	

 


	tos_count_tDBInput_1++;

/**
 * [tDBInput_1 main ] stop
 */
	
	/**
	 * [tDBInput_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBInput_1";

	

 



/**
 * [tDBInput_1 process_data_begin ] stop
 */

	
	/**
	 * [tFlowToIterate_1 main ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_1";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row1"
						
						);
					}
					


    	            
            globalMap.put("row1.ID_ADRESSE_CLIENT", row1.ID_ADRESSE_CLIENT);
    	            
            globalMap.put("row1.ADRESSE_CLIENT", row1.ADRESSE_CLIENT);
    	
 
	   nb_line_tFlowToIterate_1++;  
       counter_tFlowToIterate_1++;
       globalMap.put("tFlowToIterate_1_CURRENT_ITERATION", counter_tFlowToIterate_1);
 


	tos_count_tFlowToIterate_1++;

/**
 * [tFlowToIterate_1 main ] stop
 */
	
	/**
	 * [tFlowToIterate_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_1";

	

 



/**
 * [tFlowToIterate_1 process_data_begin ] stop
 */
	NB_ITERATE_tJava_1++;
	
	
					if(execStat){				
	       				runStat.updateStatOnConnection("row8", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row4", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row2", 3, 0);
					}           			
				
				if(execStat){
					runStat.updateStatOnConnection("iterate1", 1, "exec" + NB_ITERATE_tJava_1);
					//Thread.sleep(1000);
				}				
			




	
	/**
	 * [tDBOutput_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_3", false);
		start_Hash.put("tDBOutput_3", System.currentTimeMillis());
		
				tStatCatcher_1.addMessage("begin","tDBOutput_3");
				tStatCatcher_1Process(globalMap);
			
	
	currentComponent="tDBOutput_3";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row8");
					}
				
		int tos_count_tDBOutput_3 = 0;
		






    
    int nb_line_tDBOutput_3 = 0;
    int nb_line_update_tDBOutput_3 = 0;
    int nb_line_inserted_tDBOutput_3 = 0;
    int nb_line_deleted_tDBOutput_3 = 0;
    int nb_line_rejected_tDBOutput_3 = 0;

    int tmp_batchUpdateCount_tDBOutput_3 = 0;

    int deletedCount_tDBOutput_3=0;
    int updatedCount_tDBOutput_3=0;
    int insertedCount_tDBOutput_3=0;
    int rowsToCommitCount_tDBOutput_3=0;
    int rejectedCount_tDBOutput_3=0;

    boolean whetherReject_tDBOutput_3 = false;

    java.sql.Connection conn_tDBOutput_3 = null;

    //optional table
    String dbschema_tDBOutput_3 = null;
    String tableName_tDBOutput_3 = null;
                    String driverClass_tDBOutput_3 = "oracle.jdbc.OracleDriver";


                java.lang.Class.forName(driverClass_tDBOutput_3);
                String url_tDBOutput_3 = null;
                    url_tDBOutput_3 = "jdbc:oracle:thin:@(description=(address=(protocol=tcp)(host=" + "" + ")(port=" + "1521" + "))(connect_data=(service_name=" + "XEPDB1" + ")))";
                String dbUser_tDBOutput_3 = "DSID_LIV_OPE";
 
	final String decryptedPassword_tDBOutput_3 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:+cIk9eX9cLnrewsBdtskN1eQeFe4695yL3z5iuxv7Sw=");

                String dbPwd_tDBOutput_3 = decryptedPassword_tDBOutput_3;
                dbschema_tDBOutput_3 = "DSID_LIV_OPE";


                    conn_tDBOutput_3 = java.sql.DriverManager.getConnection(url_tDBOutput_3, dbUser_tDBOutput_3, dbPwd_tDBOutput_3);
        resourceMap.put("conn_tDBOutput_3", conn_tDBOutput_3);
            conn_tDBOutput_3.setAutoCommit(false);
            int commitEvery_tDBOutput_3 = 10000;
            int commitCounter_tDBOutput_3 = 0;
        int batchSize_tDBOutput_3 = 10000;
        int batchSizeCounter_tDBOutput_3=0;
        int count_tDBOutput_3=0;

        if(dbschema_tDBOutput_3 == null || dbschema_tDBOutput_3.trim().length() == 0) {
            tableName_tDBOutput_3 = ("ADRESSE_NORMALISEE_CLIENT");
        } else {
            tableName_tDBOutput_3 = dbschema_tDBOutput_3 + "." + ("ADRESSE_NORMALISEE_CLIENT");
        }
                String insert_tDBOutput_3 = "INSERT INTO " + tableName_tDBOutput_3 + " (" + "ID_ADRESSE_NORM_CLIENT" + "," + "ID_ADRESSE_CLIENT" + ",NUMERO_VOIE,NOM_VOIE,CODE_POSTAL,NOM_VILLE,LONGITUDE,LATITUDE) VALUES (" + "dsid_liv_ope.seq_id_adresse_norm_client.nextval" + "," + ((BigDecimal)globalMap.get("row1.ID_ADRESSE_CLIENT")) + ",?,?,?,?,?,?)";    

                        java.sql.PreparedStatement pstmt_tDBOutput_3 = conn_tDBOutput_3.prepareStatement(insert_tDBOutput_3);
                        resourceMap.put("pstmt_tDBOutput_3", pstmt_tDBOutput_3);





 



/**
 * [tDBOutput_3 begin ] stop
 */



	
	/**
	 * [tExtractJSONFields_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tExtractJSONFields_1", false);
		start_Hash.put("tExtractJSONFields_1", System.currentTimeMillis());
		
				tStatCatcher_1.addMessage("begin","tExtractJSONFields_1");
				tStatCatcher_1Process(globalMap);
			
	
	currentComponent="tExtractJSONFields_1";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row4");
					}
				
		int tos_count_tExtractJSONFields_1 = 0;
		

int nb_line_tExtractJSONFields_1 = 0;
String jsonStr_tExtractJSONFields_1 = "";

	

class JsonPathCache_tExtractJSONFields_1 {
	final java.util.Map<String,com.jayway.jsonpath.JsonPath> jsonPathString2compiledJsonPath = new java.util.HashMap<String,com.jayway.jsonpath.JsonPath>();
	
	public com.jayway.jsonpath.JsonPath getCompiledJsonPath(String jsonPath) {
		if(jsonPathString2compiledJsonPath.containsKey(jsonPath)) {
			return jsonPathString2compiledJsonPath.get(jsonPath);
		} else {
			com.jayway.jsonpath.JsonPath compiledLoopPath = com.jayway.jsonpath.JsonPath.compile(jsonPath);
			jsonPathString2compiledJsonPath.put(jsonPath,compiledLoopPath);
			return compiledLoopPath;
		}
	}
}

JsonPathCache_tExtractJSONFields_1 jsonPathCache_tExtractJSONFields_1 = new JsonPathCache_tExtractJSONFields_1();

 



/**
 * [tExtractJSONFields_1 begin ] stop
 */



	
	/**
	 * [tRESTClient_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tRESTClient_3", false);
		start_Hash.put("tRESTClient_3", System.currentTimeMillis());
		
				tStatCatcher_1.addMessage("begin","tRESTClient_3");
				tStatCatcher_1Process(globalMap);
			
	
	currentComponent="tRESTClient_3";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row2");
					}
				
		int tos_count_tRESTClient_3 = 0;
		

 



/**
 * [tRESTClient_3 begin ] stop
 */



	
	/**
	 * [tJava_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_1", false);
		start_Hash.put("tJava_1", System.currentTimeMillis());
		
				tStatCatcher_1.addMessage("begin","tJava_1");
				tStatCatcher_1Process(globalMap);
			
	
	currentComponent="tJava_1";

	
		int tos_count_tJava_1 = 0;
		



 



/**
 * [tJava_1 begin ] stop
 */
	
	/**
	 * [tJava_1 main ] start
	 */

	

	
	
	currentComponent="tJava_1";

	

 


	tos_count_tJava_1++;

/**
 * [tJava_1 main ] stop
 */
	
	/**
	 * [tJava_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tJava_1";

	

 



/**
 * [tJava_1 process_data_begin ] stop
 */

	
	/**
	 * [tRESTClient_3 main ] start
	 */

	

	
	
	currentComponent="tRESTClient_3";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row2"
						
						);
					}
					
	row4 = null;

// expected response body
Object responseDoc_tRESTClient_3 = null;

try {
	// request body
	org.dom4j.Document requestDoc_tRESTClient_3 = null;
	String requestString_tRESTClient_3 = null;
			if (null != row2.body) {
				requestDoc_tRESTClient_3 = row2.body.getDocument();
			}
			requestString_tRESTClient_3 = row2.string;

	Object requestBody_tRESTClient_3 = requestDoc_tRESTClient_3 != null ? requestDoc_tRESTClient_3 : requestString_tRESTClient_3;

	

    //resposne class name
	Class<?> responseClass_tRESTClient_3
		= String.class;

	// create web client instance
	org.apache.cxf.jaxrs.client.JAXRSClientFactoryBean factoryBean_tRESTClient_3 =
			new org.apache.cxf.jaxrs.client.JAXRSClientFactoryBean();

	boolean inOSGi = routines.system.BundleUtils.inOSGi();

	final java.util.List<org.apache.cxf.feature.Feature> features_tRESTClient_3 =
			new java.util.ArrayList<org.apache.cxf.feature.Feature>();

	
		String url = "https://api-adresse.data.gouv.fr";
		// {baseUri}tRESTClient
		factoryBean_tRESTClient_3.setServiceName(new javax.xml.namespace.QName(url, "tRESTClient"));
		factoryBean_tRESTClient_3.setAddress(url);
	

	

	

	

	factoryBean_tRESTClient_3.setFeatures(features_tRESTClient_3);


	java.util.List<Object> providers_tRESTClient_3 = new java.util.ArrayList<Object>();
	providers_tRESTClient_3.add(new org.apache.cxf.jaxrs.provider.dom4j.DOM4JProvider() {
		// workaround for https://jira.talendforge.org/browse/TESB-7276
		public org.dom4j.Document readFrom(Class<org.dom4j.Document> cls,
											java.lang.reflect.Type type,
											java.lang.annotation.Annotation[] anns,
											javax.ws.rs.core.MediaType mt,
											javax.ws.rs.core.MultivaluedMap<String, String> headers,
											java.io.InputStream is)
				throws IOException, javax.ws.rs.WebApplicationException {
			String contentLength = headers.getFirst("Content-Length");
			if (!org.apache.cxf.common.util.StringUtils.isEmpty(contentLength)
					&& Integer.valueOf(contentLength) <= 0) {
				try {
					return org.dom4j.DocumentHelper.parseText("<root/>");
				} catch (org.dom4j.DocumentException e_tRESTClient_3) {
					e_tRESTClient_3.printStackTrace();
				}
				return null;
			}
			return super.readFrom(cls, type, anns, mt, headers, is);
		}
	});
	org.apache.cxf.jaxrs.provider.json.JSONProvider jsonProvider_tRESTClient_3 =
			new org.apache.cxf.jaxrs.provider.json.JSONProvider();
		jsonProvider_tRESTClient_3.setIgnoreNamespaces(true);
		jsonProvider_tRESTClient_3.setAttributesToElements(true);
	
	
	
		jsonProvider_tRESTClient_3.setSupportUnwrapped(true);
		jsonProvider_tRESTClient_3.setWrapperName("root");
	
	
		jsonProvider_tRESTClient_3.setDropRootElement(false);
		jsonProvider_tRESTClient_3.setConvertTypesToStrings(false);
	providers_tRESTClient_3.add(jsonProvider_tRESTClient_3);
	factoryBean_tRESTClient_3.setProviders(providers_tRESTClient_3);
	factoryBean_tRESTClient_3.setTransportId("http://cxf.apache.org/transports/http");

	boolean use_auth_tRESTClient_3 = false;

	

	org.apache.cxf.jaxrs.client.WebClient webClient_tRESTClient_3 = factoryBean_tRESTClient_3.createWebClient();

	// set request path
	webClient_tRESTClient_3.path("search");

	// set connection properties
	org.apache.cxf.jaxrs.client.ClientConfiguration clientConfig_tRESTClient_3 = org.apache.cxf.jaxrs.client.WebClient.getConfig(webClient_tRESTClient_3);
	org.apache.cxf.transport.http.auth.HttpAuthSupplier httpAuthSupplerHttpConduit = null;
	org.apache.cxf.transport.http.HTTPConduit conduit_tRESTClient_3 = clientConfig_tRESTClient_3.getHttpConduit();

    if (clientConfig_tRESTClient_3.getEndpoint() != null) {
		org.apache.cxf.service.model.EndpointInfo endpointInfo_tRESTClient_3 = clientConfig_tRESTClient_3.getEndpoint().getEndpointInfo();
		if(endpointInfo_tRESTClient_3 != null) {
			endpointInfo_tRESTClient_3.setProperty("enable.webclient.operation.reporting", true);
		}
    }

	

	

	if (!inOSGi) {
		conduit_tRESTClient_3.getClient().setReceiveTimeout((long)(60 * 1000L));
		conduit_tRESTClient_3.getClient().setConnectionTimeout((long)(30 * 1000L));
		boolean use_proxy_tRESTClient_3 = false;
		
	}
	
	

	

	

	
		// set Accept-Type
		webClient_tRESTClient_3.accept("application/json");
	

	
		// set optional query and header properties if any
	
	if (use_auth_tRESTClient_3 && "OAUTH2_BEARER".equals("BASIC")) {
		// set oAuth2 bearer token
		org.apache.cxf.rs.security.oauth2.client.BearerAuthSupplier authSupplier = new org.apache.cxf.rs.security.oauth2.client.BearerAuthSupplier();
		authSupplier.setAccessToken("");
		conduit_tRESTClient_3.setAuthSupplier(authSupplier);
	}

	

	// if FORM request then capture query parameters into Form, otherwise set them as queries
	
		
			webClient_tRESTClient_3.query("q" ,((String)globalMap.get("row1.ADRESSE_CLIENT")));
		
			webClient_tRESTClient_3.query("limit" ,"1");
		
	


	try {
		// start send request
		
			responseDoc_tRESTClient_3 = webClient_tRESTClient_3.get();
			javax.ws.rs.core.Response responseObjBase_tRESTClient_3 = (javax.ws.rs.core.Response)responseDoc_tRESTClient_3;
            int status_tRESTClient_3 = responseObjBase_tRESTClient_3.getStatus();
            if (status_tRESTClient_3 != 304 && status_tRESTClient_3 >= 300 && responseClass_tRESTClient_3 != javax.ws.rs.core.Response.class) {
                throw org.apache.cxf.jaxrs.utils.ExceptionUtils.toWebApplicationException((javax.ws.rs.core.Response)responseObjBase_tRESTClient_3);
            }
            if (responseObjBase_tRESTClient_3.getEntity() != null) {
				responseDoc_tRESTClient_3 = responseObjBase_tRESTClient_3.readEntity(responseClass_tRESTClient_3);
			}
		


		int webClientResponseStatus_tRESTClient_3 = webClient_tRESTClient_3.getResponse().getStatus();
		if (webClientResponseStatus_tRESTClient_3 >= 300) {
			throw new javax.ws.rs.WebApplicationException(webClient_tRESTClient_3.getResponse());
		}

		
			if (row4 == null) {
				row4 = new row4Struct();
			}

			row4.statusCode = webClientResponseStatus_tRESTClient_3;
			row4.string = "";
			
				
				{
					Object responseObj_tRESTClient_3 = responseDoc_tRESTClient_3;
				
				if(responseObj_tRESTClient_3 != null){
					if (responseClass_tRESTClient_3 == String.class && responseObj_tRESTClient_3 instanceof String) {
							row4.string = (String) responseObj_tRESTClient_3;
					} else {
						routines.system.Document responseTalendDoc_tRESTClient_3 = null;
						if (null != responseObj_tRESTClient_3) {
							responseTalendDoc_tRESTClient_3 = new routines.system.Document();
							if (responseObj_tRESTClient_3 instanceof org.dom4j.Document) {
								responseTalendDoc_tRESTClient_3.setDocument((org.dom4j.Document) responseObj_tRESTClient_3);
							}
						}
						row4.body = responseTalendDoc_tRESTClient_3;
					}
				}
			}
			


			globalMap.put("tRESTClient_3_HEADERS", webClient_tRESTClient_3.getResponse().getHeaders());
			globalMap.put("tRESTClient_3_COOKIES", webClient_tRESTClient_3.getResponse().getCookies());
			
		

	} catch (javax.ws.rs.WebApplicationException ex_tRESTClient_3) {
	    globalMap.put("tRESTClient_3_ERROR_MESSAGE",ex_tRESTClient_3.getMessage());
		
			throw ex_tRESTClient_3;
		
	}

} catch(Exception e_tRESTClient_3) {
    globalMap.put("tRESTClient_3_ERROR_MESSAGE",e_tRESTClient_3.getMessage());
	
		throw new TalendException(e_tRESTClient_3, currentComponent, globalMap);
	
}


 


	tos_count_tRESTClient_3++;

/**
 * [tRESTClient_3 main ] stop
 */
	
	/**
	 * [tRESTClient_3 process_data_begin ] start
	 */

	

	
	
	currentComponent="tRESTClient_3";

	

 



/**
 * [tRESTClient_3 process_data_begin ] stop
 */
// Start of branch "row4"
if(row4 != null) { 



	
	/**
	 * [tExtractJSONFields_1 main ] start
	 */

	

	
	
	currentComponent="tExtractJSONFields_1";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row4"
						
						);
					}
					

            if(row4.string!=null){// C_01
                jsonStr_tExtractJSONFields_1 = row4.string.toString();
   
row8 = null;

	

String loopPath_tExtractJSONFields_1 = "$.features.[*]";
java.util.List<Object> resultset_tExtractJSONFields_1 = new java.util.ArrayList<Object>();

boolean isStructError_tExtractJSONFields_1 = true;
com.jayway.jsonpath.ReadContext document_tExtractJSONFields_1 = null;
try {
	document_tExtractJSONFields_1 = com.jayway.jsonpath.JsonPath.parse(jsonStr_tExtractJSONFields_1);
	com.jayway.jsonpath.JsonPath compiledLoopPath_tExtractJSONFields_1 = jsonPathCache_tExtractJSONFields_1.getCompiledJsonPath(loopPath_tExtractJSONFields_1);
	Object result_tExtractJSONFields_1 = document_tExtractJSONFields_1.read(compiledLoopPath_tExtractJSONFields_1,net.minidev.json.JSONObject.class);
	if (result_tExtractJSONFields_1 instanceof net.minidev.json.JSONArray) {
		resultset_tExtractJSONFields_1 = (net.minidev.json.JSONArray) result_tExtractJSONFields_1;
	} else {
		resultset_tExtractJSONFields_1.add(result_tExtractJSONFields_1);
	}
	
	isStructError_tExtractJSONFields_1 = false;
} catch (java.lang.Exception ex_tExtractJSONFields_1) {
globalMap.put("tExtractJSONFields_1_ERROR_MESSAGE",ex_tExtractJSONFields_1.getMessage());
		System.err.println(ex_tExtractJSONFields_1.getMessage());
}

String jsonPath_tExtractJSONFields_1 = null;
com.jayway.jsonpath.JsonPath compiledJsonPath_tExtractJSONFields_1 = null;

Object value_tExtractJSONFields_1 = null;

Object root_tExtractJSONFields_1 = null;
for(int i_tExtractJSONFields_1=0; isStructError_tExtractJSONFields_1 || (i_tExtractJSONFields_1 < resultset_tExtractJSONFields_1.size());i_tExtractJSONFields_1++){
	if(!isStructError_tExtractJSONFields_1){
		Object row_tExtractJSONFields_1 = resultset_tExtractJSONFields_1.get(i_tExtractJSONFields_1);
            row8 = null;
	row8 = new row8Struct();
	nb_line_tExtractJSONFields_1++;
	try {
		jsonPath_tExtractJSONFields_1 = "properties.housenumber";
		compiledJsonPath_tExtractJSONFields_1 = jsonPathCache_tExtractJSONFields_1.getCompiledJsonPath(jsonPath_tExtractJSONFields_1);
		
		try {
		    
		        value_tExtractJSONFields_1 = compiledJsonPath_tExtractJSONFields_1.read(row_tExtractJSONFields_1);
		    
				row8.NUMERO_VOIE = value_tExtractJSONFields_1 == null ? 

		null

 : value_tExtractJSONFields_1.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_1) {
globalMap.put("tExtractJSONFields_1_ERROR_MESSAGE",e_tExtractJSONFields_1.getMessage());
			row8.NUMERO_VOIE = 

		null

;
		}
		jsonPath_tExtractJSONFields_1 = "properties.name";
		compiledJsonPath_tExtractJSONFields_1 = jsonPathCache_tExtractJSONFields_1.getCompiledJsonPath(jsonPath_tExtractJSONFields_1);
		
		try {
		    
		        value_tExtractJSONFields_1 = compiledJsonPath_tExtractJSONFields_1.read(row_tExtractJSONFields_1);
		    
				row8.NOM_VOIE = value_tExtractJSONFields_1 == null ? 

		null

 : value_tExtractJSONFields_1.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_1) {
globalMap.put("tExtractJSONFields_1_ERROR_MESSAGE",e_tExtractJSONFields_1.getMessage());
			row8.NOM_VOIE = 

		null

;
		}
		jsonPath_tExtractJSONFields_1 = "properties.postcode";
		compiledJsonPath_tExtractJSONFields_1 = jsonPathCache_tExtractJSONFields_1.getCompiledJsonPath(jsonPath_tExtractJSONFields_1);
		
		try {
		    
		        value_tExtractJSONFields_1 = compiledJsonPath_tExtractJSONFields_1.read(row_tExtractJSONFields_1);
		    
				row8.CODE_POSTAL = value_tExtractJSONFields_1 == null ? 

		null

 : value_tExtractJSONFields_1.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_1) {
globalMap.put("tExtractJSONFields_1_ERROR_MESSAGE",e_tExtractJSONFields_1.getMessage());
			row8.CODE_POSTAL = 

		null

;
		}
		jsonPath_tExtractJSONFields_1 = "properties.city";
		compiledJsonPath_tExtractJSONFields_1 = jsonPathCache_tExtractJSONFields_1.getCompiledJsonPath(jsonPath_tExtractJSONFields_1);
		
		try {
		    
		        value_tExtractJSONFields_1 = compiledJsonPath_tExtractJSONFields_1.read(row_tExtractJSONFields_1);
		    
				row8.NOM_VILLE = value_tExtractJSONFields_1 == null ? 

		null

 : value_tExtractJSONFields_1.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_1) {
globalMap.put("tExtractJSONFields_1_ERROR_MESSAGE",e_tExtractJSONFields_1.getMessage());
			row8.NOM_VILLE = 

		null

;
		}
		jsonPath_tExtractJSONFields_1 = "geometry.coordinates.[0]";
		compiledJsonPath_tExtractJSONFields_1 = jsonPathCache_tExtractJSONFields_1.getCompiledJsonPath(jsonPath_tExtractJSONFields_1);
		
		try {
		    
		        value_tExtractJSONFields_1 = compiledJsonPath_tExtractJSONFields_1.read(row_tExtractJSONFields_1);
		    
				row8.LONGITUDE = value_tExtractJSONFields_1 == null ? 

		null

 : value_tExtractJSONFields_1.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_1) {
globalMap.put("tExtractJSONFields_1_ERROR_MESSAGE",e_tExtractJSONFields_1.getMessage());
			row8.LONGITUDE = 

		null

;
		}
		jsonPath_tExtractJSONFields_1 = "geometry.coordinates.[1]";
		compiledJsonPath_tExtractJSONFields_1 = jsonPathCache_tExtractJSONFields_1.getCompiledJsonPath(jsonPath_tExtractJSONFields_1);
		
		try {
		    
		        value_tExtractJSONFields_1 = compiledJsonPath_tExtractJSONFields_1.read(row_tExtractJSONFields_1);
		    
				row8.LATITUDE = value_tExtractJSONFields_1 == null ? 

		null

 : value_tExtractJSONFields_1.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_1) {
globalMap.put("tExtractJSONFields_1_ERROR_MESSAGE",e_tExtractJSONFields_1.getMessage());
			row8.LATITUDE = 

		null

;
		}	
	} catch (java.lang.Exception ex_tExtractJSONFields_1) {
globalMap.put("tExtractJSONFields_1_ERROR_MESSAGE",ex_tExtractJSONFields_1.getMessage());
		    System.err.println(ex_tExtractJSONFields_1.getMessage());
		    row8 = null;	
	}
	
	}
    
	isStructError_tExtractJSONFields_1 = false;
	
//}


 


	tos_count_tExtractJSONFields_1++;

/**
 * [tExtractJSONFields_1 main ] stop
 */
	
	/**
	 * [tExtractJSONFields_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tExtractJSONFields_1";

	

 



/**
 * [tExtractJSONFields_1 process_data_begin ] stop
 */
// Start of branch "row8"
if(row8 != null) { 



	
	/**
	 * [tDBOutput_3 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row8"
						
						);
					}
					



        whetherReject_tDBOutput_3 = false;
                        if(row8.NUMERO_VOIE == null) {
pstmt_tDBOutput_3.setNull(1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(1, row8.NUMERO_VOIE);
}

                        if(row8.NOM_VOIE == null) {
pstmt_tDBOutput_3.setNull(2, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(2, row8.NOM_VOIE);
}

                        if(row8.CODE_POSTAL == null) {
pstmt_tDBOutput_3.setNull(3, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(3, row8.CODE_POSTAL);
}

                        if(row8.NOM_VILLE == null) {
pstmt_tDBOutput_3.setNull(4, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(4, row8.NOM_VILLE);
}

                        if(row8.LONGITUDE == null) {
pstmt_tDBOutput_3.setNull(5, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(5, row8.LONGITUDE);
}

                        if(row8.LATITUDE == null) {
pstmt_tDBOutput_3.setNull(6, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(6, row8.LATITUDE);
}

                pstmt_tDBOutput_3.addBatch();
                nb_line_tDBOutput_3++;
                batchSizeCounter_tDBOutput_3++;
            if (batchSize_tDBOutput_3 > 0 &&  batchSize_tDBOutput_3 <= batchSizeCounter_tDBOutput_3) {
                try {
                    pstmt_tDBOutput_3.executeBatch();
                }catch (java.sql.BatchUpdateException e_tDBOutput_3){
globalMap.put("tDBOutput_3_ERROR_MESSAGE",e_tDBOutput_3.getMessage());
			        java.sql.SQLException ne_tDBOutput_3 = e_tDBOutput_3.getNextException(),sqle_tDBOutput_3=null;
			    	String errormessage_tDBOutput_3;
					if (ne_tDBOutput_3 != null) {
						// build new exception to provide the original cause
						sqle_tDBOutput_3 = new java.sql.SQLException(e_tDBOutput_3.getMessage() + "\ncaused by: " + ne_tDBOutput_3.getMessage(), ne_tDBOutput_3.getSQLState(), ne_tDBOutput_3.getErrorCode(), ne_tDBOutput_3);
						errormessage_tDBOutput_3 = sqle_tDBOutput_3.getMessage();
					}else{
						errormessage_tDBOutput_3 = e_tDBOutput_3.getMessage();
					}
	            	
	                	System.err.println(errormessage_tDBOutput_3);
	            	
	        	}
                tmp_batchUpdateCount_tDBOutput_3 = pstmt_tDBOutput_3.getUpdateCount();
                    insertedCount_tDBOutput_3
                += (tmp_batchUpdateCount_tDBOutput_3!=-1?tmp_batchUpdateCount_tDBOutput_3:0);
                rowsToCommitCount_tDBOutput_3 += (tmp_batchUpdateCount_tDBOutput_3!=-1?tmp_batchUpdateCount_tDBOutput_3:0);
                batchSizeCounter_tDBOutput_3 = 0;
            }
                commitCounter_tDBOutput_3++;
                if(commitEvery_tDBOutput_3 <= commitCounter_tDBOutput_3) {
                    if(batchSizeCounter_tDBOutput_3 > 0) {
                        try {
                            pstmt_tDBOutput_3.executeBatch();
                        }catch (java.sql.BatchUpdateException e_tDBOutput_3){
globalMap.put("tDBOutput_3_ERROR_MESSAGE",e_tDBOutput_3.getMessage());
					        java.sql.SQLException ne_tDBOutput_3 = e_tDBOutput_3.getNextException(),sqle_tDBOutput_3=null;
					    	String errormessage_tDBOutput_3;
							if (ne_tDBOutput_3 != null) {
								// build new exception to provide the original cause
								sqle_tDBOutput_3 = new java.sql.SQLException(e_tDBOutput_3.getMessage() + "\ncaused by: " + ne_tDBOutput_3.getMessage(), ne_tDBOutput_3.getSQLState(), ne_tDBOutput_3.getErrorCode(), ne_tDBOutput_3);
								errormessage_tDBOutput_3 = sqle_tDBOutput_3.getMessage();
							}else{
								errormessage_tDBOutput_3 = e_tDBOutput_3.getMessage();
							}
			            	
			                	System.err.println(errormessage_tDBOutput_3);
			            	
			        	}
                        tmp_batchUpdateCount_tDBOutput_3 = pstmt_tDBOutput_3.getUpdateCount();
                            insertedCount_tDBOutput_3
                        += (tmp_batchUpdateCount_tDBOutput_3!=-1?tmp_batchUpdateCount_tDBOutput_3:0);
                        rowsToCommitCount_tDBOutput_3 += (tmp_batchUpdateCount_tDBOutput_3!=-1?tmp_batchUpdateCount_tDBOutput_3:0);
                    }
                    if(rowsToCommitCount_tDBOutput_3 != 0){
                    	
                    }
                    conn_tDBOutput_3.commit();
                    if(rowsToCommitCount_tDBOutput_3 != 0){
                    	
                    	rowsToCommitCount_tDBOutput_3 = 0;
                    }
                    commitCounter_tDBOutput_3=0;
                    	batchSizeCounter_tDBOutput_3=0;
                }

 


	tos_count_tDBOutput_3++;

/**
 * [tDBOutput_3 main ] stop
 */
	
	/**
	 * [tDBOutput_3 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";

	

 



/**
 * [tDBOutput_3 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_3 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";

	

 



/**
 * [tDBOutput_3 process_data_end ] stop
 */

} // End of branch "row8"

		// end for
	}


	
		} // C_01
	
	
	/**
	 * [tExtractJSONFields_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tExtractJSONFields_1";

	

 



/**
 * [tExtractJSONFields_1 process_data_end ] stop
 */

} // End of branch "row4"




	
	/**
	 * [tRESTClient_3 process_data_end ] start
	 */

	

	
	
	currentComponent="tRESTClient_3";

	

 



/**
 * [tRESTClient_3 process_data_end ] stop
 */



	
	/**
	 * [tJava_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tJava_1";

	

 



/**
 * [tJava_1 process_data_end ] stop
 */
	
	/**
	 * [tJava_1 end ] start
	 */

	

	
	
	currentComponent="tJava_1";

	

 

ok_Hash.put("tJava_1", true);
end_Hash.put("tJava_1", System.currentTimeMillis());

tStatCatcher_1.addMessage("end","tJava_1", end_Hash.get("tJava_1")-start_Hash.get("tJava_1"));
tStatCatcher_1Process(globalMap);



/**
 * [tJava_1 end ] stop
 */

	
	/**
	 * [tRESTClient_3 end ] start
	 */

	

	
	
	currentComponent="tRESTClient_3";

	


if (globalMap.get("tRESTClient_3_NB_LINE") == null) {
	globalMap.put("tRESTClient_3_NB_LINE", 1);
}

// [tRESTCliend_end]
				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row2");
			  	}
			  	
 

ok_Hash.put("tRESTClient_3", true);
end_Hash.put("tRESTClient_3", System.currentTimeMillis());

tStatCatcher_1.addMessage("end","tRESTClient_3", end_Hash.get("tRESTClient_3")-start_Hash.get("tRESTClient_3"));
tStatCatcher_1Process(globalMap);



/**
 * [tRESTClient_3 end ] stop
 */

	
	/**
	 * [tExtractJSONFields_1 end ] start
	 */

	

	
	
	currentComponent="tExtractJSONFields_1";

	
   globalMap.put("tExtractJSONFields_1_NB_LINE", nb_line_tExtractJSONFields_1);


				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row4");
			  	}
			  	
 

ok_Hash.put("tExtractJSONFields_1", true);
end_Hash.put("tExtractJSONFields_1", System.currentTimeMillis());

tStatCatcher_1.addMessage("end","tExtractJSONFields_1", end_Hash.get("tExtractJSONFields_1")-start_Hash.get("tExtractJSONFields_1"));
tStatCatcher_1Process(globalMap);



/**
 * [tExtractJSONFields_1 end ] stop
 */

	
	/**
	 * [tDBOutput_3 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";

	
	



	
        if(batchSizeCounter_tDBOutput_3 > 0) {
            try {
            	if (pstmt_tDBOutput_3 != null) {
					
					pstmt_tDBOutput_3.executeBatch();
					
        	    }
            }catch (java.sql.BatchUpdateException e_tDBOutput_3){
globalMap.put("tDBOutput_3_ERROR_MESSAGE",e_tDBOutput_3.getMessage());
		        java.sql.SQLException ne_tDBOutput_3 = e_tDBOutput_3.getNextException(),sqle_tDBOutput_3=null;
		    	String errormessage_tDBOutput_3;
				if (ne_tDBOutput_3 != null) {
					// build new exception to provide the original cause
					sqle_tDBOutput_3 = new java.sql.SQLException(e_tDBOutput_3.getMessage() + "\ncaused by: " + ne_tDBOutput_3.getMessage(), ne_tDBOutput_3.getSQLState(), ne_tDBOutput_3.getErrorCode(), ne_tDBOutput_3);
					errormessage_tDBOutput_3 = sqle_tDBOutput_3.getMessage();
				}else{
					errormessage_tDBOutput_3 = e_tDBOutput_3.getMessage();
				}
            	
                	System.err.println(errormessage_tDBOutput_3);
            	
        	}
        	if (pstmt_tDBOutput_3 != null) {
            	tmp_batchUpdateCount_tDBOutput_3 = pstmt_tDBOutput_3.getUpdateCount();
    	    	
    	    		insertedCount_tDBOutput_3
    	    	
    	    	+= (tmp_batchUpdateCount_tDBOutput_3!=-1?tmp_batchUpdateCount_tDBOutput_3:0);
				rowsToCommitCount_tDBOutput_3 += (tmp_batchUpdateCount_tDBOutput_3!=-1?tmp_batchUpdateCount_tDBOutput_3:0);
            }
        }
        if(pstmt_tDBOutput_3 != null) {
			
				pstmt_tDBOutput_3.close();
				resourceMap.remove("pstmt_tDBOutput_3");
			
        }
    resourceMap.put("statementClosed_tDBOutput_3", true);
		if(commitCounter_tDBOutput_3 > 0 && rowsToCommitCount_tDBOutput_3 != 0) {
			
		}
		conn_tDBOutput_3.commit();
		if(commitCounter_tDBOutput_3 > 0 && rowsToCommitCount_tDBOutput_3 != 0) {
			
			rowsToCommitCount_tDBOutput_3 = 0;
		}
		commitCounter_tDBOutput_3 = 0;
		
		
		conn_tDBOutput_3 .close();
		
		resourceMap.put("finish_tDBOutput_3", true);
   	

	
	nb_line_deleted_tDBOutput_3=nb_line_deleted_tDBOutput_3+ deletedCount_tDBOutput_3;
	nb_line_update_tDBOutput_3=nb_line_update_tDBOutput_3 + updatedCount_tDBOutput_3;
	nb_line_inserted_tDBOutput_3=nb_line_inserted_tDBOutput_3 + insertedCount_tDBOutput_3;
	nb_line_rejected_tDBOutput_3=nb_line_rejected_tDBOutput_3 + rejectedCount_tDBOutput_3;
	
        globalMap.put("tDBOutput_3_NB_LINE",nb_line_tDBOutput_3);
        globalMap.put("tDBOutput_3_NB_LINE_UPDATED",nb_line_update_tDBOutput_3);
        globalMap.put("tDBOutput_3_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_3);
        globalMap.put("tDBOutput_3_NB_LINE_DELETED",nb_line_deleted_tDBOutput_3);
        globalMap.put("tDBOutput_3_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_3);
    

	



				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row8");
			  	}
			  	
 

ok_Hash.put("tDBOutput_3", true);
end_Hash.put("tDBOutput_3", System.currentTimeMillis());

tStatCatcher_1.addMessage("end","tDBOutput_3", end_Hash.get("tDBOutput_3")-start_Hash.get("tDBOutput_3"));
tStatCatcher_1Process(globalMap);



/**
 * [tDBOutput_3 end ] stop
 */









						if(execStat){
							runStat.updateStatOnConnection("iterate1", 2, "exec" + NB_ITERATE_tJava_1);
						}				
					




	
	/**
	 * [tFlowToIterate_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_1";

	

 



/**
 * [tFlowToIterate_1 process_data_end ] stop
 */



	
	/**
	 * [tDBInput_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBInput_1";

	

 



/**
 * [tDBInput_1 process_data_end ] stop
 */
	
	/**
	 * [tDBInput_1 end ] start
	 */

	

	
	
	currentComponent="tDBInput_1";

	

}
}finally{
	if (rs_tDBInput_1 != null) {
		rs_tDBInput_1.close();
	}
	if (stmt_tDBInput_1 != null) {
		stmt_tDBInput_1.close();
	}
	if(conn_tDBInput_1 != null && !conn_tDBInput_1.isClosed()) {
	
			conn_tDBInput_1.close();
			
			if("com.mysql.cj.jdbc.Driver".equals((String)globalMap.get("driverClass_"))
			    && routines.system.BundleUtils.inOSGi()) {
			        Class.forName("com.mysql.cj.jdbc.AbandonedConnectionCleanupThread").
			            getMethod("checkedShutdown").invoke(null, (Object[]) null);
			}
			
	}
	
}

globalMap.put("tDBInput_1_NB_LINE",nb_line_tDBInput_1);
 

ok_Hash.put("tDBInput_1", true);
end_Hash.put("tDBInput_1", System.currentTimeMillis());

tStatCatcher_1.addMessage("end","tDBInput_1", end_Hash.get("tDBInput_1")-start_Hash.get("tDBInput_1"));
tStatCatcher_1Process(globalMap);



/**
 * [tDBInput_1 end ] stop
 */

	
	/**
	 * [tFlowToIterate_1 end ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_1";

	

globalMap.put("tFlowToIterate_1_NB_LINE",nb_line_tFlowToIterate_1);
				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row1");
			  	}
			  	
 

ok_Hash.put("tFlowToIterate_1", true);
end_Hash.put("tFlowToIterate_1", System.currentTimeMillis());

tStatCatcher_1.addMessage("end","tFlowToIterate_1", end_Hash.get("tFlowToIterate_1")-start_Hash.get("tFlowToIterate_1"));
tStatCatcher_1Process(globalMap);



/**
 * [tFlowToIterate_1 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBInput_1 finally ] start
	 */

	

	
	
	currentComponent="tDBInput_1";

	

 



/**
 * [tDBInput_1 finally ] stop
 */

	
	/**
	 * [tFlowToIterate_1 finally ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_1";

	

 



/**
 * [tFlowToIterate_1 finally ] stop
 */

	
	/**
	 * [tJava_1 finally ] start
	 */

	

	
	
	currentComponent="tJava_1";

	

 



/**
 * [tJava_1 finally ] stop
 */

	
	/**
	 * [tRESTClient_3 finally ] start
	 */

	

	
	
	currentComponent="tRESTClient_3";

	

 



/**
 * [tRESTClient_3 finally ] stop
 */

	
	/**
	 * [tExtractJSONFields_1 finally ] start
	 */

	

	
	
	currentComponent="tExtractJSONFields_1";

	

 



/**
 * [tExtractJSONFields_1 finally ] stop
 */

	
	/**
	 * [tDBOutput_3 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";

	



    try {
    if (resourceMap.get("statementClosed_tDBOutput_3") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_3 = null;
                if ((pstmtToClose_tDBOutput_3 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_3")) != null) {
                    pstmtToClose_tDBOutput_3.close();
                }
    }
    } finally {
        if(resourceMap.get("finish_tDBOutput_3") == null){
            java.sql.Connection ctn_tDBOutput_3 = null;
            if((ctn_tDBOutput_3 = (java.sql.Connection)resourceMap.get("conn_tDBOutput_3")) != null){
                try {
                    ctn_tDBOutput_3.close();
                } catch (java.sql.SQLException sqlEx_tDBOutput_3) {
                    String errorMessage_tDBOutput_3 = "failed to close the connection in tDBOutput_3 :" + sqlEx_tDBOutput_3.getMessage();
                    System.err.println(errorMessage_tDBOutput_3);
                }
            }
        }
    }
 



/**
 * [tDBOutput_3 finally ] stop
 */















				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBInput_1_SUBPROCESS_STATE", 1);
	}
	

public void tDBRow_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBRow_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tDBRow_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBRow_2", false);
		start_Hash.put("tDBRow_2", System.currentTimeMillis());
		
				tStatCatcher_1.addMessage("begin","tDBRow_2");
				tStatCatcher_1Process(globalMap);
			
	
	currentComponent="tDBRow_2";

	
		int tos_count_tDBRow_2 = 0;
		

	java.sql.Connection conn_tDBRow_2 = null;
	String query_tDBRow_2 = "";
	boolean whetherReject_tDBRow_2 = false;
			String driverClass_tDBRow_2 = "oracle.jdbc.OracleDriver";
		    java.lang.Class jdbcclazz_tDBRow_2 = java.lang.Class.forName(driverClass_tDBRow_2);
		
			String url_tDBRow_2 = null;
				url_tDBRow_2 = "jdbc:oracle:thin:@(description=(address=(protocol=tcp)(host=" + "" + ")(port=" + "1521" + "))(connect_data=(service_name=" + "XEPDB1" + ")))";
					String dbUser_tDBRow_2 = "DSID_LIV_OPE";
	        
            		
            		
            		 
	final String decryptedPassword_tDBRow_2 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:KeWUvDNjHlSsqWbdmrsozlDSwr1ftYBtN/TbnDNCWps=");
        		   	
        	        String dbPwd_tDBRow_2 = decryptedPassword_tDBRow_2;
	        
					
			conn_tDBRow_2 = java.sql.DriverManager.getConnection(url_tDBRow_2,dbUser_tDBRow_2,dbPwd_tDBRow_2);
		
        resourceMap.put("conn_tDBRow_2", conn_tDBRow_2);
					if(conn_tDBRow_2.getAutoCommit()) {
						
				conn_tDBRow_2.setAutoCommit(false);
			
					}        
					int commitEvery_tDBRow_2 = 10000;
					int commitCounter_tDBRow_2 = 0;
				
        java.sql.Statement stmt_tDBRow_2 = conn_tDBRow_2.createStatement();
        resourceMap.put("stmt_tDBRow_2", stmt_tDBRow_2);

 



/**
 * [tDBRow_2 begin ] stop
 */
	
	/**
	 * [tDBRow_2 main ] start
	 */

	

	
	
	currentComponent="tDBRow_2";

	

query_tDBRow_2 = "TRUNCATE TABLE  DSID_LIV_OPE.ADRESSE_NORMALISEE_RESTAURANT";
whetherReject_tDBRow_2 = false;
globalMap.put("tDBRow_2_QUERY",query_tDBRow_2);
try {
		stmt_tDBRow_2.execute(query_tDBRow_2);
		
	} catch (java.lang.Exception e) {
globalMap.put("tDBRow_2_ERROR_MESSAGE",e.getMessage());
		whetherReject_tDBRow_2 = true;
		
				System.err.print(e.getMessage());
				
	}
	
	if(!whetherReject_tDBRow_2) {
		
	}
	
		commitCounter_tDBRow_2++;
		if(commitEvery_tDBRow_2 <= commitCounter_tDBRow_2) {
			
			conn_tDBRow_2.commit();
			
			commitCounter_tDBRow_2=0;
		}
		

 


	tos_count_tDBRow_2++;

/**
 * [tDBRow_2 main ] stop
 */
	
	/**
	 * [tDBRow_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBRow_2";

	

 



/**
 * [tDBRow_2 process_data_begin ] stop
 */
	
	/**
	 * [tDBRow_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBRow_2";

	

 



/**
 * [tDBRow_2 process_data_end ] stop
 */
	
	/**
	 * [tDBRow_2 end ] start
	 */

	

	
	
	currentComponent="tDBRow_2";

	

	
        stmt_tDBRow_2.close();
        resourceMap.remove("stmt_tDBRow_2");
    resourceMap.put("statementClosed_tDBRow_2", true);
		if(commitEvery_tDBRow_2>commitCounter_tDBRow_2){

			
			conn_tDBRow_2.commit();
			
	
			commitCounter_tDBRow_2=0;
	
		}
			conn_tDBRow_2.close();
			
			if("com.mysql.cj.jdbc.Driver".equals((String)globalMap.get("driverClass_"))
			    && routines.system.BundleUtils.inOSGi()) {
			        Class.forName("com.mysql.cj.jdbc.AbandonedConnectionCleanupThread").
			            getMethod("checkedShutdown").invoke(null, (Object[]) null);
			}
			
    resourceMap.put("finish_tDBRow_2", true);

 

ok_Hash.put("tDBRow_2", true);
end_Hash.put("tDBRow_2", System.currentTimeMillis());

tStatCatcher_1.addMessage("end","tDBRow_2", end_Hash.get("tDBRow_2")-start_Hash.get("tDBRow_2"));
tStatCatcher_1Process(globalMap);
				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk4", 0, "ok");
				}
				tDBInput_2Process(globalMap);



/**
 * [tDBRow_2 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBRow_2 finally ] start
	 */

	

	
	
	currentComponent="tDBRow_2";

	

try {
    if (resourceMap.get("statementClosed_tDBRow_2") == null) {
            java.sql.Statement stmtToClose_tDBRow_2 = null;
            if ((stmtToClose_tDBRow_2 = (java.sql.Statement) resourceMap.remove("stmt_tDBRow_2")) != null) {
                stmtToClose_tDBRow_2.close();
            }
    }
} finally {
        if(resourceMap.get("finish_tDBRow_2") == null){
            java.sql.Connection ctn_tDBRow_2 = null;
            if((ctn_tDBRow_2 = (java.sql.Connection)resourceMap.get("conn_tDBRow_2")) != null){
                try {
                    ctn_tDBRow_2.close();
                } catch (java.sql.SQLException sqlEx_tDBRow_2) {
                    String errorMessage_tDBRow_2 = "failed to close the connection in tDBRow_2 :" + sqlEx_tDBRow_2.getMessage();
                    System.err.println(errorMessage_tDBRow_2);
                }
            }
        }
    }
 



/**
 * [tDBRow_2 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBRow_2_SUBPROCESS_STATE", 1);
	}
	


public static class row9Struct implements routines.system.IPersistableRow<row9Struct> {
    final static byte[] commonByteArrayLock_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API = new byte[0];
    static byte[] commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public BigDecimal ID_ADRESSE_NORM_RESTAURANT;

				public BigDecimal getID_ADRESSE_NORM_RESTAURANT () {
					return this.ID_ADRESSE_NORM_RESTAURANT;
				}
				
			    public BigDecimal ID_ADRESSE_RESTAURANT;

				public BigDecimal getID_ADRESSE_RESTAURANT () {
					return this.ID_ADRESSE_RESTAURANT;
				}
				
			    public String NUMERO_VOIE;

				public String getNUMERO_VOIE () {
					return this.NUMERO_VOIE;
				}
				
			    public String NOM_VOIE;

				public String getNOM_VOIE () {
					return this.NOM_VOIE;
				}
				
			    public String CODE_POSTAL;

				public String getCODE_POSTAL () {
					return this.CODE_POSTAL;
				}
				
			    public String NOM_VILLE;

				public String getNOM_VILLE () {
					return this.NOM_VILLE;
				}
				
			    public String LONGITUDE;

				public String getLONGITUDE () {
					return this.LONGITUDE;
				}
				
			    public String LATITUDE;

				public String getLATITUDE () {
					return this.LATITUDE;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
						result = prime * result + ((this.ID_ADRESSE_NORM_RESTAURANT == null) ? 0 : this.ID_ADRESSE_NORM_RESTAURANT.hashCode());
					
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row9Struct other = (row9Struct) obj;
		
						if (this.ID_ADRESSE_NORM_RESTAURANT == null) {
							if (other.ID_ADRESSE_NORM_RESTAURANT != null)
								return false;
						
						} else if (!this.ID_ADRESSE_NORM_RESTAURANT.equals(other.ID_ADRESSE_NORM_RESTAURANT))
						
							return false;
					

		return true;
    }

	public void copyDataTo(row9Struct other) {

		other.ID_ADRESSE_NORM_RESTAURANT = this.ID_ADRESSE_NORM_RESTAURANT;
	            other.ID_ADRESSE_RESTAURANT = this.ID_ADRESSE_RESTAURANT;
	            other.NUMERO_VOIE = this.NUMERO_VOIE;
	            other.NOM_VOIE = this.NOM_VOIE;
	            other.CODE_POSTAL = this.CODE_POSTAL;
	            other.NOM_VILLE = this.NOM_VILLE;
	            other.LONGITUDE = this.LONGITUDE;
	            other.LATITUDE = this.LATITUDE;
	            
	}

	public void copyKeysDataTo(row9Struct other) {

		other.ID_ADRESSE_NORM_RESTAURANT = this.ID_ADRESSE_NORM_RESTAURANT;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API.length == 0) {
   					commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API.length == 0) {
   					commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API) {

        	try {

        		int length = 0;
		
						this.ID_ADRESSE_NORM_RESTAURANT = (BigDecimal) dis.readObject();
					
						this.ID_ADRESSE_RESTAURANT = (BigDecimal) dis.readObject();
					
					this.NUMERO_VOIE = readString(dis);
					
					this.NOM_VOIE = readString(dis);
					
					this.CODE_POSTAL = readString(dis);
					
					this.NOM_VILLE = readString(dis);
					
					this.LONGITUDE = readString(dis);
					
					this.LATITUDE = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API) {

        	try {

        		int length = 0;
		
						this.ID_ADRESSE_NORM_RESTAURANT = (BigDecimal) dis.readObject();
					
						this.ID_ADRESSE_RESTAURANT = (BigDecimal) dis.readObject();
					
					this.NUMERO_VOIE = readString(dis);
					
					this.NOM_VOIE = readString(dis);
					
					this.CODE_POSTAL = readString(dis);
					
					this.NOM_VILLE = readString(dis);
					
					this.LONGITUDE = readString(dis);
					
					this.LATITUDE = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// BigDecimal
				
       			    	dos.writeObject(this.ID_ADRESSE_NORM_RESTAURANT);
					
					// BigDecimal
				
       			    	dos.writeObject(this.ID_ADRESSE_RESTAURANT);
					
					// String
				
						writeString(this.NUMERO_VOIE,dos);
					
					// String
				
						writeString(this.NOM_VOIE,dos);
					
					// String
				
						writeString(this.CODE_POSTAL,dos);
					
					// String
				
						writeString(this.NOM_VILLE,dos);
					
					// String
				
						writeString(this.LONGITUDE,dos);
					
					// String
				
						writeString(this.LATITUDE,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// BigDecimal
				
       			    	dos.writeObject(this.ID_ADRESSE_NORM_RESTAURANT);
					
					// BigDecimal
				
       			    	dos.writeObject(this.ID_ADRESSE_RESTAURANT);
					
					// String
				
						writeString(this.NUMERO_VOIE,dos);
					
					// String
				
						writeString(this.NOM_VOIE,dos);
					
					// String
				
						writeString(this.CODE_POSTAL,dos);
					
					// String
				
						writeString(this.NOM_VILLE,dos);
					
					// String
				
						writeString(this.LONGITUDE,dos);
					
					// String
				
						writeString(this.LATITUDE,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("ID_ADRESSE_NORM_RESTAURANT="+String.valueOf(ID_ADRESSE_NORM_RESTAURANT));
		sb.append(",ID_ADRESSE_RESTAURANT="+String.valueOf(ID_ADRESSE_RESTAURANT));
		sb.append(",NUMERO_VOIE="+NUMERO_VOIE);
		sb.append(",NOM_VOIE="+NOM_VOIE);
		sb.append(",CODE_POSTAL="+CODE_POSTAL);
		sb.append(",NOM_VILLE="+NOM_VILLE);
		sb.append(",LONGITUDE="+LONGITUDE);
		sb.append(",LATITUDE="+LATITUDE);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row9Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.ID_ADRESSE_NORM_RESTAURANT, other.ID_ADRESSE_NORM_RESTAURANT);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row6Struct implements routines.system.IPersistableRow<row6Struct> {
    final static byte[] commonByteArrayLock_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API = new byte[0];
    static byte[] commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API = new byte[0];

	
			    public Integer statusCode;

				public Integer getStatusCode () {
					return this.statusCode;
				}
				
			    public routines.system.Document body;

				public routines.system.Document getBody () {
					return this.body;
				}
				
			    public String string;

				public String getString () {
					return this.string;
				}
				


	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API.length == 0) {
   					commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API.length == 0) {
   					commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API) {

        	try {

        		int length = 0;
		
						this.statusCode = readInteger(dis);
					
						this.body = (routines.system.Document) dis.readObject();
					
					this.string = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API) {

        	try {

        		int length = 0;
		
						this.statusCode = readInteger(dis);
					
						this.body = (routines.system.Document) dis.readObject();
					
					this.string = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Integer
				
						writeInteger(this.statusCode,dos);
					
					// Document
				
       			    	dos.writeObject(this.body);
					
					// String
				
						writeString(this.string,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// Integer
				
						writeInteger(this.statusCode,dos);
					
					// Document
				
       			    	dos.writeObject(this.body);
					
					// String
				
						writeString(this.string,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("statusCode="+String.valueOf(statusCode));
		sb.append(",body="+String.valueOf(body));
		sb.append(",string="+string);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row6Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row7Struct implements routines.system.IPersistableRow<row7Struct> {
    final static byte[] commonByteArrayLock_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API = new byte[0];
    static byte[] commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API = new byte[0];

	
			    public routines.system.Document body;

				public routines.system.Document getBody () {
					return this.body;
				}
				
			    public String string;

				public String getString () {
					return this.string;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API.length == 0) {
   					commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API.length == 0) {
   					commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API) {

        	try {

        		int length = 0;
		
						this.body = (routines.system.Document) dis.readObject();
					
					this.string = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API) {

        	try {

        		int length = 0;
		
						this.body = (routines.system.Document) dis.readObject();
					
					this.string = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Document
				
       			    	dos.writeObject(this.body);
					
					// String
				
						writeString(this.string,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// Document
				
       			    	dos.writeObject(this.body);
					
					// String
				
						writeString(this.string,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("body="+String.valueOf(body));
		sb.append(",string="+string);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row7Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row3Struct implements routines.system.IPersistableRow<row3Struct> {
    final static byte[] commonByteArrayLock_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API = new byte[0];
    static byte[] commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public BigDecimal ID_ADRESSE_RESTAURANT;

				public BigDecimal getID_ADRESSE_RESTAURANT () {
					return this.ID_ADRESSE_RESTAURANT;
				}
				
			    public String ADRESSE_RESTAURANT;

				public String getADRESSE_RESTAURANT () {
					return this.ADRESSE_RESTAURANT;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
						result = prime * result + ((this.ID_ADRESSE_RESTAURANT == null) ? 0 : this.ID_ADRESSE_RESTAURANT.hashCode());
					
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row3Struct other = (row3Struct) obj;
		
						if (this.ID_ADRESSE_RESTAURANT == null) {
							if (other.ID_ADRESSE_RESTAURANT != null)
								return false;
						
						} else if (!this.ID_ADRESSE_RESTAURANT.equals(other.ID_ADRESSE_RESTAURANT))
						
							return false;
					

		return true;
    }

	public void copyDataTo(row3Struct other) {

		other.ID_ADRESSE_RESTAURANT = this.ID_ADRESSE_RESTAURANT;
	            other.ADRESSE_RESTAURANT = this.ADRESSE_RESTAURANT;
	            
	}

	public void copyKeysDataTo(row3Struct other) {

		other.ID_ADRESSE_RESTAURANT = this.ID_ADRESSE_RESTAURANT;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API.length == 0) {
   					commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API.length == 0) {
   					commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API) {

        	try {

        		int length = 0;
		
						this.ID_ADRESSE_RESTAURANT = (BigDecimal) dis.readObject();
					
					this.ADRESSE_RESTAURANT = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_SI_OPE_C_ALIM_SI_OPE_API) {

        	try {

        		int length = 0;
		
						this.ID_ADRESSE_RESTAURANT = (BigDecimal) dis.readObject();
					
					this.ADRESSE_RESTAURANT = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// BigDecimal
				
       			    	dos.writeObject(this.ID_ADRESSE_RESTAURANT);
					
					// String
				
						writeString(this.ADRESSE_RESTAURANT,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// BigDecimal
				
       			    	dos.writeObject(this.ID_ADRESSE_RESTAURANT);
					
					// String
				
						writeString(this.ADRESSE_RESTAURANT,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("ID_ADRESSE_RESTAURANT="+String.valueOf(ID_ADRESSE_RESTAURANT));
		sb.append(",ADRESSE_RESTAURANT="+ADRESSE_RESTAURANT);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row3Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.ID_ADRESSE_RESTAURANT, other.ID_ADRESSE_RESTAURANT);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tDBInput_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBInput_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row3Struct row3 = new row3Struct();
row7Struct row7 = new row7Struct();
row6Struct row6 = new row6Struct();
row9Struct row9 = new row9Struct();




	
	/**
	 * [tFlowToIterate_2 begin ] start
	 */

				
			int NB_ITERATE_tJava_2 = 0; //for statistics
			

	
		
		ok_Hash.put("tFlowToIterate_2", false);
		start_Hash.put("tFlowToIterate_2", System.currentTimeMillis());
		
				tStatCatcher_1.addMessage("begin","tFlowToIterate_2");
				tStatCatcher_1Process(globalMap);
			
	
	currentComponent="tFlowToIterate_2";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row3");
					}
				
		int tos_count_tFlowToIterate_2 = 0;
		

int nb_line_tFlowToIterate_2 = 0;
int counter_tFlowToIterate_2 = 0;

 



/**
 * [tFlowToIterate_2 begin ] stop
 */



	
	/**
	 * [tDBInput_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBInput_2", false);
		start_Hash.put("tDBInput_2", System.currentTimeMillis());
		
				tStatCatcher_1.addMessage("begin","tDBInput_2");
				tStatCatcher_1Process(globalMap);
			
	
	currentComponent="tDBInput_2";

	
		int tos_count_tDBInput_2 = 0;
		
	


	
		    int nb_line_tDBInput_2 = 0;
		    java.sql.Connection conn_tDBInput_2 = null;
				String driverClass_tDBInput_2 = "oracle.jdbc.OracleDriver";
				java.lang.Class.forName(driverClass_tDBInput_2);
				
			String url_tDBInput_2 = null;
				url_tDBInput_2 = "jdbc:oracle:thin:@(description=(address=(protocol=tcp)(host=" + "" + ")(port=" + "1521" + "))(connect_data=(service_name=" + "XEPDB1" + ")))";

				String dbUser_tDBInput_2 = "DSID_LIV_OPE";

				

				 
	final String decryptedPassword_tDBInput_2 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:66NtP2eCWsZtqrkchjJkoXUOOhuC98TipRXk0h0uuu4=");

				String dbPwd_tDBInput_2 = decryptedPassword_tDBInput_2;

				
					conn_tDBInput_2 = java.sql.DriverManager.getConnection(url_tDBInput_2,dbUser_tDBInput_2,dbPwd_tDBInput_2);
				java.sql.Statement stmtGetTZ_tDBInput_2 = conn_tDBInput_2.createStatement();
				java.sql.ResultSet rsGetTZ_tDBInput_2 = stmtGetTZ_tDBInput_2.executeQuery("select sessiontimezone from dual");
				String sessionTimezone_tDBInput_2 = java.util.TimeZone.getDefault().getID();
				while (rsGetTZ_tDBInput_2.next()) {
					sessionTimezone_tDBInput_2 = rsGetTZ_tDBInput_2.getString(1);
				}
                                if (!(conn_tDBInput_2 instanceof oracle.jdbc.OracleConnection) &&
                                        conn_tDBInput_2.isWrapperFor(oracle.jdbc.OracleConnection.class)) {
                                    if (conn_tDBInput_2.unwrap(oracle.jdbc.OracleConnection.class) != null) {
                                        ((oracle.jdbc.OracleConnection)conn_tDBInput_2.unwrap(oracle.jdbc.OracleConnection.class)).setSessionTimeZone(sessionTimezone_tDBInput_2);
                                    }
                                } else {
                                    ((oracle.jdbc.OracleConnection)conn_tDBInput_2).setSessionTimeZone(sessionTimezone_tDBInput_2);
                                }
		    
			java.sql.Statement stmt_tDBInput_2 = conn_tDBInput_2.createStatement();

		    String dbquery_tDBInput_2 = "SELECT \n  DSID_LIV_OPE.ADRESSE_RESTAURANT.ID_ADRESSE_RESTAURANT, \n  DSID_LIV_OPE.ADRESSE_RESTAURANT.ADRESSE_RESTAURANT\n"
+"FROM DSID_LIV_OPE.ADRESSE_RESTAURANT";
		    

            	globalMap.put("tDBInput_2_QUERY",dbquery_tDBInput_2);
		    java.sql.ResultSet rs_tDBInput_2 = null;

		    try {
		    	rs_tDBInput_2 = stmt_tDBInput_2.executeQuery(dbquery_tDBInput_2);
		    	java.sql.ResultSetMetaData rsmd_tDBInput_2 = rs_tDBInput_2.getMetaData();
		    	int colQtyInRs_tDBInput_2 = rsmd_tDBInput_2.getColumnCount();

		    String tmpContent_tDBInput_2 = null;
		    
		    
		    while (rs_tDBInput_2.next()) {
		        nb_line_tDBInput_2++;
		        
							if(colQtyInRs_tDBInput_2 < 1) {
								row3.ID_ADRESSE_RESTAURANT = null;
							} else {
		                          
					if(rs_tDBInput_2.getObject(1) != null) {
						row3.ID_ADRESSE_RESTAURANT = rs_tDBInput_2.getBigDecimal(1);
					} else {
				
 	                	throw new RuntimeException("Null value in non-Nullable column");
					}
		                    }
							if(colQtyInRs_tDBInput_2 < 2) {
								row3.ADRESSE_RESTAURANT = null;
							} else {
	                         		
        	row3.ADRESSE_RESTAURANT = routines.system.JDBCUtil.getString(rs_tDBInput_2, 2, false);
		                    }
					




 



/**
 * [tDBInput_2 begin ] stop
 */
	
	/**
	 * [tDBInput_2 main ] start
	 */

	

	
	
	currentComponent="tDBInput_2";

	

 


	tos_count_tDBInput_2++;

/**
 * [tDBInput_2 main ] stop
 */
	
	/**
	 * [tDBInput_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBInput_2";

	

 



/**
 * [tDBInput_2 process_data_begin ] stop
 */

	
	/**
	 * [tFlowToIterate_2 main ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_2";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row3"
						
						);
					}
					


    	            
            globalMap.put("row3.ID_ADRESSE_RESTAURANT", row3.ID_ADRESSE_RESTAURANT);
    	            
            globalMap.put("row3.ADRESSE_RESTAURANT", row3.ADRESSE_RESTAURANT);
    	
 
	   nb_line_tFlowToIterate_2++;  
       counter_tFlowToIterate_2++;
       globalMap.put("tFlowToIterate_2_CURRENT_ITERATION", counter_tFlowToIterate_2);
 


	tos_count_tFlowToIterate_2++;

/**
 * [tFlowToIterate_2 main ] stop
 */
	
	/**
	 * [tFlowToIterate_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_2";

	

 



/**
 * [tFlowToIterate_2 process_data_begin ] stop
 */
	NB_ITERATE_tJava_2++;
	
	
					if(execStat){				
	       				runStat.updateStatOnConnection("row6", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row7", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row9", 3, 0);
					}           			
				
				if(execStat){
					runStat.updateStatOnConnection("iterate2", 1, "exec" + NB_ITERATE_tJava_2);
					//Thread.sleep(1000);
				}				
			




	
	/**
	 * [tDBOutput_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_2", false);
		start_Hash.put("tDBOutput_2", System.currentTimeMillis());
		
				tStatCatcher_1.addMessage("begin","tDBOutput_2");
				tStatCatcher_1Process(globalMap);
			
	
	currentComponent="tDBOutput_2";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row9");
					}
				
		int tos_count_tDBOutput_2 = 0;
		






    
    int nb_line_tDBOutput_2 = 0;
    int nb_line_update_tDBOutput_2 = 0;
    int nb_line_inserted_tDBOutput_2 = 0;
    int nb_line_deleted_tDBOutput_2 = 0;
    int nb_line_rejected_tDBOutput_2 = 0;

    int tmp_batchUpdateCount_tDBOutput_2 = 0;

    int deletedCount_tDBOutput_2=0;
    int updatedCount_tDBOutput_2=0;
    int insertedCount_tDBOutput_2=0;
    int rowsToCommitCount_tDBOutput_2=0;
    int rejectedCount_tDBOutput_2=0;

    boolean whetherReject_tDBOutput_2 = false;

    java.sql.Connection conn_tDBOutput_2 = null;

    //optional table
    String dbschema_tDBOutput_2 = null;
    String tableName_tDBOutput_2 = null;
                    String driverClass_tDBOutput_2 = "oracle.jdbc.OracleDriver";


                java.lang.Class.forName(driverClass_tDBOutput_2);
                String url_tDBOutput_2 = null;
                    url_tDBOutput_2 = "jdbc:oracle:thin:@(description=(address=(protocol=tcp)(host=" + "" + ")(port=" + "1521" + "))(connect_data=(service_name=" + "XEPDB1" + ")))";
                String dbUser_tDBOutput_2 = "DSID_LIV_OPE";
 
	final String decryptedPassword_tDBOutput_2 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:tjnYZZqX0q3RWY2veT/GVQoJ8l7aSK+gcSe7TbCMs5I=");

                String dbPwd_tDBOutput_2 = decryptedPassword_tDBOutput_2;
                dbschema_tDBOutput_2 = "DSID_LIV_OPE";


                    conn_tDBOutput_2 = java.sql.DriverManager.getConnection(url_tDBOutput_2, dbUser_tDBOutput_2, dbPwd_tDBOutput_2);
        resourceMap.put("conn_tDBOutput_2", conn_tDBOutput_2);
            conn_tDBOutput_2.setAutoCommit(false);
            int commitEvery_tDBOutput_2 = 10000;
            int commitCounter_tDBOutput_2 = 0;
        int batchSize_tDBOutput_2 = 10000;
        int batchSizeCounter_tDBOutput_2=0;
        int count_tDBOutput_2=0;

        if(dbschema_tDBOutput_2 == null || dbschema_tDBOutput_2.trim().length() == 0) {
            tableName_tDBOutput_2 = ("ADRESSE_NORMALISEE_RESTAURANT");
        } else {
            tableName_tDBOutput_2 = dbschema_tDBOutput_2 + "." + ("ADRESSE_NORMALISEE_RESTAURANT");
        }
                String insert_tDBOutput_2 = "INSERT INTO " + tableName_tDBOutput_2 + " (" + "ID_ADRESSE_NORM_RESTAURANT" + "," + "ID_ADRESSE_RESTAURANT" + ",NUMERO_VOIE,NOM_VOIE,CODE_POSTAL,NOM_VILLE,LONGITUDE,LATITUDE) VALUES (" + "dsid_liv_ope.seq_id_adresse_norm_restaurant.nextval" + "," + ((BigDecimal)globalMap.get("row3.ID_ADRESSE_RESTAURANT")) + ",?,?,?,?,?,?)";    

                        java.sql.PreparedStatement pstmt_tDBOutput_2 = conn_tDBOutput_2.prepareStatement(insert_tDBOutput_2);
                        resourceMap.put("pstmt_tDBOutput_2", pstmt_tDBOutput_2);





 



/**
 * [tDBOutput_2 begin ] stop
 */



	
	/**
	 * [tExtractJSONFields_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tExtractJSONFields_2", false);
		start_Hash.put("tExtractJSONFields_2", System.currentTimeMillis());
		
				tStatCatcher_1.addMessage("begin","tExtractJSONFields_2");
				tStatCatcher_1Process(globalMap);
			
	
	currentComponent="tExtractJSONFields_2";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row6");
					}
				
		int tos_count_tExtractJSONFields_2 = 0;
		

int nb_line_tExtractJSONFields_2 = 0;
String jsonStr_tExtractJSONFields_2 = "";

	

class JsonPathCache_tExtractJSONFields_2 {
	final java.util.Map<String,com.jayway.jsonpath.JsonPath> jsonPathString2compiledJsonPath = new java.util.HashMap<String,com.jayway.jsonpath.JsonPath>();
	
	public com.jayway.jsonpath.JsonPath getCompiledJsonPath(String jsonPath) {
		if(jsonPathString2compiledJsonPath.containsKey(jsonPath)) {
			return jsonPathString2compiledJsonPath.get(jsonPath);
		} else {
			com.jayway.jsonpath.JsonPath compiledLoopPath = com.jayway.jsonpath.JsonPath.compile(jsonPath);
			jsonPathString2compiledJsonPath.put(jsonPath,compiledLoopPath);
			return compiledLoopPath;
		}
	}
}

JsonPathCache_tExtractJSONFields_2 jsonPathCache_tExtractJSONFields_2 = new JsonPathCache_tExtractJSONFields_2();

 



/**
 * [tExtractJSONFields_2 begin ] stop
 */



	
	/**
	 * [tRESTClient_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tRESTClient_2", false);
		start_Hash.put("tRESTClient_2", System.currentTimeMillis());
		
				tStatCatcher_1.addMessage("begin","tRESTClient_2");
				tStatCatcher_1Process(globalMap);
			
	
	currentComponent="tRESTClient_2";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row7");
					}
				
		int tos_count_tRESTClient_2 = 0;
		

 



/**
 * [tRESTClient_2 begin ] stop
 */



	
	/**
	 * [tJava_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_2", false);
		start_Hash.put("tJava_2", System.currentTimeMillis());
		
				tStatCatcher_1.addMessage("begin","tJava_2");
				tStatCatcher_1Process(globalMap);
			
	
	currentComponent="tJava_2";

	
		int tos_count_tJava_2 = 0;
		



 



/**
 * [tJava_2 begin ] stop
 */
	
	/**
	 * [tJava_2 main ] start
	 */

	

	
	
	currentComponent="tJava_2";

	

 


	tos_count_tJava_2++;

/**
 * [tJava_2 main ] stop
 */
	
	/**
	 * [tJava_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tJava_2";

	

 



/**
 * [tJava_2 process_data_begin ] stop
 */

	
	/**
	 * [tRESTClient_2 main ] start
	 */

	

	
	
	currentComponent="tRESTClient_2";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row7"
						
						);
					}
					
	row6 = null;

// expected response body
Object responseDoc_tRESTClient_2 = null;

try {
	// request body
	org.dom4j.Document requestDoc_tRESTClient_2 = null;
	String requestString_tRESTClient_2 = null;
			if (null != row7.body) {
				requestDoc_tRESTClient_2 = row7.body.getDocument();
			}
			requestString_tRESTClient_2 = row7.string;

	Object requestBody_tRESTClient_2 = requestDoc_tRESTClient_2 != null ? requestDoc_tRESTClient_2 : requestString_tRESTClient_2;

	

    //resposne class name
	Class<?> responseClass_tRESTClient_2
		= String.class;

	// create web client instance
	org.apache.cxf.jaxrs.client.JAXRSClientFactoryBean factoryBean_tRESTClient_2 =
			new org.apache.cxf.jaxrs.client.JAXRSClientFactoryBean();

	boolean inOSGi = routines.system.BundleUtils.inOSGi();

	final java.util.List<org.apache.cxf.feature.Feature> features_tRESTClient_2 =
			new java.util.ArrayList<org.apache.cxf.feature.Feature>();

	
		String url = "https://api-adresse.data.gouv.fr";
		// {baseUri}tRESTClient
		factoryBean_tRESTClient_2.setServiceName(new javax.xml.namespace.QName(url, "tRESTClient"));
		factoryBean_tRESTClient_2.setAddress(url);
	

	

	

	

	factoryBean_tRESTClient_2.setFeatures(features_tRESTClient_2);


	java.util.List<Object> providers_tRESTClient_2 = new java.util.ArrayList<Object>();
	providers_tRESTClient_2.add(new org.apache.cxf.jaxrs.provider.dom4j.DOM4JProvider() {
		// workaround for https://jira.talendforge.org/browse/TESB-7276
		public org.dom4j.Document readFrom(Class<org.dom4j.Document> cls,
											java.lang.reflect.Type type,
											java.lang.annotation.Annotation[] anns,
											javax.ws.rs.core.MediaType mt,
											javax.ws.rs.core.MultivaluedMap<String, String> headers,
											java.io.InputStream is)
				throws IOException, javax.ws.rs.WebApplicationException {
			String contentLength = headers.getFirst("Content-Length");
			if (!org.apache.cxf.common.util.StringUtils.isEmpty(contentLength)
					&& Integer.valueOf(contentLength) <= 0) {
				try {
					return org.dom4j.DocumentHelper.parseText("<root/>");
				} catch (org.dom4j.DocumentException e_tRESTClient_2) {
					e_tRESTClient_2.printStackTrace();
				}
				return null;
			}
			return super.readFrom(cls, type, anns, mt, headers, is);
		}
	});
	org.apache.cxf.jaxrs.provider.json.JSONProvider jsonProvider_tRESTClient_2 =
			new org.apache.cxf.jaxrs.provider.json.JSONProvider();
		jsonProvider_tRESTClient_2.setIgnoreNamespaces(true);
		jsonProvider_tRESTClient_2.setAttributesToElements(true);
	
	
	
		jsonProvider_tRESTClient_2.setSupportUnwrapped(true);
		jsonProvider_tRESTClient_2.setWrapperName("root");
	
	
		jsonProvider_tRESTClient_2.setDropRootElement(false);
		jsonProvider_tRESTClient_2.setConvertTypesToStrings(false);
	providers_tRESTClient_2.add(jsonProvider_tRESTClient_2);
	factoryBean_tRESTClient_2.setProviders(providers_tRESTClient_2);
	factoryBean_tRESTClient_2.setTransportId("http://cxf.apache.org/transports/http");

	boolean use_auth_tRESTClient_2 = false;

	

	org.apache.cxf.jaxrs.client.WebClient webClient_tRESTClient_2 = factoryBean_tRESTClient_2.createWebClient();

	// set request path
	webClient_tRESTClient_2.path("search");

	// set connection properties
	org.apache.cxf.jaxrs.client.ClientConfiguration clientConfig_tRESTClient_2 = org.apache.cxf.jaxrs.client.WebClient.getConfig(webClient_tRESTClient_2);
	org.apache.cxf.transport.http.auth.HttpAuthSupplier httpAuthSupplerHttpConduit = null;
	org.apache.cxf.transport.http.HTTPConduit conduit_tRESTClient_2 = clientConfig_tRESTClient_2.getHttpConduit();

    if (clientConfig_tRESTClient_2.getEndpoint() != null) {
		org.apache.cxf.service.model.EndpointInfo endpointInfo_tRESTClient_2 = clientConfig_tRESTClient_2.getEndpoint().getEndpointInfo();
		if(endpointInfo_tRESTClient_2 != null) {
			endpointInfo_tRESTClient_2.setProperty("enable.webclient.operation.reporting", true);
		}
    }

	

	

	if (!inOSGi) {
		conduit_tRESTClient_2.getClient().setReceiveTimeout((long)(60 * 1000L));
		conduit_tRESTClient_2.getClient().setConnectionTimeout((long)(30 * 1000L));
		boolean use_proxy_tRESTClient_2 = false;
		
	}
	
	

	

	

	
		// set Accept-Type
		webClient_tRESTClient_2.accept("application/json");
	

	
		// set optional query and header properties if any
	
	if (use_auth_tRESTClient_2 && "OAUTH2_BEARER".equals("BASIC")) {
		// set oAuth2 bearer token
		org.apache.cxf.rs.security.oauth2.client.BearerAuthSupplier authSupplier = new org.apache.cxf.rs.security.oauth2.client.BearerAuthSupplier();
		authSupplier.setAccessToken("");
		conduit_tRESTClient_2.setAuthSupplier(authSupplier);
	}

	

	// if FORM request then capture query parameters into Form, otherwise set them as queries
	
		
			webClient_tRESTClient_2.query("q" ,((String)globalMap.get("row3.ADRESSE_RESTAURANT")));
		
			webClient_tRESTClient_2.query("limit" ,"1");
		
	


	try {
		// start send request
		
			responseDoc_tRESTClient_2 = webClient_tRESTClient_2.get();
			javax.ws.rs.core.Response responseObjBase_tRESTClient_2 = (javax.ws.rs.core.Response)responseDoc_tRESTClient_2;
            int status_tRESTClient_2 = responseObjBase_tRESTClient_2.getStatus();
            if (status_tRESTClient_2 != 304 && status_tRESTClient_2 >= 300 && responseClass_tRESTClient_2 != javax.ws.rs.core.Response.class) {
                throw org.apache.cxf.jaxrs.utils.ExceptionUtils.toWebApplicationException((javax.ws.rs.core.Response)responseObjBase_tRESTClient_2);
            }
            if (responseObjBase_tRESTClient_2.getEntity() != null) {
				responseDoc_tRESTClient_2 = responseObjBase_tRESTClient_2.readEntity(responseClass_tRESTClient_2);
			}
		


		int webClientResponseStatus_tRESTClient_2 = webClient_tRESTClient_2.getResponse().getStatus();
		if (webClientResponseStatus_tRESTClient_2 >= 300) {
			throw new javax.ws.rs.WebApplicationException(webClient_tRESTClient_2.getResponse());
		}

		
			if (row6 == null) {
				row6 = new row6Struct();
			}

			row6.statusCode = webClientResponseStatus_tRESTClient_2;
			row6.string = "";
			
				
				{
					Object responseObj_tRESTClient_2 = responseDoc_tRESTClient_2;
				
				if(responseObj_tRESTClient_2 != null){
					if (responseClass_tRESTClient_2 == String.class && responseObj_tRESTClient_2 instanceof String) {
							row6.string = (String) responseObj_tRESTClient_2;
					} else {
						routines.system.Document responseTalendDoc_tRESTClient_2 = null;
						if (null != responseObj_tRESTClient_2) {
							responseTalendDoc_tRESTClient_2 = new routines.system.Document();
							if (responseObj_tRESTClient_2 instanceof org.dom4j.Document) {
								responseTalendDoc_tRESTClient_2.setDocument((org.dom4j.Document) responseObj_tRESTClient_2);
							}
						}
						row6.body = responseTalendDoc_tRESTClient_2;
					}
				}
			}
			


			globalMap.put("tRESTClient_2_HEADERS", webClient_tRESTClient_2.getResponse().getHeaders());
			globalMap.put("tRESTClient_2_COOKIES", webClient_tRESTClient_2.getResponse().getCookies());
			
		

	} catch (javax.ws.rs.WebApplicationException ex_tRESTClient_2) {
	    globalMap.put("tRESTClient_2_ERROR_MESSAGE",ex_tRESTClient_2.getMessage());
		
			throw ex_tRESTClient_2;
		
	}

} catch(Exception e_tRESTClient_2) {
    globalMap.put("tRESTClient_2_ERROR_MESSAGE",e_tRESTClient_2.getMessage());
	
		throw new TalendException(e_tRESTClient_2, currentComponent, globalMap);
	
}


 


	tos_count_tRESTClient_2++;

/**
 * [tRESTClient_2 main ] stop
 */
	
	/**
	 * [tRESTClient_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tRESTClient_2";

	

 



/**
 * [tRESTClient_2 process_data_begin ] stop
 */
// Start of branch "row6"
if(row6 != null) { 



	
	/**
	 * [tExtractJSONFields_2 main ] start
	 */

	

	
	
	currentComponent="tExtractJSONFields_2";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row6"
						
						);
					}
					

            if(row6.string!=null){// C_01
                jsonStr_tExtractJSONFields_2 = row6.string.toString();
   
row9 = null;

	

String loopPath_tExtractJSONFields_2 = "$.features.[*]";
java.util.List<Object> resultset_tExtractJSONFields_2 = new java.util.ArrayList<Object>();

boolean isStructError_tExtractJSONFields_2 = true;
com.jayway.jsonpath.ReadContext document_tExtractJSONFields_2 = null;
try {
	document_tExtractJSONFields_2 = com.jayway.jsonpath.JsonPath.parse(jsonStr_tExtractJSONFields_2);
	com.jayway.jsonpath.JsonPath compiledLoopPath_tExtractJSONFields_2 = jsonPathCache_tExtractJSONFields_2.getCompiledJsonPath(loopPath_tExtractJSONFields_2);
	Object result_tExtractJSONFields_2 = document_tExtractJSONFields_2.read(compiledLoopPath_tExtractJSONFields_2,net.minidev.json.JSONObject.class);
	if (result_tExtractJSONFields_2 instanceof net.minidev.json.JSONArray) {
		resultset_tExtractJSONFields_2 = (net.minidev.json.JSONArray) result_tExtractJSONFields_2;
	} else {
		resultset_tExtractJSONFields_2.add(result_tExtractJSONFields_2);
	}
	
	isStructError_tExtractJSONFields_2 = false;
} catch (java.lang.Exception ex_tExtractJSONFields_2) {
globalMap.put("tExtractJSONFields_2_ERROR_MESSAGE",ex_tExtractJSONFields_2.getMessage());
		System.err.println(ex_tExtractJSONFields_2.getMessage());
}

String jsonPath_tExtractJSONFields_2 = null;
com.jayway.jsonpath.JsonPath compiledJsonPath_tExtractJSONFields_2 = null;

Object value_tExtractJSONFields_2 = null;

Object root_tExtractJSONFields_2 = null;
for(int i_tExtractJSONFields_2=0; isStructError_tExtractJSONFields_2 || (i_tExtractJSONFields_2 < resultset_tExtractJSONFields_2.size());i_tExtractJSONFields_2++){
	if(!isStructError_tExtractJSONFields_2){
		Object row_tExtractJSONFields_2 = resultset_tExtractJSONFields_2.get(i_tExtractJSONFields_2);
            row9 = null;
	row9 = new row9Struct();
	nb_line_tExtractJSONFields_2++;
	try {
		jsonPath_tExtractJSONFields_2 = "properties.housenumber";
		compiledJsonPath_tExtractJSONFields_2 = jsonPathCache_tExtractJSONFields_2.getCompiledJsonPath(jsonPath_tExtractJSONFields_2);
		
		try {
		    
		        value_tExtractJSONFields_2 = compiledJsonPath_tExtractJSONFields_2.read(row_tExtractJSONFields_2);
		    
				row9.NUMERO_VOIE = value_tExtractJSONFields_2 == null ? 

		null

 : value_tExtractJSONFields_2.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_2) {
globalMap.put("tExtractJSONFields_2_ERROR_MESSAGE",e_tExtractJSONFields_2.getMessage());
			row9.NUMERO_VOIE = 

		null

;
		}
		jsonPath_tExtractJSONFields_2 = "properties.name";
		compiledJsonPath_tExtractJSONFields_2 = jsonPathCache_tExtractJSONFields_2.getCompiledJsonPath(jsonPath_tExtractJSONFields_2);
		
		try {
		    
		        value_tExtractJSONFields_2 = compiledJsonPath_tExtractJSONFields_2.read(row_tExtractJSONFields_2);
		    
				row9.NOM_VOIE = value_tExtractJSONFields_2 == null ? 

		null

 : value_tExtractJSONFields_2.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_2) {
globalMap.put("tExtractJSONFields_2_ERROR_MESSAGE",e_tExtractJSONFields_2.getMessage());
			row9.NOM_VOIE = 

		null

;
		}
		jsonPath_tExtractJSONFields_2 = "properties.postcode";
		compiledJsonPath_tExtractJSONFields_2 = jsonPathCache_tExtractJSONFields_2.getCompiledJsonPath(jsonPath_tExtractJSONFields_2);
		
		try {
		    
		        value_tExtractJSONFields_2 = compiledJsonPath_tExtractJSONFields_2.read(row_tExtractJSONFields_2);
		    
				row9.CODE_POSTAL = value_tExtractJSONFields_2 == null ? 

		null

 : value_tExtractJSONFields_2.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_2) {
globalMap.put("tExtractJSONFields_2_ERROR_MESSAGE",e_tExtractJSONFields_2.getMessage());
			row9.CODE_POSTAL = 

		null

;
		}
		jsonPath_tExtractJSONFields_2 = "properties.city";
		compiledJsonPath_tExtractJSONFields_2 = jsonPathCache_tExtractJSONFields_2.getCompiledJsonPath(jsonPath_tExtractJSONFields_2);
		
		try {
		    
		        value_tExtractJSONFields_2 = compiledJsonPath_tExtractJSONFields_2.read(row_tExtractJSONFields_2);
		    
				row9.NOM_VILLE = value_tExtractJSONFields_2 == null ? 

		null

 : value_tExtractJSONFields_2.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_2) {
globalMap.put("tExtractJSONFields_2_ERROR_MESSAGE",e_tExtractJSONFields_2.getMessage());
			row9.NOM_VILLE = 

		null

;
		}
		jsonPath_tExtractJSONFields_2 = "geometry.coordinates.[0]";
		compiledJsonPath_tExtractJSONFields_2 = jsonPathCache_tExtractJSONFields_2.getCompiledJsonPath(jsonPath_tExtractJSONFields_2);
		
		try {
		    
		        value_tExtractJSONFields_2 = compiledJsonPath_tExtractJSONFields_2.read(row_tExtractJSONFields_2);
		    
				row9.LONGITUDE = value_tExtractJSONFields_2 == null ? 

		null

 : value_tExtractJSONFields_2.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_2) {
globalMap.put("tExtractJSONFields_2_ERROR_MESSAGE",e_tExtractJSONFields_2.getMessage());
			row9.LONGITUDE = 

		null

;
		}
		jsonPath_tExtractJSONFields_2 = "geometry.coordinates.[1]";
		compiledJsonPath_tExtractJSONFields_2 = jsonPathCache_tExtractJSONFields_2.getCompiledJsonPath(jsonPath_tExtractJSONFields_2);
		
		try {
		    
		        value_tExtractJSONFields_2 = compiledJsonPath_tExtractJSONFields_2.read(row_tExtractJSONFields_2);
		    
				row9.LATITUDE = value_tExtractJSONFields_2 == null ? 

		null

 : value_tExtractJSONFields_2.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_2) {
globalMap.put("tExtractJSONFields_2_ERROR_MESSAGE",e_tExtractJSONFields_2.getMessage());
			row9.LATITUDE = 

		null

;
		}	
	} catch (java.lang.Exception ex_tExtractJSONFields_2) {
globalMap.put("tExtractJSONFields_2_ERROR_MESSAGE",ex_tExtractJSONFields_2.getMessage());
		    System.err.println(ex_tExtractJSONFields_2.getMessage());
		    row9 = null;	
	}
	
	}
    
	isStructError_tExtractJSONFields_2 = false;
	
//}


 


	tos_count_tExtractJSONFields_2++;

/**
 * [tExtractJSONFields_2 main ] stop
 */
	
	/**
	 * [tExtractJSONFields_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tExtractJSONFields_2";

	

 



/**
 * [tExtractJSONFields_2 process_data_begin ] stop
 */
// Start of branch "row9"
if(row9 != null) { 



	
	/**
	 * [tDBOutput_2 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row9"
						
						);
					}
					



        whetherReject_tDBOutput_2 = false;
                        if(row9.NUMERO_VOIE == null) {
pstmt_tDBOutput_2.setNull(1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(1, row9.NUMERO_VOIE);
}

                        if(row9.NOM_VOIE == null) {
pstmt_tDBOutput_2.setNull(2, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(2, row9.NOM_VOIE);
}

                        if(row9.CODE_POSTAL == null) {
pstmt_tDBOutput_2.setNull(3, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(3, row9.CODE_POSTAL);
}

                        if(row9.NOM_VILLE == null) {
pstmt_tDBOutput_2.setNull(4, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(4, row9.NOM_VILLE);
}

                        if(row9.LONGITUDE == null) {
pstmt_tDBOutput_2.setNull(5, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(5, row9.LONGITUDE);
}

                        if(row9.LATITUDE == null) {
pstmt_tDBOutput_2.setNull(6, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(6, row9.LATITUDE);
}

                pstmt_tDBOutput_2.addBatch();
                nb_line_tDBOutput_2++;
                batchSizeCounter_tDBOutput_2++;
            if (batchSize_tDBOutput_2 > 0 &&  batchSize_tDBOutput_2 <= batchSizeCounter_tDBOutput_2) {
                try {
                    pstmt_tDBOutput_2.executeBatch();
                }catch (java.sql.BatchUpdateException e_tDBOutput_2){
globalMap.put("tDBOutput_2_ERROR_MESSAGE",e_tDBOutput_2.getMessage());
			        java.sql.SQLException ne_tDBOutput_2 = e_tDBOutput_2.getNextException(),sqle_tDBOutput_2=null;
			    	String errormessage_tDBOutput_2;
					if (ne_tDBOutput_2 != null) {
						// build new exception to provide the original cause
						sqle_tDBOutput_2 = new java.sql.SQLException(e_tDBOutput_2.getMessage() + "\ncaused by: " + ne_tDBOutput_2.getMessage(), ne_tDBOutput_2.getSQLState(), ne_tDBOutput_2.getErrorCode(), ne_tDBOutput_2);
						errormessage_tDBOutput_2 = sqle_tDBOutput_2.getMessage();
					}else{
						errormessage_tDBOutput_2 = e_tDBOutput_2.getMessage();
					}
	            	
	                	System.err.println(errormessage_tDBOutput_2);
	            	
	        	}
                tmp_batchUpdateCount_tDBOutput_2 = pstmt_tDBOutput_2.getUpdateCount();
                    insertedCount_tDBOutput_2
                += (tmp_batchUpdateCount_tDBOutput_2!=-1?tmp_batchUpdateCount_tDBOutput_2:0);
                rowsToCommitCount_tDBOutput_2 += (tmp_batchUpdateCount_tDBOutput_2!=-1?tmp_batchUpdateCount_tDBOutput_2:0);
                batchSizeCounter_tDBOutput_2 = 0;
            }
                commitCounter_tDBOutput_2++;
                if(commitEvery_tDBOutput_2 <= commitCounter_tDBOutput_2) {
                    if(batchSizeCounter_tDBOutput_2 > 0) {
                        try {
                            pstmt_tDBOutput_2.executeBatch();
                        }catch (java.sql.BatchUpdateException e_tDBOutput_2){
globalMap.put("tDBOutput_2_ERROR_MESSAGE",e_tDBOutput_2.getMessage());
					        java.sql.SQLException ne_tDBOutput_2 = e_tDBOutput_2.getNextException(),sqle_tDBOutput_2=null;
					    	String errormessage_tDBOutput_2;
							if (ne_tDBOutput_2 != null) {
								// build new exception to provide the original cause
								sqle_tDBOutput_2 = new java.sql.SQLException(e_tDBOutput_2.getMessage() + "\ncaused by: " + ne_tDBOutput_2.getMessage(), ne_tDBOutput_2.getSQLState(), ne_tDBOutput_2.getErrorCode(), ne_tDBOutput_2);
								errormessage_tDBOutput_2 = sqle_tDBOutput_2.getMessage();
							}else{
								errormessage_tDBOutput_2 = e_tDBOutput_2.getMessage();
							}
			            	
			                	System.err.println(errormessage_tDBOutput_2);
			            	
			        	}
                        tmp_batchUpdateCount_tDBOutput_2 = pstmt_tDBOutput_2.getUpdateCount();
                            insertedCount_tDBOutput_2
                        += (tmp_batchUpdateCount_tDBOutput_2!=-1?tmp_batchUpdateCount_tDBOutput_2:0);
                        rowsToCommitCount_tDBOutput_2 += (tmp_batchUpdateCount_tDBOutput_2!=-1?tmp_batchUpdateCount_tDBOutput_2:0);
                    }
                    if(rowsToCommitCount_tDBOutput_2 != 0){
                    	
                    }
                    conn_tDBOutput_2.commit();
                    if(rowsToCommitCount_tDBOutput_2 != 0){
                    	
                    	rowsToCommitCount_tDBOutput_2 = 0;
                    }
                    commitCounter_tDBOutput_2=0;
                    	batchSizeCounter_tDBOutput_2=0;
                }

 


	tos_count_tDBOutput_2++;

/**
 * [tDBOutput_2 main ] stop
 */
	
	/**
	 * [tDBOutput_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";

	

 



/**
 * [tDBOutput_2 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";

	

 



/**
 * [tDBOutput_2 process_data_end ] stop
 */

} // End of branch "row9"

		// end for
	}


	
		} // C_01
	
	
	/**
	 * [tExtractJSONFields_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tExtractJSONFields_2";

	

 



/**
 * [tExtractJSONFields_2 process_data_end ] stop
 */

} // End of branch "row6"




	
	/**
	 * [tRESTClient_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tRESTClient_2";

	

 



/**
 * [tRESTClient_2 process_data_end ] stop
 */



	
	/**
	 * [tJava_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tJava_2";

	

 



/**
 * [tJava_2 process_data_end ] stop
 */
	
	/**
	 * [tJava_2 end ] start
	 */

	

	
	
	currentComponent="tJava_2";

	

 

ok_Hash.put("tJava_2", true);
end_Hash.put("tJava_2", System.currentTimeMillis());

tStatCatcher_1.addMessage("end","tJava_2", end_Hash.get("tJava_2")-start_Hash.get("tJava_2"));
tStatCatcher_1Process(globalMap);



/**
 * [tJava_2 end ] stop
 */

	
	/**
	 * [tRESTClient_2 end ] start
	 */

	

	
	
	currentComponent="tRESTClient_2";

	


if (globalMap.get("tRESTClient_2_NB_LINE") == null) {
	globalMap.put("tRESTClient_2_NB_LINE", 1);
}

// [tRESTCliend_end]
				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row7");
			  	}
			  	
 

ok_Hash.put("tRESTClient_2", true);
end_Hash.put("tRESTClient_2", System.currentTimeMillis());

tStatCatcher_1.addMessage("end","tRESTClient_2", end_Hash.get("tRESTClient_2")-start_Hash.get("tRESTClient_2"));
tStatCatcher_1Process(globalMap);



/**
 * [tRESTClient_2 end ] stop
 */

	
	/**
	 * [tExtractJSONFields_2 end ] start
	 */

	

	
	
	currentComponent="tExtractJSONFields_2";

	
   globalMap.put("tExtractJSONFields_2_NB_LINE", nb_line_tExtractJSONFields_2);


				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row6");
			  	}
			  	
 

ok_Hash.put("tExtractJSONFields_2", true);
end_Hash.put("tExtractJSONFields_2", System.currentTimeMillis());

tStatCatcher_1.addMessage("end","tExtractJSONFields_2", end_Hash.get("tExtractJSONFields_2")-start_Hash.get("tExtractJSONFields_2"));
tStatCatcher_1Process(globalMap);



/**
 * [tExtractJSONFields_2 end ] stop
 */

	
	/**
	 * [tDBOutput_2 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";

	
	



	
        if(batchSizeCounter_tDBOutput_2 > 0) {
            try {
            	if (pstmt_tDBOutput_2 != null) {
					
					pstmt_tDBOutput_2.executeBatch();
					
        	    }
            }catch (java.sql.BatchUpdateException e_tDBOutput_2){
globalMap.put("tDBOutput_2_ERROR_MESSAGE",e_tDBOutput_2.getMessage());
		        java.sql.SQLException ne_tDBOutput_2 = e_tDBOutput_2.getNextException(),sqle_tDBOutput_2=null;
		    	String errormessage_tDBOutput_2;
				if (ne_tDBOutput_2 != null) {
					// build new exception to provide the original cause
					sqle_tDBOutput_2 = new java.sql.SQLException(e_tDBOutput_2.getMessage() + "\ncaused by: " + ne_tDBOutput_2.getMessage(), ne_tDBOutput_2.getSQLState(), ne_tDBOutput_2.getErrorCode(), ne_tDBOutput_2);
					errormessage_tDBOutput_2 = sqle_tDBOutput_2.getMessage();
				}else{
					errormessage_tDBOutput_2 = e_tDBOutput_2.getMessage();
				}
            	
                	System.err.println(errormessage_tDBOutput_2);
            	
        	}
        	if (pstmt_tDBOutput_2 != null) {
            	tmp_batchUpdateCount_tDBOutput_2 = pstmt_tDBOutput_2.getUpdateCount();
    	    	
    	    		insertedCount_tDBOutput_2
    	    	
    	    	+= (tmp_batchUpdateCount_tDBOutput_2!=-1?tmp_batchUpdateCount_tDBOutput_2:0);
				rowsToCommitCount_tDBOutput_2 += (tmp_batchUpdateCount_tDBOutput_2!=-1?tmp_batchUpdateCount_tDBOutput_2:0);
            }
        }
        if(pstmt_tDBOutput_2 != null) {
			
				pstmt_tDBOutput_2.close();
				resourceMap.remove("pstmt_tDBOutput_2");
			
        }
    resourceMap.put("statementClosed_tDBOutput_2", true);
		if(commitCounter_tDBOutput_2 > 0 && rowsToCommitCount_tDBOutput_2 != 0) {
			
		}
		conn_tDBOutput_2.commit();
		if(commitCounter_tDBOutput_2 > 0 && rowsToCommitCount_tDBOutput_2 != 0) {
			
			rowsToCommitCount_tDBOutput_2 = 0;
		}
		commitCounter_tDBOutput_2 = 0;
		
		
		conn_tDBOutput_2 .close();
		
		resourceMap.put("finish_tDBOutput_2", true);
   	

	
	nb_line_deleted_tDBOutput_2=nb_line_deleted_tDBOutput_2+ deletedCount_tDBOutput_2;
	nb_line_update_tDBOutput_2=nb_line_update_tDBOutput_2 + updatedCount_tDBOutput_2;
	nb_line_inserted_tDBOutput_2=nb_line_inserted_tDBOutput_2 + insertedCount_tDBOutput_2;
	nb_line_rejected_tDBOutput_2=nb_line_rejected_tDBOutput_2 + rejectedCount_tDBOutput_2;
	
        globalMap.put("tDBOutput_2_NB_LINE",nb_line_tDBOutput_2);
        globalMap.put("tDBOutput_2_NB_LINE_UPDATED",nb_line_update_tDBOutput_2);
        globalMap.put("tDBOutput_2_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_2);
        globalMap.put("tDBOutput_2_NB_LINE_DELETED",nb_line_deleted_tDBOutput_2);
        globalMap.put("tDBOutput_2_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_2);
    

	



				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row9");
			  	}
			  	
 

ok_Hash.put("tDBOutput_2", true);
end_Hash.put("tDBOutput_2", System.currentTimeMillis());

tStatCatcher_1.addMessage("end","tDBOutput_2", end_Hash.get("tDBOutput_2")-start_Hash.get("tDBOutput_2"));
tStatCatcher_1Process(globalMap);



/**
 * [tDBOutput_2 end ] stop
 */









						if(execStat){
							runStat.updateStatOnConnection("iterate2", 2, "exec" + NB_ITERATE_tJava_2);
						}				
					




	
	/**
	 * [tFlowToIterate_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_2";

	

 



/**
 * [tFlowToIterate_2 process_data_end ] stop
 */



	
	/**
	 * [tDBInput_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBInput_2";

	

 



/**
 * [tDBInput_2 process_data_end ] stop
 */
	
	/**
	 * [tDBInput_2 end ] start
	 */

	

	
	
	currentComponent="tDBInput_2";

	

}
}finally{
	if (rs_tDBInput_2 != null) {
		rs_tDBInput_2.close();
	}
	if (stmt_tDBInput_2 != null) {
		stmt_tDBInput_2.close();
	}
	if(conn_tDBInput_2 != null && !conn_tDBInput_2.isClosed()) {
	
			conn_tDBInput_2.close();
			
			if("com.mysql.cj.jdbc.Driver".equals((String)globalMap.get("driverClass_"))
			    && routines.system.BundleUtils.inOSGi()) {
			        Class.forName("com.mysql.cj.jdbc.AbandonedConnectionCleanupThread").
			            getMethod("checkedShutdown").invoke(null, (Object[]) null);
			}
			
	}
	
}

globalMap.put("tDBInput_2_NB_LINE",nb_line_tDBInput_2);
 

ok_Hash.put("tDBInput_2", true);
end_Hash.put("tDBInput_2", System.currentTimeMillis());

tStatCatcher_1.addMessage("end","tDBInput_2", end_Hash.get("tDBInput_2")-start_Hash.get("tDBInput_2"));
tStatCatcher_1Process(globalMap);



/**
 * [tDBInput_2 end ] stop
 */

	
	/**
	 * [tFlowToIterate_2 end ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_2";

	

globalMap.put("tFlowToIterate_2_NB_LINE",nb_line_tFlowToIterate_2);
				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row3");
			  	}
			  	
 

ok_Hash.put("tFlowToIterate_2", true);
end_Hash.put("tFlowToIterate_2", System.currentTimeMillis());

tStatCatcher_1.addMessage("end","tFlowToIterate_2", end_Hash.get("tFlowToIterate_2")-start_Hash.get("tFlowToIterate_2"));
tStatCatcher_1Process(globalMap);



/**
 * [tFlowToIterate_2 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBInput_2 finally ] start
	 */

	

	
	
	currentComponent="tDBInput_2";

	

 



/**
 * [tDBInput_2 finally ] stop
 */

	
	/**
	 * [tFlowToIterate_2 finally ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_2";

	

 



/**
 * [tFlowToIterate_2 finally ] stop
 */

	
	/**
	 * [tJava_2 finally ] start
	 */

	

	
	
	currentComponent="tJava_2";

	

 



/**
 * [tJava_2 finally ] stop
 */

	
	/**
	 * [tRESTClient_2 finally ] start
	 */

	

	
	
	currentComponent="tRESTClient_2";

	

 



/**
 * [tRESTClient_2 finally ] stop
 */

	
	/**
	 * [tExtractJSONFields_2 finally ] start
	 */

	

	
	
	currentComponent="tExtractJSONFields_2";

	

 



/**
 * [tExtractJSONFields_2 finally ] stop
 */

	
	/**
	 * [tDBOutput_2 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";

	



    try {
    if (resourceMap.get("statementClosed_tDBOutput_2") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_2 = null;
                if ((pstmtToClose_tDBOutput_2 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_2")) != null) {
                    pstmtToClose_tDBOutput_2.close();
                }
    }
    } finally {
        if(resourceMap.get("finish_tDBOutput_2") == null){
            java.sql.Connection ctn_tDBOutput_2 = null;
            if((ctn_tDBOutput_2 = (java.sql.Connection)resourceMap.get("conn_tDBOutput_2")) != null){
                try {
                    ctn_tDBOutput_2.close();
                } catch (java.sql.SQLException sqlEx_tDBOutput_2) {
                    String errorMessage_tDBOutput_2 = "failed to close the connection in tDBOutput_2 :" + sqlEx_tDBOutput_2.getMessage();
                    System.err.println(errorMessage_tDBOutput_2);
                }
            }
        }
    }
 



/**
 * [tDBOutput_2 finally ] stop
 */















				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBInput_2_SUBPROCESS_STATE", 1);
	}
	
    public String resuming_logs_dir_path = null;
    public String resuming_checkpoint_path = null;
    public String parent_part_launcher = null;
    private String resumeEntryMethodName = null;
    private boolean globalResumeTicket = false;

    public boolean watch = false;
    // portStats is null, it means don't execute the statistics
    public Integer portStats = null;
    public int portTraces = 4334;
    public String clientHost;
    public String defaultClientHost = "localhost";
    public String contextStr = "Default";
    public boolean isDefaultContext = true;
    public String pid = "0";
    public String rootPid = null;
    public String fatherPid = null;
    public String fatherNode = null;
    public long startTime = 0;
    public boolean isChildJob = false;
    public String log4jLevel = "";
    
    private boolean enableLogStash;

    private boolean execStat = true;

    private ThreadLocal<java.util.Map<String, String>> threadLocal = new ThreadLocal<java.util.Map<String, String>>() {
        protected java.util.Map<String, String> initialValue() {
            java.util.Map<String,String> threadRunResultMap = new java.util.HashMap<String, String>();
            threadRunResultMap.put("errorCode", null);
            threadRunResultMap.put("status", "");
            return threadRunResultMap;
        };
    };


    protected PropertiesWithType context_param = new PropertiesWithType();
    public java.util.Map<String, Object> parentContextMap = new java.util.HashMap<String, Object>();

    public String status= "";
    

    public static void main(String[] args){
        final C_ALIM_SI_OPE_API C_ALIM_SI_OPE_APIClass = new C_ALIM_SI_OPE_API();

        int exitCode = C_ALIM_SI_OPE_APIClass.runJobInTOS(args);

        System.exit(exitCode);
    }


    public String[][] runJob(String[] args) {

        int exitCode = runJobInTOS(args);
        String[][] bufferValue = new String[][] { { Integer.toString(exitCode) } };

        return bufferValue;
    }

    public boolean hastBufferOutputComponent() {
		boolean hastBufferOutput = false;
    	
        return hastBufferOutput;
    }

    public int runJobInTOS(String[] args) {
	   	// reset status
	   	status = "";
	   	
        String lastStr = "";
        for (String arg : args) {
            if (arg.equalsIgnoreCase("--context_param")) {
                lastStr = arg;
            } else if (lastStr.equals("")) {
                evalParam(arg);
            } else {
                evalParam(lastStr + " " + arg);
                lastStr = "";
            }
        }
        enableLogStash = "true".equalsIgnoreCase(System.getProperty("audit.enabled"));

    	
    	

        if(clientHost == null) {
            clientHost = defaultClientHost;
        }

        if(pid == null || "0".equals(pid)) {
            pid = TalendString.getAsciiRandomString(6);
        }

        if (rootPid==null) {
            rootPid = pid;
        }
        if (fatherPid==null) {
            fatherPid = pid;
        }else{
            isChildJob = true;
        }

        if (portStats != null) {
            // portStats = -1; //for testing
            if (portStats < 0 || portStats > 65535) {
                // issue:10869, the portStats is invalid, so this client socket can't open
                System.err.println("The statistics socket port " + portStats + " is invalid.");
                execStat = false;
            }
        } else {
            execStat = false;
        }
        boolean inOSGi = routines.system.BundleUtils.inOSGi();

        if (inOSGi) {
            java.util.Dictionary<String, Object> jobProperties = routines.system.BundleUtils.getJobProperties(jobName);

            if (jobProperties != null && jobProperties.get("context") != null) {
                contextStr = (String)jobProperties.get("context");
            }
        }

        try {
            //call job/subjob with an existing context, like: --context=production. if without this parameter, there will use the default context instead.
            java.io.InputStream inContext = C_ALIM_SI_OPE_API.class.getClassLoader().getResourceAsStream("alimentation_si_ope/c_alim_si_ope_api_0_1/contexts/" + contextStr + ".properties");
            if (inContext == null) {
                inContext = C_ALIM_SI_OPE_API.class.getClassLoader().getResourceAsStream("config/contexts/" + contextStr + ".properties");
            }
            if (inContext != null) {
                try {
                    //defaultProps is in order to keep the original context value
                    if(context != null && context.isEmpty()) {
	                defaultProps.load(inContext);
	                context = new ContextProperties(defaultProps);
                    }
                } finally {
                    inContext.close();
                }
            } else if (!isDefaultContext) {
                //print info and job continue to run, for case: context_param is not empty.
                System.err.println("Could not find the context " + contextStr);
            }

            if(!context_param.isEmpty()) {
                context.putAll(context_param);
				//set types for params from parentJobs
				for (Object key: context_param.keySet()){
					String context_key = key.toString();
					String context_type = context_param.getContextType(context_key);
					context.setContextType(context_key, context_type);

				}
            }
            class ContextProcessing {
                private void processContext_0() {
                } 
                public void processAllContext() {
                        processContext_0();
                }
            }

            new ContextProcessing().processAllContext();
        } catch (java.io.IOException ie) {
            System.err.println("Could not load context "+contextStr);
            ie.printStackTrace();
        }

        // get context value from parent directly
        if (parentContextMap != null && !parentContextMap.isEmpty()) {
        }

        //Resume: init the resumeUtil
        resumeEntryMethodName = ResumeUtil.getResumeEntryMethodName(resuming_checkpoint_path);
        resumeUtil = new ResumeUtil(resuming_logs_dir_path, isChildJob, rootPid);
        resumeUtil.initCommonInfo(pid, rootPid, fatherPid, projectName, jobName, contextStr, jobVersion);

		List<String> parametersToEncrypt = new java.util.ArrayList<String>();
        //Resume: jobStart
        resumeUtil.addLog("JOB_STARTED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","","","",resumeUtil.convertToJsonText(context,parametersToEncrypt));

if(execStat) {
    try {
        runStat.openSocket(!isChildJob);
        runStat.setAllPID(rootPid, fatherPid, pid, jobName);
        runStat.startThreadStat(clientHost, portStats);
        runStat.updateStatOnJob(RunStat.JOBSTART, fatherNode);
    } catch (java.io.IOException ioException) {
        ioException.printStackTrace();
    }
}



	
	    java.util.concurrent.ConcurrentHashMap<Object, Object> concurrentHashMap = new java.util.concurrent.ConcurrentHashMap<Object, Object>();
	    globalMap.put("concurrentHashMap", concurrentHashMap);
	

    long startUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
    long endUsedMemory = 0;
    long end = 0;

    startTime = System.currentTimeMillis();
        tStatCatcher_1.addMessage("begin");


this.globalResumeTicket = true;//to run tPreJob




        try {
            tStatCatcher_1Process(globalMap);
        } catch (java.lang.Exception e) {
            e.printStackTrace();
        }

this.globalResumeTicket = false;//to run others jobs

try {
errorCode = null;tDBRow_1Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tDBRow_1) {
globalMap.put("tDBRow_1_SUBPROCESS_STATE", -1);

e_tDBRow_1.printStackTrace();

}
try {
errorCode = null;tDBRow_2Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tDBRow_2) {
globalMap.put("tDBRow_2_SUBPROCESS_STATE", -1);

e_tDBRow_2.printStackTrace();

}

this.globalResumeTicket = true;//to run tPostJob




        end = System.currentTimeMillis();

        if (watch) {
            System.out.println((end-startTime)+" milliseconds");
        }

        endUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        if (false) {
            System.out.println((endUsedMemory - startUsedMemory) + " bytes memory increase when running : C_ALIM_SI_OPE_API");
        }
        tStatCatcher_1.addMessage(status==""?"end":status, (end-startTime));
        try {
            tStatCatcher_1Process(globalMap);
        } catch (java.lang.Exception e) {
            e.printStackTrace();
        }



if (execStat) {
    runStat.updateStatOnJob(RunStat.JOBEND, fatherNode);
    runStat.stopThreadStat();
}
    int returnCode = 0;


    if(errorCode == null) {
         returnCode = status != null && status.equals("failure") ? 1 : 0;
    } else {
         returnCode = errorCode.intValue();
    }
    resumeUtil.addLog("JOB_ENDED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","" + returnCode,"","","");

    return returnCode;

  }

    // only for OSGi env
    public void destroy() {


    }














    private java.util.Map<String, Object> getSharedConnections4REST() {
        java.util.Map<String, Object> connections = new java.util.HashMap<String, Object>();






        return connections;
    }

    private void evalParam(String arg) {
        if (arg.startsWith("--resuming_logs_dir_path")) {
            resuming_logs_dir_path = arg.substring(25);
        } else if (arg.startsWith("--resuming_checkpoint_path")) {
            resuming_checkpoint_path = arg.substring(27);
        } else if (arg.startsWith("--parent_part_launcher")) {
            parent_part_launcher = arg.substring(23);
        } else if (arg.startsWith("--watch")) {
            watch = true;
        } else if (arg.startsWith("--stat_port=")) {
            String portStatsStr = arg.substring(12);
            if (portStatsStr != null && !portStatsStr.equals("null")) {
                portStats = Integer.parseInt(portStatsStr);
            }
        } else if (arg.startsWith("--trace_port=")) {
            portTraces = Integer.parseInt(arg.substring(13));
        } else if (arg.startsWith("--client_host=")) {
            clientHost = arg.substring(14);
        } else if (arg.startsWith("--context=")) {
            contextStr = arg.substring(10);
            isDefaultContext = false;
        } else if (arg.startsWith("--father_pid=")) {
            fatherPid = arg.substring(13);
        } else if (arg.startsWith("--root_pid=")) {
            rootPid = arg.substring(11);
        } else if (arg.startsWith("--father_node=")) {
            fatherNode = arg.substring(14);
        } else if (arg.startsWith("--pid=")) {
            pid = arg.substring(6);
        } else if (arg.startsWith("--context_type")) {
            String keyValue = arg.substring(15);
			int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.setContextType(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.setContextType(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }

            }

		} else if (arg.startsWith("--context_param")) {
            String keyValue = arg.substring(16);
            int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.put(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.put(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }
            }
        } else if (arg.startsWith("--log4jLevel=")) {
            log4jLevel = arg.substring(13);
		} else if (arg.startsWith("--audit.enabled") && arg.contains("=")) {//for trunjob call
		    final int equal = arg.indexOf('=');
			final String key = arg.substring("--".length(), equal);
			System.setProperty(key, arg.substring(equal + 1));
		}
    }
    
    private static final String NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY = "<TALEND_NULL>";

    private final String[][] escapeChars = {
        {"\\\\","\\"},{"\\n","\n"},{"\\'","\'"},{"\\r","\r"},
        {"\\f","\f"},{"\\b","\b"},{"\\t","\t"}
        };
    private String replaceEscapeChars (String keyValue) {

		if (keyValue == null || ("").equals(keyValue.trim())) {
			return keyValue;
		}

		StringBuilder result = new StringBuilder();
		int currIndex = 0;
		while (currIndex < keyValue.length()) {
			int index = -1;
			// judege if the left string includes escape chars
			for (String[] strArray : escapeChars) {
				index = keyValue.indexOf(strArray[0],currIndex);
				if (index>=0) {

					result.append(keyValue.substring(currIndex, index + strArray[0].length()).replace(strArray[0], strArray[1]));
					currIndex = index + strArray[0].length();
					break;
				}
			}
			// if the left string doesn't include escape chars, append the left into the result
			if (index < 0) {
				result.append(keyValue.substring(currIndex));
				currIndex = currIndex + keyValue.length();
			}
		}

		return result.toString();
    }

    public Integer getErrorCode() {
        return errorCode;
    }


    public String getStatus() {
        return status;
    }

    ResumeUtil resumeUtil = null;
}
/************************************************************************************************
 *     227684 characters generated by Talend Open Studio for Data Integration 
 *     on the 18 janvier 2024 à 11:53:31 CET
 ************************************************************************************************/