// ============================================================================
//
// Copyright (c) 2006-2015, Talend SA
//
// Ce code source a été automatiquement généré par_Talend Open Studio for Data Integration
// / Soumis à la Licence Apache, Version 2.0 (la "Licence") ;
// votre utilisation de ce fichier doit respecter les termes de la Licence.
// Vous pouvez obtenir une copie de la Licence sur
// http://www.apache.org/licenses/LICENSE-2.0
// 
// Sauf lorsqu'explicitement prévu par la loi en vigueur ou accepté par écrit, le logiciel
// distribué sous la Licence est distribué "TEL QUEL",
// SANS GARANTIE OU CONDITION D'AUCUNE SORTE, expresse ou implicite.
// Consultez la Licence pour connaître la terminologie spécifique régissant les autorisations et
// les limites prévues par la Licence.


package alimentation_si_ope.a_alim_si_ope_fichier_bq_0_1;

import routines.Numeric;
import routines.DataOperation;
import routines.TalendDataGenerator;
import routines.TalendStringUtil;
import routines.TalendString;
import routines.StringHandling;
import routines.Relational;
import routines.TalendDate;
import routines.Mathematical;
import routines.system.*;
import routines.system.api.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.math.BigDecimal;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.util.Comparator;
 





@SuppressWarnings("unused")

/**
 * Job: A_ALIM_SI_OPE_FICHIER_BQ Purpose: Alimenter les tables via des fichiers ou par Big Query<br>
 * Description: Alimenter les tables via des fichiers ou par Big Query <br>
 * @author user@talend.com
 * @version 8.0.1.20211109_1610
 * @status 
 */
public class A_ALIM_SI_OPE_FICHIER_BQ implements TalendJob {

protected static void logIgnoredError(String message, Throwable cause) {
       System.err.println(message);
       if (cause != null) {
               cause.printStackTrace();
       }

}


	public final Object obj = new Object();

	// for transmiting parameters purpose
	private Object valueObject = null;

	public Object getValueObject() {
		return this.valueObject;
	}

	public void setValueObject(Object valueObject) {
		this.valueObject = valueObject;
	}
	
	private final static String defaultCharset = java.nio.charset.Charset.defaultCharset().name();

	
	private final static String utf8Charset = "UTF-8";
	//contains type for every context property
	public class PropertiesWithType extends java.util.Properties {
		private static final long serialVersionUID = 1L;
		private java.util.Map<String,String> propertyTypes = new java.util.HashMap<>();
		
		public PropertiesWithType(java.util.Properties properties){
			super(properties);
		}
		public PropertiesWithType(){
			super();
		}
		
		public void setContextType(String key, String type) {
			propertyTypes.put(key,type);
		}
	
		public String getContextType(String key) {
			return propertyTypes.get(key);
		}
	}
	
	// create and load default properties
	private java.util.Properties defaultProps = new java.util.Properties();
	// create application properties with default
	public class ContextProperties extends PropertiesWithType {

		private static final long serialVersionUID = 1L;

		public ContextProperties(java.util.Properties properties){
			super(properties);
		}
		public ContextProperties(){
			super();
		}

		public void synchronizeContext(){
			
		}
		
		//if the stored or passed value is "<TALEND_NULL>" string, it mean null
		public String getStringValue(String key) {
			String origin_value = this.getProperty(key);
			if(NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY.equals(origin_value)) {
				return null;
			}
			return origin_value;
		}

	}
	protected ContextProperties context = new ContextProperties(); // will be instanciated by MS.
	public ContextProperties getContext() {
		return this.context;
	}
	private final String jobVersion = "0.1";
	private final String jobName = "A_ALIM_SI_OPE_FICHIER_BQ";
	private final String projectName = "ALIMENTATION_SI_OPE";
	public Integer errorCode = null;
	private String currentComponent = "";
	
		private final java.util.Map<String, Object> globalMap = new java.util.HashMap<String, Object>();
        private final static java.util.Map<String, Object> junitGlobalMap = new java.util.HashMap<String, Object>();
	
		private final java.util.Map<String, Long> start_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Long> end_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Boolean> ok_Hash = new java.util.HashMap<String, Boolean>();
		public  final java.util.List<String[]> globalBuffer = new java.util.ArrayList<String[]>();
	

private RunStat runStat = new RunStat();

	// OSGi DataSource
	private final static String KEY_DB_DATASOURCES = "KEY_DB_DATASOURCES";
	
	private final static String KEY_DB_DATASOURCES_RAW = "KEY_DB_DATASOURCES_RAW";

	public void setDataSources(java.util.Map<String, javax.sql.DataSource> dataSources) {
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		for (java.util.Map.Entry<String, javax.sql.DataSource> dataSourceEntry : dataSources.entrySet()) {
			talendDataSources.put(dataSourceEntry.getKey(), new routines.system.TalendDataSource(dataSourceEntry.getValue()));
		}
		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}
	
	public void setDataSourceReferences(List serviceReferences) throws Exception{
		
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		java.util.Map<String, javax.sql.DataSource> dataSources = new java.util.HashMap<String, javax.sql.DataSource>();
		
		for (java.util.Map.Entry<String, javax.sql.DataSource> entry : BundleUtils.getServices(serviceReferences,  javax.sql.DataSource.class).entrySet()) {
                    dataSources.put(entry.getKey(), entry.getValue());
                    talendDataSources.put(entry.getKey(), new routines.system.TalendDataSource(entry.getValue()));
		}

		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}

	StatCatcherUtils tStatCatcher_1 = new StatCatcherUtils("_td9PoKAhEe6GZJpm5Sg0wA", "0.1");

private final java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
private final java.io.PrintStream errorMessagePS = new java.io.PrintStream(new java.io.BufferedOutputStream(baos));

public String getExceptionStackTrace() {
	if ("failure".equals(this.getStatus())) {
		errorMessagePS.flush();
		return baos.toString();
	}
	return null;
}

private Exception exception;

public Exception getException() {
	if ("failure".equals(this.getStatus())) {
		return this.exception;
	}
	return null;
}

private class TalendException extends Exception {

	private static final long serialVersionUID = 1L;

	private java.util.Map<String, Object> globalMap = null;
	private Exception e = null;
	private String currentComponent = null;
	private String virtualComponentName = null;
	
	public void setVirtualComponentName (String virtualComponentName){
		this.virtualComponentName = virtualComponentName;
	}

	private TalendException(Exception e, String errorComponent, final java.util.Map<String, Object> globalMap) {
		this.currentComponent= errorComponent;
		this.globalMap = globalMap;
		this.e = e;
	}

	public Exception getException() {
		return this.e;
	}

	public String getCurrentComponent() {
		return this.currentComponent;
	}

	
    public String getExceptionCauseMessage(Exception e){
        Throwable cause = e;
        String message = null;
        int i = 10;
        while (null != cause && 0 < i--) {
            message = cause.getMessage();
            if (null == message) {
                cause = cause.getCause();
            } else {
                break;          
            }
        }
        if (null == message) {
            message = e.getClass().getName();
        }   
        return message;
    }

	@Override
	public void printStackTrace() {
		if (!(e instanceof TalendException || e instanceof TDieException)) {
			if(virtualComponentName!=null && currentComponent.indexOf(virtualComponentName+"_")==0){
				globalMap.put(virtualComponentName+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			}
			globalMap.put(currentComponent+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			System.err.println("Exception in component " + currentComponent + " (" + jobName + ")");
		}
		if (!(e instanceof TDieException)) {
			if(e instanceof TalendException){
				e.printStackTrace();
			} else {
				e.printStackTrace();
				e.printStackTrace(errorMessagePS);
				A_ALIM_SI_OPE_FICHIER_BQ.this.exception = e;
			}
		}
		if (!(e instanceof TalendException)) {
		try {
			for (java.lang.reflect.Method m : this.getClass().getEnclosingClass().getMethods()) {
				if (m.getName().compareTo(currentComponent + "_error") == 0) {
					m.invoke(A_ALIM_SI_OPE_FICHIER_BQ.this, new Object[] { e , currentComponent, globalMap});
					break;
				}
			}

			if(!(e instanceof TDieException)){
			}
		} catch (Exception e) {
			this.e.printStackTrace();
		}
		}
	}
}

			public void tStatCatcher_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tStatCatcher_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tStatCatcher_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBRow_8_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
							tStatCatcher_1.addMessage("failure",errorComponent, end_Hash.get(errorComponent)-start_Hash.get(errorComponent));
							tStatCatcher_1Process(globalMap);
							
				status = "failure";
				
					tDBRow_8_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBRow_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
							tStatCatcher_1.addMessage("failure",errorComponent, end_Hash.get(errorComponent)-start_Hash.get(errorComponent));
							tStatCatcher_1Process(globalMap);
							
				status = "failure";
				
					tDBRow_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileInputDelimited_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
							tStatCatcher_1.addMessage("failure",errorComponent, end_Hash.get(errorComponent)-start_Hash.get(errorComponent));
							tStatCatcher_1Process(globalMap);
							
				status = "failure";
				
					tFileInputDelimited_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
							tStatCatcher_1.addMessage("failure",errorComponent, end_Hash.get(errorComponent)-start_Hash.get(errorComponent));
							tStatCatcher_1Process(globalMap);
							
				status = "failure";
				
					tFileInputDelimited_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tBigQueryInput_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
							tStatCatcher_1.addMessage("failure",errorComponent, end_Hash.get(errorComponent)-start_Hash.get(errorComponent));
							tStatCatcher_1Process(globalMap);
							
				status = "failure";
				
					tBigQueryInput_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_7_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
							tStatCatcher_1.addMessage("failure",errorComponent, end_Hash.get(errorComponent)-start_Hash.get(errorComponent));
							tStatCatcher_1Process(globalMap);
							
				status = "failure";
				
					tBigQueryInput_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBRow_6_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
							tStatCatcher_1.addMessage("failure",errorComponent, end_Hash.get(errorComponent)-start_Hash.get(errorComponent));
							tStatCatcher_1Process(globalMap);
							
				status = "failure";
				
					tDBRow_6_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBRow_7_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
							tStatCatcher_1.addMessage("failure",errorComponent, end_Hash.get(errorComponent)-start_Hash.get(errorComponent));
							tStatCatcher_1Process(globalMap);
							
				status = "failure";
				
					tDBRow_7_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileInputXML_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
							tStatCatcher_1.addMessage("failure",errorComponent, end_Hash.get(errorComponent)-start_Hash.get(errorComponent));
							tStatCatcher_1Process(globalMap);
							
				status = "failure";
				
					tFileInputXML_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tUnite_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
							tStatCatcher_1.addMessage("failure",errorComponent, end_Hash.get(errorComponent)-start_Hash.get(errorComponent));
							tStatCatcher_1Process(globalMap);
							
				status = "failure";
				
					tFileInputXML_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
							tStatCatcher_1.addMessage("failure",errorComponent, end_Hash.get(errorComponent)-start_Hash.get(errorComponent));
							tStatCatcher_1Process(globalMap);
							
				status = "failure";
				
					tFileInputXML_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBRow_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
							tStatCatcher_1.addMessage("failure",errorComponent, end_Hash.get(errorComponent)-start_Hash.get(errorComponent));
							tStatCatcher_1Process(globalMap);
							
				status = "failure";
				
					tDBRow_4_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBRow_5_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
							tStatCatcher_1.addMessage("failure",errorComponent, end_Hash.get(errorComponent)-start_Hash.get(errorComponent));
							tStatCatcher_1Process(globalMap);
							
				status = "failure";
				
					tDBRow_5_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileInputDelimited_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
							tStatCatcher_1.addMessage("failure",errorComponent, end_Hash.get(errorComponent)-start_Hash.get(errorComponent));
							tStatCatcher_1Process(globalMap);
							
				status = "failure";
				
					tFileInputDelimited_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tUnite_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
							tStatCatcher_1.addMessage("failure",errorComponent, end_Hash.get(errorComponent)-start_Hash.get(errorComponent));
							tStatCatcher_1Process(globalMap);
							
				status = "failure";
				
					tFileInputDelimited_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
							tStatCatcher_1.addMessage("failure",errorComponent, end_Hash.get(errorComponent)-start_Hash.get(errorComponent));
							tStatCatcher_1Process(globalMap);
							
				status = "failure";
				
					tFileInputDelimited_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileInputExcel_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
							tStatCatcher_1.addMessage("failure",errorComponent, end_Hash.get(errorComponent)-start_Hash.get(errorComponent));
							tStatCatcher_1Process(globalMap);
							
				status = "failure";
				
					tFileInputDelimited_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileInputExcel_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
							tStatCatcher_1.addMessage("failure",errorComponent, end_Hash.get(errorComponent)-start_Hash.get(errorComponent));
							tStatCatcher_1Process(globalMap);
							
				status = "failure";
				
					tFileInputXML_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileInputJSON_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
							tStatCatcher_1.addMessage("failure",errorComponent, end_Hash.get(errorComponent)-start_Hash.get(errorComponent));
							tStatCatcher_1Process(globalMap);
							
				status = "failure";
				
					tFileInputXML_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBRow_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
							tStatCatcher_1.addMessage("failure",errorComponent, end_Hash.get(errorComponent)-start_Hash.get(errorComponent));
							tStatCatcher_1Process(globalMap);
							
				status = "failure";
				
					tDBRow_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBRow_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
							tStatCatcher_1.addMessage("failure",errorComponent, end_Hash.get(errorComponent)-start_Hash.get(errorComponent));
							tStatCatcher_1Process(globalMap);
							
				status = "failure";
				
					tDBRow_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tBigQueryInput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
							tStatCatcher_1.addMessage("failure",errorComponent, end_Hash.get(errorComponent)-start_Hash.get(errorComponent));
							tStatCatcher_1Process(globalMap);
							
				status = "failure";
				
					tBigQueryInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_5_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
							tStatCatcher_1.addMessage("failure",errorComponent, end_Hash.get(errorComponent)-start_Hash.get(errorComponent));
							tStatCatcher_1Process(globalMap);
							
				status = "failure";
				
					tBigQueryInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tBigQueryInput_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
							tStatCatcher_1.addMessage("failure",errorComponent, end_Hash.get(errorComponent)-start_Hash.get(errorComponent));
							tStatCatcher_1Process(globalMap);
							
				status = "failure";
				
					tBigQueryInput_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_6_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
							tStatCatcher_1.addMessage("failure",errorComponent, end_Hash.get(errorComponent)-start_Hash.get(errorComponent));
							tStatCatcher_1Process(globalMap);
							
				status = "failure";
				
					tBigQueryInput_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tStatCatcher_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBRow_8_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBRow_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFileInputDelimited_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tBigQueryInput_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBRow_6_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBRow_7_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFileInputXML_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBRow_4_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBRow_5_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFileInputDelimited_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBRow_3_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBRow_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tBigQueryInput_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tBigQueryInput_3_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
	






public static class row5Struct implements routines.system.IPersistableRow<row5Struct> {
    final static byte[] commonByteArrayLock_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ = new byte[0];
    static byte[] commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ = new byte[0];

	
			    public java.util.Date moment;

				public java.util.Date getMoment () {
					return this.moment;
				}
				
			    public String pid;

				public String getPid () {
					return this.pid;
				}
				
			    public String father_pid;

				public String getFather_pid () {
					return this.father_pid;
				}
				
			    public String root_pid;

				public String getRoot_pid () {
					return this.root_pid;
				}
				
			    public Long system_pid;

				public Long getSystem_pid () {
					return this.system_pid;
				}
				
			    public String project;

				public String getProject () {
					return this.project;
				}
				
			    public String job;

				public String getJob () {
					return this.job;
				}
				
			    public String job_repository_id;

				public String getJob_repository_id () {
					return this.job_repository_id;
				}
				
			    public String job_version;

				public String getJob_version () {
					return this.job_version;
				}
				
			    public String context;

				public String getContext () {
					return this.context;
				}
				
			    public String origin;

				public String getOrigin () {
					return this.origin;
				}
				
			    public String message_type;

				public String getMessage_type () {
					return this.message_type;
				}
				
			    public String message;

				public String getMessage () {
					return this.message;
				}
				
			    public Long duration;

				public Long getDuration () {
					return this.duration;
				}
				



	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ.length == 0) {
   					commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ.length == 0) {
   					commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ) {

        	try {

        		int length = 0;
		
					this.moment = readDate(dis);
					
					this.pid = readString(dis);
					
					this.father_pid = readString(dis);
					
					this.root_pid = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.system_pid = null;
           				} else {
           			    	this.system_pid = dis.readLong();
           				}
					
					this.project = readString(dis);
					
					this.job = readString(dis);
					
					this.job_repository_id = readString(dis);
					
					this.job_version = readString(dis);
					
					this.context = readString(dis);
					
					this.origin = readString(dis);
					
					this.message_type = readString(dis);
					
					this.message = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.duration = null;
           				} else {
           			    	this.duration = dis.readLong();
           				}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ) {

        	try {

        		int length = 0;
		
					this.moment = readDate(dis);
					
					this.pid = readString(dis);
					
					this.father_pid = readString(dis);
					
					this.root_pid = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.system_pid = null;
           				} else {
           			    	this.system_pid = dis.readLong();
           				}
					
					this.project = readString(dis);
					
					this.job = readString(dis);
					
					this.job_repository_id = readString(dis);
					
					this.job_version = readString(dis);
					
					this.context = readString(dis);
					
					this.origin = readString(dis);
					
					this.message_type = readString(dis);
					
					this.message = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.duration = null;
           				} else {
           			    	this.duration = dis.readLong();
           				}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// java.util.Date
				
						writeDate(this.moment,dos);
					
					// String
				
						writeString(this.pid,dos);
					
					// String
				
						writeString(this.father_pid,dos);
					
					// String
				
						writeString(this.root_pid,dos);
					
					// Long
				
						if(this.system_pid == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.system_pid);
		            	}
					
					// String
				
						writeString(this.project,dos);
					
					// String
				
						writeString(this.job,dos);
					
					// String
				
						writeString(this.job_repository_id,dos);
					
					// String
				
						writeString(this.job_version,dos);
					
					// String
				
						writeString(this.context,dos);
					
					// String
				
						writeString(this.origin,dos);
					
					// String
				
						writeString(this.message_type,dos);
					
					// String
				
						writeString(this.message,dos);
					
					// Long
				
						if(this.duration == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.duration);
		            	}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// java.util.Date
				
						writeDate(this.moment,dos);
					
					// String
				
						writeString(this.pid,dos);
					
					// String
				
						writeString(this.father_pid,dos);
					
					// String
				
						writeString(this.root_pid,dos);
					
					// Long
				
						if(this.system_pid == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.system_pid);
		            	}
					
					// String
				
						writeString(this.project,dos);
					
					// String
				
						writeString(this.job,dos);
					
					// String
				
						writeString(this.job_repository_id,dos);
					
					// String
				
						writeString(this.job_version,dos);
					
					// String
				
						writeString(this.context,dos);
					
					// String
				
						writeString(this.origin,dos);
					
					// String
				
						writeString(this.message_type,dos);
					
					// String
				
						writeString(this.message,dos);
					
					// Long
				
						if(this.duration == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.duration);
		            	}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("moment="+String.valueOf(moment));
		sb.append(",pid="+pid);
		sb.append(",father_pid="+father_pid);
		sb.append(",root_pid="+root_pid);
		sb.append(",system_pid="+String.valueOf(system_pid));
		sb.append(",project="+project);
		sb.append(",job="+job);
		sb.append(",job_repository_id="+job_repository_id);
		sb.append(",job_version="+job_version);
		sb.append(",context="+context);
		sb.append(",origin="+origin);
		sb.append(",message_type="+message_type);
		sb.append(",message="+message);
		sb.append(",duration="+String.valueOf(duration));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row5Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tStatCatcher_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tStatCatcher_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row5Struct row5 = new row5Struct();




	
	/**
	 * [tDBOutput_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_2", false);
		start_Hash.put("tDBOutput_2", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_2";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row5");
					}
				
		int tos_count_tDBOutput_2 = 0;
		





String dbschema_tDBOutput_2 = null;
	dbschema_tDBOutput_2 = "dsid_liv_met";
	

String tableName_tDBOutput_2 = null;
if(dbschema_tDBOutput_2 == null || dbschema_tDBOutput_2.trim().length() == 0) {
	tableName_tDBOutput_2 = ("JOB_STATS");
} else {
	tableName_tDBOutput_2 = dbschema_tDBOutput_2 + "\".\"" + ("JOB_STATS");
}


int nb_line_tDBOutput_2 = 0;
int nb_line_update_tDBOutput_2 = 0;
int nb_line_inserted_tDBOutput_2 = 0;
int nb_line_deleted_tDBOutput_2 = 0;
int nb_line_rejected_tDBOutput_2 = 0;

int deletedCount_tDBOutput_2=0;
int updatedCount_tDBOutput_2=0;
int insertedCount_tDBOutput_2=0;
int rowsToCommitCount_tDBOutput_2=0;
int rejectedCount_tDBOutput_2=0;

boolean whetherReject_tDBOutput_2 = false;

java.sql.Connection conn_tDBOutput_2 = null;
String dbUser_tDBOutput_2 = null;

	
    java.lang.Class.forName("org.postgresql.Driver");
    
        String url_tDBOutput_2 = "jdbc:postgresql://"+""+":"+"5432"+"/"+"postgres";
    dbUser_tDBOutput_2 = "dsid_cc2_tos_rw";
 
	final String decryptedPassword_tDBOutput_2 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:fkN8QqsSWWlThDGFPsizD+xk3y2nIEIGFWJYd/RtpOU=");

    String dbPwd_tDBOutput_2 = decryptedPassword_tDBOutput_2;

    conn_tDBOutput_2 = java.sql.DriverManager.getConnection(url_tDBOutput_2,dbUser_tDBOutput_2,dbPwd_tDBOutput_2);
	
	resourceMap.put("conn_tDBOutput_2", conn_tDBOutput_2);
        conn_tDBOutput_2.setAutoCommit(false);
        int commitEvery_tDBOutput_2 = 10000;
        int commitCounter_tDBOutput_2 = 0;


   int batchSize_tDBOutput_2 = 10000;
   int batchSizeCounter_tDBOutput_2=0;

int count_tDBOutput_2=0;
                                java.sql.DatabaseMetaData dbMetaData_tDBOutput_2 = conn_tDBOutput_2.getMetaData();
                                boolean whetherExist_tDBOutput_2 = false;
                                try (java.sql.ResultSet rsTable_tDBOutput_2 = dbMetaData_tDBOutput_2.getTables(null, null, null, new String[]{"TABLE"})) {
                                    String defaultSchema_tDBOutput_2 = "public";
                                    if(dbschema_tDBOutput_2 == null || dbschema_tDBOutput_2.trim().length() == 0) {
                                        try(java.sql.Statement stmtSchema_tDBOutput_2 = conn_tDBOutput_2.createStatement();
                                            java.sql.ResultSet rsSchema_tDBOutput_2 = stmtSchema_tDBOutput_2.executeQuery("select current_schema() ")) {
                                            while(rsSchema_tDBOutput_2.next()){
                                                defaultSchema_tDBOutput_2 = rsSchema_tDBOutput_2.getString("current_schema");
                                            }
                                        }
                                    }
                                    while(rsTable_tDBOutput_2.next()) {
                                        String table_tDBOutput_2 = rsTable_tDBOutput_2.getString("TABLE_NAME");
                                        String schema_tDBOutput_2 = rsTable_tDBOutput_2.getString("TABLE_SCHEM");
                                        if(table_tDBOutput_2.equals(("JOB_STATS"))
                                            && (schema_tDBOutput_2.equals(dbschema_tDBOutput_2) || ((dbschema_tDBOutput_2 ==null || dbschema_tDBOutput_2.trim().length() ==0) && defaultSchema_tDBOutput_2.equals(schema_tDBOutput_2)))) {
                                            whetherExist_tDBOutput_2 = true;
                                            break;
                                        }
                                    }
                                }
                                if(!whetherExist_tDBOutput_2) {
                                    try (java.sql.Statement stmtCreate_tDBOutput_2 = conn_tDBOutput_2.createStatement()) {
                                        stmtCreate_tDBOutput_2.execute("CREATE TABLE \"" + tableName_tDBOutput_2 + "\"(\"moment\" TIMESTAMP(0)  ,\"pid\" VARCHAR(20)  ,\"father_pid\" VARCHAR(20)  ,\"root_pid\" VARCHAR(20)  ,\"system_pid\" INT8 ,\"project\" VARCHAR(50)  ,\"job\" VARCHAR(255)  ,\"job_repository_id\" VARCHAR(255)  ,\"job_version\" VARCHAR(255)  ,\"context\" VARCHAR(50)  ,\"origin\" VARCHAR(255)  ,\"message_type\" VARCHAR(255)  ,\"message\" VARCHAR(255)  ,\"duration\" INT8 )");
                                    }
                                }
	    String insert_tDBOutput_2 = "INSERT INTO \"" + tableName_tDBOutput_2 + "\" (\"moment\",\"pid\",\"father_pid\",\"root_pid\",\"system_pid\",\"project\",\"job\",\"job_repository_id\",\"job_version\",\"context\",\"origin\",\"message_type\",\"message\",\"duration\") VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
	    
	    java.sql.PreparedStatement pstmt_tDBOutput_2 = conn_tDBOutput_2.prepareStatement(insert_tDBOutput_2);
	    resourceMap.put("pstmt_tDBOutput_2", pstmt_tDBOutput_2);
	    

 



/**
 * [tDBOutput_2 begin ] stop
 */



	
	/**
	 * [tStatCatcher_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tStatCatcher_1", false);
		start_Hash.put("tStatCatcher_1", System.currentTimeMillis());
		
	
	currentComponent="tStatCatcher_1";

	
		int tos_count_tStatCatcher_1 = 0;
		

	for (StatCatcherUtils.StatCatcherMessage scm : tStatCatcher_1.getMessages()) {
		row5.pid = pid;
		row5.root_pid = rootPid;
		row5.father_pid = fatherPid;	
    	row5.project = projectName;
    	row5.job = jobName;
    	row5.context = contextStr;
		row5.origin = (scm.getOrigin()==null || scm.getOrigin().length()<1 ? null : scm.getOrigin());
		row5.message = scm.getMessage();
		row5.duration = scm.getDuration();
		row5.moment = scm.getMoment();
		row5.message_type = scm.getMessageType();
		row5.job_version = scm.getJobVersion();
		row5.job_repository_id = scm.getJobId();
		row5.system_pid = scm.getSystemPid();

 



/**
 * [tStatCatcher_1 begin ] stop
 */
	
	/**
	 * [tStatCatcher_1 main ] start
	 */

	

	
	
	currentComponent="tStatCatcher_1";

	

 


	tos_count_tStatCatcher_1++;

/**
 * [tStatCatcher_1 main ] stop
 */
	
	/**
	 * [tStatCatcher_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tStatCatcher_1";

	

 



/**
 * [tStatCatcher_1 process_data_begin ] stop
 */

	
	/**
	 * [tDBOutput_2 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row5"
						
						);
					}
					



        whetherReject_tDBOutput_2 = false;
                    if(row5.moment != null) {
pstmt_tDBOutput_2.setTimestamp(1, new java.sql.Timestamp(row5.moment.getTime()));
} else {
pstmt_tDBOutput_2.setNull(1, java.sql.Types.TIMESTAMP);
}

                    if(row5.pid == null) {
pstmt_tDBOutput_2.setNull(2, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(2, row5.pid);
}

                    if(row5.father_pid == null) {
pstmt_tDBOutput_2.setNull(3, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(3, row5.father_pid);
}

                    if(row5.root_pid == null) {
pstmt_tDBOutput_2.setNull(4, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(4, row5.root_pid);
}

                    if(row5.system_pid == null) {
pstmt_tDBOutput_2.setNull(5, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_2.setLong(5, row5.system_pid);
}

                    if(row5.project == null) {
pstmt_tDBOutput_2.setNull(6, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(6, row5.project);
}

                    if(row5.job == null) {
pstmt_tDBOutput_2.setNull(7, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(7, row5.job);
}

                    if(row5.job_repository_id == null) {
pstmt_tDBOutput_2.setNull(8, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(8, row5.job_repository_id);
}

                    if(row5.job_version == null) {
pstmt_tDBOutput_2.setNull(9, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(9, row5.job_version);
}

                    if(row5.context == null) {
pstmt_tDBOutput_2.setNull(10, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(10, row5.context);
}

                    if(row5.origin == null) {
pstmt_tDBOutput_2.setNull(11, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(11, row5.origin);
}

                    if(row5.message_type == null) {
pstmt_tDBOutput_2.setNull(12, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(12, row5.message_type);
}

                    if(row5.message == null) {
pstmt_tDBOutput_2.setNull(13, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(13, row5.message);
}

                    if(row5.duration == null) {
pstmt_tDBOutput_2.setNull(14, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_2.setLong(14, row5.duration);
}

			
    		pstmt_tDBOutput_2.addBatch();
    		nb_line_tDBOutput_2++;
    		  
    		  
    		  batchSizeCounter_tDBOutput_2++;
    		  
    			if ((batchSize_tDBOutput_2 > 0) && (batchSize_tDBOutput_2 <= batchSizeCounter_tDBOutput_2)) {
                try {
						int countSum_tDBOutput_2 = 0;
						    
						for(int countEach_tDBOutput_2: pstmt_tDBOutput_2.executeBatch()) {
							countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
						}
				    	rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;
				    	
				    		insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
				    	
            	    	batchSizeCounter_tDBOutput_2 = 0;
                }catch (java.sql.BatchUpdateException e_tDBOutput_2){
globalMap.put("tDBOutput_2_ERROR_MESSAGE",e_tDBOutput_2.getMessage());
				    	java.sql.SQLException ne_tDBOutput_2 = e_tDBOutput_2.getNextException(),sqle_tDBOutput_2=null;
				    	String errormessage_tDBOutput_2;
						if (ne_tDBOutput_2 != null) {
							// build new exception to provide the original cause
							sqle_tDBOutput_2 = new java.sql.SQLException(e_tDBOutput_2.getMessage() + "\ncaused by: " + ne_tDBOutput_2.getMessage(), ne_tDBOutput_2.getSQLState(), ne_tDBOutput_2.getErrorCode(), ne_tDBOutput_2);
							errormessage_tDBOutput_2 = sqle_tDBOutput_2.getMessage();
						}else{
							errormessage_tDBOutput_2 = e_tDBOutput_2.getMessage();
						}
				    	
				    	int countSum_tDBOutput_2 = 0;
						for(int countEach_tDBOutput_2: e_tDBOutput_2.getUpdateCounts()) {
							countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
						}
						rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;
						
				    		insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
				    	
				    	System.err.println(errormessage_tDBOutput_2);
				    	
					}
    			}
    		
    		    commitCounter_tDBOutput_2++;
                if(commitEvery_tDBOutput_2 <= commitCounter_tDBOutput_2) {
                if ((batchSize_tDBOutput_2 > 0) && (batchSizeCounter_tDBOutput_2 > 0)) {
                try {
                		int countSum_tDBOutput_2 = 0;
                		    
						for(int countEach_tDBOutput_2: pstmt_tDBOutput_2.executeBatch()) {
							countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
						}
            	    	rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;
            	    	
            	    		insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
            	    	
                batchSizeCounter_tDBOutput_2 = 0;
               }catch (java.sql.BatchUpdateException e_tDBOutput_2){
globalMap.put("tDBOutput_2_ERROR_MESSAGE",e_tDBOutput_2.getMessage());
			    	java.sql.SQLException ne_tDBOutput_2 = e_tDBOutput_2.getNextException(),sqle_tDBOutput_2=null;
			    	String errormessage_tDBOutput_2;
					if (ne_tDBOutput_2 != null) {
						// build new exception to provide the original cause
						sqle_tDBOutput_2 = new java.sql.SQLException(e_tDBOutput_2.getMessage() + "\ncaused by: " + ne_tDBOutput_2.getMessage(), ne_tDBOutput_2.getSQLState(), ne_tDBOutput_2.getErrorCode(), ne_tDBOutput_2);
						errormessage_tDBOutput_2 = sqle_tDBOutput_2.getMessage();
					}else{
						errormessage_tDBOutput_2 = e_tDBOutput_2.getMessage();
					}
			    	
			    	int countSum_tDBOutput_2 = 0;
					for(int countEach_tDBOutput_2: e_tDBOutput_2.getUpdateCounts()) {
						countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
					}
					rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;
					
			    		insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
			    	
			    	System.err.println(errormessage_tDBOutput_2);
			    	
				}
            }
                    if(rowsToCommitCount_tDBOutput_2 != 0){
                    	
                    }
                    conn_tDBOutput_2.commit();
                    if(rowsToCommitCount_tDBOutput_2 != 0){
                    	
                    	rowsToCommitCount_tDBOutput_2 = 0;
                    }
                    commitCounter_tDBOutput_2=0;
                }

 


	tos_count_tDBOutput_2++;

/**
 * [tDBOutput_2 main ] stop
 */
	
	/**
	 * [tDBOutput_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";

	

 



/**
 * [tDBOutput_2 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";

	

 



/**
 * [tDBOutput_2 process_data_end ] stop
 */



	
	/**
	 * [tStatCatcher_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tStatCatcher_1";

	

 



/**
 * [tStatCatcher_1 process_data_end ] stop
 */
	
	/**
	 * [tStatCatcher_1 end ] start
	 */

	

	
	
	currentComponent="tStatCatcher_1";

	

	}


 

ok_Hash.put("tStatCatcher_1", true);
end_Hash.put("tStatCatcher_1", System.currentTimeMillis());




/**
 * [tStatCatcher_1 end ] stop
 */

	
	/**
	 * [tDBOutput_2 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";

	



	    try {
				int countSum_tDBOutput_2 = 0;
				if (pstmt_tDBOutput_2 != null && batchSizeCounter_tDBOutput_2 > 0) {
						
					for(int countEach_tDBOutput_2: pstmt_tDBOutput_2.executeBatch()) {
						countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
					}
					rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;
						
				}
		    	
		    		insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
		    	
	    }catch (java.sql.BatchUpdateException e_tDBOutput_2){
globalMap.put("tDBOutput_2_ERROR_MESSAGE",e_tDBOutput_2.getMessage());
	    	java.sql.SQLException ne_tDBOutput_2 = e_tDBOutput_2.getNextException(),sqle_tDBOutput_2=null;
	    	String errormessage_tDBOutput_2;
			if (ne_tDBOutput_2 != null) {
				// build new exception to provide the original cause
				sqle_tDBOutput_2 = new java.sql.SQLException(e_tDBOutput_2.getMessage() + "\ncaused by: " + ne_tDBOutput_2.getMessage(), ne_tDBOutput_2.getSQLState(), ne_tDBOutput_2.getErrorCode(), ne_tDBOutput_2);
				errormessage_tDBOutput_2 = sqle_tDBOutput_2.getMessage();
			}else{
				errormessage_tDBOutput_2 = e_tDBOutput_2.getMessage();
			}
	    	
	    	int countSum_tDBOutput_2 = 0;
			for(int countEach_tDBOutput_2: e_tDBOutput_2.getUpdateCounts()) {
				countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
			}
			rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;
			
	    		insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
	    	
	    	System.err.println(errormessage_tDBOutput_2);
	    	
		}
	    
        if(pstmt_tDBOutput_2 != null) {
        		
            pstmt_tDBOutput_2.close();
            resourceMap.remove("pstmt_tDBOutput_2");
        }
    resourceMap.put("statementClosed_tDBOutput_2", true);
			if(rowsToCommitCount_tDBOutput_2 != 0){
				
			}
			conn_tDBOutput_2.commit();
			if(rowsToCommitCount_tDBOutput_2 != 0){
				
				rowsToCommitCount_tDBOutput_2 = 0;
			}
			commitCounter_tDBOutput_2 = 0;
		
    	conn_tDBOutput_2 .close();
    	
    	resourceMap.put("finish_tDBOutput_2", true);
    	

	nb_line_deleted_tDBOutput_2=nb_line_deleted_tDBOutput_2+ deletedCount_tDBOutput_2;
	nb_line_update_tDBOutput_2=nb_line_update_tDBOutput_2 + updatedCount_tDBOutput_2;
	nb_line_inserted_tDBOutput_2=nb_line_inserted_tDBOutput_2 + insertedCount_tDBOutput_2;
	nb_line_rejected_tDBOutput_2=nb_line_rejected_tDBOutput_2 + rejectedCount_tDBOutput_2;
	
        globalMap.put("tDBOutput_2_NB_LINE",nb_line_tDBOutput_2);
        globalMap.put("tDBOutput_2_NB_LINE_UPDATED",nb_line_update_tDBOutput_2);
        globalMap.put("tDBOutput_2_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_2);
        globalMap.put("tDBOutput_2_NB_LINE_DELETED",nb_line_deleted_tDBOutput_2);
        globalMap.put("tDBOutput_2_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_2);
    

	


				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row5");
			  	}
			  	
 

ok_Hash.put("tDBOutput_2", true);
end_Hash.put("tDBOutput_2", System.currentTimeMillis());




/**
 * [tDBOutput_2 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tStatCatcher_1 finally ] start
	 */

	

	
	
	currentComponent="tStatCatcher_1";

	

 



/**
 * [tStatCatcher_1 finally ] stop
 */

	
	/**
	 * [tDBOutput_2 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";

	



    try {
    if (resourceMap.get("statementClosed_tDBOutput_2") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_2 = null;
                if ((pstmtToClose_tDBOutput_2 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_2")) != null) {
                    pstmtToClose_tDBOutput_2.close();
                }
    }
    } finally {
        if(resourceMap.get("finish_tDBOutput_2") == null){
            java.sql.Connection ctn_tDBOutput_2 = null;
            if((ctn_tDBOutput_2 = (java.sql.Connection)resourceMap.get("conn_tDBOutput_2")) != null){
                try {
                    ctn_tDBOutput_2.close();
                } catch (java.sql.SQLException sqlEx_tDBOutput_2) {
                    String errorMessage_tDBOutput_2 = "failed to close the connection in tDBOutput_2 :" + sqlEx_tDBOutput_2.getMessage();
                    System.err.println(errorMessage_tDBOutput_2);
                }
            }
        }
    }
 



/**
 * [tDBOutput_2 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tStatCatcher_1_SUBPROCESS_STATE", 1);
	}
	

public void tDBRow_8Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBRow_8_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tDBRow_8 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBRow_8", false);
		start_Hash.put("tDBRow_8", System.currentTimeMillis());
		
				tStatCatcher_1.addMessage("begin","tDBRow_8");
				tStatCatcher_1Process(globalMap);
			
	
	currentComponent="tDBRow_8";

	
		int tos_count_tDBRow_8 = 0;
		

	java.sql.Connection conn_tDBRow_8 = null;
	String query_tDBRow_8 = "";
	boolean whetherReject_tDBRow_8 = false;
			String driverClass_tDBRow_8 = "oracle.jdbc.OracleDriver";
		    java.lang.Class jdbcclazz_tDBRow_8 = java.lang.Class.forName(driverClass_tDBRow_8);
		
			String url_tDBRow_8 = null;
				url_tDBRow_8 = "jdbc:oracle:thin:@(description=(address=(protocol=tcp)(host=" + "" + ")(port=" + "1521" + "))(connect_data=(service_name=" + "XEPDB1" + ")))";
					String dbUser_tDBRow_8 = "DSID_LIV_OPE";
	        
            		
            		
            		 
	final String decryptedPassword_tDBRow_8 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:QIKIguG5fzWjNw1XdBKjb2mC/fTwvWXOscojBhQY5f4=");
        		   	
        	        String dbPwd_tDBRow_8 = decryptedPassword_tDBRow_8;
	        
					
			conn_tDBRow_8 = java.sql.DriverManager.getConnection(url_tDBRow_8,dbUser_tDBRow_8,dbPwd_tDBRow_8);
		
        resourceMap.put("conn_tDBRow_8", conn_tDBRow_8);
					if(conn_tDBRow_8.getAutoCommit()) {
						
				conn_tDBRow_8.setAutoCommit(false);
			
					}        
					int commitEvery_tDBRow_8 = 10000;
					int commitCounter_tDBRow_8 = 0;
				
        java.sql.Statement stmt_tDBRow_8 = conn_tDBRow_8.createStatement();
        resourceMap.put("stmt_tDBRow_8", stmt_tDBRow_8);

 



/**
 * [tDBRow_8 begin ] stop
 */
	
	/**
	 * [tDBRow_8 main ] start
	 */

	

	
	
	currentComponent="tDBRow_8";

	

query_tDBRow_8 = "TRUNCATE TABLE  DSID_LIV_OPE.PREPARATION";
whetherReject_tDBRow_8 = false;
globalMap.put("tDBRow_8_QUERY",query_tDBRow_8);
try {
		stmt_tDBRow_8.execute(query_tDBRow_8);
		
	} catch (java.lang.Exception e) {
globalMap.put("tDBRow_8_ERROR_MESSAGE",e.getMessage());
		whetherReject_tDBRow_8 = true;
		
				System.err.print(e.getMessage());
				
	}
	
	if(!whetherReject_tDBRow_8) {
		
	}
	
		commitCounter_tDBRow_8++;
		if(commitEvery_tDBRow_8 <= commitCounter_tDBRow_8) {
			
			conn_tDBRow_8.commit();
			
			commitCounter_tDBRow_8=0;
		}
		

 


	tos_count_tDBRow_8++;

/**
 * [tDBRow_8 main ] stop
 */
	
	/**
	 * [tDBRow_8 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBRow_8";

	

 



/**
 * [tDBRow_8 process_data_begin ] stop
 */
	
	/**
	 * [tDBRow_8 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBRow_8";

	

 



/**
 * [tDBRow_8 process_data_end ] stop
 */
	
	/**
	 * [tDBRow_8 end ] start
	 */

	

	
	
	currentComponent="tDBRow_8";

	

	
        stmt_tDBRow_8.close();
        resourceMap.remove("stmt_tDBRow_8");
    resourceMap.put("statementClosed_tDBRow_8", true);
		if(commitEvery_tDBRow_8>commitCounter_tDBRow_8){

			
			conn_tDBRow_8.commit();
			
	
			commitCounter_tDBRow_8=0;
	
		}
			conn_tDBRow_8.close();
			
			if("com.mysql.cj.jdbc.Driver".equals((String)globalMap.get("driverClass_"))
			    && routines.system.BundleUtils.inOSGi()) {
			        Class.forName("com.mysql.cj.jdbc.AbandonedConnectionCleanupThread").
			            getMethod("checkedShutdown").invoke(null, (Object[]) null);
			}
			
    resourceMap.put("finish_tDBRow_8", true);

 

ok_Hash.put("tDBRow_8", true);
end_Hash.put("tDBRow_8", System.currentTimeMillis());

tStatCatcher_1.addMessage("end","tDBRow_8", end_Hash.get("tDBRow_8")-start_Hash.get("tDBRow_8"));
tStatCatcher_1Process(globalMap);
				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk12", 0, "ok");
				}
				tDBRow_2Process(globalMap);
				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk9", 0, "ok");
				}
				tDBRow_4Process(globalMap);



/**
 * [tDBRow_8 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBRow_8 finally ] start
	 */

	

	
	
	currentComponent="tDBRow_8";

	

try {
    if (resourceMap.get("statementClosed_tDBRow_8") == null) {
            java.sql.Statement stmtToClose_tDBRow_8 = null;
            if ((stmtToClose_tDBRow_8 = (java.sql.Statement) resourceMap.remove("stmt_tDBRow_8")) != null) {
                stmtToClose_tDBRow_8.close();
            }
    }
} finally {
        if(resourceMap.get("finish_tDBRow_8") == null){
            java.sql.Connection ctn_tDBRow_8 = null;
            if((ctn_tDBRow_8 = (java.sql.Connection)resourceMap.get("conn_tDBRow_8")) != null){
                try {
                    ctn_tDBRow_8.close();
                } catch (java.sql.SQLException sqlEx_tDBRow_8) {
                    String errorMessage_tDBRow_8 = "failed to close the connection in tDBRow_8 :" + sqlEx_tDBRow_8.getMessage();
                    System.err.println(errorMessage_tDBRow_8);
                }
            }
        }
    }
 



/**
 * [tDBRow_8 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBRow_8_SUBPROCESS_STATE", 1);
	}
	

public void tDBRow_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBRow_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tDBRow_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBRow_2", false);
		start_Hash.put("tDBRow_2", System.currentTimeMillis());
		
				tStatCatcher_1.addMessage("begin","tDBRow_2");
				tStatCatcher_1Process(globalMap);
			
	
	currentComponent="tDBRow_2";

	
		int tos_count_tDBRow_2 = 0;
		

	java.sql.Connection conn_tDBRow_2 = null;
	String query_tDBRow_2 = "";
	boolean whetherReject_tDBRow_2 = false;
			String driverClass_tDBRow_2 = "oracle.jdbc.OracleDriver";
		    java.lang.Class jdbcclazz_tDBRow_2 = java.lang.Class.forName(driverClass_tDBRow_2);
		
			String url_tDBRow_2 = null;
				url_tDBRow_2 = "jdbc:oracle:thin:@(description=(address=(protocol=tcp)(host=" + "" + ")(port=" + "1521" + "))(connect_data=(service_name=" + "XEPDB1" + ")))";
					String dbUser_tDBRow_2 = "DSID_LIV_OPE";
	        
            		
            		
            		 
	final String decryptedPassword_tDBRow_2 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:q0OMKignHxaPbyzQCguijQi1lWR+e8G8M0UNUW+A3WE=");
        		   	
        	        String dbPwd_tDBRow_2 = decryptedPassword_tDBRow_2;
	        
					
			conn_tDBRow_2 = java.sql.DriverManager.getConnection(url_tDBRow_2,dbUser_tDBRow_2,dbPwd_tDBRow_2);
		
        resourceMap.put("conn_tDBRow_2", conn_tDBRow_2);
					if(conn_tDBRow_2.getAutoCommit()) {
						
				conn_tDBRow_2.setAutoCommit(false);
			
					}        
					int commitEvery_tDBRow_2 = 10000;
					int commitCounter_tDBRow_2 = 0;
				
        java.sql.Statement stmt_tDBRow_2 = conn_tDBRow_2.createStatement();
        resourceMap.put("stmt_tDBRow_2", stmt_tDBRow_2);

 



/**
 * [tDBRow_2 begin ] stop
 */
	
	/**
	 * [tDBRow_2 main ] start
	 */

	

	
	
	currentComponent="tDBRow_2";

	

query_tDBRow_2 = "TRUNCATE TABLE  DSID_LIV_OPE.COMMANDE";
whetherReject_tDBRow_2 = false;
globalMap.put("tDBRow_2_QUERY",query_tDBRow_2);
try {
		stmt_tDBRow_2.execute(query_tDBRow_2);
		
	} catch (java.lang.Exception e) {
globalMap.put("tDBRow_2_ERROR_MESSAGE",e.getMessage());
		whetherReject_tDBRow_2 = true;
		
				System.err.print(e.getMessage());
				
	}
	
	if(!whetherReject_tDBRow_2) {
		
	}
	
		commitCounter_tDBRow_2++;
		if(commitEvery_tDBRow_2 <= commitCounter_tDBRow_2) {
			
			conn_tDBRow_2.commit();
			
			commitCounter_tDBRow_2=0;
		}
		

 


	tos_count_tDBRow_2++;

/**
 * [tDBRow_2 main ] stop
 */
	
	/**
	 * [tDBRow_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBRow_2";

	

 



/**
 * [tDBRow_2 process_data_begin ] stop
 */
	
	/**
	 * [tDBRow_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBRow_2";

	

 



/**
 * [tDBRow_2 process_data_end ] stop
 */
	
	/**
	 * [tDBRow_2 end ] start
	 */

	

	
	
	currentComponent="tDBRow_2";

	

	
        stmt_tDBRow_2.close();
        resourceMap.remove("stmt_tDBRow_2");
    resourceMap.put("statementClosed_tDBRow_2", true);
		if(commitEvery_tDBRow_2>commitCounter_tDBRow_2){

			
			conn_tDBRow_2.commit();
			
	
			commitCounter_tDBRow_2=0;
	
		}
			conn_tDBRow_2.close();
			
			if("com.mysql.cj.jdbc.Driver".equals((String)globalMap.get("driverClass_"))
			    && routines.system.BundleUtils.inOSGi()) {
			        Class.forName("com.mysql.cj.jdbc.AbandonedConnectionCleanupThread").
			            getMethod("checkedShutdown").invoke(null, (Object[]) null);
			}
			
    resourceMap.put("finish_tDBRow_2", true);

 

ok_Hash.put("tDBRow_2", true);
end_Hash.put("tDBRow_2", System.currentTimeMillis());

tStatCatcher_1.addMessage("end","tDBRow_2", end_Hash.get("tDBRow_2")-start_Hash.get("tDBRow_2"));
tStatCatcher_1Process(globalMap);
				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk2", 0, "ok");
				}
				tFileInputDelimited_2Process(globalMap);
				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk3", 0, "ok");
				}
				tBigQueryInput_2Process(globalMap);
				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk10", 0, "ok");
				}
				tDBRow_6Process(globalMap);



/**
 * [tDBRow_2 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBRow_2 finally ] start
	 */

	

	
	
	currentComponent="tDBRow_2";

	

try {
    if (resourceMap.get("statementClosed_tDBRow_2") == null) {
            java.sql.Statement stmtToClose_tDBRow_2 = null;
            if ((stmtToClose_tDBRow_2 = (java.sql.Statement) resourceMap.remove("stmt_tDBRow_2")) != null) {
                stmtToClose_tDBRow_2.close();
            }
    }
} finally {
        if(resourceMap.get("finish_tDBRow_2") == null){
            java.sql.Connection ctn_tDBRow_2 = null;
            if((ctn_tDBRow_2 = (java.sql.Connection)resourceMap.get("conn_tDBRow_2")) != null){
                try {
                    ctn_tDBRow_2.close();
                } catch (java.sql.SQLException sqlEx_tDBRow_2) {
                    String errorMessage_tDBRow_2 = "failed to close the connection in tDBRow_2 :" + sqlEx_tDBRow_2.getMessage();
                    System.err.println(errorMessage_tDBRow_2);
                }
            }
        }
    }
 



/**
 * [tDBRow_2 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBRow_2_SUBPROCESS_STATE", 1);
	}
	


public static class row9Struct implements routines.system.IPersistableRow<row9Struct> {
    final static byte[] commonByteArrayLock_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ = new byte[0];
    static byte[] commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public BigDecimal ID_MOYEN_PAIEMENT;

				public BigDecimal getID_MOYEN_PAIEMENT () {
					return this.ID_MOYEN_PAIEMENT;
				}
				
			    public String CODE_MOYEN_PAIEMENT;

				public String getCODE_MOYEN_PAIEMENT () {
					return this.CODE_MOYEN_PAIEMENT;
				}
				
			    public String LIVELLE_MOYEN_PAIEMENT;

				public String getLIVELLE_MOYEN_PAIEMENT () {
					return this.LIVELLE_MOYEN_PAIEMENT;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
						result = prime * result + ((this.ID_MOYEN_PAIEMENT == null) ? 0 : this.ID_MOYEN_PAIEMENT.hashCode());
					
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row9Struct other = (row9Struct) obj;
		
						if (this.ID_MOYEN_PAIEMENT == null) {
							if (other.ID_MOYEN_PAIEMENT != null)
								return false;
						
						} else if (!this.ID_MOYEN_PAIEMENT.equals(other.ID_MOYEN_PAIEMENT))
						
							return false;
					

		return true;
    }

	public void copyDataTo(row9Struct other) {

		other.ID_MOYEN_PAIEMENT = this.ID_MOYEN_PAIEMENT;
	            other.CODE_MOYEN_PAIEMENT = this.CODE_MOYEN_PAIEMENT;
	            other.LIVELLE_MOYEN_PAIEMENT = this.LIVELLE_MOYEN_PAIEMENT;
	            
	}

	public void copyKeysDataTo(row9Struct other) {

		other.ID_MOYEN_PAIEMENT = this.ID_MOYEN_PAIEMENT;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ.length == 0) {
   					commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ.length == 0) {
   					commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ) {

        	try {

        		int length = 0;
		
						this.ID_MOYEN_PAIEMENT = (BigDecimal) dis.readObject();
					
					this.CODE_MOYEN_PAIEMENT = readString(dis);
					
					this.LIVELLE_MOYEN_PAIEMENT = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ) {

        	try {

        		int length = 0;
		
						this.ID_MOYEN_PAIEMENT = (BigDecimal) dis.readObject();
					
					this.CODE_MOYEN_PAIEMENT = readString(dis);
					
					this.LIVELLE_MOYEN_PAIEMENT = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// BigDecimal
				
       			    	dos.writeObject(this.ID_MOYEN_PAIEMENT);
					
					// String
				
						writeString(this.CODE_MOYEN_PAIEMENT,dos);
					
					// String
				
						writeString(this.LIVELLE_MOYEN_PAIEMENT,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// BigDecimal
				
       			    	dos.writeObject(this.ID_MOYEN_PAIEMENT);
					
					// String
				
						writeString(this.CODE_MOYEN_PAIEMENT,dos);
					
					// String
				
						writeString(this.LIVELLE_MOYEN_PAIEMENT,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("ID_MOYEN_PAIEMENT="+String.valueOf(ID_MOYEN_PAIEMENT));
		sb.append(",CODE_MOYEN_PAIEMENT="+CODE_MOYEN_PAIEMENT);
		sb.append(",LIVELLE_MOYEN_PAIEMENT="+LIVELLE_MOYEN_PAIEMENT);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row9Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.ID_MOYEN_PAIEMENT, other.ID_MOYEN_PAIEMENT);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tFileInputDelimited_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFileInputDelimited_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row9Struct row9 = new row9Struct();




	
	/**
	 * [tDBOutput_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_4", false);
		start_Hash.put("tDBOutput_4", System.currentTimeMillis());
		
				tStatCatcher_1.addMessage("begin","tDBOutput_4");
				tStatCatcher_1Process(globalMap);
			
	
	currentComponent="tDBOutput_4";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row9");
					}
				
		int tos_count_tDBOutput_4 = 0;
		






    
    int nb_line_tDBOutput_4 = 0;
    int nb_line_update_tDBOutput_4 = 0;
    int nb_line_inserted_tDBOutput_4 = 0;
    int nb_line_deleted_tDBOutput_4 = 0;
    int nb_line_rejected_tDBOutput_4 = 0;

    int tmp_batchUpdateCount_tDBOutput_4 = 0;

    int deletedCount_tDBOutput_4=0;
    int updatedCount_tDBOutput_4=0;
    int insertedCount_tDBOutput_4=0;
    int rowsToCommitCount_tDBOutput_4=0;
    int rejectedCount_tDBOutput_4=0;

    boolean whetherReject_tDBOutput_4 = false;

    java.sql.Connection conn_tDBOutput_4 = null;

    //optional table
    String dbschema_tDBOutput_4 = null;
    String tableName_tDBOutput_4 = null;
                    String driverClass_tDBOutput_4 = "oracle.jdbc.OracleDriver";


                java.lang.Class.forName(driverClass_tDBOutput_4);
                String url_tDBOutput_4 = null;
                    url_tDBOutput_4 = "jdbc:oracle:thin:@(description=(address=(protocol=tcp)(host=" + "" + ")(port=" + "1521" + "))(connect_data=(service_name=" + "XEPDB1" + ")))";
                String dbUser_tDBOutput_4 = "DSID_LIV_OPE";
 
	final String decryptedPassword_tDBOutput_4 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:AdsQG0Jz1Qn5YlzXPaEFgTw1vF6b8VHLXfNXRnn/Ekw=");

                String dbPwd_tDBOutput_4 = decryptedPassword_tDBOutput_4;
                dbschema_tDBOutput_4 = "DSID_LIV_OPE";


                    conn_tDBOutput_4 = java.sql.DriverManager.getConnection(url_tDBOutput_4, dbUser_tDBOutput_4, dbPwd_tDBOutput_4);
        resourceMap.put("conn_tDBOutput_4", conn_tDBOutput_4);
            conn_tDBOutput_4.setAutoCommit(false);
            int commitEvery_tDBOutput_4 = 10000;
            int commitCounter_tDBOutput_4 = 0;
        int batchSize_tDBOutput_4 = 10000;
        int batchSizeCounter_tDBOutput_4=0;
        int count_tDBOutput_4=0;

        if(dbschema_tDBOutput_4 == null || dbschema_tDBOutput_4.trim().length() == 0) {
            tableName_tDBOutput_4 = ("MOYEN_PAIEMENT");
        } else {
            tableName_tDBOutput_4 = dbschema_tDBOutput_4 + "." + ("MOYEN_PAIEMENT");
        }
            int rsTruncCountNumber_tDBOutput_4 = 0;
            try(java.sql.Statement stmtTruncCount_tDBOutput_4 = conn_tDBOutput_4.createStatement()) {
                try (java.sql.ResultSet rsTruncCount_tDBOutput_4 = stmtTruncCount_tDBOutput_4.executeQuery("SELECT COUNT(1) FROM " + tableName_tDBOutput_4 + "")) {
                    if(rsTruncCount_tDBOutput_4.next()) {
                        rsTruncCountNumber_tDBOutput_4 = rsTruncCount_tDBOutput_4.getInt(1);
                    }
                }
            }
            try (java.sql.Statement stmtTrunc_tDBOutput_4 = conn_tDBOutput_4.createStatement()) {
                stmtTrunc_tDBOutput_4.executeUpdate("TRUNCATE TABLE " + tableName_tDBOutput_4 + "");
                deletedCount_tDBOutput_4 += rsTruncCountNumber_tDBOutput_4;
            }
                String insert_tDBOutput_4 = "INSERT INTO " + tableName_tDBOutput_4 + " (ID_MOYEN_PAIEMENT,CODE_MOYEN_PAIEMENT,LIVELLE_MOYEN_PAIEMENT) VALUES (?,?,?)";    

                        java.sql.PreparedStatement pstmt_tDBOutput_4 = conn_tDBOutput_4.prepareStatement(insert_tDBOutput_4);
                        resourceMap.put("pstmt_tDBOutput_4", pstmt_tDBOutput_4);





 



/**
 * [tDBOutput_4 begin ] stop
 */



	
	/**
	 * [tFileInputDelimited_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileInputDelimited_2", false);
		start_Hash.put("tFileInputDelimited_2", System.currentTimeMillis());
		
				tStatCatcher_1.addMessage("begin","tFileInputDelimited_2");
				tStatCatcher_1Process(globalMap);
			
	
	currentComponent="tFileInputDelimited_2";

	
		int tos_count_tFileInputDelimited_2 = 0;
		
	
	
	
 
	
	
	final routines.system.RowState rowstate_tFileInputDelimited_2 = new routines.system.RowState();
	
	
				int nb_line_tFileInputDelimited_2 = 0;
				org.talend.fileprocess.FileInputDelimited fid_tFileInputDelimited_2 = null;
				int limit_tFileInputDelimited_2 = -1;
				try{
					
						Object filename_tFileInputDelimited_2 = "C:/CC2/Groupe1/5_DATA_IN/moyen_paiement.csv";
						if(filename_tFileInputDelimited_2 instanceof java.io.InputStream){
							
			int footer_value_tFileInputDelimited_2 = 0, random_value_tFileInputDelimited_2 = -1;
			if(footer_value_tFileInputDelimited_2 >0 || random_value_tFileInputDelimited_2 > 0){
				throw new java.lang.Exception("When the input source is a stream,footer and random shouldn't be bigger than 0.");				
			}
		
						}
						try {
							fid_tFileInputDelimited_2 = new org.talend.fileprocess.FileInputDelimited("C:/CC2/Groupe1/5_DATA_IN/moyen_paiement.csv", "US-ASCII",";","\n",false,1,0,
									limit_tFileInputDelimited_2
								,-1, false);
						} catch(java.lang.Exception e) {
globalMap.put("tFileInputDelimited_2_ERROR_MESSAGE",e.getMessage());
							
								
								System.err.println(e.getMessage());
							
						}
					
				    
					while (fid_tFileInputDelimited_2!=null && fid_tFileInputDelimited_2.nextRecord()) {
						rowstate_tFileInputDelimited_2.reset();
						
			    						row9 = null;			
												
									boolean whetherReject_tFileInputDelimited_2 = false;
									row9 = new row9Struct();
									try {
										
				int columnIndexWithD_tFileInputDelimited_2 = 0;
				
					String temp = ""; 
				
					columnIndexWithD_tFileInputDelimited_2 = 0;
					
						temp = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);
						if(temp.length() > 0) {
							
								try {
								
    								row9.ID_MOYEN_PAIEMENT = ParserUtils.parseTo_BigDecimal(temp);
    							
    							} catch(java.lang.Exception ex_tFileInputDelimited_2) {
globalMap.put("tFileInputDelimited_2_ERROR_MESSAGE",ex_tFileInputDelimited_2.getMessage());
									rowstate_tFileInputDelimited_2.setException(new RuntimeException(String.format("Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
										"ID_MOYEN_PAIEMENT", "row9", temp, ex_tFileInputDelimited_2), ex_tFileInputDelimited_2));
								}
    							
						} else {						
							
								
									row9.ID_MOYEN_PAIEMENT = null;
								
							
						}
					
				
					columnIndexWithD_tFileInputDelimited_2 = 1;
					
							row9.CODE_MOYEN_PAIEMENT = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);
						
				
					columnIndexWithD_tFileInputDelimited_2 = 2;
					
							row9.LIVELLE_MOYEN_PAIEMENT = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);
						
				
				
										
										if(rowstate_tFileInputDelimited_2.getException()!=null) {
											throw rowstate_tFileInputDelimited_2.getException();
										}
										
										
							
			    					} catch (java.lang.Exception e) {
globalMap.put("tFileInputDelimited_2_ERROR_MESSAGE",e.getMessage());
			        					whetherReject_tFileInputDelimited_2 = true;
			        					
			                					System.err.println(e.getMessage());
			                					row9 = null;
			                				
										
			    					}
								

 



/**
 * [tFileInputDelimited_2 begin ] stop
 */
	
	/**
	 * [tFileInputDelimited_2 main ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_2";

	

 


	tos_count_tFileInputDelimited_2++;

/**
 * [tFileInputDelimited_2 main ] stop
 */
	
	/**
	 * [tFileInputDelimited_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_2";

	

 



/**
 * [tFileInputDelimited_2 process_data_begin ] stop
 */
// Start of branch "row9"
if(row9 != null) { 



	
	/**
	 * [tDBOutput_4 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_4";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row9"
						
						);
					}
					



        whetherReject_tDBOutput_4 = false;
                        pstmt_tDBOutput_4.setBigDecimal(1, row9.ID_MOYEN_PAIEMENT);

                        if(row9.CODE_MOYEN_PAIEMENT == null) {
pstmt_tDBOutput_4.setNull(2, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_4.setString(2, row9.CODE_MOYEN_PAIEMENT);
}

                        if(row9.LIVELLE_MOYEN_PAIEMENT == null) {
pstmt_tDBOutput_4.setNull(3, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_4.setString(3, row9.LIVELLE_MOYEN_PAIEMENT);
}

                pstmt_tDBOutput_4.addBatch();
                nb_line_tDBOutput_4++;
                batchSizeCounter_tDBOutput_4++;
            if (batchSize_tDBOutput_4 > 0 &&  batchSize_tDBOutput_4 <= batchSizeCounter_tDBOutput_4) {
                try {
                    pstmt_tDBOutput_4.executeBatch();
                }catch (java.sql.BatchUpdateException e_tDBOutput_4){
globalMap.put("tDBOutput_4_ERROR_MESSAGE",e_tDBOutput_4.getMessage());
			        java.sql.SQLException ne_tDBOutput_4 = e_tDBOutput_4.getNextException(),sqle_tDBOutput_4=null;
			    	String errormessage_tDBOutput_4;
					if (ne_tDBOutput_4 != null) {
						// build new exception to provide the original cause
						sqle_tDBOutput_4 = new java.sql.SQLException(e_tDBOutput_4.getMessage() + "\ncaused by: " + ne_tDBOutput_4.getMessage(), ne_tDBOutput_4.getSQLState(), ne_tDBOutput_4.getErrorCode(), ne_tDBOutput_4);
						errormessage_tDBOutput_4 = sqle_tDBOutput_4.getMessage();
					}else{
						errormessage_tDBOutput_4 = e_tDBOutput_4.getMessage();
					}
	            	
	                	System.err.println(errormessage_tDBOutput_4);
	            	
	        	}
                tmp_batchUpdateCount_tDBOutput_4 = pstmt_tDBOutput_4.getUpdateCount();
                    insertedCount_tDBOutput_4
                += (tmp_batchUpdateCount_tDBOutput_4!=-1?tmp_batchUpdateCount_tDBOutput_4:0);
                rowsToCommitCount_tDBOutput_4 += (tmp_batchUpdateCount_tDBOutput_4!=-1?tmp_batchUpdateCount_tDBOutput_4:0);
                batchSizeCounter_tDBOutput_4 = 0;
            }
                commitCounter_tDBOutput_4++;
                if(commitEvery_tDBOutput_4 <= commitCounter_tDBOutput_4) {
                    if(batchSizeCounter_tDBOutput_4 > 0) {
                        try {
                            pstmt_tDBOutput_4.executeBatch();
                        }catch (java.sql.BatchUpdateException e_tDBOutput_4){
globalMap.put("tDBOutput_4_ERROR_MESSAGE",e_tDBOutput_4.getMessage());
					        java.sql.SQLException ne_tDBOutput_4 = e_tDBOutput_4.getNextException(),sqle_tDBOutput_4=null;
					    	String errormessage_tDBOutput_4;
							if (ne_tDBOutput_4 != null) {
								// build new exception to provide the original cause
								sqle_tDBOutput_4 = new java.sql.SQLException(e_tDBOutput_4.getMessage() + "\ncaused by: " + ne_tDBOutput_4.getMessage(), ne_tDBOutput_4.getSQLState(), ne_tDBOutput_4.getErrorCode(), ne_tDBOutput_4);
								errormessage_tDBOutput_4 = sqle_tDBOutput_4.getMessage();
							}else{
								errormessage_tDBOutput_4 = e_tDBOutput_4.getMessage();
							}
			            	
			                	System.err.println(errormessage_tDBOutput_4);
			            	
			        	}
                        tmp_batchUpdateCount_tDBOutput_4 = pstmt_tDBOutput_4.getUpdateCount();
                            insertedCount_tDBOutput_4
                        += (tmp_batchUpdateCount_tDBOutput_4!=-1?tmp_batchUpdateCount_tDBOutput_4:0);
                        rowsToCommitCount_tDBOutput_4 += (tmp_batchUpdateCount_tDBOutput_4!=-1?tmp_batchUpdateCount_tDBOutput_4:0);
                    }
                    if(rowsToCommitCount_tDBOutput_4 != 0){
                    	
                    }
                    conn_tDBOutput_4.commit();
                    if(rowsToCommitCount_tDBOutput_4 != 0){
                    	
                    	rowsToCommitCount_tDBOutput_4 = 0;
                    }
                    commitCounter_tDBOutput_4=0;
                    	batchSizeCounter_tDBOutput_4=0;
                }

 


	tos_count_tDBOutput_4++;

/**
 * [tDBOutput_4 main ] stop
 */
	
	/**
	 * [tDBOutput_4 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_4";

	

 



/**
 * [tDBOutput_4 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_4 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_4";

	

 



/**
 * [tDBOutput_4 process_data_end ] stop
 */

} // End of branch "row9"




	
	/**
	 * [tFileInputDelimited_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_2";

	

 



/**
 * [tFileInputDelimited_2 process_data_end ] stop
 */
	
	/**
	 * [tFileInputDelimited_2 end ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_2";

	



            }
            }finally{
                if(!((Object)("C:/CC2/Groupe1/5_DATA_IN/moyen_paiement.csv") instanceof java.io.InputStream)){
                	if(fid_tFileInputDelimited_2!=null){
                		fid_tFileInputDelimited_2.close();
                	}
                }
                if(fid_tFileInputDelimited_2!=null){
                	globalMap.put("tFileInputDelimited_2_NB_LINE", fid_tFileInputDelimited_2.getRowNumber());
					
                }
			}
			  

 

ok_Hash.put("tFileInputDelimited_2", true);
end_Hash.put("tFileInputDelimited_2", System.currentTimeMillis());

tStatCatcher_1.addMessage("end","tFileInputDelimited_2", end_Hash.get("tFileInputDelimited_2")-start_Hash.get("tFileInputDelimited_2"));
tStatCatcher_1Process(globalMap);



/**
 * [tFileInputDelimited_2 end ] stop
 */

	
	/**
	 * [tDBOutput_4 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_4";

	
	



	
        if(batchSizeCounter_tDBOutput_4 > 0) {
            try {
            	if (pstmt_tDBOutput_4 != null) {
					
					pstmt_tDBOutput_4.executeBatch();
					
        	    }
            }catch (java.sql.BatchUpdateException e_tDBOutput_4){
globalMap.put("tDBOutput_4_ERROR_MESSAGE",e_tDBOutput_4.getMessage());
		        java.sql.SQLException ne_tDBOutput_4 = e_tDBOutput_4.getNextException(),sqle_tDBOutput_4=null;
		    	String errormessage_tDBOutput_4;
				if (ne_tDBOutput_4 != null) {
					// build new exception to provide the original cause
					sqle_tDBOutput_4 = new java.sql.SQLException(e_tDBOutput_4.getMessage() + "\ncaused by: " + ne_tDBOutput_4.getMessage(), ne_tDBOutput_4.getSQLState(), ne_tDBOutput_4.getErrorCode(), ne_tDBOutput_4);
					errormessage_tDBOutput_4 = sqle_tDBOutput_4.getMessage();
				}else{
					errormessage_tDBOutput_4 = e_tDBOutput_4.getMessage();
				}
            	
                	System.err.println(errormessage_tDBOutput_4);
            	
        	}
        	if (pstmt_tDBOutput_4 != null) {
            	tmp_batchUpdateCount_tDBOutput_4 = pstmt_tDBOutput_4.getUpdateCount();
    	    	
    	    		insertedCount_tDBOutput_4
    	    	
    	    	+= (tmp_batchUpdateCount_tDBOutput_4!=-1?tmp_batchUpdateCount_tDBOutput_4:0);
				rowsToCommitCount_tDBOutput_4 += (tmp_batchUpdateCount_tDBOutput_4!=-1?tmp_batchUpdateCount_tDBOutput_4:0);
            }
        }
        if(pstmt_tDBOutput_4 != null) {
			
				pstmt_tDBOutput_4.close();
				resourceMap.remove("pstmt_tDBOutput_4");
			
        }
    resourceMap.put("statementClosed_tDBOutput_4", true);
		if(commitCounter_tDBOutput_4 > 0 && rowsToCommitCount_tDBOutput_4 != 0) {
			
		}
		conn_tDBOutput_4.commit();
		if(commitCounter_tDBOutput_4 > 0 && rowsToCommitCount_tDBOutput_4 != 0) {
			
			rowsToCommitCount_tDBOutput_4 = 0;
		}
		commitCounter_tDBOutput_4 = 0;
		
		
		conn_tDBOutput_4 .close();
		
		resourceMap.put("finish_tDBOutput_4", true);
   	

	
	nb_line_deleted_tDBOutput_4=nb_line_deleted_tDBOutput_4+ deletedCount_tDBOutput_4;
	nb_line_update_tDBOutput_4=nb_line_update_tDBOutput_4 + updatedCount_tDBOutput_4;
	nb_line_inserted_tDBOutput_4=nb_line_inserted_tDBOutput_4 + insertedCount_tDBOutput_4;
	nb_line_rejected_tDBOutput_4=nb_line_rejected_tDBOutput_4 + rejectedCount_tDBOutput_4;
	
        globalMap.put("tDBOutput_4_NB_LINE",nb_line_tDBOutput_4);
        globalMap.put("tDBOutput_4_NB_LINE_UPDATED",nb_line_update_tDBOutput_4);
        globalMap.put("tDBOutput_4_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_4);
        globalMap.put("tDBOutput_4_NB_LINE_DELETED",nb_line_deleted_tDBOutput_4);
        globalMap.put("tDBOutput_4_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_4);
    

	



				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row9");
			  	}
			  	
 

ok_Hash.put("tDBOutput_4", true);
end_Hash.put("tDBOutput_4", System.currentTimeMillis());

tStatCatcher_1.addMessage("end","tDBOutput_4", end_Hash.get("tDBOutput_4")-start_Hash.get("tDBOutput_4"));
tStatCatcher_1Process(globalMap);



/**
 * [tDBOutput_4 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFileInputDelimited_2 finally ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_2";

	

 



/**
 * [tFileInputDelimited_2 finally ] stop
 */

	
	/**
	 * [tDBOutput_4 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_4";

	



    try {
    if (resourceMap.get("statementClosed_tDBOutput_4") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_4 = null;
                if ((pstmtToClose_tDBOutput_4 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_4")) != null) {
                    pstmtToClose_tDBOutput_4.close();
                }
    }
    } finally {
        if(resourceMap.get("finish_tDBOutput_4") == null){
            java.sql.Connection ctn_tDBOutput_4 = null;
            if((ctn_tDBOutput_4 = (java.sql.Connection)resourceMap.get("conn_tDBOutput_4")) != null){
                try {
                    ctn_tDBOutput_4.close();
                } catch (java.sql.SQLException sqlEx_tDBOutput_4) {
                    String errorMessage_tDBOutput_4 = "failed to close the connection in tDBOutput_4 :" + sqlEx_tDBOutput_4.getMessage();
                    System.err.println(errorMessage_tDBOutput_4);
                }
            }
        }
    }
 



/**
 * [tDBOutput_4 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFileInputDelimited_2_SUBPROCESS_STATE", 1);
	}
	


public static class row12Struct implements routines.system.IPersistableRow<row12Struct> {
    final static byte[] commonByteArrayLock_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ = new byte[0];
    static byte[] commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public BigDecimal ID_MENU;

				public BigDecimal getID_MENU () {
					return this.ID_MENU;
				}
				
			    public String CODE_MENU;

				public String getCODE_MENU () {
					return this.CODE_MENU;
				}
				
			    public String LIBELLE_MENU;

				public String getLIBELLE_MENU () {
					return this.LIBELLE_MENU;
				}
				
			    public BigDecimal NOMBRE_ARTICLES;

				public BigDecimal getNOMBRE_ARTICLES () {
					return this.NOMBRE_ARTICLES;
				}
				
			    public String TEMPS_THEO_PREPARATION;

				public String getTEMPS_THEO_PREPARATION () {
					return this.TEMPS_THEO_PREPARATION;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
						result = prime * result + ((this.ID_MENU == null) ? 0 : this.ID_MENU.hashCode());
					
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row12Struct other = (row12Struct) obj;
		
						if (this.ID_MENU == null) {
							if (other.ID_MENU != null)
								return false;
						
						} else if (!this.ID_MENU.equals(other.ID_MENU))
						
							return false;
					

		return true;
    }

	public void copyDataTo(row12Struct other) {

		other.ID_MENU = this.ID_MENU;
	            other.CODE_MENU = this.CODE_MENU;
	            other.LIBELLE_MENU = this.LIBELLE_MENU;
	            other.NOMBRE_ARTICLES = this.NOMBRE_ARTICLES;
	            other.TEMPS_THEO_PREPARATION = this.TEMPS_THEO_PREPARATION;
	            
	}

	public void copyKeysDataTo(row12Struct other) {

		other.ID_MENU = this.ID_MENU;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ.length == 0) {
   					commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ.length == 0) {
   					commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ) {

        	try {

        		int length = 0;
		
						this.ID_MENU = (BigDecimal) dis.readObject();
					
					this.CODE_MENU = readString(dis);
					
					this.LIBELLE_MENU = readString(dis);
					
						this.NOMBRE_ARTICLES = (BigDecimal) dis.readObject();
					
					this.TEMPS_THEO_PREPARATION = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ) {

        	try {

        		int length = 0;
		
						this.ID_MENU = (BigDecimal) dis.readObject();
					
					this.CODE_MENU = readString(dis);
					
					this.LIBELLE_MENU = readString(dis);
					
						this.NOMBRE_ARTICLES = (BigDecimal) dis.readObject();
					
					this.TEMPS_THEO_PREPARATION = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// BigDecimal
				
       			    	dos.writeObject(this.ID_MENU);
					
					// String
				
						writeString(this.CODE_MENU,dos);
					
					// String
				
						writeString(this.LIBELLE_MENU,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.NOMBRE_ARTICLES);
					
					// String
				
						writeString(this.TEMPS_THEO_PREPARATION,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// BigDecimal
				
       			    	dos.writeObject(this.ID_MENU);
					
					// String
				
						writeString(this.CODE_MENU,dos);
					
					// String
				
						writeString(this.LIBELLE_MENU,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.NOMBRE_ARTICLES);
					
					// String
				
						writeString(this.TEMPS_THEO_PREPARATION,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("ID_MENU="+String.valueOf(ID_MENU));
		sb.append(",CODE_MENU="+CODE_MENU);
		sb.append(",LIBELLE_MENU="+LIBELLE_MENU);
		sb.append(",NOMBRE_ARTICLES="+String.valueOf(NOMBRE_ARTICLES));
		sb.append(",TEMPS_THEO_PREPARATION="+TEMPS_THEO_PREPARATION);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row12Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.ID_MENU, other.ID_MENU);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tBigQueryInput_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tBigQueryInput_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row12Struct row12 = new row12Struct();




	
	/**
	 * [tDBOutput_7 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_7", false);
		start_Hash.put("tDBOutput_7", System.currentTimeMillis());
		
				tStatCatcher_1.addMessage("begin","tDBOutput_7");
				tStatCatcher_1Process(globalMap);
			
	
	currentComponent="tDBOutput_7";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row12");
					}
				
		int tos_count_tDBOutput_7 = 0;
		






    
    int nb_line_tDBOutput_7 = 0;
    int nb_line_update_tDBOutput_7 = 0;
    int nb_line_inserted_tDBOutput_7 = 0;
    int nb_line_deleted_tDBOutput_7 = 0;
    int nb_line_rejected_tDBOutput_7 = 0;

    int tmp_batchUpdateCount_tDBOutput_7 = 0;

    int deletedCount_tDBOutput_7=0;
    int updatedCount_tDBOutput_7=0;
    int insertedCount_tDBOutput_7=0;
    int rowsToCommitCount_tDBOutput_7=0;
    int rejectedCount_tDBOutput_7=0;

    boolean whetherReject_tDBOutput_7 = false;

    java.sql.Connection conn_tDBOutput_7 = null;

    //optional table
    String dbschema_tDBOutput_7 = null;
    String tableName_tDBOutput_7 = null;
                    String driverClass_tDBOutput_7 = "oracle.jdbc.OracleDriver";


                java.lang.Class.forName(driverClass_tDBOutput_7);
                String url_tDBOutput_7 = null;
                    url_tDBOutput_7 = "jdbc:oracle:thin:@(description=(address=(protocol=tcp)(host=" + "" + ")(port=" + "1521" + "))(connect_data=(service_name=" + "XEPDB1" + ")))";
                String dbUser_tDBOutput_7 = "DSID_LIV_OPE";
 
	final String decryptedPassword_tDBOutput_7 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:7XG0EvrZzFR732ZX8Tn9w+jiy7fYa2Zi7xiHTTYjxTA=");

                String dbPwd_tDBOutput_7 = decryptedPassword_tDBOutput_7;
                dbschema_tDBOutput_7 = "DSID_LIV_OPE";


                    conn_tDBOutput_7 = java.sql.DriverManager.getConnection(url_tDBOutput_7, dbUser_tDBOutput_7, dbPwd_tDBOutput_7);
        resourceMap.put("conn_tDBOutput_7", conn_tDBOutput_7);
            conn_tDBOutput_7.setAutoCommit(false);
            int commitEvery_tDBOutput_7 = 10000;
            int commitCounter_tDBOutput_7 = 0;
        int batchSize_tDBOutput_7 = 10000;
        int batchSizeCounter_tDBOutput_7=0;
        int count_tDBOutput_7=0;

        if(dbschema_tDBOutput_7 == null || dbschema_tDBOutput_7.trim().length() == 0) {
            tableName_tDBOutput_7 = ("MENU");
        } else {
            tableName_tDBOutput_7 = dbschema_tDBOutput_7 + "." + ("MENU");
        }
            int rsTruncCountNumber_tDBOutput_7 = 0;
            try(java.sql.Statement stmtTruncCount_tDBOutput_7 = conn_tDBOutput_7.createStatement()) {
                try (java.sql.ResultSet rsTruncCount_tDBOutput_7 = stmtTruncCount_tDBOutput_7.executeQuery("SELECT COUNT(1) FROM " + tableName_tDBOutput_7 + "")) {
                    if(rsTruncCount_tDBOutput_7.next()) {
                        rsTruncCountNumber_tDBOutput_7 = rsTruncCount_tDBOutput_7.getInt(1);
                    }
                }
            }
            try (java.sql.Statement stmtTrunc_tDBOutput_7 = conn_tDBOutput_7.createStatement()) {
                stmtTrunc_tDBOutput_7.executeUpdate("TRUNCATE TABLE " + tableName_tDBOutput_7 + "");
                deletedCount_tDBOutput_7 += rsTruncCountNumber_tDBOutput_7;
            }
                String insert_tDBOutput_7 = "INSERT INTO " + tableName_tDBOutput_7 + " (ID_MENU,CODE_MENU,LIBELLE_MENU,NOMBRE_ARTICLES,TEMPS_THEO_PREPARATION) VALUES (?,?,?,?,?)";    

                        java.sql.PreparedStatement pstmt_tDBOutput_7 = conn_tDBOutput_7.prepareStatement(insert_tDBOutput_7);
                        resourceMap.put("pstmt_tDBOutput_7", pstmt_tDBOutput_7);





 



/**
 * [tDBOutput_7 begin ] stop
 */



	
	/**
	 * [tBigQueryInput_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tBigQueryInput_2", false);
		start_Hash.put("tBigQueryInput_2", System.currentTimeMillis());
		
				tStatCatcher_1.addMessage("begin","tBigQueryInput_2");
				tStatCatcher_1Process(globalMap);
			
	
	currentComponent="tBigQueryInput_2";

	
		int tos_count_tBigQueryInput_2 = 0;
		
	
	

		
class ServiceAccountBigQueryUtil_tBigQueryInput_2 {
	private com.google.cloud.bigquery.BigQuery bigQuery;
	private boolean useLargeResult;
	private String tempTable;

	public ServiceAccountBigQueryUtil_tBigQueryInput_2() {
		this.useLargeResult = false;
	}

	private com.google.cloud.bigquery.BigQuery buildBigQuery() throws java.io.IOException {
		if (bigQuery != null) {
			return bigQuery;
		}
		com.google.auth.oauth2.GoogleCredentials credentials;
		java.io.File credentialsFile = new java.io.File("C:/CC2/Groupe1/4_DATA_BIGQUERY/dsid-cc2-grp1-407520-99e8a6c61c07.json");
		try(java.io.FileInputStream credentialsStream = new java.io.FileInputStream(credentialsFile)) {
			credentials = com.google.auth.oauth2.ServiceAccountCredentials.fromStream(credentialsStream);
		}

		com.google.cloud.bigquery.BigQuery result = com.google.cloud.bigquery.BigQueryOptions.newBuilder()
			.setCredentials(credentials)
			.setProjectId("dsid-cc2-grp1-407520")
			.build()
			.getService();

		return result;
	}

	private com.google.cloud.bigquery.Job buildJob(com.google.cloud.bigquery.BigQuery bigquery, com.google.cloud.bigquery.QueryJobConfiguration queryConfiguration, com.google.cloud.bigquery.JobId jobId) throws InterruptedException {
        globalMap.put("tBigQueryInput_2_JOBID", jobId.getJob());
        com.google.cloud.bigquery.Job job = bigquery.create(com.google.cloud.bigquery.JobInfo.newBuilder(queryConfiguration).setJobId(jobId).build());

		
		job = job.waitFor();

		if (job == null) {
            String message = "tBigQueryInput_2 - Job no longer exists";
            globalMap.put("tBigQueryInput_2_ERROR_MESSAGE", message);
            throw new RuntimeException(message);
		} else if (job.getStatus().getError() != null) {
            com.google.gson.Gson gsonObject = new com.google.gson.Gson();
            globalMap.put("tBigQueryInput_2_STATISTICS", gsonObject.toJson(job.getStatistics()));
            String message = job.getStatus().getError().toString();
            globalMap.put("tBigQueryInput_2_ERROR_MESSAGE", message);
            throw new RuntimeException(message);
		}

		

		return job;
	}

	private com.google.cloud.bigquery.Job executeQuerySmallResult(String query, boolean useLegacySql) throws java.io.IOException, InterruptedException {
		bigQuery = buildBigQuery();
		com.google.cloud.bigquery.QueryJobConfiguration queryConfiguration = com.google.cloud.bigquery.QueryJobConfiguration.newBuilder(query)
			.setUseLegacySql(useLegacySql)
			.build();
		com.google.cloud.bigquery.JobId jobId = com.google.cloud.bigquery.JobId.of("dsid-cc2-grp1-407520", java.util.UUID.randomUUID().toString());
		return buildJob(bigQuery, queryConfiguration, jobId);
	}

	private com.google.cloud.bigquery.Job executeQueryLargeResult(String query, boolean useLegacySql) throws java.io.IOException, InterruptedException {
		bigQuery = buildBigQuery();

		
			com.google.cloud.bigquery.QueryJobConfiguration jobConfDryRun = com.google.cloud.bigquery.QueryJobConfiguration.newBuilder(query)
				.setUseLegacySql(useLegacySql)
				.setDryRun(true)
				.build();
			com.google.cloud.bigquery.Job jobDryRun = bigQuery.create(com.google.cloud.bigquery.JobInfo.of(jobConfDryRun));

			String queryLocation =jobDryRun.getJobId().getLocation();
			String location = queryLocation == null ? "US" : queryLocation;
			String tempDataset = java.util.UUID.randomUUID().toString().replaceAll("-", "")
			+ Integer.toHexString(java.util.concurrent.ThreadLocalRandom.current().nextInt())
			+ Integer.toHexString(java.util.concurrent.ThreadLocalRandom.current().nextInt());

			

			com.google.cloud.bigquery.DatasetInfo datasetInfo = com.google.cloud.bigquery.DatasetInfo.newBuilder(tempDataset).setLocation(location).build();
			com.google.cloud.bigquery.Dataset dataset = bigQuery.create(datasetInfo);
		
		tempTable = java.util.UUID.randomUUID().toString().replaceAll("-", "")
			+ Integer.toHexString(java.util.concurrent.ThreadLocalRandom.current().nextInt())
			+ Integer.toHexString(java.util.concurrent.ThreadLocalRandom.current().nextInt());
		
		com.google.cloud.bigquery.QueryJobConfiguration queryConfiguration = com.google.cloud.bigquery.QueryJobConfiguration.newBuilder(query)
			.setUseLegacySql(useLegacySql)
			.setDryRun(false)
			.setAllowLargeResults(true)
			.setDestinationTable(com.google.cloud.bigquery.TableId.of(tempDataset, tempTable))
			.build();

		com.google.cloud.bigquery.JobId jobId  = com.google.cloud.bigquery.JobId
			.newBuilder().setProject("dsid-cc2-grp1-407520")
			.setJob(java.util.UUID.randomUUID().toString())
			.build();

		
		return buildJob(bigQuery, queryConfiguration, jobId);
	}

	public com.google.cloud.bigquery.Job executeQuery(String query, boolean useLegacySql) throws Exception {

		com.google.cloud.bigquery.Job job;

		
			job = executeQuerySmallResult(query, useLegacySql);
		
		
		

		return job;
	}

    public java.util.List<com.google.cloud.bigquery.Job> getChildJobs(String jobId) throws java.io.IOException {
        return java.util.Optional.ofNullable(buildBigQuery().listJobs(com.google.cloud.bigquery.BigQuery.JobListOption.parentJobId(jobId)))
                    .map(com.google.api.gax.paging.Page::getValues)
                    .flatMap(iterable ->
                            java.util.Optional.ofNullable(java.util.stream.StreamSupport
                                .stream(iterable.spliterator(), false)
                                .collect(java.util.stream.Collectors.toList())))
                    .orElse(java.util.Collections.emptyList());
    }

	public void cleanup() throws Exception {
		if(useLargeResult) {
			
				com.google.cloud.bigquery.DatasetId datasetId = com.google.cloud.bigquery.DatasetId.of("dsid-cc2-grp1-407520", "temp_dataset");
				bigQuery.delete(datasetId, com.google.cloud.bigquery.BigQuery.DatasetDeleteOption.deleteContents());
			
		}
	}

}

		

		ServiceAccountBigQueryUtil_tBigQueryInput_2 serviceAccountBigQueryUtil_tBigQueryInput_2 = new ServiceAccountBigQueryUtil_tBigQueryInput_2();

        try {
                com.google.cloud.bigquery.Job job_tBigQueryInput_2 = serviceAccountBigQueryUtil_tBigQueryInput_2.executeQuery("SELECT * FROM `dsid-cc2-grp1-407520.dsid_liv_ope_bq.menu`", false);

                com.google.gson.Gson gsonObject_tBigQueryInput_2 = new com.google.gson.Gson();
                globalMap.put("tBigQueryInput_2_STATISTICS", gsonObject_tBigQueryInput_2.toJson(job_tBigQueryInput_2.getStatistics()));
                long nb_line_tBigQueryInput_2 = 0;
                java.util.List<String> child_statistics_tBigQueryInput_2 = null;
                java.util.List<com.google.cloud.bigquery.Job> childJobs_tBigQueryInput_2;
                if(job_tBigQueryInput_2.getStatistics().getNumChildJobs() != null){
                    childJobs_tBigQueryInput_2 = serviceAccountBigQueryUtil_tBigQueryInput_2.getChildJobs(job_tBigQueryInput_2.getJobId().getJob());
                    java.util.Collections.reverse(childJobs_tBigQueryInput_2);
                    child_statistics_tBigQueryInput_2 = new java.util.ArrayList<>();
                } else {
                    childJobs_tBigQueryInput_2 = java.util.Collections.singletonList(job_tBigQueryInput_2);
                }
                for (com.google.cloud.bigquery.Job job_iterable_tBigQueryInput_2 : childJobs_tBigQueryInput_2) {
                    if (child_statistics_tBigQueryInput_2 != null) {
                        child_statistics_tBigQueryInput_2.add(gsonObject_tBigQueryInput_2.toJson(job_iterable_tBigQueryInput_2.getStatistics()));
                    }
                    if (job_iterable_tBigQueryInput_2.getStatus().getError() != null) {
                        globalMap.put("tBigQueryInput_2_ERROR_MESSAGE", job_iterable_tBigQueryInput_2.getStatus().getError().toString());
                        String message_tBigQueryInput_2 = "tBigQueryInput_2 - " + job_iterable_tBigQueryInput_2.getStatus().getError().toString();
                System.err.println(message_tBigQueryInput_2);
                        continue;
                    }

                    com.google.cloud.bigquery.TableResult result_tBigQueryInput_2 = job_iterable_tBigQueryInput_2.getQueryResults();
		//Dynamic start

		
		//Dynamic end
	
		for (com.google.cloud.bigquery.FieldValueList field_tBigQueryInput_2 : result_tBigQueryInput_2.iterateAll()) {
			Object value_tBigQueryInput_2;
			nb_line_tBigQueryInput_2 ++;
	
		int fieldsCount_tBigQueryInput_2 = field_tBigQueryInput_2.size();
		int column_index_tBigQueryInput_2 =0;
		
									column_index_tBigQueryInput_2 = 0;
								
								if(fieldsCount_tBigQueryInput_2 <= column_index_tBigQueryInput_2) {
									row12.ID_MENU = null;
								} else {
								
								value_tBigQueryInput_2 = field_tBigQueryInput_2.get(column_index_tBigQueryInput_2).getValue();
								
								if(com.google.api.client.util.Data.isNull(value_tBigQueryInput_2)) value_tBigQueryInput_2 = null;

								if(value_tBigQueryInput_2 != null){

									
										row12.ID_MENU = ParserUtils.parseTo_BigDecimal(value_tBigQueryInput_2.toString());
									
								}else{
									row12.ID_MENU = null;
								}
								}
							
									column_index_tBigQueryInput_2 = 1;
								
								if(fieldsCount_tBigQueryInput_2 <= column_index_tBigQueryInput_2) {
									row12.CODE_MENU = null;
								} else {
								
								value_tBigQueryInput_2 = field_tBigQueryInput_2.get(column_index_tBigQueryInput_2).getValue();
								
								if(com.google.api.client.util.Data.isNull(value_tBigQueryInput_2)) value_tBigQueryInput_2 = null;

								if(value_tBigQueryInput_2 != null){

									
										row12.CODE_MENU = value_tBigQueryInput_2.toString();
									
								}else{
									row12.CODE_MENU = null;
								}
								}
							
									column_index_tBigQueryInput_2 = 2;
								
								if(fieldsCount_tBigQueryInput_2 <= column_index_tBigQueryInput_2) {
									row12.LIBELLE_MENU = null;
								} else {
								
								value_tBigQueryInput_2 = field_tBigQueryInput_2.get(column_index_tBigQueryInput_2).getValue();
								
								if(com.google.api.client.util.Data.isNull(value_tBigQueryInput_2)) value_tBigQueryInput_2 = null;

								if(value_tBigQueryInput_2 != null){

									
										row12.LIBELLE_MENU = value_tBigQueryInput_2.toString();
									
								}else{
									row12.LIBELLE_MENU = null;
								}
								}
							
									column_index_tBigQueryInput_2 = 3;
								
								if(fieldsCount_tBigQueryInput_2 <= column_index_tBigQueryInput_2) {
									row12.NOMBRE_ARTICLES = null;
								} else {
								
								value_tBigQueryInput_2 = field_tBigQueryInput_2.get(column_index_tBigQueryInput_2).getValue();
								
								if(com.google.api.client.util.Data.isNull(value_tBigQueryInput_2)) value_tBigQueryInput_2 = null;

								if(value_tBigQueryInput_2 != null){

									
										row12.NOMBRE_ARTICLES = ParserUtils.parseTo_BigDecimal(value_tBigQueryInput_2.toString());
									
								}else{
									row12.NOMBRE_ARTICLES = null;
								}
								}
							
									column_index_tBigQueryInput_2 = 4;
								
								if(fieldsCount_tBigQueryInput_2 <= column_index_tBigQueryInput_2) {
									row12.TEMPS_THEO_PREPARATION = null;
								} else {
								
								value_tBigQueryInput_2 = field_tBigQueryInput_2.get(column_index_tBigQueryInput_2).getValue();
								
								if(com.google.api.client.util.Data.isNull(value_tBigQueryInput_2)) value_tBigQueryInput_2 = null;

								if(value_tBigQueryInput_2 != null){

									
										row12.TEMPS_THEO_PREPARATION = value_tBigQueryInput_2.toString();
									
								}else{
									row12.TEMPS_THEO_PREPARATION = null;
								}
								}
							

 



/**
 * [tBigQueryInput_2 begin ] stop
 */
	
	/**
	 * [tBigQueryInput_2 main ] start
	 */

	

	
	
	currentComponent="tBigQueryInput_2";

	

 


	tos_count_tBigQueryInput_2++;

/**
 * [tBigQueryInput_2 main ] stop
 */
	
	/**
	 * [tBigQueryInput_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tBigQueryInput_2";

	

 



/**
 * [tBigQueryInput_2 process_data_begin ] stop
 */

	
	/**
	 * [tDBOutput_7 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_7";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row12"
						
						);
					}
					



        whetherReject_tDBOutput_7 = false;
                        pstmt_tDBOutput_7.setBigDecimal(1, row12.ID_MENU);

                        if(row12.CODE_MENU == null) {
pstmt_tDBOutput_7.setNull(2, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_7.setString(2, row12.CODE_MENU);
}

                        if(row12.LIBELLE_MENU == null) {
pstmt_tDBOutput_7.setNull(3, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_7.setString(3, row12.LIBELLE_MENU);
}

                        pstmt_tDBOutput_7.setBigDecimal(4, row12.NOMBRE_ARTICLES);

                        if(row12.TEMPS_THEO_PREPARATION == null) {
pstmt_tDBOutput_7.setNull(5, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_7.setString(5, row12.TEMPS_THEO_PREPARATION);
}

                pstmt_tDBOutput_7.addBatch();
                nb_line_tDBOutput_7++;
                batchSizeCounter_tDBOutput_7++;
            if (batchSize_tDBOutput_7 > 0 &&  batchSize_tDBOutput_7 <= batchSizeCounter_tDBOutput_7) {
                try {
                    pstmt_tDBOutput_7.executeBatch();
                }catch (java.sql.BatchUpdateException e_tDBOutput_7){
globalMap.put("tDBOutput_7_ERROR_MESSAGE",e_tDBOutput_7.getMessage());
			        java.sql.SQLException ne_tDBOutput_7 = e_tDBOutput_7.getNextException(),sqle_tDBOutput_7=null;
			    	String errormessage_tDBOutput_7;
					if (ne_tDBOutput_7 != null) {
						// build new exception to provide the original cause
						sqle_tDBOutput_7 = new java.sql.SQLException(e_tDBOutput_7.getMessage() + "\ncaused by: " + ne_tDBOutput_7.getMessage(), ne_tDBOutput_7.getSQLState(), ne_tDBOutput_7.getErrorCode(), ne_tDBOutput_7);
						errormessage_tDBOutput_7 = sqle_tDBOutput_7.getMessage();
					}else{
						errormessage_tDBOutput_7 = e_tDBOutput_7.getMessage();
					}
	            	
	                	System.err.println(errormessage_tDBOutput_7);
	            	
	        	}
                tmp_batchUpdateCount_tDBOutput_7 = pstmt_tDBOutput_7.getUpdateCount();
                    insertedCount_tDBOutput_7
                += (tmp_batchUpdateCount_tDBOutput_7!=-1?tmp_batchUpdateCount_tDBOutput_7:0);
                rowsToCommitCount_tDBOutput_7 += (tmp_batchUpdateCount_tDBOutput_7!=-1?tmp_batchUpdateCount_tDBOutput_7:0);
                batchSizeCounter_tDBOutput_7 = 0;
            }
                commitCounter_tDBOutput_7++;
                if(commitEvery_tDBOutput_7 <= commitCounter_tDBOutput_7) {
                    if(batchSizeCounter_tDBOutput_7 > 0) {
                        try {
                            pstmt_tDBOutput_7.executeBatch();
                        }catch (java.sql.BatchUpdateException e_tDBOutput_7){
globalMap.put("tDBOutput_7_ERROR_MESSAGE",e_tDBOutput_7.getMessage());
					        java.sql.SQLException ne_tDBOutput_7 = e_tDBOutput_7.getNextException(),sqle_tDBOutput_7=null;
					    	String errormessage_tDBOutput_7;
							if (ne_tDBOutput_7 != null) {
								// build new exception to provide the original cause
								sqle_tDBOutput_7 = new java.sql.SQLException(e_tDBOutput_7.getMessage() + "\ncaused by: " + ne_tDBOutput_7.getMessage(), ne_tDBOutput_7.getSQLState(), ne_tDBOutput_7.getErrorCode(), ne_tDBOutput_7);
								errormessage_tDBOutput_7 = sqle_tDBOutput_7.getMessage();
							}else{
								errormessage_tDBOutput_7 = e_tDBOutput_7.getMessage();
							}
			            	
			                	System.err.println(errormessage_tDBOutput_7);
			            	
			        	}
                        tmp_batchUpdateCount_tDBOutput_7 = pstmt_tDBOutput_7.getUpdateCount();
                            insertedCount_tDBOutput_7
                        += (tmp_batchUpdateCount_tDBOutput_7!=-1?tmp_batchUpdateCount_tDBOutput_7:0);
                        rowsToCommitCount_tDBOutput_7 += (tmp_batchUpdateCount_tDBOutput_7!=-1?tmp_batchUpdateCount_tDBOutput_7:0);
                    }
                    if(rowsToCommitCount_tDBOutput_7 != 0){
                    	
                    }
                    conn_tDBOutput_7.commit();
                    if(rowsToCommitCount_tDBOutput_7 != 0){
                    	
                    	rowsToCommitCount_tDBOutput_7 = 0;
                    }
                    commitCounter_tDBOutput_7=0;
                    	batchSizeCounter_tDBOutput_7=0;
                }

 


	tos_count_tDBOutput_7++;

/**
 * [tDBOutput_7 main ] stop
 */
	
	/**
	 * [tDBOutput_7 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_7";

	

 



/**
 * [tDBOutput_7 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_7 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_7";

	

 



/**
 * [tDBOutput_7 process_data_end ] stop
 */



	
	/**
	 * [tBigQueryInput_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tBigQueryInput_2";

	

 



/**
 * [tBigQueryInput_2 process_data_end ] stop
 */
	
	/**
	 * [tBigQueryInput_2 end ] start
	 */

	

	
	
	currentComponent="tBigQueryInput_2";

	
	
	
            }
            if (child_statistics_tBigQueryInput_2 != null) {
                globalMap.put("tBigQueryInput_2_STATISTICS_CHILD", child_statistics_tBigQueryInput_2.stream().collect(java.util.stream.Collectors.joining(",", "{\"statistics\": [", "]}")));
            }
        //}
}
        } catch (Exception e_tBigQueryInput_2) {
            String message_tBigQueryInput_2 = e_tBigQueryInput_2.getMessage();
                System.err.println(message_tBigQueryInput_2);
            globalMap.put("tBigQueryInput_2_ERROR_MESSAGE", message_tBigQueryInput_2);
            throw e_tBigQueryInput_2;
        } finally {
            serviceAccountBigQueryUtil_tBigQueryInput_2.cleanup();
        }

 

ok_Hash.put("tBigQueryInput_2", true);
end_Hash.put("tBigQueryInput_2", System.currentTimeMillis());

tStatCatcher_1.addMessage("end","tBigQueryInput_2", end_Hash.get("tBigQueryInput_2")-start_Hash.get("tBigQueryInput_2"));
tStatCatcher_1Process(globalMap);



/**
 * [tBigQueryInput_2 end ] stop
 */

	
	/**
	 * [tDBOutput_7 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_7";

	
	



	
        if(batchSizeCounter_tDBOutput_7 > 0) {
            try {
            	if (pstmt_tDBOutput_7 != null) {
					
					pstmt_tDBOutput_7.executeBatch();
					
        	    }
            }catch (java.sql.BatchUpdateException e_tDBOutput_7){
globalMap.put("tDBOutput_7_ERROR_MESSAGE",e_tDBOutput_7.getMessage());
		        java.sql.SQLException ne_tDBOutput_7 = e_tDBOutput_7.getNextException(),sqle_tDBOutput_7=null;
		    	String errormessage_tDBOutput_7;
				if (ne_tDBOutput_7 != null) {
					// build new exception to provide the original cause
					sqle_tDBOutput_7 = new java.sql.SQLException(e_tDBOutput_7.getMessage() + "\ncaused by: " + ne_tDBOutput_7.getMessage(), ne_tDBOutput_7.getSQLState(), ne_tDBOutput_7.getErrorCode(), ne_tDBOutput_7);
					errormessage_tDBOutput_7 = sqle_tDBOutput_7.getMessage();
				}else{
					errormessage_tDBOutput_7 = e_tDBOutput_7.getMessage();
				}
            	
                	System.err.println(errormessage_tDBOutput_7);
            	
        	}
        	if (pstmt_tDBOutput_7 != null) {
            	tmp_batchUpdateCount_tDBOutput_7 = pstmt_tDBOutput_7.getUpdateCount();
    	    	
    	    		insertedCount_tDBOutput_7
    	    	
    	    	+= (tmp_batchUpdateCount_tDBOutput_7!=-1?tmp_batchUpdateCount_tDBOutput_7:0);
				rowsToCommitCount_tDBOutput_7 += (tmp_batchUpdateCount_tDBOutput_7!=-1?tmp_batchUpdateCount_tDBOutput_7:0);
            }
        }
        if(pstmt_tDBOutput_7 != null) {
			
				pstmt_tDBOutput_7.close();
				resourceMap.remove("pstmt_tDBOutput_7");
			
        }
    resourceMap.put("statementClosed_tDBOutput_7", true);
		if(commitCounter_tDBOutput_7 > 0 && rowsToCommitCount_tDBOutput_7 != 0) {
			
		}
		conn_tDBOutput_7.commit();
		if(commitCounter_tDBOutput_7 > 0 && rowsToCommitCount_tDBOutput_7 != 0) {
			
			rowsToCommitCount_tDBOutput_7 = 0;
		}
		commitCounter_tDBOutput_7 = 0;
		
		
		conn_tDBOutput_7 .close();
		
		resourceMap.put("finish_tDBOutput_7", true);
   	

	
	nb_line_deleted_tDBOutput_7=nb_line_deleted_tDBOutput_7+ deletedCount_tDBOutput_7;
	nb_line_update_tDBOutput_7=nb_line_update_tDBOutput_7 + updatedCount_tDBOutput_7;
	nb_line_inserted_tDBOutput_7=nb_line_inserted_tDBOutput_7 + insertedCount_tDBOutput_7;
	nb_line_rejected_tDBOutput_7=nb_line_rejected_tDBOutput_7 + rejectedCount_tDBOutput_7;
	
        globalMap.put("tDBOutput_7_NB_LINE",nb_line_tDBOutput_7);
        globalMap.put("tDBOutput_7_NB_LINE_UPDATED",nb_line_update_tDBOutput_7);
        globalMap.put("tDBOutput_7_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_7);
        globalMap.put("tDBOutput_7_NB_LINE_DELETED",nb_line_deleted_tDBOutput_7);
        globalMap.put("tDBOutput_7_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_7);
    

	



				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row12");
			  	}
			  	
 

ok_Hash.put("tDBOutput_7", true);
end_Hash.put("tDBOutput_7", System.currentTimeMillis());

tStatCatcher_1.addMessage("end","tDBOutput_7", end_Hash.get("tDBOutput_7")-start_Hash.get("tDBOutput_7"));
tStatCatcher_1Process(globalMap);



/**
 * [tDBOutput_7 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tBigQueryInput_2 finally ] start
	 */

	

	
	
	currentComponent="tBigQueryInput_2";

	

 



/**
 * [tBigQueryInput_2 finally ] stop
 */

	
	/**
	 * [tDBOutput_7 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_7";

	



    try {
    if (resourceMap.get("statementClosed_tDBOutput_7") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_7 = null;
                if ((pstmtToClose_tDBOutput_7 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_7")) != null) {
                    pstmtToClose_tDBOutput_7.close();
                }
    }
    } finally {
        if(resourceMap.get("finish_tDBOutput_7") == null){
            java.sql.Connection ctn_tDBOutput_7 = null;
            if((ctn_tDBOutput_7 = (java.sql.Connection)resourceMap.get("conn_tDBOutput_7")) != null){
                try {
                    ctn_tDBOutput_7.close();
                } catch (java.sql.SQLException sqlEx_tDBOutput_7) {
                    String errorMessage_tDBOutput_7 = "failed to close the connection in tDBOutput_7 :" + sqlEx_tDBOutput_7.getMessage();
                    System.err.println(errorMessage_tDBOutput_7);
                }
            }
        }
    }
 



/**
 * [tDBOutput_7 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tBigQueryInput_2_SUBPROCESS_STATE", 1);
	}
	

public void tDBRow_6Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBRow_6_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tDBRow_6 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBRow_6", false);
		start_Hash.put("tDBRow_6", System.currentTimeMillis());
		
				tStatCatcher_1.addMessage("begin","tDBRow_6");
				tStatCatcher_1Process(globalMap);
			
	
	currentComponent="tDBRow_6";

	
		int tos_count_tDBRow_6 = 0;
		

	java.sql.Connection conn_tDBRow_6 = null;
	String query_tDBRow_6 = "";
	boolean whetherReject_tDBRow_6 = false;
			String driverClass_tDBRow_6 = "oracle.jdbc.OracleDriver";
		    java.lang.Class jdbcclazz_tDBRow_6 = java.lang.Class.forName(driverClass_tDBRow_6);
		
			String url_tDBRow_6 = null;
				url_tDBRow_6 = "jdbc:oracle:thin:@(description=(address=(protocol=tcp)(host=" + "" + ")(port=" + "1521" + "))(connect_data=(service_name=" + "XEPDB1" + ")))";
					String dbUser_tDBRow_6 = "DSID_LIV_OPE";
	        
            		
            		
            		 
	final String decryptedPassword_tDBRow_6 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:eHdb7U8ffaWFioSOvyJ5kycVYS2HaL161bqU4KENRMY=");
        		   	
        	        String dbPwd_tDBRow_6 = decryptedPassword_tDBRow_6;
	        
					
			conn_tDBRow_6 = java.sql.DriverManager.getConnection(url_tDBRow_6,dbUser_tDBRow_6,dbPwd_tDBRow_6);
		
        resourceMap.put("conn_tDBRow_6", conn_tDBRow_6);
					if(conn_tDBRow_6.getAutoCommit()) {
						
				conn_tDBRow_6.setAutoCommit(false);
			
					}        
					int commitEvery_tDBRow_6 = 10000;
					int commitCounter_tDBRow_6 = 0;
				
        java.sql.Statement stmt_tDBRow_6 = conn_tDBRow_6.createStatement();
        resourceMap.put("stmt_tDBRow_6", stmt_tDBRow_6);

 



/**
 * [tDBRow_6 begin ] stop
 */
	
	/**
	 * [tDBRow_6 main ] start
	 */

	

	
	
	currentComponent="tDBRow_6";

	

query_tDBRow_6 = "TRUNCATE TABLE  DSID_LIV_OPE.CLIENT";
whetherReject_tDBRow_6 = false;
globalMap.put("tDBRow_6_QUERY",query_tDBRow_6);
try {
		stmt_tDBRow_6.execute(query_tDBRow_6);
		
	} catch (java.lang.Exception e) {
globalMap.put("tDBRow_6_ERROR_MESSAGE",e.getMessage());
		whetherReject_tDBRow_6 = true;
		
				System.err.print(e.getMessage());
				
	}
	
	if(!whetherReject_tDBRow_6) {
		
	}
	
		commitCounter_tDBRow_6++;
		if(commitEvery_tDBRow_6 <= commitCounter_tDBRow_6) {
			
			conn_tDBRow_6.commit();
			
			commitCounter_tDBRow_6=0;
		}
		

 


	tos_count_tDBRow_6++;

/**
 * [tDBRow_6 main ] stop
 */
	
	/**
	 * [tDBRow_6 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBRow_6";

	

 



/**
 * [tDBRow_6 process_data_begin ] stop
 */
	
	/**
	 * [tDBRow_6 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBRow_6";

	

 



/**
 * [tDBRow_6 process_data_end ] stop
 */
	
	/**
	 * [tDBRow_6 end ] start
	 */

	

	
	
	currentComponent="tDBRow_6";

	

	
        stmt_tDBRow_6.close();
        resourceMap.remove("stmt_tDBRow_6");
    resourceMap.put("statementClosed_tDBRow_6", true);
		if(commitEvery_tDBRow_6>commitCounter_tDBRow_6){

			
			conn_tDBRow_6.commit();
			
	
			commitCounter_tDBRow_6=0;
	
		}
			conn_tDBRow_6.close();
			
			if("com.mysql.cj.jdbc.Driver".equals((String)globalMap.get("driverClass_"))
			    && routines.system.BundleUtils.inOSGi()) {
			        Class.forName("com.mysql.cj.jdbc.AbandonedConnectionCleanupThread").
			            getMethod("checkedShutdown").invoke(null, (Object[]) null);
			}
			
    resourceMap.put("finish_tDBRow_6", true);

 

ok_Hash.put("tDBRow_6", true);
end_Hash.put("tDBRow_6", System.currentTimeMillis());

tStatCatcher_1.addMessage("end","tDBRow_6", end_Hash.get("tDBRow_6")-start_Hash.get("tDBRow_6"));
tStatCatcher_1Process(globalMap);
				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk7", 0, "ok");
				}
				tDBRow_7Process(globalMap);



/**
 * [tDBRow_6 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBRow_6 finally ] start
	 */

	

	
	
	currentComponent="tDBRow_6";

	

try {
    if (resourceMap.get("statementClosed_tDBRow_6") == null) {
            java.sql.Statement stmtToClose_tDBRow_6 = null;
            if ((stmtToClose_tDBRow_6 = (java.sql.Statement) resourceMap.remove("stmt_tDBRow_6")) != null) {
                stmtToClose_tDBRow_6.close();
            }
    }
} finally {
        if(resourceMap.get("finish_tDBRow_6") == null){
            java.sql.Connection ctn_tDBRow_6 = null;
            if((ctn_tDBRow_6 = (java.sql.Connection)resourceMap.get("conn_tDBRow_6")) != null){
                try {
                    ctn_tDBRow_6.close();
                } catch (java.sql.SQLException sqlEx_tDBRow_6) {
                    String errorMessage_tDBRow_6 = "failed to close the connection in tDBRow_6 :" + sqlEx_tDBRow_6.getMessage();
                    System.err.println(errorMessage_tDBRow_6);
                }
            }
        }
    }
 



/**
 * [tDBRow_6 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBRow_6_SUBPROCESS_STATE", 1);
	}
	

public void tDBRow_7Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBRow_7_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tDBRow_7 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBRow_7", false);
		start_Hash.put("tDBRow_7", System.currentTimeMillis());
		
				tStatCatcher_1.addMessage("begin","tDBRow_7");
				tStatCatcher_1Process(globalMap);
			
	
	currentComponent="tDBRow_7";

	
		int tos_count_tDBRow_7 = 0;
		

	java.sql.Connection conn_tDBRow_7 = null;
	String query_tDBRow_7 = "";
	boolean whetherReject_tDBRow_7 = false;
			String driverClass_tDBRow_7 = "oracle.jdbc.OracleDriver";
		    java.lang.Class jdbcclazz_tDBRow_7 = java.lang.Class.forName(driverClass_tDBRow_7);
		
			String url_tDBRow_7 = null;
				url_tDBRow_7 = "jdbc:oracle:thin:@(description=(address=(protocol=tcp)(host=" + "" + ")(port=" + "1521" + "))(connect_data=(service_name=" + "XEPDB1" + ")))";
					String dbUser_tDBRow_7 = "DSID_LIV_OPE";
	        
            		
            		
            		 
	final String decryptedPassword_tDBRow_7 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:pzi2aQs8sSAGW5cQOTZIfpdFHwBc1aTVebLFwxgmxcE=");
        		   	
        	        String dbPwd_tDBRow_7 = decryptedPassword_tDBRow_7;
	        
					
			conn_tDBRow_7 = java.sql.DriverManager.getConnection(url_tDBRow_7,dbUser_tDBRow_7,dbPwd_tDBRow_7);
		
        resourceMap.put("conn_tDBRow_7", conn_tDBRow_7);
					if(conn_tDBRow_7.getAutoCommit()) {
						
				conn_tDBRow_7.setAutoCommit(false);
			
					}        
					int commitEvery_tDBRow_7 = 10000;
					int commitCounter_tDBRow_7 = 0;
				
        java.sql.Statement stmt_tDBRow_7 = conn_tDBRow_7.createStatement();
        resourceMap.put("stmt_tDBRow_7", stmt_tDBRow_7);

 



/**
 * [tDBRow_7 begin ] stop
 */
	
	/**
	 * [tDBRow_7 main ] start
	 */

	

	
	
	currentComponent="tDBRow_7";

	

query_tDBRow_7 = "TRUNCATE TABLE  DSID_LIV_OPE.ADRESSE_NORMALISEE_CLIENT";
whetherReject_tDBRow_7 = false;
globalMap.put("tDBRow_7_QUERY",query_tDBRow_7);
try {
		stmt_tDBRow_7.execute(query_tDBRow_7);
		
	} catch (java.lang.Exception e) {
globalMap.put("tDBRow_7_ERROR_MESSAGE",e.getMessage());
		whetherReject_tDBRow_7 = true;
		
				System.err.print(e.getMessage());
				
	}
	
	if(!whetherReject_tDBRow_7) {
		
	}
	
		commitCounter_tDBRow_7++;
		if(commitEvery_tDBRow_7 <= commitCounter_tDBRow_7) {
			
			conn_tDBRow_7.commit();
			
			commitCounter_tDBRow_7=0;
		}
		

 


	tos_count_tDBRow_7++;

/**
 * [tDBRow_7 main ] stop
 */
	
	/**
	 * [tDBRow_7 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBRow_7";

	

 



/**
 * [tDBRow_7 process_data_begin ] stop
 */
	
	/**
	 * [tDBRow_7 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBRow_7";

	

 



/**
 * [tDBRow_7 process_data_end ] stop
 */
	
	/**
	 * [tDBRow_7 end ] start
	 */

	

	
	
	currentComponent="tDBRow_7";

	

	
        stmt_tDBRow_7.close();
        resourceMap.remove("stmt_tDBRow_7");
    resourceMap.put("statementClosed_tDBRow_7", true);
		if(commitEvery_tDBRow_7>commitCounter_tDBRow_7){

			
			conn_tDBRow_7.commit();
			
	
			commitCounter_tDBRow_7=0;
	
		}
			conn_tDBRow_7.close();
			
			if("com.mysql.cj.jdbc.Driver".equals((String)globalMap.get("driverClass_"))
			    && routines.system.BundleUtils.inOSGi()) {
			        Class.forName("com.mysql.cj.jdbc.AbandonedConnectionCleanupThread").
			            getMethod("checkedShutdown").invoke(null, (Object[]) null);
			}
			
    resourceMap.put("finish_tDBRow_7", true);

 

ok_Hash.put("tDBRow_7", true);
end_Hash.put("tDBRow_7", System.currentTimeMillis());

tStatCatcher_1.addMessage("end","tDBRow_7", end_Hash.get("tDBRow_7")-start_Hash.get("tDBRow_7"));
tStatCatcher_1Process(globalMap);
				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk8", 0, "ok");
				}
				tFileInputXML_1Process(globalMap);



/**
 * [tDBRow_7 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBRow_7 finally ] start
	 */

	

	
	
	currentComponent="tDBRow_7";

	

try {
    if (resourceMap.get("statementClosed_tDBRow_7") == null) {
            java.sql.Statement stmtToClose_tDBRow_7 = null;
            if ((stmtToClose_tDBRow_7 = (java.sql.Statement) resourceMap.remove("stmt_tDBRow_7")) != null) {
                stmtToClose_tDBRow_7.close();
            }
    }
} finally {
        if(resourceMap.get("finish_tDBRow_7") == null){
            java.sql.Connection ctn_tDBRow_7 = null;
            if((ctn_tDBRow_7 = (java.sql.Connection)resourceMap.get("conn_tDBRow_7")) != null){
                try {
                    ctn_tDBRow_7.close();
                } catch (java.sql.SQLException sqlEx_tDBRow_7) {
                    String errorMessage_tDBRow_7 = "failed to close the connection in tDBRow_7 :" + sqlEx_tDBRow_7.getMessage();
                    System.err.println(errorMessage_tDBRow_7);
                }
            }
        }
    }
 



/**
 * [tDBRow_7 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBRow_7_SUBPROCESS_STATE", 1);
	}
	


public static class row4Struct implements routines.system.IPersistableRow<row4Struct> {
    final static byte[] commonByteArrayLock_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ = new byte[0];
    static byte[] commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int ID_ADRESSE_CLIENT;

				public int getID_ADRESSE_CLIENT () {
					return this.ID_ADRESSE_CLIENT;
				}
				
			    public String ADRESSE_CLIENT;

				public String getADRESSE_CLIENT () {
					return this.ADRESSE_CLIENT;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.ID_ADRESSE_CLIENT;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row4Struct other = (row4Struct) obj;
		
						if (this.ID_ADRESSE_CLIENT != other.ID_ADRESSE_CLIENT)
							return false;
					

		return true;
    }

	public void copyDataTo(row4Struct other) {

		other.ID_ADRESSE_CLIENT = this.ID_ADRESSE_CLIENT;
	            other.ADRESSE_CLIENT = this.ADRESSE_CLIENT;
	            
	}

	public void copyKeysDataTo(row4Struct other) {

		other.ID_ADRESSE_CLIENT = this.ID_ADRESSE_CLIENT;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ.length == 0) {
   					commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ.length == 0) {
   					commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ) {

        	try {

        		int length = 0;
		
			        this.ID_ADRESSE_CLIENT = dis.readInt();
					
					this.ADRESSE_CLIENT = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ) {

        	try {

        		int length = 0;
		
			        this.ID_ADRESSE_CLIENT = dis.readInt();
					
					this.ADRESSE_CLIENT = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.ID_ADRESSE_CLIENT);
					
					// String
				
						writeString(this.ADRESSE_CLIENT,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.ID_ADRESSE_CLIENT);
					
					// String
				
						writeString(this.ADRESSE_CLIENT,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("ID_ADRESSE_CLIENT="+String.valueOf(ID_ADRESSE_CLIENT));
		sb.append(",ADRESSE_CLIENT="+ADRESSE_CLIENT);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row4Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.ID_ADRESSE_CLIENT, other.ID_ADRESSE_CLIENT);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row1Struct implements routines.system.IPersistableRow<row1Struct> {
    final static byte[] commonByteArrayLock_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ = new byte[0];
    static byte[] commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int ID_ADRESSE_CLIENT;

				public int getID_ADRESSE_CLIENT () {
					return this.ID_ADRESSE_CLIENT;
				}
				
			    public String ADRESSE_CLIENT;

				public String getADRESSE_CLIENT () {
					return this.ADRESSE_CLIENT;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.ID_ADRESSE_CLIENT;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row1Struct other = (row1Struct) obj;
		
						if (this.ID_ADRESSE_CLIENT != other.ID_ADRESSE_CLIENT)
							return false;
					

		return true;
    }

	public void copyDataTo(row1Struct other) {

		other.ID_ADRESSE_CLIENT = this.ID_ADRESSE_CLIENT;
	            other.ADRESSE_CLIENT = this.ADRESSE_CLIENT;
	            
	}

	public void copyKeysDataTo(row1Struct other) {

		other.ID_ADRESSE_CLIENT = this.ID_ADRESSE_CLIENT;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ.length == 0) {
   					commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ.length == 0) {
   					commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ) {

        	try {

        		int length = 0;
		
			        this.ID_ADRESSE_CLIENT = dis.readInt();
					
					this.ADRESSE_CLIENT = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ) {

        	try {

        		int length = 0;
		
			        this.ID_ADRESSE_CLIENT = dis.readInt();
					
					this.ADRESSE_CLIENT = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.ID_ADRESSE_CLIENT);
					
					// String
				
						writeString(this.ADRESSE_CLIENT,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.ID_ADRESSE_CLIENT);
					
					// String
				
						writeString(this.ADRESSE_CLIENT,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("ID_ADRESSE_CLIENT="+String.valueOf(ID_ADRESSE_CLIENT));
		sb.append(",ADRESSE_CLIENT="+ADRESSE_CLIENT);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row1Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.ID_ADRESSE_CLIENT, other.ID_ADRESSE_CLIENT);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row2Struct implements routines.system.IPersistableRow<row2Struct> {
    final static byte[] commonByteArrayLock_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ = new byte[0];
    static byte[] commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int ID_ADRESSE_CLIENT;

				public int getID_ADRESSE_CLIENT () {
					return this.ID_ADRESSE_CLIENT;
				}
				
			    public String ADRESSE_CLIENT;

				public String getADRESSE_CLIENT () {
					return this.ADRESSE_CLIENT;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.ID_ADRESSE_CLIENT;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row2Struct other = (row2Struct) obj;
		
						if (this.ID_ADRESSE_CLIENT != other.ID_ADRESSE_CLIENT)
							return false;
					

		return true;
    }

	public void copyDataTo(row2Struct other) {

		other.ID_ADRESSE_CLIENT = this.ID_ADRESSE_CLIENT;
	            other.ADRESSE_CLIENT = this.ADRESSE_CLIENT;
	            
	}

	public void copyKeysDataTo(row2Struct other) {

		other.ID_ADRESSE_CLIENT = this.ID_ADRESSE_CLIENT;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ.length == 0) {
   					commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ.length == 0) {
   					commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ) {

        	try {

        		int length = 0;
		
			        this.ID_ADRESSE_CLIENT = dis.readInt();
					
					this.ADRESSE_CLIENT = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ) {

        	try {

        		int length = 0;
		
			        this.ID_ADRESSE_CLIENT = dis.readInt();
					
					this.ADRESSE_CLIENT = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.ID_ADRESSE_CLIENT);
					
					// String
				
						writeString(this.ADRESSE_CLIENT,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.ID_ADRESSE_CLIENT);
					
					// String
				
						writeString(this.ADRESSE_CLIENT,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("ID_ADRESSE_CLIENT="+String.valueOf(ID_ADRESSE_CLIENT));
		sb.append(",ADRESSE_CLIENT="+ADRESSE_CLIENT);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row2Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.ID_ADRESSE_CLIENT, other.ID_ADRESSE_CLIENT);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row3Struct implements routines.system.IPersistableRow<row3Struct> {
    final static byte[] commonByteArrayLock_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ = new byte[0];
    static byte[] commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int ID_ADRESSE_CLIENT;

				public int getID_ADRESSE_CLIENT () {
					return this.ID_ADRESSE_CLIENT;
				}
				
			    public String ADRESSE_CLIENT;

				public String getADRESSE_CLIENT () {
					return this.ADRESSE_CLIENT;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.ID_ADRESSE_CLIENT;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row3Struct other = (row3Struct) obj;
		
						if (this.ID_ADRESSE_CLIENT != other.ID_ADRESSE_CLIENT)
							return false;
					

		return true;
    }

	public void copyDataTo(row3Struct other) {

		other.ID_ADRESSE_CLIENT = this.ID_ADRESSE_CLIENT;
	            other.ADRESSE_CLIENT = this.ADRESSE_CLIENT;
	            
	}

	public void copyKeysDataTo(row3Struct other) {

		other.ID_ADRESSE_CLIENT = this.ID_ADRESSE_CLIENT;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ.length == 0) {
   					commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ.length == 0) {
   					commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ) {

        	try {

        		int length = 0;
		
			        this.ID_ADRESSE_CLIENT = dis.readInt();
					
					this.ADRESSE_CLIENT = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ) {

        	try {

        		int length = 0;
		
			        this.ID_ADRESSE_CLIENT = dis.readInt();
					
					this.ADRESSE_CLIENT = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.ID_ADRESSE_CLIENT);
					
					// String
				
						writeString(this.ADRESSE_CLIENT,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.ID_ADRESSE_CLIENT);
					
					// String
				
						writeString(this.ADRESSE_CLIENT,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("ID_ADRESSE_CLIENT="+String.valueOf(ID_ADRESSE_CLIENT));
		sb.append(",ADRESSE_CLIENT="+ADRESSE_CLIENT);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row3Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.ID_ADRESSE_CLIENT, other.ID_ADRESSE_CLIENT);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tFileInputXML_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFileInputXML_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row1Struct row1 = new row1Struct();

		row2Struct row2 = new row2Struct();

		row3Struct row3 = new row3Struct();

			row4Struct row4 = new row4Struct();




	
	/**
	 * [tDBOutput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_1", false);
		start_Hash.put("tDBOutput_1", System.currentTimeMillis());
		
				tStatCatcher_1.addMessage("begin","tDBOutput_1");
				tStatCatcher_1Process(globalMap);
			
	
	currentComponent="tDBOutput_1";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row4");
					}
				
		int tos_count_tDBOutput_1 = 0;
		






    
    int nb_line_tDBOutput_1 = 0;
    int nb_line_update_tDBOutput_1 = 0;
    int nb_line_inserted_tDBOutput_1 = 0;
    int nb_line_deleted_tDBOutput_1 = 0;
    int nb_line_rejected_tDBOutput_1 = 0;

    int tmp_batchUpdateCount_tDBOutput_1 = 0;

    int deletedCount_tDBOutput_1=0;
    int updatedCount_tDBOutput_1=0;
    int insertedCount_tDBOutput_1=0;
    int rowsToCommitCount_tDBOutput_1=0;
    int rejectedCount_tDBOutput_1=0;

    boolean whetherReject_tDBOutput_1 = false;

    java.sql.Connection conn_tDBOutput_1 = null;

    //optional table
    String dbschema_tDBOutput_1 = null;
    String tableName_tDBOutput_1 = null;
                    String driverClass_tDBOutput_1 = "oracle.jdbc.OracleDriver";


                java.lang.Class.forName(driverClass_tDBOutput_1);
                String url_tDBOutput_1 = null;
                    url_tDBOutput_1 = "jdbc:oracle:thin:@(description=(address=(protocol=tcp)(host=" + "" + ")(port=" + "1521" + "))(connect_data=(service_name=" + "XEPDB1" + ")))";
                String dbUser_tDBOutput_1 = "DSID_LIV_OPE";
 
	final String decryptedPassword_tDBOutput_1 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:43F2qSxzuADJir1xWba0txMqPwSXJHT5HkuNAsX5zt8=");

                String dbPwd_tDBOutput_1 = decryptedPassword_tDBOutput_1;
                dbschema_tDBOutput_1 = "DSID_LIV_OPE";


                    conn_tDBOutput_1 = java.sql.DriverManager.getConnection(url_tDBOutput_1, dbUser_tDBOutput_1, dbPwd_tDBOutput_1);
        resourceMap.put("conn_tDBOutput_1", conn_tDBOutput_1);
            conn_tDBOutput_1.setAutoCommit(false);
            int commitEvery_tDBOutput_1 = 10000;
            int commitCounter_tDBOutput_1 = 0;
        int batchSize_tDBOutput_1 = 10000;
        int batchSizeCounter_tDBOutput_1=0;
        int count_tDBOutput_1=0;

        if(dbschema_tDBOutput_1 == null || dbschema_tDBOutput_1.trim().length() == 0) {
            tableName_tDBOutput_1 = ("ADRESSE_CLIENT");
        } else {
            tableName_tDBOutput_1 = dbschema_tDBOutput_1 + "." + ("ADRESSE_CLIENT");
        }
            int rsTruncCountNumber_tDBOutput_1 = 0;
            try(java.sql.Statement stmtTruncCount_tDBOutput_1 = conn_tDBOutput_1.createStatement()) {
                try (java.sql.ResultSet rsTruncCount_tDBOutput_1 = stmtTruncCount_tDBOutput_1.executeQuery("SELECT COUNT(1) FROM " + tableName_tDBOutput_1 + "")) {
                    if(rsTruncCount_tDBOutput_1.next()) {
                        rsTruncCountNumber_tDBOutput_1 = rsTruncCount_tDBOutput_1.getInt(1);
                    }
                }
            }
            try (java.sql.Statement stmtTrunc_tDBOutput_1 = conn_tDBOutput_1.createStatement()) {
                stmtTrunc_tDBOutput_1.executeUpdate("TRUNCATE TABLE " + tableName_tDBOutput_1 + "");
                deletedCount_tDBOutput_1 += rsTruncCountNumber_tDBOutput_1;
            }
                String insert_tDBOutput_1 = "INSERT INTO " + tableName_tDBOutput_1 + " (ID_ADRESSE_CLIENT,ADRESSE_CLIENT) VALUES (?,?)";    

                        java.sql.PreparedStatement pstmt_tDBOutput_1 = conn_tDBOutput_1.prepareStatement(insert_tDBOutput_1);
                        resourceMap.put("pstmt_tDBOutput_1", pstmt_tDBOutput_1);





 



/**
 * [tDBOutput_1 begin ] stop
 */



	
	/**
	 * [tUnite_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tUnite_1", false);
		start_Hash.put("tUnite_1", System.currentTimeMillis());
		
				tStatCatcher_1.addMessage("begin","tUnite_1");
				tStatCatcher_1Process(globalMap);
			
	
	currentComponent="tUnite_1";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row3","row1","row2");
					}
				
		int tos_count_tUnite_1 = 0;
		

int nb_line_tUnite_1 = 0;

 



/**
 * [tUnite_1 begin ] stop
 */
	
	/**
	 * [tFileInputXML_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileInputXML_1", false);
		start_Hash.put("tFileInputXML_1", System.currentTimeMillis());
		
				tStatCatcher_1.addMessage("begin","tFileInputXML_1");
				tStatCatcher_1Process(globalMap);
			
	
	currentComponent="tFileInputXML_1";

	
		int tos_count_tFileInputXML_1 = 0;
		

	

int nb_line_tFileInputXML_1 = 0;

	String os_tFileInputXML_1 = System.getProperty("os.name").toLowerCase();
	boolean isWindows_tFileInputXML_1=false;
	if(os_tFileInputXML_1.indexOf("windows") > -1 || os_tFileInputXML_1.indexOf("nt") > -1){
		isWindows_tFileInputXML_1=true;
	}
class NameSpaceTool_tFileInputXML_1 {

    public java.util.HashMap<String, String> xmlNameSpaceMap = new java.util.HashMap<String, String>();
    
	private java.util.List<String> defualtNSPath = new java.util.ArrayList<String>();

    public void countNSMap(org.dom4j.Element el) {
        for (org.dom4j.Namespace ns : (java.util.List<org.dom4j.Namespace>) el.declaredNamespaces()) {
            if (ns.getPrefix().trim().length() == 0) {
                xmlNameSpaceMap.put("pre"+defualtNSPath.size(), ns.getURI());
                String path = "";
                org.dom4j.Element elTmp = el;
                while (elTmp != null) {
                	if (elTmp.getNamespacePrefix() != null && elTmp.getNamespacePrefix().length() > 0) {
                        path = "/" + elTmp.getNamespacePrefix() + ":" + elTmp.getName() + path;
                    } else {
                        path = "/" + elTmp.getName() + path;
                    }
                    elTmp = elTmp.getParent();
                }
                defualtNSPath.add(path);
            } else {
                xmlNameSpaceMap.put(ns.getPrefix(), ns.getURI());
            }

        }
        for (org.dom4j.Element e : (java.util.List<org.dom4j.Element>) el.elements()) {
            countNSMap(e);
        }
    }
    
    private final org.talend.xpath.XPathUtil util = new  org.talend.xpath.XPathUtil();
    
    {
    	util.setDefaultNSPath(defualtNSPath);
    }
    
	public String addDefaultNSPrefix(String path) {
		return util.addDefaultNSPrefix(path);
	}
	
	public String addDefaultNSPrefix(String relativeXpression, String basePath) {
		return util.addDefaultNSPrefix(relativeXpression,basePath);
	}
    
}

class XML_API_tFileInputXML_1{
	public boolean isDefNull(org.dom4j.Node node) throws javax.xml.transform.TransformerException {
        if (node != null && node instanceof org.dom4j.Element) {
        	org.dom4j.Attribute attri = ((org.dom4j.Element)node).attribute("nil");
        	if(attri != null && ("true").equals(attri.getText())){
            	return true;
            }
        }
        return false;
    }

    public boolean isMissing(org.dom4j.Node node) throws javax.xml.transform.TransformerException {
        return node == null ? true : false;
    }

    public boolean isEmpty(org.dom4j.Node node) throws javax.xml.transform.TransformerException {
        if (node != null) {
            return node.getText().length() == 0;
        }
        return false;
    }
}


org.dom4j.io.SAXReader reader_tFileInputXML_1 = new org.dom4j.io.SAXReader();
Object filename_tFileInputXML_1 = null;
try {
	filename_tFileInputXML_1 = "C:/CC2/Groupe1/5_DATA_IN/adresse_client_1.xml";
} catch(java.lang.Exception e) {
globalMap.put("tFileInputXML_1_ERROR_MESSAGE",e.getMessage());
	
	
	System.err.println(e.getMessage());
	
}
if(filename_tFileInputXML_1 != null && filename_tFileInputXML_1 instanceof String && filename_tFileInputXML_1.toString().startsWith("//")){
	if (!isWindows_tFileInputXML_1){
		filename_tFileInputXML_1 = filename_tFileInputXML_1.toString().replaceFirst("//","/");
	}
}

boolean isValidFile_tFileInputXML_1 = true;
org.dom4j.Document doc_tFileInputXML_1 = null;
java.io.Closeable toClose_tFileInputXML_1 = null;
try{
	if(filename_tFileInputXML_1 instanceof java.io.InputStream){
		java.io.InputStream inputStream_tFileInputXML_1 = (java.io.InputStream)filename_tFileInputXML_1;
		toClose_tFileInputXML_1 = inputStream_tFileInputXML_1;
		doc_tFileInputXML_1 = reader_tFileInputXML_1.read(inputStream_tFileInputXML_1);
	}else{
		java.io.Reader unicodeReader_tFileInputXML_1 = new UnicodeReader(new java.io.FileInputStream(String.valueOf(filename_tFileInputXML_1)),"UTF-8");
		toClose_tFileInputXML_1 = unicodeReader_tFileInputXML_1;
		org.xml.sax.InputSource in_tFileInputXML_1= new org.xml.sax.InputSource(unicodeReader_tFileInputXML_1);
		doc_tFileInputXML_1 = reader_tFileInputXML_1.read(in_tFileInputXML_1);
	}
}catch(java.lang.Exception e){
globalMap.put("tFileInputXML_1_ERROR_MESSAGE",e.getMessage());
	
	System.err.println(e.getMessage());
	isValidFile_tFileInputXML_1 = false;
} finally {
	if(toClose_tFileInputXML_1!=null) {
		toClose_tFileInputXML_1.close();
	}
}
if(isValidFile_tFileInputXML_1){
NameSpaceTool_tFileInputXML_1 nsTool_tFileInputXML_1 = new NameSpaceTool_tFileInputXML_1();
nsTool_tFileInputXML_1.countNSMap(doc_tFileInputXML_1.getRootElement());
java.util.HashMap<String,String> xmlNameSpaceMap_tFileInputXML_1 = nsTool_tFileInputXML_1.xmlNameSpaceMap;  

org.dom4j.XPath x_tFileInputXML_1 = doc_tFileInputXML_1.createXPath(nsTool_tFileInputXML_1.addDefaultNSPrefix("/ADRESSES_CLIENTS/ADRESSE_CLIENT"));  
x_tFileInputXML_1.setNamespaceURIs(xmlNameSpaceMap_tFileInputXML_1); 

java.util.List<org.dom4j.Node> nodeList_tFileInputXML_1 = (java.util.List<org.dom4j.Node>)x_tFileInputXML_1.selectNodes(doc_tFileInputXML_1);	
XML_API_tFileInputXML_1 xml_api_tFileInputXML_1 = new XML_API_tFileInputXML_1();
String str_tFileInputXML_1 = "";
org.dom4j.Node node_tFileInputXML_1 = null;

//init all mapping xpaths
java.util.Map<Integer,org.dom4j.XPath> xpaths_tFileInputXML_1=new java.util.HashMap<Integer,org.dom4j.XPath>();
	class XPathUtil_tFileInputXML_1{
	
			   public void initXPaths_0(java.util.Map<Integer,org.dom4j.XPath> xpaths,NameSpaceTool_tFileInputXML_1 nsTool,
			       java.util.HashMap<String,String> xmlNameSpaceMap){
			
	org.dom4j.XPath xpath_0 = org.dom4j.DocumentHelper.createXPath(nsTool.addDefaultNSPrefix("ID_ADRESSE_CLIENT","/ADRESSES_CLIENTS/ADRESSE_CLIENT"));
	xpath_0.setNamespaceURIs(xmlNameSpaceMap);
	
			xpaths.put(0,xpath_0);
			
	org.dom4j.XPath xpath_1 = org.dom4j.DocumentHelper.createXPath(nsTool.addDefaultNSPrefix("ADRESSE_CLIENT","/ADRESSES_CLIENTS/ADRESSE_CLIENT"));
	xpath_1.setNamespaceURIs(xmlNameSpaceMap);
	
			xpaths.put(1,xpath_1);
			
	     }
	   
	      public void initXPaths(java.util.Map<Integer,org.dom4j.XPath> xpaths,NameSpaceTool_tFileInputXML_1 nsTool,
			    java.util.HashMap<String,String> xmlNameSpaceMap){
			    
			        initXPaths_0(xpaths,nsTool, xmlNameSpaceMap);
			    
		   }
	}
	XPathUtil_tFileInputXML_1 xPathUtil_tFileInputXML_1 = new XPathUtil_tFileInputXML_1();
	xPathUtil_tFileInputXML_1.initXPaths(xpaths_tFileInputXML_1, nsTool_tFileInputXML_1, xmlNameSpaceMap_tFileInputXML_1);
for (org.dom4j.Node temp_tFileInputXML_1: nodeList_tFileInputXML_1) {
	if (nb_line_tFileInputXML_1>=50) {
	
		break;
	}
		nb_line_tFileInputXML_1++;
		
	row1 = null;			
	boolean whetherReject_tFileInputXML_1 = false;
	row1 = new row1Struct();
	try{
    Object obj0_tFileInputXML_1 = xpaths_tFileInputXML_1.get(0).evaluate(temp_tFileInputXML_1);
    if(obj0_tFileInputXML_1 == null) {
    	node_tFileInputXML_1 = null;
    	str_tFileInputXML_1 = "";
    	
    } else if(obj0_tFileInputXML_1 instanceof org.dom4j.Node) {
    	node_tFileInputXML_1 = (org.dom4j.Node)obj0_tFileInputXML_1;
    	str_tFileInputXML_1 = org.jaxen.function.StringFunction.evaluate(node_tFileInputXML_1,org.jaxen.dom4j.DocumentNavigator.getInstance());
    } else if(obj0_tFileInputXML_1 instanceof String || obj0_tFileInputXML_1 instanceof Number){
    	node_tFileInputXML_1 = temp_tFileInputXML_1;
    	str_tFileInputXML_1 = String.valueOf(obj0_tFileInputXML_1);
    } else if(obj0_tFileInputXML_1 instanceof java.util.List){
    	java.util.List<org.dom4j.Node> nodes_tFileInputXML_1 = (java.util.List<org.dom4j.Node>)obj0_tFileInputXML_1;
    	node_tFileInputXML_1 = nodes_tFileInputXML_1.size()>0 ? nodes_tFileInputXML_1.get(0) : null;
    	str_tFileInputXML_1 = node_tFileInputXML_1==null?"":org.jaxen.function.StringFunction.evaluate(node_tFileInputXML_1,org.jaxen.dom4j.DocumentNavigator.getInstance());
	}
										if(xml_api_tFileInputXML_1.isMissing(node_tFileInputXML_1) || xml_api_tFileInputXML_1.isEmpty(node_tFileInputXML_1)){
											row1.ID_ADRESSE_CLIENT =0;
										}else{
		row1.ID_ADRESSE_CLIENT = ParserUtils.parseTo_int(str_tFileInputXML_1);
	}
    Object obj1_tFileInputXML_1 = xpaths_tFileInputXML_1.get(1).evaluate(temp_tFileInputXML_1);
    if(obj1_tFileInputXML_1 == null) {
    	node_tFileInputXML_1 = null;
    	str_tFileInputXML_1 = "";
    	
    } else if(obj1_tFileInputXML_1 instanceof org.dom4j.Node) {
    	node_tFileInputXML_1 = (org.dom4j.Node)obj1_tFileInputXML_1;
    	str_tFileInputXML_1 = org.jaxen.function.StringFunction.evaluate(node_tFileInputXML_1,org.jaxen.dom4j.DocumentNavigator.getInstance());
    } else if(obj1_tFileInputXML_1 instanceof String || obj1_tFileInputXML_1 instanceof Number){
    	node_tFileInputXML_1 = temp_tFileInputXML_1;
    	str_tFileInputXML_1 = String.valueOf(obj1_tFileInputXML_1);
    } else if(obj1_tFileInputXML_1 instanceof java.util.List){
    	java.util.List<org.dom4j.Node> nodes_tFileInputXML_1 = (java.util.List<org.dom4j.Node>)obj1_tFileInputXML_1;
    	node_tFileInputXML_1 = nodes_tFileInputXML_1.size()>0 ? nodes_tFileInputXML_1.get(0) : null;
    	str_tFileInputXML_1 = node_tFileInputXML_1==null?"":org.jaxen.function.StringFunction.evaluate(node_tFileInputXML_1,org.jaxen.dom4j.DocumentNavigator.getInstance());
	}
									if(xml_api_tFileInputXML_1.isDefNull(node_tFileInputXML_1)){
											row1.ADRESSE_CLIENT =null;
									}else if(xml_api_tFileInputXML_1.isEmpty(node_tFileInputXML_1)){
										row1.ADRESSE_CLIENT ="";
									}else if(xml_api_tFileInputXML_1.isMissing(node_tFileInputXML_1 )){ 
										row1.ADRESSE_CLIENT =null;
									}else{
		row1.ADRESSE_CLIENT = str_tFileInputXML_1;
	} 
			
    } catch (java.lang.Exception e) {
globalMap.put("tFileInputXML_1_ERROR_MESSAGE",e.getMessage());
        whetherReject_tFileInputXML_1 = true;
                System.err.println(e.getMessage());
                row1 = null;
    }
			
			

 



/**
 * [tFileInputXML_1 begin ] stop
 */
	
	/**
	 * [tFileInputXML_1 main ] start
	 */

	

	
	
	currentComponent="tFileInputXML_1";

	

 


	tos_count_tFileInputXML_1++;

/**
 * [tFileInputXML_1 main ] stop
 */
	
	/**
	 * [tFileInputXML_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFileInputXML_1";

	

 



/**
 * [tFileInputXML_1 process_data_begin ] stop
 */
// Start of branch "row1"
if(row1 != null) { 



	
	/**
	 * [tUnite_1 main ] start
	 */

	

	
	
	currentComponent="tUnite_1";

	
						if(execStat){
							runStat.updateStatOnConnection(iterateId,1,1
								
									,"row1"
									
							);
						}
						
//////////
 

// for output
			row4 = new row4Struct();
								
			row4.ID_ADRESSE_CLIENT = row1.ID_ADRESSE_CLIENT;								
			row4.ADRESSE_CLIENT = row1.ADRESSE_CLIENT;			

			nb_line_tUnite_1++;

//////////
 


	tos_count_tUnite_1++;

/**
 * [tUnite_1 main ] stop
 */
	
	/**
	 * [tUnite_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tUnite_1";

	

 



/**
 * [tUnite_1 process_data_begin ] stop
 */

	
	/**
	 * [tDBOutput_1 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row4"
						
						);
					}
					



        whetherReject_tDBOutput_1 = false;
                        pstmt_tDBOutput_1.setInt(1, row4.ID_ADRESSE_CLIENT);

                        if(row4.ADRESSE_CLIENT == null) {
pstmt_tDBOutput_1.setNull(2, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(2, row4.ADRESSE_CLIENT);
}

                pstmt_tDBOutput_1.addBatch();
                nb_line_tDBOutput_1++;
                batchSizeCounter_tDBOutput_1++;
            if (batchSize_tDBOutput_1 > 0 &&  batchSize_tDBOutput_1 <= batchSizeCounter_tDBOutput_1) {
                try {
                    pstmt_tDBOutput_1.executeBatch();
                }catch (java.sql.BatchUpdateException e_tDBOutput_1){
globalMap.put("tDBOutput_1_ERROR_MESSAGE",e_tDBOutput_1.getMessage());
			        java.sql.SQLException ne_tDBOutput_1 = e_tDBOutput_1.getNextException(),sqle_tDBOutput_1=null;
			    	String errormessage_tDBOutput_1;
					if (ne_tDBOutput_1 != null) {
						// build new exception to provide the original cause
						sqle_tDBOutput_1 = new java.sql.SQLException(e_tDBOutput_1.getMessage() + "\ncaused by: " + ne_tDBOutput_1.getMessage(), ne_tDBOutput_1.getSQLState(), ne_tDBOutput_1.getErrorCode(), ne_tDBOutput_1);
						errormessage_tDBOutput_1 = sqle_tDBOutput_1.getMessage();
					}else{
						errormessage_tDBOutput_1 = e_tDBOutput_1.getMessage();
					}
	            	
	                	System.err.println(errormessage_tDBOutput_1);
	            	
	        	}
                tmp_batchUpdateCount_tDBOutput_1 = pstmt_tDBOutput_1.getUpdateCount();
                    insertedCount_tDBOutput_1
                += (tmp_batchUpdateCount_tDBOutput_1!=-1?tmp_batchUpdateCount_tDBOutput_1:0);
                rowsToCommitCount_tDBOutput_1 += (tmp_batchUpdateCount_tDBOutput_1!=-1?tmp_batchUpdateCount_tDBOutput_1:0);
                batchSizeCounter_tDBOutput_1 = 0;
            }
                commitCounter_tDBOutput_1++;
                if(commitEvery_tDBOutput_1 <= commitCounter_tDBOutput_1) {
                    if(batchSizeCounter_tDBOutput_1 > 0) {
                        try {
                            pstmt_tDBOutput_1.executeBatch();
                        }catch (java.sql.BatchUpdateException e_tDBOutput_1){
globalMap.put("tDBOutput_1_ERROR_MESSAGE",e_tDBOutput_1.getMessage());
					        java.sql.SQLException ne_tDBOutput_1 = e_tDBOutput_1.getNextException(),sqle_tDBOutput_1=null;
					    	String errormessage_tDBOutput_1;
							if (ne_tDBOutput_1 != null) {
								// build new exception to provide the original cause
								sqle_tDBOutput_1 = new java.sql.SQLException(e_tDBOutput_1.getMessage() + "\ncaused by: " + ne_tDBOutput_1.getMessage(), ne_tDBOutput_1.getSQLState(), ne_tDBOutput_1.getErrorCode(), ne_tDBOutput_1);
								errormessage_tDBOutput_1 = sqle_tDBOutput_1.getMessage();
							}else{
								errormessage_tDBOutput_1 = e_tDBOutput_1.getMessage();
							}
			            	
			                	System.err.println(errormessage_tDBOutput_1);
			            	
			        	}
                        tmp_batchUpdateCount_tDBOutput_1 = pstmt_tDBOutput_1.getUpdateCount();
                            insertedCount_tDBOutput_1
                        += (tmp_batchUpdateCount_tDBOutput_1!=-1?tmp_batchUpdateCount_tDBOutput_1:0);
                        rowsToCommitCount_tDBOutput_1 += (tmp_batchUpdateCount_tDBOutput_1!=-1?tmp_batchUpdateCount_tDBOutput_1:0);
                    }
                    if(rowsToCommitCount_tDBOutput_1 != 0){
                    	
                    }
                    conn_tDBOutput_1.commit();
                    if(rowsToCommitCount_tDBOutput_1 != 0){
                    	
                    	rowsToCommitCount_tDBOutput_1 = 0;
                    }
                    commitCounter_tDBOutput_1=0;
                    	batchSizeCounter_tDBOutput_1=0;
                }

 


	tos_count_tDBOutput_1++;

/**
 * [tDBOutput_1 main ] stop
 */
	
	/**
	 * [tDBOutput_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";

	

 



/**
 * [tDBOutput_1 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";

	

 



/**
 * [tDBOutput_1 process_data_end ] stop
 */



	
	/**
	 * [tUnite_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tUnite_1";

	

 



/**
 * [tUnite_1 process_data_end ] stop
 */

} // End of branch "row1"




	
	/**
	 * [tFileInputXML_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tFileInputXML_1";

	

 



/**
 * [tFileInputXML_1 process_data_end ] stop
 */
	
	/**
	 * [tFileInputXML_1 end ] start
	 */

	

	
	
	currentComponent="tFileInputXML_1";

	


}
	}
	globalMap.put("tFileInputXML_1_NB_LINE",nb_line_tFileInputXML_1);

	

 

ok_Hash.put("tFileInputXML_1", true);
end_Hash.put("tFileInputXML_1", System.currentTimeMillis());

tStatCatcher_1.addMessage("end","tFileInputXML_1", end_Hash.get("tFileInputXML_1")-start_Hash.get("tFileInputXML_1"));
tStatCatcher_1Process(globalMap);



/**
 * [tFileInputXML_1 end ] stop
 */
	
	/**
	 * [tFileInputExcel_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileInputExcel_1", false);
		start_Hash.put("tFileInputExcel_1", System.currentTimeMillis());
		
				tStatCatcher_1.addMessage("begin","tFileInputExcel_1");
				tStatCatcher_1Process(globalMap);
			
	
	currentComponent="tFileInputExcel_1";

	
		int tos_count_tFileInputExcel_1 = 0;
		



			class RegexUtil_tFileInputExcel_1 {

		    	public java.util.List<jxl.Sheet> getSheets(jxl.Workbook workbook, String oneSheetName, boolean useRegex) {

			        java.util.List<jxl.Sheet> list = new java.util.ArrayList<jxl.Sheet>();

			        if(useRegex){//this part process the regex issue

				        jxl.Sheet[] sheets = workbook.getSheets();
				        java.util.regex.Pattern pattern = java.util.regex.Pattern.compile(oneSheetName);
				        for (int i = 0; i < sheets.length; i++) {
				            String sheetName = sheets[i].getName();
				            java.util.regex.Matcher matcher = pattern.matcher(sheetName);
				            if (matcher.matches()) {
				            	jxl.Sheet sheet = workbook.getSheet(sheetName);
				            	if(sheet != null){
				                	list.add(sheet);
				                }
				            }
				        }

			        }else{
			        	jxl.Sheet sheet = workbook.getSheet(oneSheetName);
		            	if(sheet != null){
		                	list.add(sheet);
		                }

			        }

			        return list;
			    }

			    public java.util.List<jxl.Sheet> getSheets(jxl.Workbook workbook, int index, boolean useRegex) {
			    	java.util.List<jxl.Sheet> list =  new java.util.ArrayList<jxl.Sheet>();
			    	jxl.Sheet sheet = workbook.getSheet(index);
	            	if(sheet != null){
	                	list.add(sheet);
	                }
			    	return list;
			    }

			}


		RegexUtil_tFileInputExcel_1 regexUtil_tFileInputExcel_1 = new RegexUtil_tFileInputExcel_1();
		final jxl.WorkbookSettings workbookSettings_tFileInputExcel_1 = new jxl.WorkbookSettings();
		workbookSettings_tFileInputExcel_1.setDrawingsDisabled(true);
        workbookSettings_tFileInputExcel_1.setEncoding("UTF-8");

        Object source_tFileInputExcel_1 ="C:/CC2/Groupe1/5_DATA_IN/adresse_client_2.xls";
        final jxl.Workbook workbook_tFileInputExcel_1;

        java.io.InputStream toClose_tFileInputExcel_1 = null;
        java.io.BufferedInputStream buffIStreamtFileInputExcel_1 = null;
        try {
            if(source_tFileInputExcel_1 instanceof java.io.InputStream){
        		toClose_tFileInputExcel_1 = (java.io.InputStream)source_tFileInputExcel_1;
        		buffIStreamtFileInputExcel_1 = new java.io.BufferedInputStream(toClose_tFileInputExcel_1);
        		workbook_tFileInputExcel_1 = jxl.Workbook.getWorkbook(buffIStreamtFileInputExcel_1, workbookSettings_tFileInputExcel_1);
            }else if(source_tFileInputExcel_1 instanceof String){
        		toClose_tFileInputExcel_1 = new java.io.FileInputStream(source_tFileInputExcel_1.toString());
        		buffIStreamtFileInputExcel_1 = new java.io.BufferedInputStream(toClose_tFileInputExcel_1);
        		workbook_tFileInputExcel_1 = jxl.Workbook.getWorkbook(buffIStreamtFileInputExcel_1, workbookSettings_tFileInputExcel_1);
            }else{
            	workbook_tFileInputExcel_1 = null;
            	throw new java.lang.Exception("The data source should be specified as Inputstream or File Path!");
            }
        } finally {
			try{
			   if(buffIStreamtFileInputExcel_1 != null){
			   	  buffIStreamtFileInputExcel_1.close();
			   }
			}catch(Exception e){
globalMap.put("tFileInputExcel_1_ERROR_MESSAGE",e.getMessage());
			}
        }
        try {
		java.util.List<jxl.Sheet> sheetList_tFileInputExcel_1 = java.util.Arrays.<jxl.Sheet> asList(workbook_tFileInputExcel_1.getSheets());
        if(sheetList_tFileInputExcel_1.size() <= 0){
        	throw new RuntimeException("Special sheets not exist!");
        }

        java.util.List<jxl.Sheet> sheet_FilterNullList_tFileInputExcel_1 = new java.util.ArrayList<jxl.Sheet>();
        for(jxl.Sheet sheet_FilterNull_tFileInputExcel_1 : sheetList_tFileInputExcel_1){
        	if(sheet_FilterNull_tFileInputExcel_1.getRows()>0){
        		sheet_FilterNullList_tFileInputExcel_1.add(sheet_FilterNull_tFileInputExcel_1);
        	}
        }
		sheetList_tFileInputExcel_1 = sheet_FilterNullList_tFileInputExcel_1;
	if(sheetList_tFileInputExcel_1.size()>0){
        int nb_line_tFileInputExcel_1 = 0;

        int begin_line_tFileInputExcel_1 = 1;

        int footer_input_tFileInputExcel_1 = 0;

        int end_line_tFileInputExcel_1=0;
        for(jxl.Sheet sheet_tFileInputExcel_1:sheetList_tFileInputExcel_1){
        	end_line_tFileInputExcel_1+=sheet_tFileInputExcel_1.getRows();
        }
        end_line_tFileInputExcel_1 -= footer_input_tFileInputExcel_1;
        int limit_tFileInputExcel_1 = -1;
        int start_column_tFileInputExcel_1 = 1-1;
        int end_column_tFileInputExcel_1 = sheetList_tFileInputExcel_1.get(0).getColumns();
        jxl.Cell[] row_tFileInputExcel_1 = null;
        jxl.Sheet sheet_tFileInputExcel_1 = sheetList_tFileInputExcel_1.get(0);
        int rowCount_tFileInputExcel_1 = 0;
        int sheetIndex_tFileInputExcel_1 = 0;
        int currentRows_tFileInputExcel_1 = sheetList_tFileInputExcel_1.get(0).getRows();

        //for the number format
        java.text.DecimalFormat df_tFileInputExcel_1 = new java.text.DecimalFormat("#.####################################");
		char separatorChar_tFileInputExcel_1 = df_tFileInputExcel_1.getDecimalFormatSymbols().getDecimalSeparator();
		
		
		
        for(int i_tFileInputExcel_1 = begin_line_tFileInputExcel_1; i_tFileInputExcel_1 < end_line_tFileInputExcel_1; i_tFileInputExcel_1++){

        	int emptyColumnCount_tFileInputExcel_1 = 0;

        	if (limit_tFileInputExcel_1 != -1 && nb_line_tFileInputExcel_1 >= limit_tFileInputExcel_1) {
        		break;
        	}

            while (i_tFileInputExcel_1 >= rowCount_tFileInputExcel_1 + currentRows_tFileInputExcel_1) {
                rowCount_tFileInputExcel_1 += currentRows_tFileInputExcel_1;
                sheet_tFileInputExcel_1 = sheetList_tFileInputExcel_1.get(++sheetIndex_tFileInputExcel_1);
                currentRows_tFileInputExcel_1 = sheet_tFileInputExcel_1.getRows();
            }
            if (rowCount_tFileInputExcel_1 <= i_tFileInputExcel_1) {
                row_tFileInputExcel_1 = sheet_tFileInputExcel_1.getRow(i_tFileInputExcel_1 - rowCount_tFileInputExcel_1);
            }
        	globalMap.put("tFileInputExcel_1_CURRENT_SHEET",sheet_tFileInputExcel_1.getName());
    		row2 = null;
					int tempRowLength_tFileInputExcel_1 = 2;
				
				int columnIndex_tFileInputExcel_1 = 0;
			
//
//end%>
			
			String[] temp_row_tFileInputExcel_1 = new String[tempRowLength_tFileInputExcel_1];
			int actual_end_column_tFileInputExcel_1 = end_column_tFileInputExcel_1 >	row_tFileInputExcel_1.length ? row_tFileInputExcel_1.length : end_column_tFileInputExcel_1;

				java.util.TimeZone zone_tFileInputExcel_1 = java.util.TimeZone.getTimeZone("GMT");
                java.text.SimpleDateFormat sdf_tFileInputExcel_1 = new java.text.SimpleDateFormat("dd-MM-yyyy");
                sdf_tFileInputExcel_1.setTimeZone(zone_tFileInputExcel_1);
                

			for(int i=0;i<tempRowLength_tFileInputExcel_1;i++){

				if(i + start_column_tFileInputExcel_1 < actual_end_column_tFileInputExcel_1){

				  jxl.Cell cell_tFileInputExcel_1 = row_tFileInputExcel_1[i + start_column_tFileInputExcel_1];
                        temp_row_tFileInputExcel_1[i] = cell_tFileInputExcel_1.getContents();

				}else{
					temp_row_tFileInputExcel_1[i]="";
				}
			}

			boolean whetherReject_tFileInputExcel_1 = false;
			row2 = new row2Struct();
			int curColNum_tFileInputExcel_1 = -1;
			String curColName_tFileInputExcel_1 = "";
			try {
							columnIndex_tFileInputExcel_1 = 0;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "ID_ADRESSE_CLIENT";
			row2.ID_ADRESSE_CLIENT = ParserUtils.parseTo_int(temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1]);
			}else {
				row2.ID_ADRESSE_CLIENT = 0;
				emptyColumnCount_tFileInputExcel_1++;
		}
							columnIndex_tFileInputExcel_1 = 1;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "ADRESSE_CLIENT";
			row2.ADRESSE_CLIENT = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
			}else {
				row2.ADRESSE_CLIENT = null;
				emptyColumnCount_tFileInputExcel_1++;
		}

			nb_line_tFileInputExcel_1++;
			
    } catch (java.lang.Exception e) {
globalMap.put("tFileInputExcel_1_ERROR_MESSAGE",e.getMessage());
        whetherReject_tFileInputExcel_1 = true;
                System.err.println(e.getMessage());
                row2 = null;
    }

					
		



 



/**
 * [tFileInputExcel_1 begin ] stop
 */
	
	/**
	 * [tFileInputExcel_1 main ] start
	 */

	

	
	
	currentComponent="tFileInputExcel_1";

	

 


	tos_count_tFileInputExcel_1++;

/**
 * [tFileInputExcel_1 main ] stop
 */
	
	/**
	 * [tFileInputExcel_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFileInputExcel_1";

	

 



/**
 * [tFileInputExcel_1 process_data_begin ] stop
 */
// Start of branch "row2"
if(row2 != null) { 



	
	/**
	 * [tUnite_1 main ] start
	 */

	

	
	
	currentComponent="tUnite_1";

	
						if(execStat){
							runStat.updateStatOnConnection(iterateId,1,1
								
									,"row2"
									
							);
						}
						
//////////
 

// for output
			row4 = new row4Struct();
								
			row4.ID_ADRESSE_CLIENT = row2.ID_ADRESSE_CLIENT;								
			row4.ADRESSE_CLIENT = row2.ADRESSE_CLIENT;			

			nb_line_tUnite_1++;

//////////
 


	tos_count_tUnite_1++;

/**
 * [tUnite_1 main ] stop
 */
	
	/**
	 * [tUnite_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tUnite_1";

	

 



/**
 * [tUnite_1 process_data_begin ] stop
 */

	
	/**
	 * [tDBOutput_1 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row4"
						
						);
					}
					



        whetherReject_tDBOutput_1 = false;
                        pstmt_tDBOutput_1.setInt(1, row4.ID_ADRESSE_CLIENT);

                        if(row4.ADRESSE_CLIENT == null) {
pstmt_tDBOutput_1.setNull(2, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(2, row4.ADRESSE_CLIENT);
}

                pstmt_tDBOutput_1.addBatch();
                nb_line_tDBOutput_1++;
                batchSizeCounter_tDBOutput_1++;
            if (batchSize_tDBOutput_1 > 0 &&  batchSize_tDBOutput_1 <= batchSizeCounter_tDBOutput_1) {
                try {
                    pstmt_tDBOutput_1.executeBatch();
                }catch (java.sql.BatchUpdateException e_tDBOutput_1){
globalMap.put("tDBOutput_1_ERROR_MESSAGE",e_tDBOutput_1.getMessage());
			        java.sql.SQLException ne_tDBOutput_1 = e_tDBOutput_1.getNextException(),sqle_tDBOutput_1=null;
			    	String errormessage_tDBOutput_1;
					if (ne_tDBOutput_1 != null) {
						// build new exception to provide the original cause
						sqle_tDBOutput_1 = new java.sql.SQLException(e_tDBOutput_1.getMessage() + "\ncaused by: " + ne_tDBOutput_1.getMessage(), ne_tDBOutput_1.getSQLState(), ne_tDBOutput_1.getErrorCode(), ne_tDBOutput_1);
						errormessage_tDBOutput_1 = sqle_tDBOutput_1.getMessage();
					}else{
						errormessage_tDBOutput_1 = e_tDBOutput_1.getMessage();
					}
	            	
	                	System.err.println(errormessage_tDBOutput_1);
	            	
	        	}
                tmp_batchUpdateCount_tDBOutput_1 = pstmt_tDBOutput_1.getUpdateCount();
                    insertedCount_tDBOutput_1
                += (tmp_batchUpdateCount_tDBOutput_1!=-1?tmp_batchUpdateCount_tDBOutput_1:0);
                rowsToCommitCount_tDBOutput_1 += (tmp_batchUpdateCount_tDBOutput_1!=-1?tmp_batchUpdateCount_tDBOutput_1:0);
                batchSizeCounter_tDBOutput_1 = 0;
            }
                commitCounter_tDBOutput_1++;
                if(commitEvery_tDBOutput_1 <= commitCounter_tDBOutput_1) {
                    if(batchSizeCounter_tDBOutput_1 > 0) {
                        try {
                            pstmt_tDBOutput_1.executeBatch();
                        }catch (java.sql.BatchUpdateException e_tDBOutput_1){
globalMap.put("tDBOutput_1_ERROR_MESSAGE",e_tDBOutput_1.getMessage());
					        java.sql.SQLException ne_tDBOutput_1 = e_tDBOutput_1.getNextException(),sqle_tDBOutput_1=null;
					    	String errormessage_tDBOutput_1;
							if (ne_tDBOutput_1 != null) {
								// build new exception to provide the original cause
								sqle_tDBOutput_1 = new java.sql.SQLException(e_tDBOutput_1.getMessage() + "\ncaused by: " + ne_tDBOutput_1.getMessage(), ne_tDBOutput_1.getSQLState(), ne_tDBOutput_1.getErrorCode(), ne_tDBOutput_1);
								errormessage_tDBOutput_1 = sqle_tDBOutput_1.getMessage();
							}else{
								errormessage_tDBOutput_1 = e_tDBOutput_1.getMessage();
							}
			            	
			                	System.err.println(errormessage_tDBOutput_1);
			            	
			        	}
                        tmp_batchUpdateCount_tDBOutput_1 = pstmt_tDBOutput_1.getUpdateCount();
                            insertedCount_tDBOutput_1
                        += (tmp_batchUpdateCount_tDBOutput_1!=-1?tmp_batchUpdateCount_tDBOutput_1:0);
                        rowsToCommitCount_tDBOutput_1 += (tmp_batchUpdateCount_tDBOutput_1!=-1?tmp_batchUpdateCount_tDBOutput_1:0);
                    }
                    if(rowsToCommitCount_tDBOutput_1 != 0){
                    	
                    }
                    conn_tDBOutput_1.commit();
                    if(rowsToCommitCount_tDBOutput_1 != 0){
                    	
                    	rowsToCommitCount_tDBOutput_1 = 0;
                    }
                    commitCounter_tDBOutput_1=0;
                    	batchSizeCounter_tDBOutput_1=0;
                }

 


	tos_count_tDBOutput_1++;

/**
 * [tDBOutput_1 main ] stop
 */
	
	/**
	 * [tDBOutput_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";

	

 



/**
 * [tDBOutput_1 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";

	

 



/**
 * [tDBOutput_1 process_data_end ] stop
 */



	
	/**
	 * [tUnite_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tUnite_1";

	

 



/**
 * [tUnite_1 process_data_end ] stop
 */

} // End of branch "row2"




	
	/**
	 * [tFileInputExcel_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tFileInputExcel_1";

	

 



/**
 * [tFileInputExcel_1 process_data_end ] stop
 */
	
	/**
	 * [tFileInputExcel_1 end ] start
	 */

	

	
	
	currentComponent="tFileInputExcel_1";

	

			}
			
			
			
			globalMap.put("tFileInputExcel_1_NB_LINE",nb_line_tFileInputExcel_1);
			
				}
			
		} finally { 
				
					if(!(source_tFileInputExcel_1 instanceof java.io.InputStream)){
						workbook_tFileInputExcel_1.close();
					}
				
		}	
		

 

ok_Hash.put("tFileInputExcel_1", true);
end_Hash.put("tFileInputExcel_1", System.currentTimeMillis());

tStatCatcher_1.addMessage("end","tFileInputExcel_1", end_Hash.get("tFileInputExcel_1")-start_Hash.get("tFileInputExcel_1"));
tStatCatcher_1Process(globalMap);



/**
 * [tFileInputExcel_1 end ] stop
 */
	
	/**
	 * [tFileInputJSON_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileInputJSON_1", false);
		start_Hash.put("tFileInputJSON_1", System.currentTimeMillis());
		
				tStatCatcher_1.addMessage("begin","tFileInputJSON_1");
				tStatCatcher_1Process(globalMap);
			
	
	currentComponent="tFileInputJSON_1";

	
		int tos_count_tFileInputJSON_1 = 0;
		

	
class JsonPathCache_tFileInputJSON_1 {
	final java.util.Map<String,com.jayway.jsonpath.JsonPath> jsonPathString2compiledJsonPath = new java.util.HashMap<String,com.jayway.jsonpath.JsonPath>();
	
	public com.jayway.jsonpath.JsonPath getCompiledJsonPath(String jsonPath) {
		if(jsonPathString2compiledJsonPath.containsKey(jsonPath)) {
			return jsonPathString2compiledJsonPath.get(jsonPath);
		} else {
			com.jayway.jsonpath.JsonPath compiledLoopPath = com.jayway.jsonpath.JsonPath.compile(jsonPath);
			jsonPathString2compiledJsonPath.put(jsonPath,compiledLoopPath);
			return compiledLoopPath;
		}
	}
}

int nb_line_tFileInputJSON_1 = 0;

JsonPathCache_tFileInputJSON_1 jsonPathCache_tFileInputJSON_1 = new JsonPathCache_tFileInputJSON_1();

String loopPath_tFileInputJSON_1 = "$[*]";
java.util.List<Object> resultset_tFileInputJSON_1 = new java.util.ArrayList<Object>();

java.io.InputStream is_tFileInputJSON_1 = null;
com.jayway.jsonpath.ParseContext parseContext_tFileInputJSON_1 = com.jayway.jsonpath.JsonPath.using(com.jayway.jsonpath.Configuration.defaultConfiguration());
Object filenameOrStream_tFileInputJSON_1 = null;
        try {
            filenameOrStream_tFileInputJSON_1 = "C:/CC2/Groupe1/5_DATA_IN/adresse_client_3.json";
        } catch(java.lang.Exception e_tFileInputJSON_1) {
globalMap.put("tFileInputJSON_1_ERROR_MESSAGE",e_tFileInputJSON_1.getMessage());
				
	            globalMap.put("tFileInputJSON_1_ERROR_MESSAGE", e_tFileInputJSON_1.getMessage());
	            System.err.println(e_tFileInputJSON_1.getMessage());
        }
        
com.jayway.jsonpath.ReadContext document_tFileInputJSON_1 = null;
try {
     if(filenameOrStream_tFileInputJSON_1 instanceof java.io.InputStream){
         is_tFileInputJSON_1 = (java.io.InputStream)filenameOrStream_tFileInputJSON_1;
     }else{
	    
	        is_tFileInputJSON_1 = new java.io.FileInputStream((String)filenameOrStream_tFileInputJSON_1);
	    
	 }
	
	
	document_tFileInputJSON_1 = parseContext_tFileInputJSON_1.parse(is_tFileInputJSON_1,"UTF-8");
	com.jayway.jsonpath.JsonPath compiledLoopPath_tFileInputJSON_1 = jsonPathCache_tFileInputJSON_1.getCompiledJsonPath(loopPath_tFileInputJSON_1);
	Object result_tFileInputJSON_1 = document_tFileInputJSON_1.read(compiledLoopPath_tFileInputJSON_1,net.minidev.json.JSONObject.class);
	if (result_tFileInputJSON_1 instanceof net.minidev.json.JSONArray) {
		resultset_tFileInputJSON_1 = (net.minidev.json.JSONArray) result_tFileInputJSON_1;
	} else {
		resultset_tFileInputJSON_1.add(result_tFileInputJSON_1);
	}
} catch (java.lang.Exception e_tFileInputJSON_1) {
globalMap.put("tFileInputJSON_1_ERROR_MESSAGE",e_tFileInputJSON_1.getMessage());
	globalMap.put("tFileInputJSON_1_ERROR_MESSAGE", e_tFileInputJSON_1.getMessage());
	System.err.println(e_tFileInputJSON_1.getMessage());
} finally {
	if(is_tFileInputJSON_1 != null) {
		is_tFileInputJSON_1.close();
	}
}

String jsonPath_tFileInputJSON_1 = null;
com.jayway.jsonpath.JsonPath compiledJsonPath_tFileInputJSON_1 = null;

Object value_tFileInputJSON_1 = null;
Object root_tFileInputJSON_1 = null;
for(Object row_tFileInputJSON_1 : resultset_tFileInputJSON_1) {
	nb_line_tFileInputJSON_1++;
			row3 = null;			
	boolean whetherReject_tFileInputJSON_1 = false;
	row3 = new row3Struct();
	
	try{
				jsonPath_tFileInputJSON_1 = "id_adresse_client";
				compiledJsonPath_tFileInputJSON_1 = jsonPathCache_tFileInputJSON_1.getCompiledJsonPath(jsonPath_tFileInputJSON_1);
				
				try {
				   
					    if(jsonPath_tFileInputJSON_1.startsWith("$")){
					        if(root_tFileInputJSON_1 == null){
					            root_tFileInputJSON_1 = document_tFileInputJSON_1.read(jsonPathCache_tFileInputJSON_1.getCompiledJsonPath("$"));
					        }
				           value_tFileInputJSON_1 = compiledJsonPath_tFileInputJSON_1.read(root_tFileInputJSON_1);
				       }else{
				           value_tFileInputJSON_1 = compiledJsonPath_tFileInputJSON_1.read(row_tFileInputJSON_1);
				       }
						if(value_tFileInputJSON_1 != null && !value_tFileInputJSON_1.toString().isEmpty()) {
						row3.ID_ADRESSE_CLIENT = ParserUtils.parseTo_int(value_tFileInputJSON_1.toString());
						} else {
							row3.ID_ADRESSE_CLIENT = 

		0
;
						}
				} catch (com.jayway.jsonpath.PathNotFoundException e_tFileInputJSON_1) {
globalMap.put("tFileInputJSON_1_ERROR_MESSAGE",e_tFileInputJSON_1.getMessage());
					row3.ID_ADRESSE_CLIENT = 

		0
;
				}				
				jsonPath_tFileInputJSON_1 = "adresse_client";
				compiledJsonPath_tFileInputJSON_1 = jsonPathCache_tFileInputJSON_1.getCompiledJsonPath(jsonPath_tFileInputJSON_1);
				
				try {
				   
					    if(jsonPath_tFileInputJSON_1.startsWith("$")){
					        if(root_tFileInputJSON_1 == null){
					            root_tFileInputJSON_1 = document_tFileInputJSON_1.read(jsonPathCache_tFileInputJSON_1.getCompiledJsonPath("$"));
					        }
				           value_tFileInputJSON_1 = compiledJsonPath_tFileInputJSON_1.read(root_tFileInputJSON_1);
				       }else{
				           value_tFileInputJSON_1 = compiledJsonPath_tFileInputJSON_1.read(row_tFileInputJSON_1);
				       }
						row3.ADRESSE_CLIENT = value_tFileInputJSON_1 == null ? 

		null
 : value_tFileInputJSON_1.toString();
				} catch (com.jayway.jsonpath.PathNotFoundException e_tFileInputJSON_1) {
globalMap.put("tFileInputJSON_1_ERROR_MESSAGE",e_tFileInputJSON_1.getMessage());
					row3.ADRESSE_CLIENT = 

		null
;
				}				
    } catch (java.lang.Exception e_tFileInputJSON_1) {
globalMap.put("tFileInputJSON_1_ERROR_MESSAGE",e_tFileInputJSON_1.getMessage());
        whetherReject_tFileInputJSON_1 = true;
                System.err.println(e_tFileInputJSON_1.getMessage());
                row3 = null;
            globalMap.put("tFileInputJSON_1_ERROR_MESSAGE", e_tFileInputJSON_1.getMessage());
    }
//}

 



/**
 * [tFileInputJSON_1 begin ] stop
 */
	
	/**
	 * [tFileInputJSON_1 main ] start
	 */

	

	
	
	currentComponent="tFileInputJSON_1";

	

 


	tos_count_tFileInputJSON_1++;

/**
 * [tFileInputJSON_1 main ] stop
 */
	
	/**
	 * [tFileInputJSON_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFileInputJSON_1";

	

 



/**
 * [tFileInputJSON_1 process_data_begin ] stop
 */
// Start of branch "row3"
if(row3 != null) { 



	
	/**
	 * [tUnite_1 main ] start
	 */

	

	
	
	currentComponent="tUnite_1";

	
						if(execStat){
							runStat.updateStatOnConnection(iterateId,1,1
								
									,"row3"
									
							);
						}
						
//////////
 

// for output
			row4 = new row4Struct();
								
			row4.ID_ADRESSE_CLIENT = row3.ID_ADRESSE_CLIENT;								
			row4.ADRESSE_CLIENT = row3.ADRESSE_CLIENT;			

			nb_line_tUnite_1++;

//////////
 


	tos_count_tUnite_1++;

/**
 * [tUnite_1 main ] stop
 */
	
	/**
	 * [tUnite_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tUnite_1";

	

 



/**
 * [tUnite_1 process_data_begin ] stop
 */

	
	/**
	 * [tDBOutput_1 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row4"
						
						);
					}
					



        whetherReject_tDBOutput_1 = false;
                        pstmt_tDBOutput_1.setInt(1, row4.ID_ADRESSE_CLIENT);

                        if(row4.ADRESSE_CLIENT == null) {
pstmt_tDBOutput_1.setNull(2, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(2, row4.ADRESSE_CLIENT);
}

                pstmt_tDBOutput_1.addBatch();
                nb_line_tDBOutput_1++;
                batchSizeCounter_tDBOutput_1++;
            if (batchSize_tDBOutput_1 > 0 &&  batchSize_tDBOutput_1 <= batchSizeCounter_tDBOutput_1) {
                try {
                    pstmt_tDBOutput_1.executeBatch();
                }catch (java.sql.BatchUpdateException e_tDBOutput_1){
globalMap.put("tDBOutput_1_ERROR_MESSAGE",e_tDBOutput_1.getMessage());
			        java.sql.SQLException ne_tDBOutput_1 = e_tDBOutput_1.getNextException(),sqle_tDBOutput_1=null;
			    	String errormessage_tDBOutput_1;
					if (ne_tDBOutput_1 != null) {
						// build new exception to provide the original cause
						sqle_tDBOutput_1 = new java.sql.SQLException(e_tDBOutput_1.getMessage() + "\ncaused by: " + ne_tDBOutput_1.getMessage(), ne_tDBOutput_1.getSQLState(), ne_tDBOutput_1.getErrorCode(), ne_tDBOutput_1);
						errormessage_tDBOutput_1 = sqle_tDBOutput_1.getMessage();
					}else{
						errormessage_tDBOutput_1 = e_tDBOutput_1.getMessage();
					}
	            	
	                	System.err.println(errormessage_tDBOutput_1);
	            	
	        	}
                tmp_batchUpdateCount_tDBOutput_1 = pstmt_tDBOutput_1.getUpdateCount();
                    insertedCount_tDBOutput_1
                += (tmp_batchUpdateCount_tDBOutput_1!=-1?tmp_batchUpdateCount_tDBOutput_1:0);
                rowsToCommitCount_tDBOutput_1 += (tmp_batchUpdateCount_tDBOutput_1!=-1?tmp_batchUpdateCount_tDBOutput_1:0);
                batchSizeCounter_tDBOutput_1 = 0;
            }
                commitCounter_tDBOutput_1++;
                if(commitEvery_tDBOutput_1 <= commitCounter_tDBOutput_1) {
                    if(batchSizeCounter_tDBOutput_1 > 0) {
                        try {
                            pstmt_tDBOutput_1.executeBatch();
                        }catch (java.sql.BatchUpdateException e_tDBOutput_1){
globalMap.put("tDBOutput_1_ERROR_MESSAGE",e_tDBOutput_1.getMessage());
					        java.sql.SQLException ne_tDBOutput_1 = e_tDBOutput_1.getNextException(),sqle_tDBOutput_1=null;
					    	String errormessage_tDBOutput_1;
							if (ne_tDBOutput_1 != null) {
								// build new exception to provide the original cause
								sqle_tDBOutput_1 = new java.sql.SQLException(e_tDBOutput_1.getMessage() + "\ncaused by: " + ne_tDBOutput_1.getMessage(), ne_tDBOutput_1.getSQLState(), ne_tDBOutput_1.getErrorCode(), ne_tDBOutput_1);
								errormessage_tDBOutput_1 = sqle_tDBOutput_1.getMessage();
							}else{
								errormessage_tDBOutput_1 = e_tDBOutput_1.getMessage();
							}
			            	
			                	System.err.println(errormessage_tDBOutput_1);
			            	
			        	}
                        tmp_batchUpdateCount_tDBOutput_1 = pstmt_tDBOutput_1.getUpdateCount();
                            insertedCount_tDBOutput_1
                        += (tmp_batchUpdateCount_tDBOutput_1!=-1?tmp_batchUpdateCount_tDBOutput_1:0);
                        rowsToCommitCount_tDBOutput_1 += (tmp_batchUpdateCount_tDBOutput_1!=-1?tmp_batchUpdateCount_tDBOutput_1:0);
                    }
                    if(rowsToCommitCount_tDBOutput_1 != 0){
                    	
                    }
                    conn_tDBOutput_1.commit();
                    if(rowsToCommitCount_tDBOutput_1 != 0){
                    	
                    	rowsToCommitCount_tDBOutput_1 = 0;
                    }
                    commitCounter_tDBOutput_1=0;
                    	batchSizeCounter_tDBOutput_1=0;
                }

 


	tos_count_tDBOutput_1++;

/**
 * [tDBOutput_1 main ] stop
 */
	
	/**
	 * [tDBOutput_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";

	

 



/**
 * [tDBOutput_1 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";

	

 



/**
 * [tDBOutput_1 process_data_end ] stop
 */



	
	/**
	 * [tUnite_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tUnite_1";

	

 



/**
 * [tUnite_1 process_data_end ] stop
 */

} // End of branch "row3"




	
	/**
	 * [tFileInputJSON_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tFileInputJSON_1";

	

 



/**
 * [tFileInputJSON_1 process_data_end ] stop
 */
	
	/**
	 * [tFileInputJSON_1 end ] start
	 */

	

	
	
	currentComponent="tFileInputJSON_1";

	

	}
	globalMap.put("tFileInputJSON_1_NB_LINE",nb_line_tFileInputJSON_1);
 

ok_Hash.put("tFileInputJSON_1", true);
end_Hash.put("tFileInputJSON_1", System.currentTimeMillis());

tStatCatcher_1.addMessage("end","tFileInputJSON_1", end_Hash.get("tFileInputJSON_1")-start_Hash.get("tFileInputJSON_1"));
tStatCatcher_1Process(globalMap);



/**
 * [tFileInputJSON_1 end ] stop
 */
	
	/**
	 * [tUnite_1 end ] start
	 */

	

	
	
	currentComponent="tUnite_1";

	

globalMap.put("tUnite_1_NB_LINE", nb_line_tUnite_1);
				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row3","row1","row2");
			  	}
			  	
 

ok_Hash.put("tUnite_1", true);
end_Hash.put("tUnite_1", System.currentTimeMillis());

tStatCatcher_1.addMessage("end","tUnite_1", end_Hash.get("tUnite_1")-start_Hash.get("tUnite_1"));
tStatCatcher_1Process(globalMap);



/**
 * [tUnite_1 end ] stop
 */

	
	/**
	 * [tDBOutput_1 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";

	
	



	
        if(batchSizeCounter_tDBOutput_1 > 0) {
            try {
            	if (pstmt_tDBOutput_1 != null) {
					
					pstmt_tDBOutput_1.executeBatch();
					
        	    }
            }catch (java.sql.BatchUpdateException e_tDBOutput_1){
globalMap.put("tDBOutput_1_ERROR_MESSAGE",e_tDBOutput_1.getMessage());
		        java.sql.SQLException ne_tDBOutput_1 = e_tDBOutput_1.getNextException(),sqle_tDBOutput_1=null;
		    	String errormessage_tDBOutput_1;
				if (ne_tDBOutput_1 != null) {
					// build new exception to provide the original cause
					sqle_tDBOutput_1 = new java.sql.SQLException(e_tDBOutput_1.getMessage() + "\ncaused by: " + ne_tDBOutput_1.getMessage(), ne_tDBOutput_1.getSQLState(), ne_tDBOutput_1.getErrorCode(), ne_tDBOutput_1);
					errormessage_tDBOutput_1 = sqle_tDBOutput_1.getMessage();
				}else{
					errormessage_tDBOutput_1 = e_tDBOutput_1.getMessage();
				}
            	
                	System.err.println(errormessage_tDBOutput_1);
            	
        	}
        	if (pstmt_tDBOutput_1 != null) {
            	tmp_batchUpdateCount_tDBOutput_1 = pstmt_tDBOutput_1.getUpdateCount();
    	    	
    	    		insertedCount_tDBOutput_1
    	    	
    	    	+= (tmp_batchUpdateCount_tDBOutput_1!=-1?tmp_batchUpdateCount_tDBOutput_1:0);
				rowsToCommitCount_tDBOutput_1 += (tmp_batchUpdateCount_tDBOutput_1!=-1?tmp_batchUpdateCount_tDBOutput_1:0);
            }
        }
        if(pstmt_tDBOutput_1 != null) {
			
				pstmt_tDBOutput_1.close();
				resourceMap.remove("pstmt_tDBOutput_1");
			
        }
    resourceMap.put("statementClosed_tDBOutput_1", true);
		if(commitCounter_tDBOutput_1 > 0 && rowsToCommitCount_tDBOutput_1 != 0) {
			
		}
		conn_tDBOutput_1.commit();
		if(commitCounter_tDBOutput_1 > 0 && rowsToCommitCount_tDBOutput_1 != 0) {
			
			rowsToCommitCount_tDBOutput_1 = 0;
		}
		commitCounter_tDBOutput_1 = 0;
		
		
		conn_tDBOutput_1 .close();
		
		resourceMap.put("finish_tDBOutput_1", true);
   	

	
	nb_line_deleted_tDBOutput_1=nb_line_deleted_tDBOutput_1+ deletedCount_tDBOutput_1;
	nb_line_update_tDBOutput_1=nb_line_update_tDBOutput_1 + updatedCount_tDBOutput_1;
	nb_line_inserted_tDBOutput_1=nb_line_inserted_tDBOutput_1 + insertedCount_tDBOutput_1;
	nb_line_rejected_tDBOutput_1=nb_line_rejected_tDBOutput_1 + rejectedCount_tDBOutput_1;
	
        globalMap.put("tDBOutput_1_NB_LINE",nb_line_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_UPDATED",nb_line_update_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_DELETED",nb_line_deleted_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_1);
    

	



				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row4");
			  	}
			  	
 

ok_Hash.put("tDBOutput_1", true);
end_Hash.put("tDBOutput_1", System.currentTimeMillis());

tStatCatcher_1.addMessage("end","tDBOutput_1", end_Hash.get("tDBOutput_1")-start_Hash.get("tDBOutput_1"));
tStatCatcher_1Process(globalMap);



/**
 * [tDBOutput_1 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFileInputXML_1 finally ] start
	 */

	

	
	
	currentComponent="tFileInputXML_1";

	

 



/**
 * [tFileInputXML_1 finally ] stop
 */
	
	/**
	 * [tFileInputExcel_1 finally ] start
	 */

	

	
	
	currentComponent="tFileInputExcel_1";

	

 



/**
 * [tFileInputExcel_1 finally ] stop
 */
	
	/**
	 * [tFileInputJSON_1 finally ] start
	 */

	

	
	
	currentComponent="tFileInputJSON_1";

	

 



/**
 * [tFileInputJSON_1 finally ] stop
 */
	
	/**
	 * [tUnite_1 finally ] start
	 */

	

	
	
	currentComponent="tUnite_1";

	

 



/**
 * [tUnite_1 finally ] stop
 */

	
	/**
	 * [tDBOutput_1 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";

	



    try {
    if (resourceMap.get("statementClosed_tDBOutput_1") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_1 = null;
                if ((pstmtToClose_tDBOutput_1 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_1")) != null) {
                    pstmtToClose_tDBOutput_1.close();
                }
    }
    } finally {
        if(resourceMap.get("finish_tDBOutput_1") == null){
            java.sql.Connection ctn_tDBOutput_1 = null;
            if((ctn_tDBOutput_1 = (java.sql.Connection)resourceMap.get("conn_tDBOutput_1")) != null){
                try {
                    ctn_tDBOutput_1.close();
                } catch (java.sql.SQLException sqlEx_tDBOutput_1) {
                    String errorMessage_tDBOutput_1 = "failed to close the connection in tDBOutput_1 :" + sqlEx_tDBOutput_1.getMessage();
                    System.err.println(errorMessage_tDBOutput_1);
                }
            }
        }
    }
 



/**
 * [tDBOutput_1 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFileInputXML_1_SUBPROCESS_STATE", 1);
	}
	

public void tDBRow_4Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBRow_4_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tDBRow_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBRow_4", false);
		start_Hash.put("tDBRow_4", System.currentTimeMillis());
		
				tStatCatcher_1.addMessage("begin","tDBRow_4");
				tStatCatcher_1Process(globalMap);
			
	
	currentComponent="tDBRow_4";

	
		int tos_count_tDBRow_4 = 0;
		

	java.sql.Connection conn_tDBRow_4 = null;
	String query_tDBRow_4 = "";
	boolean whetherReject_tDBRow_4 = false;
			String driverClass_tDBRow_4 = "oracle.jdbc.OracleDriver";
		    java.lang.Class jdbcclazz_tDBRow_4 = java.lang.Class.forName(driverClass_tDBRow_4);
		
			String url_tDBRow_4 = null;
				url_tDBRow_4 = "jdbc:oracle:thin:@(description=(address=(protocol=tcp)(host=" + "" + ")(port=" + "1521" + "))(connect_data=(service_name=" + "XEPDB1" + ")))";
					String dbUser_tDBRow_4 = "DSID_LIV_OPE";
	        
            		
            		
            		 
	final String decryptedPassword_tDBRow_4 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:wO2TtE0z3RwHGDAxeKYcT2ELVlwUQ7qFnvAZEJ6I9f8=");
        		   	
        	        String dbPwd_tDBRow_4 = decryptedPassword_tDBRow_4;
	        
					
			conn_tDBRow_4 = java.sql.DriverManager.getConnection(url_tDBRow_4,dbUser_tDBRow_4,dbPwd_tDBRow_4);
		
        resourceMap.put("conn_tDBRow_4", conn_tDBRow_4);
					if(conn_tDBRow_4.getAutoCommit()) {
						
				conn_tDBRow_4.setAutoCommit(false);
			
					}        
					int commitEvery_tDBRow_4 = 10000;
					int commitCounter_tDBRow_4 = 0;
				
        java.sql.Statement stmt_tDBRow_4 = conn_tDBRow_4.createStatement();
        resourceMap.put("stmt_tDBRow_4", stmt_tDBRow_4);

 



/**
 * [tDBRow_4 begin ] stop
 */
	
	/**
	 * [tDBRow_4 main ] start
	 */

	

	
	
	currentComponent="tDBRow_4";

	

query_tDBRow_4 = "TRUNCATE TABLE  DSID_LIV_OPE.RESTAURANT";
whetherReject_tDBRow_4 = false;
globalMap.put("tDBRow_4_QUERY",query_tDBRow_4);
try {
		stmt_tDBRow_4.execute(query_tDBRow_4);
		
	} catch (java.lang.Exception e) {
globalMap.put("tDBRow_4_ERROR_MESSAGE",e.getMessage());
		whetherReject_tDBRow_4 = true;
		
				System.err.print(e.getMessage());
				
	}
	
	if(!whetherReject_tDBRow_4) {
		
	}
	
		commitCounter_tDBRow_4++;
		if(commitEvery_tDBRow_4 <= commitCounter_tDBRow_4) {
			
			conn_tDBRow_4.commit();
			
			commitCounter_tDBRow_4=0;
		}
		

 


	tos_count_tDBRow_4++;

/**
 * [tDBRow_4 main ] stop
 */
	
	/**
	 * [tDBRow_4 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBRow_4";

	

 



/**
 * [tDBRow_4 process_data_begin ] stop
 */
	
	/**
	 * [tDBRow_4 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBRow_4";

	

 



/**
 * [tDBRow_4 process_data_end ] stop
 */
	
	/**
	 * [tDBRow_4 end ] start
	 */

	

	
	
	currentComponent="tDBRow_4";

	

	
        stmt_tDBRow_4.close();
        resourceMap.remove("stmt_tDBRow_4");
    resourceMap.put("statementClosed_tDBRow_4", true);
		if(commitEvery_tDBRow_4>commitCounter_tDBRow_4){

			
			conn_tDBRow_4.commit();
			
	
			commitCounter_tDBRow_4=0;
	
		}
			conn_tDBRow_4.close();
			
			if("com.mysql.cj.jdbc.Driver".equals((String)globalMap.get("driverClass_"))
			    && routines.system.BundleUtils.inOSGi()) {
			        Class.forName("com.mysql.cj.jdbc.AbandonedConnectionCleanupThread").
			            getMethod("checkedShutdown").invoke(null, (Object[]) null);
			}
			
    resourceMap.put("finish_tDBRow_4", true);

 

ok_Hash.put("tDBRow_4", true);
end_Hash.put("tDBRow_4", System.currentTimeMillis());

tStatCatcher_1.addMessage("end","tDBRow_4", end_Hash.get("tDBRow_4")-start_Hash.get("tDBRow_4"));
tStatCatcher_1Process(globalMap);
				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk5", 0, "ok");
				}
				tDBRow_5Process(globalMap);



/**
 * [tDBRow_4 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBRow_4 finally ] start
	 */

	

	
	
	currentComponent="tDBRow_4";

	

try {
    if (resourceMap.get("statementClosed_tDBRow_4") == null) {
            java.sql.Statement stmtToClose_tDBRow_4 = null;
            if ((stmtToClose_tDBRow_4 = (java.sql.Statement) resourceMap.remove("stmt_tDBRow_4")) != null) {
                stmtToClose_tDBRow_4.close();
            }
    }
} finally {
        if(resourceMap.get("finish_tDBRow_4") == null){
            java.sql.Connection ctn_tDBRow_4 = null;
            if((ctn_tDBRow_4 = (java.sql.Connection)resourceMap.get("conn_tDBRow_4")) != null){
                try {
                    ctn_tDBRow_4.close();
                } catch (java.sql.SQLException sqlEx_tDBRow_4) {
                    String errorMessage_tDBRow_4 = "failed to close the connection in tDBRow_4 :" + sqlEx_tDBRow_4.getMessage();
                    System.err.println(errorMessage_tDBRow_4);
                }
            }
        }
    }
 



/**
 * [tDBRow_4 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBRow_4_SUBPROCESS_STATE", 1);
	}
	

public void tDBRow_5Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBRow_5_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tDBRow_5 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBRow_5", false);
		start_Hash.put("tDBRow_5", System.currentTimeMillis());
		
				tStatCatcher_1.addMessage("begin","tDBRow_5");
				tStatCatcher_1Process(globalMap);
			
	
	currentComponent="tDBRow_5";

	
		int tos_count_tDBRow_5 = 0;
		

	java.sql.Connection conn_tDBRow_5 = null;
	String query_tDBRow_5 = "";
	boolean whetherReject_tDBRow_5 = false;
			String driverClass_tDBRow_5 = "oracle.jdbc.OracleDriver";
		    java.lang.Class jdbcclazz_tDBRow_5 = java.lang.Class.forName(driverClass_tDBRow_5);
		
			String url_tDBRow_5 = null;
				url_tDBRow_5 = "jdbc:oracle:thin:@(description=(address=(protocol=tcp)(host=" + "" + ")(port=" + "1521" + "))(connect_data=(service_name=" + "XEPDB1" + ")))";
					String dbUser_tDBRow_5 = "DSID_LIV_OPE";
	        
            		
            		
            		 
	final String decryptedPassword_tDBRow_5 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:SYuz0gVxxznVZ/0Z5bAlCADsDSYtTas0Y/23pShf9mA=");
        		   	
        	        String dbPwd_tDBRow_5 = decryptedPassword_tDBRow_5;
	        
					
			conn_tDBRow_5 = java.sql.DriverManager.getConnection(url_tDBRow_5,dbUser_tDBRow_5,dbPwd_tDBRow_5);
		
        resourceMap.put("conn_tDBRow_5", conn_tDBRow_5);
					if(conn_tDBRow_5.getAutoCommit()) {
						
				conn_tDBRow_5.setAutoCommit(false);
			
					}        
					int commitEvery_tDBRow_5 = 10000;
					int commitCounter_tDBRow_5 = 0;
				
        java.sql.Statement stmt_tDBRow_5 = conn_tDBRow_5.createStatement();
        resourceMap.put("stmt_tDBRow_5", stmt_tDBRow_5);

 



/**
 * [tDBRow_5 begin ] stop
 */
	
	/**
	 * [tDBRow_5 main ] start
	 */

	

	
	
	currentComponent="tDBRow_5";

	

query_tDBRow_5 = "TRUNCATE TABLE  DSID_LIV_OPE.ADRESSE_NORMALISEE_RESTAURANT";
whetherReject_tDBRow_5 = false;
globalMap.put("tDBRow_5_QUERY",query_tDBRow_5);
try {
		stmt_tDBRow_5.execute(query_tDBRow_5);
		
	} catch (java.lang.Exception e) {
globalMap.put("tDBRow_5_ERROR_MESSAGE",e.getMessage());
		whetherReject_tDBRow_5 = true;
		
				System.err.print(e.getMessage());
				
	}
	
	if(!whetherReject_tDBRow_5) {
		
	}
	
		commitCounter_tDBRow_5++;
		if(commitEvery_tDBRow_5 <= commitCounter_tDBRow_5) {
			
			conn_tDBRow_5.commit();
			
			commitCounter_tDBRow_5=0;
		}
		

 


	tos_count_tDBRow_5++;

/**
 * [tDBRow_5 main ] stop
 */
	
	/**
	 * [tDBRow_5 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBRow_5";

	

 



/**
 * [tDBRow_5 process_data_begin ] stop
 */
	
	/**
	 * [tDBRow_5 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBRow_5";

	

 



/**
 * [tDBRow_5 process_data_end ] stop
 */
	
	/**
	 * [tDBRow_5 end ] start
	 */

	

	
	
	currentComponent="tDBRow_5";

	

	
        stmt_tDBRow_5.close();
        resourceMap.remove("stmt_tDBRow_5");
    resourceMap.put("statementClosed_tDBRow_5", true);
		if(commitEvery_tDBRow_5>commitCounter_tDBRow_5){

			
			conn_tDBRow_5.commit();
			
	
			commitCounter_tDBRow_5=0;
	
		}
			conn_tDBRow_5.close();
			
			if("com.mysql.cj.jdbc.Driver".equals((String)globalMap.get("driverClass_"))
			    && routines.system.BundleUtils.inOSGi()) {
			        Class.forName("com.mysql.cj.jdbc.AbandonedConnectionCleanupThread").
			            getMethod("checkedShutdown").invoke(null, (Object[]) null);
			}
			
    resourceMap.put("finish_tDBRow_5", true);

 

ok_Hash.put("tDBRow_5", true);
end_Hash.put("tDBRow_5", System.currentTimeMillis());

tStatCatcher_1.addMessage("end","tDBRow_5", end_Hash.get("tDBRow_5")-start_Hash.get("tDBRow_5"));
tStatCatcher_1Process(globalMap);
				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk6", 0, "ok");
				}
				tFileInputDelimited_1Process(globalMap);



/**
 * [tDBRow_5 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBRow_5 finally ] start
	 */

	

	
	
	currentComponent="tDBRow_5";

	

try {
    if (resourceMap.get("statementClosed_tDBRow_5") == null) {
            java.sql.Statement stmtToClose_tDBRow_5 = null;
            if ((stmtToClose_tDBRow_5 = (java.sql.Statement) resourceMap.remove("stmt_tDBRow_5")) != null) {
                stmtToClose_tDBRow_5.close();
            }
    }
} finally {
        if(resourceMap.get("finish_tDBRow_5") == null){
            java.sql.Connection ctn_tDBRow_5 = null;
            if((ctn_tDBRow_5 = (java.sql.Connection)resourceMap.get("conn_tDBRow_5")) != null){
                try {
                    ctn_tDBRow_5.close();
                } catch (java.sql.SQLException sqlEx_tDBRow_5) {
                    String errorMessage_tDBRow_5 = "failed to close the connection in tDBRow_5 :" + sqlEx_tDBRow_5.getMessage();
                    System.err.println(errorMessage_tDBRow_5);
                }
            }
        }
    }
 



/**
 * [tDBRow_5 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBRow_5_SUBPROCESS_STATE", 1);
	}
	


public static class row8Struct implements routines.system.IPersistableRow<row8Struct> {
    final static byte[] commonByteArrayLock_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ = new byte[0];
    static byte[] commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public Integer ID_ADRESSE_RESTAURANT;

				public Integer getID_ADRESSE_RESTAURANT () {
					return this.ID_ADRESSE_RESTAURANT;
				}
				
			    public String ADRESSE_RESTAURANT;

				public String getADRESSE_RESTAURANT () {
					return this.ADRESSE_RESTAURANT;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
						result = prime * result + ((this.ID_ADRESSE_RESTAURANT == null) ? 0 : this.ID_ADRESSE_RESTAURANT.hashCode());
					
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row8Struct other = (row8Struct) obj;
		
						if (this.ID_ADRESSE_RESTAURANT == null) {
							if (other.ID_ADRESSE_RESTAURANT != null)
								return false;
						
						} else if (!this.ID_ADRESSE_RESTAURANT.equals(other.ID_ADRESSE_RESTAURANT))
						
							return false;
					

		return true;
    }

	public void copyDataTo(row8Struct other) {

		other.ID_ADRESSE_RESTAURANT = this.ID_ADRESSE_RESTAURANT;
	            other.ADRESSE_RESTAURANT = this.ADRESSE_RESTAURANT;
	            
	}

	public void copyKeysDataTo(row8Struct other) {

		other.ID_ADRESSE_RESTAURANT = this.ID_ADRESSE_RESTAURANT;
	            	
	}



	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ.length == 0) {
   					commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ.length == 0) {
   					commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ) {

        	try {

        		int length = 0;
		
						this.ID_ADRESSE_RESTAURANT = readInteger(dis);
					
					this.ADRESSE_RESTAURANT = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ) {

        	try {

        		int length = 0;
		
						this.ID_ADRESSE_RESTAURANT = readInteger(dis);
					
					this.ADRESSE_RESTAURANT = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Integer
				
						writeInteger(this.ID_ADRESSE_RESTAURANT,dos);
					
					// String
				
						writeString(this.ADRESSE_RESTAURANT,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// Integer
				
						writeInteger(this.ID_ADRESSE_RESTAURANT,dos);
					
					// String
				
						writeString(this.ADRESSE_RESTAURANT,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("ID_ADRESSE_RESTAURANT="+String.valueOf(ID_ADRESSE_RESTAURANT));
		sb.append(",ADRESSE_RESTAURANT="+ADRESSE_RESTAURANT);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row8Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.ID_ADRESSE_RESTAURANT, other.ID_ADRESSE_RESTAURANT);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row6Struct implements routines.system.IPersistableRow<row6Struct> {
    final static byte[] commonByteArrayLock_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ = new byte[0];
    static byte[] commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public Integer ID_ADRESSE_RESTAURANT;

				public Integer getID_ADRESSE_RESTAURANT () {
					return this.ID_ADRESSE_RESTAURANT;
				}
				
			    public String ADRESSE_RESTAURANT;

				public String getADRESSE_RESTAURANT () {
					return this.ADRESSE_RESTAURANT;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
						result = prime * result + ((this.ID_ADRESSE_RESTAURANT == null) ? 0 : this.ID_ADRESSE_RESTAURANT.hashCode());
					
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row6Struct other = (row6Struct) obj;
		
						if (this.ID_ADRESSE_RESTAURANT == null) {
							if (other.ID_ADRESSE_RESTAURANT != null)
								return false;
						
						} else if (!this.ID_ADRESSE_RESTAURANT.equals(other.ID_ADRESSE_RESTAURANT))
						
							return false;
					

		return true;
    }

	public void copyDataTo(row6Struct other) {

		other.ID_ADRESSE_RESTAURANT = this.ID_ADRESSE_RESTAURANT;
	            other.ADRESSE_RESTAURANT = this.ADRESSE_RESTAURANT;
	            
	}

	public void copyKeysDataTo(row6Struct other) {

		other.ID_ADRESSE_RESTAURANT = this.ID_ADRESSE_RESTAURANT;
	            	
	}



	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ.length == 0) {
   					commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ.length == 0) {
   					commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ) {

        	try {

        		int length = 0;
		
						this.ID_ADRESSE_RESTAURANT = readInteger(dis);
					
					this.ADRESSE_RESTAURANT = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ) {

        	try {

        		int length = 0;
		
						this.ID_ADRESSE_RESTAURANT = readInteger(dis);
					
					this.ADRESSE_RESTAURANT = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Integer
				
						writeInteger(this.ID_ADRESSE_RESTAURANT,dos);
					
					// String
				
						writeString(this.ADRESSE_RESTAURANT,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// Integer
				
						writeInteger(this.ID_ADRESSE_RESTAURANT,dos);
					
					// String
				
						writeString(this.ADRESSE_RESTAURANT,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("ID_ADRESSE_RESTAURANT="+String.valueOf(ID_ADRESSE_RESTAURANT));
		sb.append(",ADRESSE_RESTAURANT="+ADRESSE_RESTAURANT);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row6Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.ID_ADRESSE_RESTAURANT, other.ID_ADRESSE_RESTAURANT);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row7Struct implements routines.system.IPersistableRow<row7Struct> {
    final static byte[] commonByteArrayLock_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ = new byte[0];
    static byte[] commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public Integer ID_ADRESSE_RESTAURANT;

				public Integer getID_ADRESSE_RESTAURANT () {
					return this.ID_ADRESSE_RESTAURANT;
				}
				
			    public String ADRESSE_RESTAURANT;

				public String getADRESSE_RESTAURANT () {
					return this.ADRESSE_RESTAURANT;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
						result = prime * result + ((this.ID_ADRESSE_RESTAURANT == null) ? 0 : this.ID_ADRESSE_RESTAURANT.hashCode());
					
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row7Struct other = (row7Struct) obj;
		
						if (this.ID_ADRESSE_RESTAURANT == null) {
							if (other.ID_ADRESSE_RESTAURANT != null)
								return false;
						
						} else if (!this.ID_ADRESSE_RESTAURANT.equals(other.ID_ADRESSE_RESTAURANT))
						
							return false;
					

		return true;
    }

	public void copyDataTo(row7Struct other) {

		other.ID_ADRESSE_RESTAURANT = this.ID_ADRESSE_RESTAURANT;
	            other.ADRESSE_RESTAURANT = this.ADRESSE_RESTAURANT;
	            
	}

	public void copyKeysDataTo(row7Struct other) {

		other.ID_ADRESSE_RESTAURANT = this.ID_ADRESSE_RESTAURANT;
	            	
	}



	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ.length == 0) {
   					commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ.length == 0) {
   					commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ) {

        	try {

        		int length = 0;
		
						this.ID_ADRESSE_RESTAURANT = readInteger(dis);
					
					this.ADRESSE_RESTAURANT = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ) {

        	try {

        		int length = 0;
		
						this.ID_ADRESSE_RESTAURANT = readInteger(dis);
					
					this.ADRESSE_RESTAURANT = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Integer
				
						writeInteger(this.ID_ADRESSE_RESTAURANT,dos);
					
					// String
				
						writeString(this.ADRESSE_RESTAURANT,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// Integer
				
						writeInteger(this.ID_ADRESSE_RESTAURANT,dos);
					
					// String
				
						writeString(this.ADRESSE_RESTAURANT,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("ID_ADRESSE_RESTAURANT="+String.valueOf(ID_ADRESSE_RESTAURANT));
		sb.append(",ADRESSE_RESTAURANT="+ADRESSE_RESTAURANT);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row7Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.ID_ADRESSE_RESTAURANT, other.ID_ADRESSE_RESTAURANT);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tFileInputDelimited_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFileInputDelimited_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row6Struct row6 = new row6Struct();

		row7Struct row7 = new row7Struct();

			row8Struct row8 = new row8Struct();




	
	/**
	 * [tDBOutput_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_3", false);
		start_Hash.put("tDBOutput_3", System.currentTimeMillis());
		
				tStatCatcher_1.addMessage("begin","tDBOutput_3");
				tStatCatcher_1Process(globalMap);
			
	
	currentComponent="tDBOutput_3";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row8");
					}
				
		int tos_count_tDBOutput_3 = 0;
		






    
    int nb_line_tDBOutput_3 = 0;
    int nb_line_update_tDBOutput_3 = 0;
    int nb_line_inserted_tDBOutput_3 = 0;
    int nb_line_deleted_tDBOutput_3 = 0;
    int nb_line_rejected_tDBOutput_3 = 0;

    int tmp_batchUpdateCount_tDBOutput_3 = 0;

    int deletedCount_tDBOutput_3=0;
    int updatedCount_tDBOutput_3=0;
    int insertedCount_tDBOutput_3=0;
    int rowsToCommitCount_tDBOutput_3=0;
    int rejectedCount_tDBOutput_3=0;

    boolean whetherReject_tDBOutput_3 = false;

    java.sql.Connection conn_tDBOutput_3 = null;

    //optional table
    String dbschema_tDBOutput_3 = null;
    String tableName_tDBOutput_3 = null;
                    String driverClass_tDBOutput_3 = "oracle.jdbc.OracleDriver";


                java.lang.Class.forName(driverClass_tDBOutput_3);
                String url_tDBOutput_3 = null;
                    url_tDBOutput_3 = "jdbc:oracle:thin:@(description=(address=(protocol=tcp)(host=" + "" + ")(port=" + "1521" + "))(connect_data=(service_name=" + "XEPDB1" + ")))";
                String dbUser_tDBOutput_3 = "DSID_LIV_OPE";
 
	final String decryptedPassword_tDBOutput_3 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:d2keUt1iP51BWTelg+igVqnppFEpi7nglS0ZbIXw/eE=");

                String dbPwd_tDBOutput_3 = decryptedPassword_tDBOutput_3;
                dbschema_tDBOutput_3 = "DSID_LIV_OPE";


                    conn_tDBOutput_3 = java.sql.DriverManager.getConnection(url_tDBOutput_3, dbUser_tDBOutput_3, dbPwd_tDBOutput_3);
        resourceMap.put("conn_tDBOutput_3", conn_tDBOutput_3);
            conn_tDBOutput_3.setAutoCommit(false);
            int commitEvery_tDBOutput_3 = 10000;
            int commitCounter_tDBOutput_3 = 0;
        int batchSize_tDBOutput_3 = 10000;
        int batchSizeCounter_tDBOutput_3=0;
        int count_tDBOutput_3=0;

        if(dbschema_tDBOutput_3 == null || dbschema_tDBOutput_3.trim().length() == 0) {
            tableName_tDBOutput_3 = ("ADRESSE_RESTAURANT");
        } else {
            tableName_tDBOutput_3 = dbschema_tDBOutput_3 + "." + ("ADRESSE_RESTAURANT");
        }
            int rsTruncCountNumber_tDBOutput_3 = 0;
            try(java.sql.Statement stmtTruncCount_tDBOutput_3 = conn_tDBOutput_3.createStatement()) {
                try (java.sql.ResultSet rsTruncCount_tDBOutput_3 = stmtTruncCount_tDBOutput_3.executeQuery("SELECT COUNT(1) FROM " + tableName_tDBOutput_3 + "")) {
                    if(rsTruncCount_tDBOutput_3.next()) {
                        rsTruncCountNumber_tDBOutput_3 = rsTruncCount_tDBOutput_3.getInt(1);
                    }
                }
            }
            try (java.sql.Statement stmtTrunc_tDBOutput_3 = conn_tDBOutput_3.createStatement()) {
                stmtTrunc_tDBOutput_3.executeUpdate("TRUNCATE TABLE " + tableName_tDBOutput_3 + "");
                deletedCount_tDBOutput_3 += rsTruncCountNumber_tDBOutput_3;
            }
                String insert_tDBOutput_3 = "INSERT INTO " + tableName_tDBOutput_3 + " (ID_ADRESSE_RESTAURANT,ADRESSE_RESTAURANT) VALUES (?,?)";    

                        java.sql.PreparedStatement pstmt_tDBOutput_3 = conn_tDBOutput_3.prepareStatement(insert_tDBOutput_3);
                        resourceMap.put("pstmt_tDBOutput_3", pstmt_tDBOutput_3);





 



/**
 * [tDBOutput_3 begin ] stop
 */



	
	/**
	 * [tUnite_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tUnite_2", false);
		start_Hash.put("tUnite_2", System.currentTimeMillis());
		
				tStatCatcher_1.addMessage("begin","tUnite_2");
				tStatCatcher_1Process(globalMap);
			
	
	currentComponent="tUnite_2";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row7","row6");
					}
				
		int tos_count_tUnite_2 = 0;
		

int nb_line_tUnite_2 = 0;

 



/**
 * [tUnite_2 begin ] stop
 */
	
	/**
	 * [tFileInputDelimited_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileInputDelimited_1", false);
		start_Hash.put("tFileInputDelimited_1", System.currentTimeMillis());
		
				tStatCatcher_1.addMessage("begin","tFileInputDelimited_1");
				tStatCatcher_1Process(globalMap);
			
	
	currentComponent="tFileInputDelimited_1";

	
		int tos_count_tFileInputDelimited_1 = 0;
		
	
	
	
 
	
	
	final routines.system.RowState rowstate_tFileInputDelimited_1 = new routines.system.RowState();
	
	
				int nb_line_tFileInputDelimited_1 = 0;
				org.talend.fileprocess.FileInputDelimited fid_tFileInputDelimited_1 = null;
				int limit_tFileInputDelimited_1 = -1;
				try{
					
						Object filename_tFileInputDelimited_1 = "C:/CC2/Groupe1/5_DATA_IN/adresse_restaurant_1.csv";
						if(filename_tFileInputDelimited_1 instanceof java.io.InputStream){
							
			int footer_value_tFileInputDelimited_1 = 0, random_value_tFileInputDelimited_1 = -1;
			if(footer_value_tFileInputDelimited_1 >0 || random_value_tFileInputDelimited_1 > 0){
				throw new java.lang.Exception("When the input source is a stream,footer and random shouldn't be bigger than 0.");				
			}
		
						}
						try {
							fid_tFileInputDelimited_1 = new org.talend.fileprocess.FileInputDelimited("C:/CC2/Groupe1/5_DATA_IN/adresse_restaurant_1.csv", "US-ASCII",";","\n",false,1,0,
									limit_tFileInputDelimited_1
								,-1, false);
						} catch(java.lang.Exception e) {
globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",e.getMessage());
							
								
								System.err.println(e.getMessage());
							
						}
					
				    
					while (fid_tFileInputDelimited_1!=null && fid_tFileInputDelimited_1.nextRecord()) {
						rowstate_tFileInputDelimited_1.reset();
						
			    						row6 = null;			
												
									boolean whetherReject_tFileInputDelimited_1 = false;
									row6 = new row6Struct();
									try {
										
				int columnIndexWithD_tFileInputDelimited_1 = 0;
				
					String temp = ""; 
				
					columnIndexWithD_tFileInputDelimited_1 = 0;
					
						temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						if(temp.length() > 0) {
							
								try {
								
    								row6.ID_ADRESSE_RESTAURANT = ParserUtils.parseTo_Integer(temp);
    							
    							} catch(java.lang.Exception ex_tFileInputDelimited_1) {
globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format("Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
										"ID_ADRESSE_RESTAURANT", "row6", temp, ex_tFileInputDelimited_1), ex_tFileInputDelimited_1));
								}
    							
						} else {						
							
								
									row6.ID_ADRESSE_RESTAURANT = null;
								
							
						}
					
				
					columnIndexWithD_tFileInputDelimited_1 = 1;
					
							row6.ADRESSE_RESTAURANT = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
				
										
										if(rowstate_tFileInputDelimited_1.getException()!=null) {
											throw rowstate_tFileInputDelimited_1.getException();
										}
										
										
							
			    					} catch (java.lang.Exception e) {
globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",e.getMessage());
			        					whetherReject_tFileInputDelimited_1 = true;
			        					
			                					System.err.println(e.getMessage());
			                					row6 = null;
			                				
										
			    					}
								

 



/**
 * [tFileInputDelimited_1 begin ] stop
 */
	
	/**
	 * [tFileInputDelimited_1 main ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_1";

	

 


	tos_count_tFileInputDelimited_1++;

/**
 * [tFileInputDelimited_1 main ] stop
 */
	
	/**
	 * [tFileInputDelimited_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_1";

	

 



/**
 * [tFileInputDelimited_1 process_data_begin ] stop
 */
// Start of branch "row6"
if(row6 != null) { 



	
	/**
	 * [tUnite_2 main ] start
	 */

	

	
	
	currentComponent="tUnite_2";

	
						if(execStat){
							runStat.updateStatOnConnection(iterateId,1,1
								
									,"row6"
									
							);
						}
						
//////////
 

// for output
			row8 = new row8Struct();
								
			row8.ID_ADRESSE_RESTAURANT = row6.ID_ADRESSE_RESTAURANT;								
			row8.ADRESSE_RESTAURANT = row6.ADRESSE_RESTAURANT;			

			nb_line_tUnite_2++;

//////////
 


	tos_count_tUnite_2++;

/**
 * [tUnite_2 main ] stop
 */
	
	/**
	 * [tUnite_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tUnite_2";

	

 



/**
 * [tUnite_2 process_data_begin ] stop
 */

	
	/**
	 * [tDBOutput_3 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row8"
						
						);
					}
					



        whetherReject_tDBOutput_3 = false;
                        if(row8.ID_ADRESSE_RESTAURANT == null) {
pstmt_tDBOutput_3.setNull(1, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_3.setInt(1, row8.ID_ADRESSE_RESTAURANT);
}

                        if(row8.ADRESSE_RESTAURANT == null) {
pstmt_tDBOutput_3.setNull(2, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(2, row8.ADRESSE_RESTAURANT);
}

                pstmt_tDBOutput_3.addBatch();
                nb_line_tDBOutput_3++;
                batchSizeCounter_tDBOutput_3++;
            if (batchSize_tDBOutput_3 > 0 &&  batchSize_tDBOutput_3 <= batchSizeCounter_tDBOutput_3) {
                try {
                    pstmt_tDBOutput_3.executeBatch();
                }catch (java.sql.BatchUpdateException e_tDBOutput_3){
globalMap.put("tDBOutput_3_ERROR_MESSAGE",e_tDBOutput_3.getMessage());
			        java.sql.SQLException ne_tDBOutput_3 = e_tDBOutput_3.getNextException(),sqle_tDBOutput_3=null;
			    	String errormessage_tDBOutput_3;
					if (ne_tDBOutput_3 != null) {
						// build new exception to provide the original cause
						sqle_tDBOutput_3 = new java.sql.SQLException(e_tDBOutput_3.getMessage() + "\ncaused by: " + ne_tDBOutput_3.getMessage(), ne_tDBOutput_3.getSQLState(), ne_tDBOutput_3.getErrorCode(), ne_tDBOutput_3);
						errormessage_tDBOutput_3 = sqle_tDBOutput_3.getMessage();
					}else{
						errormessage_tDBOutput_3 = e_tDBOutput_3.getMessage();
					}
	            	
	                	System.err.println(errormessage_tDBOutput_3);
	            	
	        	}
                tmp_batchUpdateCount_tDBOutput_3 = pstmt_tDBOutput_3.getUpdateCount();
                    insertedCount_tDBOutput_3
                += (tmp_batchUpdateCount_tDBOutput_3!=-1?tmp_batchUpdateCount_tDBOutput_3:0);
                rowsToCommitCount_tDBOutput_3 += (tmp_batchUpdateCount_tDBOutput_3!=-1?tmp_batchUpdateCount_tDBOutput_3:0);
                batchSizeCounter_tDBOutput_3 = 0;
            }
                commitCounter_tDBOutput_3++;
                if(commitEvery_tDBOutput_3 <= commitCounter_tDBOutput_3) {
                    if(batchSizeCounter_tDBOutput_3 > 0) {
                        try {
                            pstmt_tDBOutput_3.executeBatch();
                        }catch (java.sql.BatchUpdateException e_tDBOutput_3){
globalMap.put("tDBOutput_3_ERROR_MESSAGE",e_tDBOutput_3.getMessage());
					        java.sql.SQLException ne_tDBOutput_3 = e_tDBOutput_3.getNextException(),sqle_tDBOutput_3=null;
					    	String errormessage_tDBOutput_3;
							if (ne_tDBOutput_3 != null) {
								// build new exception to provide the original cause
								sqle_tDBOutput_3 = new java.sql.SQLException(e_tDBOutput_3.getMessage() + "\ncaused by: " + ne_tDBOutput_3.getMessage(), ne_tDBOutput_3.getSQLState(), ne_tDBOutput_3.getErrorCode(), ne_tDBOutput_3);
								errormessage_tDBOutput_3 = sqle_tDBOutput_3.getMessage();
							}else{
								errormessage_tDBOutput_3 = e_tDBOutput_3.getMessage();
							}
			            	
			                	System.err.println(errormessage_tDBOutput_3);
			            	
			        	}
                        tmp_batchUpdateCount_tDBOutput_3 = pstmt_tDBOutput_3.getUpdateCount();
                            insertedCount_tDBOutput_3
                        += (tmp_batchUpdateCount_tDBOutput_3!=-1?tmp_batchUpdateCount_tDBOutput_3:0);
                        rowsToCommitCount_tDBOutput_3 += (tmp_batchUpdateCount_tDBOutput_3!=-1?tmp_batchUpdateCount_tDBOutput_3:0);
                    }
                    if(rowsToCommitCount_tDBOutput_3 != 0){
                    	
                    }
                    conn_tDBOutput_3.commit();
                    if(rowsToCommitCount_tDBOutput_3 != 0){
                    	
                    	rowsToCommitCount_tDBOutput_3 = 0;
                    }
                    commitCounter_tDBOutput_3=0;
                    	batchSizeCounter_tDBOutput_3=0;
                }

 


	tos_count_tDBOutput_3++;

/**
 * [tDBOutput_3 main ] stop
 */
	
	/**
	 * [tDBOutput_3 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";

	

 



/**
 * [tDBOutput_3 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_3 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";

	

 



/**
 * [tDBOutput_3 process_data_end ] stop
 */



	
	/**
	 * [tUnite_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tUnite_2";

	

 



/**
 * [tUnite_2 process_data_end ] stop
 */

} // End of branch "row6"




	
	/**
	 * [tFileInputDelimited_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_1";

	

 



/**
 * [tFileInputDelimited_1 process_data_end ] stop
 */
	
	/**
	 * [tFileInputDelimited_1 end ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_1";

	



            }
            }finally{
                if(!((Object)("C:/CC2/Groupe1/5_DATA_IN/adresse_restaurant_1.csv") instanceof java.io.InputStream)){
                	if(fid_tFileInputDelimited_1!=null){
                		fid_tFileInputDelimited_1.close();
                	}
                }
                if(fid_tFileInputDelimited_1!=null){
                	globalMap.put("tFileInputDelimited_1_NB_LINE", fid_tFileInputDelimited_1.getRowNumber());
					
                }
			}
			  

 

ok_Hash.put("tFileInputDelimited_1", true);
end_Hash.put("tFileInputDelimited_1", System.currentTimeMillis());

tStatCatcher_1.addMessage("end","tFileInputDelimited_1", end_Hash.get("tFileInputDelimited_1")-start_Hash.get("tFileInputDelimited_1"));
tStatCatcher_1Process(globalMap);



/**
 * [tFileInputDelimited_1 end ] stop
 */
	
	/**
	 * [tFileInputExcel_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileInputExcel_2", false);
		start_Hash.put("tFileInputExcel_2", System.currentTimeMillis());
		
				tStatCatcher_1.addMessage("begin","tFileInputExcel_2");
				tStatCatcher_1Process(globalMap);
			
	
	currentComponent="tFileInputExcel_2";

	
		int tos_count_tFileInputExcel_2 = 0;
		



			class RegexUtil_tFileInputExcel_2 {

		    	public java.util.List<jxl.Sheet> getSheets(jxl.Workbook workbook, String oneSheetName, boolean useRegex) {

			        java.util.List<jxl.Sheet> list = new java.util.ArrayList<jxl.Sheet>();

			        if(useRegex){//this part process the regex issue

				        jxl.Sheet[] sheets = workbook.getSheets();
				        java.util.regex.Pattern pattern = java.util.regex.Pattern.compile(oneSheetName);
				        for (int i = 0; i < sheets.length; i++) {
				            String sheetName = sheets[i].getName();
				            java.util.regex.Matcher matcher = pattern.matcher(sheetName);
				            if (matcher.matches()) {
				            	jxl.Sheet sheet = workbook.getSheet(sheetName);
				            	if(sheet != null){
				                	list.add(sheet);
				                }
				            }
				        }

			        }else{
			        	jxl.Sheet sheet = workbook.getSheet(oneSheetName);
		            	if(sheet != null){
		                	list.add(sheet);
		                }

			        }

			        return list;
			    }

			    public java.util.List<jxl.Sheet> getSheets(jxl.Workbook workbook, int index, boolean useRegex) {
			    	java.util.List<jxl.Sheet> list =  new java.util.ArrayList<jxl.Sheet>();
			    	jxl.Sheet sheet = workbook.getSheet(index);
	            	if(sheet != null){
	                	list.add(sheet);
	                }
			    	return list;
			    }

			}


		RegexUtil_tFileInputExcel_2 regexUtil_tFileInputExcel_2 = new RegexUtil_tFileInputExcel_2();
		final jxl.WorkbookSettings workbookSettings_tFileInputExcel_2 = new jxl.WorkbookSettings();
		workbookSettings_tFileInputExcel_2.setDrawingsDisabled(true);
        workbookSettings_tFileInputExcel_2.setEncoding("UTF-8");

        Object source_tFileInputExcel_2 ="C:/CC2/Groupe1/5_DATA_IN/adresse_restaurant_2.xls";
        final jxl.Workbook workbook_tFileInputExcel_2;

        java.io.InputStream toClose_tFileInputExcel_2 = null;
        java.io.BufferedInputStream buffIStreamtFileInputExcel_2 = null;
        try {
            if(source_tFileInputExcel_2 instanceof java.io.InputStream){
        		toClose_tFileInputExcel_2 = (java.io.InputStream)source_tFileInputExcel_2;
        		buffIStreamtFileInputExcel_2 = new java.io.BufferedInputStream(toClose_tFileInputExcel_2);
        		workbook_tFileInputExcel_2 = jxl.Workbook.getWorkbook(buffIStreamtFileInputExcel_2, workbookSettings_tFileInputExcel_2);
            }else if(source_tFileInputExcel_2 instanceof String){
        		toClose_tFileInputExcel_2 = new java.io.FileInputStream(source_tFileInputExcel_2.toString());
        		buffIStreamtFileInputExcel_2 = new java.io.BufferedInputStream(toClose_tFileInputExcel_2);
        		workbook_tFileInputExcel_2 = jxl.Workbook.getWorkbook(buffIStreamtFileInputExcel_2, workbookSettings_tFileInputExcel_2);
            }else{
            	workbook_tFileInputExcel_2 = null;
            	throw new java.lang.Exception("The data source should be specified as Inputstream or File Path!");
            }
        } finally {
			try{
			   if(buffIStreamtFileInputExcel_2 != null){
			   	  buffIStreamtFileInputExcel_2.close();
			   }
			}catch(Exception e){
globalMap.put("tFileInputExcel_2_ERROR_MESSAGE",e.getMessage());
			}
        }
        try {
		java.util.List<jxl.Sheet> sheetList_tFileInputExcel_2 = java.util.Arrays.<jxl.Sheet> asList(workbook_tFileInputExcel_2.getSheets());
        if(sheetList_tFileInputExcel_2.size() <= 0){
        	throw new RuntimeException("Special sheets not exist!");
        }

        java.util.List<jxl.Sheet> sheet_FilterNullList_tFileInputExcel_2 = new java.util.ArrayList<jxl.Sheet>();
        for(jxl.Sheet sheet_FilterNull_tFileInputExcel_2 : sheetList_tFileInputExcel_2){
        	if(sheet_FilterNull_tFileInputExcel_2.getRows()>0){
        		sheet_FilterNullList_tFileInputExcel_2.add(sheet_FilterNull_tFileInputExcel_2);
        	}
        }
		sheetList_tFileInputExcel_2 = sheet_FilterNullList_tFileInputExcel_2;
	if(sheetList_tFileInputExcel_2.size()>0){
        int nb_line_tFileInputExcel_2 = 0;

        int begin_line_tFileInputExcel_2 = 1;

        int footer_input_tFileInputExcel_2 = 0;

        int end_line_tFileInputExcel_2=0;
        for(jxl.Sheet sheet_tFileInputExcel_2:sheetList_tFileInputExcel_2){
        	end_line_tFileInputExcel_2+=sheet_tFileInputExcel_2.getRows();
        }
        end_line_tFileInputExcel_2 -= footer_input_tFileInputExcel_2;
        int limit_tFileInputExcel_2 = -1;
        int start_column_tFileInputExcel_2 = 1-1;
        int end_column_tFileInputExcel_2 = sheetList_tFileInputExcel_2.get(0).getColumns();
        jxl.Cell[] row_tFileInputExcel_2 = null;
        jxl.Sheet sheet_tFileInputExcel_2 = sheetList_tFileInputExcel_2.get(0);
        int rowCount_tFileInputExcel_2 = 0;
        int sheetIndex_tFileInputExcel_2 = 0;
        int currentRows_tFileInputExcel_2 = sheetList_tFileInputExcel_2.get(0).getRows();

        //for the number format
        java.text.DecimalFormat df_tFileInputExcel_2 = new java.text.DecimalFormat("#.####################################");
		char separatorChar_tFileInputExcel_2 = df_tFileInputExcel_2.getDecimalFormatSymbols().getDecimalSeparator();
		
		
		
        for(int i_tFileInputExcel_2 = begin_line_tFileInputExcel_2; i_tFileInputExcel_2 < end_line_tFileInputExcel_2; i_tFileInputExcel_2++){

        	int emptyColumnCount_tFileInputExcel_2 = 0;

        	if (limit_tFileInputExcel_2 != -1 && nb_line_tFileInputExcel_2 >= limit_tFileInputExcel_2) {
        		break;
        	}

            while (i_tFileInputExcel_2 >= rowCount_tFileInputExcel_2 + currentRows_tFileInputExcel_2) {
                rowCount_tFileInputExcel_2 += currentRows_tFileInputExcel_2;
                sheet_tFileInputExcel_2 = sheetList_tFileInputExcel_2.get(++sheetIndex_tFileInputExcel_2);
                currentRows_tFileInputExcel_2 = sheet_tFileInputExcel_2.getRows();
            }
            if (rowCount_tFileInputExcel_2 <= i_tFileInputExcel_2) {
                row_tFileInputExcel_2 = sheet_tFileInputExcel_2.getRow(i_tFileInputExcel_2 - rowCount_tFileInputExcel_2);
            }
        	globalMap.put("tFileInputExcel_2_CURRENT_SHEET",sheet_tFileInputExcel_2.getName());
    		row7 = null;
					int tempRowLength_tFileInputExcel_2 = 2;
				
				int columnIndex_tFileInputExcel_2 = 0;
			
//
//end%>
			
			String[] temp_row_tFileInputExcel_2 = new String[tempRowLength_tFileInputExcel_2];
			int actual_end_column_tFileInputExcel_2 = end_column_tFileInputExcel_2 >	row_tFileInputExcel_2.length ? row_tFileInputExcel_2.length : end_column_tFileInputExcel_2;

				java.util.TimeZone zone_tFileInputExcel_2 = java.util.TimeZone.getTimeZone("GMT");
                java.text.SimpleDateFormat sdf_tFileInputExcel_2 = new java.text.SimpleDateFormat("dd-MM-yyyy");
                sdf_tFileInputExcel_2.setTimeZone(zone_tFileInputExcel_2);
                

			for(int i=0;i<tempRowLength_tFileInputExcel_2;i++){

				if(i + start_column_tFileInputExcel_2 < actual_end_column_tFileInputExcel_2){

				  jxl.Cell cell_tFileInputExcel_2 = row_tFileInputExcel_2[i + start_column_tFileInputExcel_2];
                        temp_row_tFileInputExcel_2[i] = cell_tFileInputExcel_2.getContents();

				}else{
					temp_row_tFileInputExcel_2[i]="";
				}
			}

			boolean whetherReject_tFileInputExcel_2 = false;
			row7 = new row7Struct();
			int curColNum_tFileInputExcel_2 = -1;
			String curColName_tFileInputExcel_2 = "";
			try {
							columnIndex_tFileInputExcel_2 = 0;
						
			if( temp_row_tFileInputExcel_2[columnIndex_tFileInputExcel_2].length() > 0) {
				curColNum_tFileInputExcel_2=columnIndex_tFileInputExcel_2 + start_column_tFileInputExcel_2 + 1;
				curColName_tFileInputExcel_2 = "ID_ADRESSE_RESTAURANT";
			row7.ID_ADRESSE_RESTAURANT = ParserUtils.parseTo_Integer(temp_row_tFileInputExcel_2[columnIndex_tFileInputExcel_2]);
			}else {
				row7.ID_ADRESSE_RESTAURANT = null;
				emptyColumnCount_tFileInputExcel_2++;
		}
							columnIndex_tFileInputExcel_2 = 1;
						
			if( temp_row_tFileInputExcel_2[columnIndex_tFileInputExcel_2].length() > 0) {
				curColNum_tFileInputExcel_2=columnIndex_tFileInputExcel_2 + start_column_tFileInputExcel_2 + 1;
				curColName_tFileInputExcel_2 = "ADRESSE_RESTAURANT";
			row7.ADRESSE_RESTAURANT = temp_row_tFileInputExcel_2[columnIndex_tFileInputExcel_2];
			}else {
				row7.ADRESSE_RESTAURANT = null;
				emptyColumnCount_tFileInputExcel_2++;
		}

			nb_line_tFileInputExcel_2++;
			
    } catch (java.lang.Exception e) {
globalMap.put("tFileInputExcel_2_ERROR_MESSAGE",e.getMessage());
        whetherReject_tFileInputExcel_2 = true;
                System.err.println(e.getMessage());
                row7 = null;
    }

					
		



 



/**
 * [tFileInputExcel_2 begin ] stop
 */
	
	/**
	 * [tFileInputExcel_2 main ] start
	 */

	

	
	
	currentComponent="tFileInputExcel_2";

	

 


	tos_count_tFileInputExcel_2++;

/**
 * [tFileInputExcel_2 main ] stop
 */
	
	/**
	 * [tFileInputExcel_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFileInputExcel_2";

	

 



/**
 * [tFileInputExcel_2 process_data_begin ] stop
 */
// Start of branch "row7"
if(row7 != null) { 



	
	/**
	 * [tUnite_2 main ] start
	 */

	

	
	
	currentComponent="tUnite_2";

	
						if(execStat){
							runStat.updateStatOnConnection(iterateId,1,1
								
									,"row7"
									
							);
						}
						
//////////
 

// for output
			row8 = new row8Struct();
								
			row8.ID_ADRESSE_RESTAURANT = row7.ID_ADRESSE_RESTAURANT;								
			row8.ADRESSE_RESTAURANT = row7.ADRESSE_RESTAURANT;			

			nb_line_tUnite_2++;

//////////
 


	tos_count_tUnite_2++;

/**
 * [tUnite_2 main ] stop
 */
	
	/**
	 * [tUnite_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tUnite_2";

	

 



/**
 * [tUnite_2 process_data_begin ] stop
 */

	
	/**
	 * [tDBOutput_3 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row8"
						
						);
					}
					



        whetherReject_tDBOutput_3 = false;
                        if(row8.ID_ADRESSE_RESTAURANT == null) {
pstmt_tDBOutput_3.setNull(1, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_3.setInt(1, row8.ID_ADRESSE_RESTAURANT);
}

                        if(row8.ADRESSE_RESTAURANT == null) {
pstmt_tDBOutput_3.setNull(2, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(2, row8.ADRESSE_RESTAURANT);
}

                pstmt_tDBOutput_3.addBatch();
                nb_line_tDBOutput_3++;
                batchSizeCounter_tDBOutput_3++;
            if (batchSize_tDBOutput_3 > 0 &&  batchSize_tDBOutput_3 <= batchSizeCounter_tDBOutput_3) {
                try {
                    pstmt_tDBOutput_3.executeBatch();
                }catch (java.sql.BatchUpdateException e_tDBOutput_3){
globalMap.put("tDBOutput_3_ERROR_MESSAGE",e_tDBOutput_3.getMessage());
			        java.sql.SQLException ne_tDBOutput_3 = e_tDBOutput_3.getNextException(),sqle_tDBOutput_3=null;
			    	String errormessage_tDBOutput_3;
					if (ne_tDBOutput_3 != null) {
						// build new exception to provide the original cause
						sqle_tDBOutput_3 = new java.sql.SQLException(e_tDBOutput_3.getMessage() + "\ncaused by: " + ne_tDBOutput_3.getMessage(), ne_tDBOutput_3.getSQLState(), ne_tDBOutput_3.getErrorCode(), ne_tDBOutput_3);
						errormessage_tDBOutput_3 = sqle_tDBOutput_3.getMessage();
					}else{
						errormessage_tDBOutput_3 = e_tDBOutput_3.getMessage();
					}
	            	
	                	System.err.println(errormessage_tDBOutput_3);
	            	
	        	}
                tmp_batchUpdateCount_tDBOutput_3 = pstmt_tDBOutput_3.getUpdateCount();
                    insertedCount_tDBOutput_3
                += (tmp_batchUpdateCount_tDBOutput_3!=-1?tmp_batchUpdateCount_tDBOutput_3:0);
                rowsToCommitCount_tDBOutput_3 += (tmp_batchUpdateCount_tDBOutput_3!=-1?tmp_batchUpdateCount_tDBOutput_3:0);
                batchSizeCounter_tDBOutput_3 = 0;
            }
                commitCounter_tDBOutput_3++;
                if(commitEvery_tDBOutput_3 <= commitCounter_tDBOutput_3) {
                    if(batchSizeCounter_tDBOutput_3 > 0) {
                        try {
                            pstmt_tDBOutput_3.executeBatch();
                        }catch (java.sql.BatchUpdateException e_tDBOutput_3){
globalMap.put("tDBOutput_3_ERROR_MESSAGE",e_tDBOutput_3.getMessage());
					        java.sql.SQLException ne_tDBOutput_3 = e_tDBOutput_3.getNextException(),sqle_tDBOutput_3=null;
					    	String errormessage_tDBOutput_3;
							if (ne_tDBOutput_3 != null) {
								// build new exception to provide the original cause
								sqle_tDBOutput_3 = new java.sql.SQLException(e_tDBOutput_3.getMessage() + "\ncaused by: " + ne_tDBOutput_3.getMessage(), ne_tDBOutput_3.getSQLState(), ne_tDBOutput_3.getErrorCode(), ne_tDBOutput_3);
								errormessage_tDBOutput_3 = sqle_tDBOutput_3.getMessage();
							}else{
								errormessage_tDBOutput_3 = e_tDBOutput_3.getMessage();
							}
			            	
			                	System.err.println(errormessage_tDBOutput_3);
			            	
			        	}
                        tmp_batchUpdateCount_tDBOutput_3 = pstmt_tDBOutput_3.getUpdateCount();
                            insertedCount_tDBOutput_3
                        += (tmp_batchUpdateCount_tDBOutput_3!=-1?tmp_batchUpdateCount_tDBOutput_3:0);
                        rowsToCommitCount_tDBOutput_3 += (tmp_batchUpdateCount_tDBOutput_3!=-1?tmp_batchUpdateCount_tDBOutput_3:0);
                    }
                    if(rowsToCommitCount_tDBOutput_3 != 0){
                    	
                    }
                    conn_tDBOutput_3.commit();
                    if(rowsToCommitCount_tDBOutput_3 != 0){
                    	
                    	rowsToCommitCount_tDBOutput_3 = 0;
                    }
                    commitCounter_tDBOutput_3=0;
                    	batchSizeCounter_tDBOutput_3=0;
                }

 


	tos_count_tDBOutput_3++;

/**
 * [tDBOutput_3 main ] stop
 */
	
	/**
	 * [tDBOutput_3 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";

	

 



/**
 * [tDBOutput_3 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_3 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";

	

 



/**
 * [tDBOutput_3 process_data_end ] stop
 */



	
	/**
	 * [tUnite_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tUnite_2";

	

 



/**
 * [tUnite_2 process_data_end ] stop
 */

} // End of branch "row7"




	
	/**
	 * [tFileInputExcel_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tFileInputExcel_2";

	

 



/**
 * [tFileInputExcel_2 process_data_end ] stop
 */
	
	/**
	 * [tFileInputExcel_2 end ] start
	 */

	

	
	
	currentComponent="tFileInputExcel_2";

	

			}
			
			
			
			globalMap.put("tFileInputExcel_2_NB_LINE",nb_line_tFileInputExcel_2);
			
				}
			
		} finally { 
				
					if(!(source_tFileInputExcel_2 instanceof java.io.InputStream)){
						workbook_tFileInputExcel_2.close();
					}
				
		}	
		

 

ok_Hash.put("tFileInputExcel_2", true);
end_Hash.put("tFileInputExcel_2", System.currentTimeMillis());

tStatCatcher_1.addMessage("end","tFileInputExcel_2", end_Hash.get("tFileInputExcel_2")-start_Hash.get("tFileInputExcel_2"));
tStatCatcher_1Process(globalMap);



/**
 * [tFileInputExcel_2 end ] stop
 */
	
	/**
	 * [tUnite_2 end ] start
	 */

	

	
	
	currentComponent="tUnite_2";

	

globalMap.put("tUnite_2_NB_LINE", nb_line_tUnite_2);
				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row7","row6");
			  	}
			  	
 

ok_Hash.put("tUnite_2", true);
end_Hash.put("tUnite_2", System.currentTimeMillis());

tStatCatcher_1.addMessage("end","tUnite_2", end_Hash.get("tUnite_2")-start_Hash.get("tUnite_2"));
tStatCatcher_1Process(globalMap);



/**
 * [tUnite_2 end ] stop
 */

	
	/**
	 * [tDBOutput_3 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";

	
	



	
        if(batchSizeCounter_tDBOutput_3 > 0) {
            try {
            	if (pstmt_tDBOutput_3 != null) {
					
					pstmt_tDBOutput_3.executeBatch();
					
        	    }
            }catch (java.sql.BatchUpdateException e_tDBOutput_3){
globalMap.put("tDBOutput_3_ERROR_MESSAGE",e_tDBOutput_3.getMessage());
		        java.sql.SQLException ne_tDBOutput_3 = e_tDBOutput_3.getNextException(),sqle_tDBOutput_3=null;
		    	String errormessage_tDBOutput_3;
				if (ne_tDBOutput_3 != null) {
					// build new exception to provide the original cause
					sqle_tDBOutput_3 = new java.sql.SQLException(e_tDBOutput_3.getMessage() + "\ncaused by: " + ne_tDBOutput_3.getMessage(), ne_tDBOutput_3.getSQLState(), ne_tDBOutput_3.getErrorCode(), ne_tDBOutput_3);
					errormessage_tDBOutput_3 = sqle_tDBOutput_3.getMessage();
				}else{
					errormessage_tDBOutput_3 = e_tDBOutput_3.getMessage();
				}
            	
                	System.err.println(errormessage_tDBOutput_3);
            	
        	}
        	if (pstmt_tDBOutput_3 != null) {
            	tmp_batchUpdateCount_tDBOutput_3 = pstmt_tDBOutput_3.getUpdateCount();
    	    	
    	    		insertedCount_tDBOutput_3
    	    	
    	    	+= (tmp_batchUpdateCount_tDBOutput_3!=-1?tmp_batchUpdateCount_tDBOutput_3:0);
				rowsToCommitCount_tDBOutput_3 += (tmp_batchUpdateCount_tDBOutput_3!=-1?tmp_batchUpdateCount_tDBOutput_3:0);
            }
        }
        if(pstmt_tDBOutput_3 != null) {
			
				pstmt_tDBOutput_3.close();
				resourceMap.remove("pstmt_tDBOutput_3");
			
        }
    resourceMap.put("statementClosed_tDBOutput_3", true);
		if(commitCounter_tDBOutput_3 > 0 && rowsToCommitCount_tDBOutput_3 != 0) {
			
		}
		conn_tDBOutput_3.commit();
		if(commitCounter_tDBOutput_3 > 0 && rowsToCommitCount_tDBOutput_3 != 0) {
			
			rowsToCommitCount_tDBOutput_3 = 0;
		}
		commitCounter_tDBOutput_3 = 0;
		
		
		conn_tDBOutput_3 .close();
		
		resourceMap.put("finish_tDBOutput_3", true);
   	

	
	nb_line_deleted_tDBOutput_3=nb_line_deleted_tDBOutput_3+ deletedCount_tDBOutput_3;
	nb_line_update_tDBOutput_3=nb_line_update_tDBOutput_3 + updatedCount_tDBOutput_3;
	nb_line_inserted_tDBOutput_3=nb_line_inserted_tDBOutput_3 + insertedCount_tDBOutput_3;
	nb_line_rejected_tDBOutput_3=nb_line_rejected_tDBOutput_3 + rejectedCount_tDBOutput_3;
	
        globalMap.put("tDBOutput_3_NB_LINE",nb_line_tDBOutput_3);
        globalMap.put("tDBOutput_3_NB_LINE_UPDATED",nb_line_update_tDBOutput_3);
        globalMap.put("tDBOutput_3_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_3);
        globalMap.put("tDBOutput_3_NB_LINE_DELETED",nb_line_deleted_tDBOutput_3);
        globalMap.put("tDBOutput_3_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_3);
    

	



				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row8");
			  	}
			  	
 

ok_Hash.put("tDBOutput_3", true);
end_Hash.put("tDBOutput_3", System.currentTimeMillis());

tStatCatcher_1.addMessage("end","tDBOutput_3", end_Hash.get("tDBOutput_3")-start_Hash.get("tDBOutput_3"));
tStatCatcher_1Process(globalMap);



/**
 * [tDBOutput_3 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFileInputDelimited_1 finally ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_1";

	

 



/**
 * [tFileInputDelimited_1 finally ] stop
 */
	
	/**
	 * [tFileInputExcel_2 finally ] start
	 */

	

	
	
	currentComponent="tFileInputExcel_2";

	

 



/**
 * [tFileInputExcel_2 finally ] stop
 */
	
	/**
	 * [tUnite_2 finally ] start
	 */

	

	
	
	currentComponent="tUnite_2";

	

 



/**
 * [tUnite_2 finally ] stop
 */

	
	/**
	 * [tDBOutput_3 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";

	



    try {
    if (resourceMap.get("statementClosed_tDBOutput_3") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_3 = null;
                if ((pstmtToClose_tDBOutput_3 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_3")) != null) {
                    pstmtToClose_tDBOutput_3.close();
                }
    }
    } finally {
        if(resourceMap.get("finish_tDBOutput_3") == null){
            java.sql.Connection ctn_tDBOutput_3 = null;
            if((ctn_tDBOutput_3 = (java.sql.Connection)resourceMap.get("conn_tDBOutput_3")) != null){
                try {
                    ctn_tDBOutput_3.close();
                } catch (java.sql.SQLException sqlEx_tDBOutput_3) {
                    String errorMessage_tDBOutput_3 = "failed to close the connection in tDBOutput_3 :" + sqlEx_tDBOutput_3.getMessage();
                    System.err.println(errorMessage_tDBOutput_3);
                }
            }
        }
    }
 



/**
 * [tDBOutput_3 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFileInputDelimited_1_SUBPROCESS_STATE", 1);
	}
	

public void tDBRow_3Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBRow_3_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tDBRow_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBRow_3", false);
		start_Hash.put("tDBRow_3", System.currentTimeMillis());
		
				tStatCatcher_1.addMessage("begin","tDBRow_3");
				tStatCatcher_1Process(globalMap);
			
	
	currentComponent="tDBRow_3";

	
		int tos_count_tDBRow_3 = 0;
		

	java.sql.Connection conn_tDBRow_3 = null;
	String query_tDBRow_3 = "";
	boolean whetherReject_tDBRow_3 = false;
			String driverClass_tDBRow_3 = "oracle.jdbc.OracleDriver";
		    java.lang.Class jdbcclazz_tDBRow_3 = java.lang.Class.forName(driverClass_tDBRow_3);
		
			String url_tDBRow_3 = null;
				url_tDBRow_3 = "jdbc:oracle:thin:@(description=(address=(protocol=tcp)(host=" + "" + ")(port=" + "1521" + "))(connect_data=(service_name=" + "XEPDB1" + ")))";
					String dbUser_tDBRow_3 = "DSID_LIV_OPE";
	        
            		
            		
            		 
	final String decryptedPassword_tDBRow_3 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:/skS3OWEYAl+ByJN4QF8TQP3/cpxFITuWK8TewQVhV0=");
        		   	
        	        String dbPwd_tDBRow_3 = decryptedPassword_tDBRow_3;
	        
					
			conn_tDBRow_3 = java.sql.DriverManager.getConnection(url_tDBRow_3,dbUser_tDBRow_3,dbPwd_tDBRow_3);
		
        resourceMap.put("conn_tDBRow_3", conn_tDBRow_3);
					if(conn_tDBRow_3.getAutoCommit()) {
						
				conn_tDBRow_3.setAutoCommit(false);
			
					}        
					int commitEvery_tDBRow_3 = 10000;
					int commitCounter_tDBRow_3 = 0;
				
        java.sql.Statement stmt_tDBRow_3 = conn_tDBRow_3.createStatement();
        resourceMap.put("stmt_tDBRow_3", stmt_tDBRow_3);

 



/**
 * [tDBRow_3 begin ] stop
 */
	
	/**
	 * [tDBRow_3 main ] start
	 */

	

	
	
	currentComponent="tDBRow_3";

	

query_tDBRow_3 = "TRUNCATE TABLE  DSID_LIV_OPE.LIVRAISON";
whetherReject_tDBRow_3 = false;
globalMap.put("tDBRow_3_QUERY",query_tDBRow_3);
try {
		stmt_tDBRow_3.execute(query_tDBRow_3);
		
	} catch (java.lang.Exception e) {
globalMap.put("tDBRow_3_ERROR_MESSAGE",e.getMessage());
		whetherReject_tDBRow_3 = true;
		
				System.err.print(e.getMessage());
				
	}
	
	if(!whetherReject_tDBRow_3) {
		
	}
	
		commitCounter_tDBRow_3++;
		if(commitEvery_tDBRow_3 <= commitCounter_tDBRow_3) {
			
			conn_tDBRow_3.commit();
			
			commitCounter_tDBRow_3=0;
		}
		

 


	tos_count_tDBRow_3++;

/**
 * [tDBRow_3 main ] stop
 */
	
	/**
	 * [tDBRow_3 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBRow_3";

	

 



/**
 * [tDBRow_3 process_data_begin ] stop
 */
	
	/**
	 * [tDBRow_3 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBRow_3";

	

 



/**
 * [tDBRow_3 process_data_end ] stop
 */
	
	/**
	 * [tDBRow_3 end ] start
	 */

	

	
	
	currentComponent="tDBRow_3";

	

	
        stmt_tDBRow_3.close();
        resourceMap.remove("stmt_tDBRow_3");
    resourceMap.put("statementClosed_tDBRow_3", true);
		if(commitEvery_tDBRow_3>commitCounter_tDBRow_3){

			
			conn_tDBRow_3.commit();
			
	
			commitCounter_tDBRow_3=0;
	
		}
			conn_tDBRow_3.close();
			
			if("com.mysql.cj.jdbc.Driver".equals((String)globalMap.get("driverClass_"))
			    && routines.system.BundleUtils.inOSGi()) {
			        Class.forName("com.mysql.cj.jdbc.AbandonedConnectionCleanupThread").
			            getMethod("checkedShutdown").invoke(null, (Object[]) null);
			}
			
    resourceMap.put("finish_tDBRow_3", true);

 

ok_Hash.put("tDBRow_3", true);
end_Hash.put("tDBRow_3", System.currentTimeMillis());

tStatCatcher_1.addMessage("end","tDBRow_3", end_Hash.get("tDBRow_3")-start_Hash.get("tDBRow_3"));
tStatCatcher_1Process(globalMap);
				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk1", 0, "ok");
				}
				tDBRow_1Process(globalMap);



/**
 * [tDBRow_3 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBRow_3 finally ] start
	 */

	

	
	
	currentComponent="tDBRow_3";

	

try {
    if (resourceMap.get("statementClosed_tDBRow_3") == null) {
            java.sql.Statement stmtToClose_tDBRow_3 = null;
            if ((stmtToClose_tDBRow_3 = (java.sql.Statement) resourceMap.remove("stmt_tDBRow_3")) != null) {
                stmtToClose_tDBRow_3.close();
            }
    }
} finally {
        if(resourceMap.get("finish_tDBRow_3") == null){
            java.sql.Connection ctn_tDBRow_3 = null;
            if((ctn_tDBRow_3 = (java.sql.Connection)resourceMap.get("conn_tDBRow_3")) != null){
                try {
                    ctn_tDBRow_3.close();
                } catch (java.sql.SQLException sqlEx_tDBRow_3) {
                    String errorMessage_tDBRow_3 = "failed to close the connection in tDBRow_3 :" + sqlEx_tDBRow_3.getMessage();
                    System.err.println(errorMessage_tDBRow_3);
                }
            }
        }
    }
 



/**
 * [tDBRow_3 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBRow_3_SUBPROCESS_STATE", 1);
	}
	

public void tDBRow_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBRow_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tDBRow_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBRow_1", false);
		start_Hash.put("tDBRow_1", System.currentTimeMillis());
		
				tStatCatcher_1.addMessage("begin","tDBRow_1");
				tStatCatcher_1Process(globalMap);
			
	
	currentComponent="tDBRow_1";

	
		int tos_count_tDBRow_1 = 0;
		

	java.sql.Connection conn_tDBRow_1 = null;
	String query_tDBRow_1 = "";
	boolean whetherReject_tDBRow_1 = false;
			String driverClass_tDBRow_1 = "oracle.jdbc.OracleDriver";
		    java.lang.Class jdbcclazz_tDBRow_1 = java.lang.Class.forName(driverClass_tDBRow_1);
		
			String url_tDBRow_1 = null;
				url_tDBRow_1 = "jdbc:oracle:thin:@(description=(address=(protocol=tcp)(host=" + "" + ")(port=" + "1521" + "))(connect_data=(service_name=" + "XEPDB1" + ")))";
					String dbUser_tDBRow_1 = "DSID_LIV_OPE";
	        
            		
            		
            		 
	final String decryptedPassword_tDBRow_1 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:iMZhsN+efGHllUxcwJMaIhrRBc3v2JQ/UR6uZorruOE=");
        		   	
        	        String dbPwd_tDBRow_1 = decryptedPassword_tDBRow_1;
	        
					
			conn_tDBRow_1 = java.sql.DriverManager.getConnection(url_tDBRow_1,dbUser_tDBRow_1,dbPwd_tDBRow_1);
		
        resourceMap.put("conn_tDBRow_1", conn_tDBRow_1);
					if(conn_tDBRow_1.getAutoCommit()) {
						
				conn_tDBRow_1.setAutoCommit(false);
			
					}        
					int commitEvery_tDBRow_1 = 10000;
					int commitCounter_tDBRow_1 = 0;
				
        java.sql.Statement stmt_tDBRow_1 = conn_tDBRow_1.createStatement();
        resourceMap.put("stmt_tDBRow_1", stmt_tDBRow_1);

 



/**
 * [tDBRow_1 begin ] stop
 */
	
	/**
	 * [tDBRow_1 main ] start
	 */

	

	
	
	currentComponent="tDBRow_1";

	

query_tDBRow_1 = "TRUNCATE TABLE  DSID_LIV_OPE.LIVREUR";
whetherReject_tDBRow_1 = false;
globalMap.put("tDBRow_1_QUERY",query_tDBRow_1);
try {
		stmt_tDBRow_1.execute(query_tDBRow_1);
		
	} catch (java.lang.Exception e) {
globalMap.put("tDBRow_1_ERROR_MESSAGE",e.getMessage());
		whetherReject_tDBRow_1 = true;
		
				System.err.print(e.getMessage());
				
	}
	
	if(!whetherReject_tDBRow_1) {
		
	}
	
		commitCounter_tDBRow_1++;
		if(commitEvery_tDBRow_1 <= commitCounter_tDBRow_1) {
			
			conn_tDBRow_1.commit();
			
			commitCounter_tDBRow_1=0;
		}
		

 


	tos_count_tDBRow_1++;

/**
 * [tDBRow_1 main ] stop
 */
	
	/**
	 * [tDBRow_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBRow_1";

	

 



/**
 * [tDBRow_1 process_data_begin ] stop
 */
	
	/**
	 * [tDBRow_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBRow_1";

	

 



/**
 * [tDBRow_1 process_data_end ] stop
 */
	
	/**
	 * [tDBRow_1 end ] start
	 */

	

	
	
	currentComponent="tDBRow_1";

	

	
        stmt_tDBRow_1.close();
        resourceMap.remove("stmt_tDBRow_1");
    resourceMap.put("statementClosed_tDBRow_1", true);
		if(commitEvery_tDBRow_1>commitCounter_tDBRow_1){

			
			conn_tDBRow_1.commit();
			
	
			commitCounter_tDBRow_1=0;
	
		}
			conn_tDBRow_1.close();
			
			if("com.mysql.cj.jdbc.Driver".equals((String)globalMap.get("driverClass_"))
			    && routines.system.BundleUtils.inOSGi()) {
			        Class.forName("com.mysql.cj.jdbc.AbandonedConnectionCleanupThread").
			            getMethod("checkedShutdown").invoke(null, (Object[]) null);
			}
			
    resourceMap.put("finish_tDBRow_1", true);

 

ok_Hash.put("tDBRow_1", true);
end_Hash.put("tDBRow_1", System.currentTimeMillis());

tStatCatcher_1.addMessage("end","tDBRow_1", end_Hash.get("tDBRow_1")-start_Hash.get("tDBRow_1"));
tStatCatcher_1Process(globalMap);
				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk4", 0, "ok");
				}
				tBigQueryInput_1Process(globalMap);



/**
 * [tDBRow_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBRow_1 finally ] start
	 */

	

	
	
	currentComponent="tDBRow_1";

	

try {
    if (resourceMap.get("statementClosed_tDBRow_1") == null) {
            java.sql.Statement stmtToClose_tDBRow_1 = null;
            if ((stmtToClose_tDBRow_1 = (java.sql.Statement) resourceMap.remove("stmt_tDBRow_1")) != null) {
                stmtToClose_tDBRow_1.close();
            }
    }
} finally {
        if(resourceMap.get("finish_tDBRow_1") == null){
            java.sql.Connection ctn_tDBRow_1 = null;
            if((ctn_tDBRow_1 = (java.sql.Connection)resourceMap.get("conn_tDBRow_1")) != null){
                try {
                    ctn_tDBRow_1.close();
                } catch (java.sql.SQLException sqlEx_tDBRow_1) {
                    String errorMessage_tDBRow_1 = "failed to close the connection in tDBRow_1 :" + sqlEx_tDBRow_1.getMessage();
                    System.err.println(errorMessage_tDBRow_1);
                }
            }
        }
    }
 



/**
 * [tDBRow_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBRow_1_SUBPROCESS_STATE", 1);
	}
	


public static class row10Struct implements routines.system.IPersistableRow<row10Struct> {
    final static byte[] commonByteArrayLock_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ = new byte[0];
    static byte[] commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public BigDecimal ID_MOYEN_LIVRAISON;

				public BigDecimal getID_MOYEN_LIVRAISON () {
					return this.ID_MOYEN_LIVRAISON;
				}
				
			    public String CODE_MOYEN_LIVRAISON;

				public String getCODE_MOYEN_LIVRAISON () {
					return this.CODE_MOYEN_LIVRAISON;
				}
				
			    public String LIBELLE_MOYEN_LIVRAISON;

				public String getLIBELLE_MOYEN_LIVRAISON () {
					return this.LIBELLE_MOYEN_LIVRAISON;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
						result = prime * result + ((this.ID_MOYEN_LIVRAISON == null) ? 0 : this.ID_MOYEN_LIVRAISON.hashCode());
					
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row10Struct other = (row10Struct) obj;
		
						if (this.ID_MOYEN_LIVRAISON == null) {
							if (other.ID_MOYEN_LIVRAISON != null)
								return false;
						
						} else if (!this.ID_MOYEN_LIVRAISON.equals(other.ID_MOYEN_LIVRAISON))
						
							return false;
					

		return true;
    }

	public void copyDataTo(row10Struct other) {

		other.ID_MOYEN_LIVRAISON = this.ID_MOYEN_LIVRAISON;
	            other.CODE_MOYEN_LIVRAISON = this.CODE_MOYEN_LIVRAISON;
	            other.LIBELLE_MOYEN_LIVRAISON = this.LIBELLE_MOYEN_LIVRAISON;
	            
	}

	public void copyKeysDataTo(row10Struct other) {

		other.ID_MOYEN_LIVRAISON = this.ID_MOYEN_LIVRAISON;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ.length == 0) {
   					commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ.length == 0) {
   					commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ) {

        	try {

        		int length = 0;
		
						this.ID_MOYEN_LIVRAISON = (BigDecimal) dis.readObject();
					
					this.CODE_MOYEN_LIVRAISON = readString(dis);
					
					this.LIBELLE_MOYEN_LIVRAISON = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ) {

        	try {

        		int length = 0;
		
						this.ID_MOYEN_LIVRAISON = (BigDecimal) dis.readObject();
					
					this.CODE_MOYEN_LIVRAISON = readString(dis);
					
					this.LIBELLE_MOYEN_LIVRAISON = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// BigDecimal
				
       			    	dos.writeObject(this.ID_MOYEN_LIVRAISON);
					
					// String
				
						writeString(this.CODE_MOYEN_LIVRAISON,dos);
					
					// String
				
						writeString(this.LIBELLE_MOYEN_LIVRAISON,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// BigDecimal
				
       			    	dos.writeObject(this.ID_MOYEN_LIVRAISON);
					
					// String
				
						writeString(this.CODE_MOYEN_LIVRAISON,dos);
					
					// String
				
						writeString(this.LIBELLE_MOYEN_LIVRAISON,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("ID_MOYEN_LIVRAISON="+String.valueOf(ID_MOYEN_LIVRAISON));
		sb.append(",CODE_MOYEN_LIVRAISON="+CODE_MOYEN_LIVRAISON);
		sb.append(",LIBELLE_MOYEN_LIVRAISON="+LIBELLE_MOYEN_LIVRAISON);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row10Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.ID_MOYEN_LIVRAISON, other.ID_MOYEN_LIVRAISON);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tBigQueryInput_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tBigQueryInput_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row10Struct row10 = new row10Struct();




	
	/**
	 * [tDBOutput_5 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_5", false);
		start_Hash.put("tDBOutput_5", System.currentTimeMillis());
		
				tStatCatcher_1.addMessage("begin","tDBOutput_5");
				tStatCatcher_1Process(globalMap);
			
	
	currentComponent="tDBOutput_5";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row10");
					}
				
		int tos_count_tDBOutput_5 = 0;
		






    
    int nb_line_tDBOutput_5 = 0;
    int nb_line_update_tDBOutput_5 = 0;
    int nb_line_inserted_tDBOutput_5 = 0;
    int nb_line_deleted_tDBOutput_5 = 0;
    int nb_line_rejected_tDBOutput_5 = 0;

    int tmp_batchUpdateCount_tDBOutput_5 = 0;

    int deletedCount_tDBOutput_5=0;
    int updatedCount_tDBOutput_5=0;
    int insertedCount_tDBOutput_5=0;
    int rowsToCommitCount_tDBOutput_5=0;
    int rejectedCount_tDBOutput_5=0;

    boolean whetherReject_tDBOutput_5 = false;

    java.sql.Connection conn_tDBOutput_5 = null;

    //optional table
    String dbschema_tDBOutput_5 = null;
    String tableName_tDBOutput_5 = null;
                    String driverClass_tDBOutput_5 = "oracle.jdbc.OracleDriver";


                java.lang.Class.forName(driverClass_tDBOutput_5);
                String url_tDBOutput_5 = null;
                    url_tDBOutput_5 = "jdbc:oracle:thin:@(description=(address=(protocol=tcp)(host=" + "" + ")(port=" + "1521" + "))(connect_data=(service_name=" + "XEPDB1" + ")))";
                String dbUser_tDBOutput_5 = "DSID_LIV_OPE";
 
	final String decryptedPassword_tDBOutput_5 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:uXtg91Bcq2aBHMRo+O0cp8ceGO2wzz7LVIMoQeywDmU=");

                String dbPwd_tDBOutput_5 = decryptedPassword_tDBOutput_5;
                dbschema_tDBOutput_5 = "DSID_LIV_OPE";


                    conn_tDBOutput_5 = java.sql.DriverManager.getConnection(url_tDBOutput_5, dbUser_tDBOutput_5, dbPwd_tDBOutput_5);
        resourceMap.put("conn_tDBOutput_5", conn_tDBOutput_5);
            conn_tDBOutput_5.setAutoCommit(false);
            int commitEvery_tDBOutput_5 = 10000;
            int commitCounter_tDBOutput_5 = 0;
        int batchSize_tDBOutput_5 = 10000;
        int batchSizeCounter_tDBOutput_5=0;
        int count_tDBOutput_5=0;

        if(dbschema_tDBOutput_5 == null || dbschema_tDBOutput_5.trim().length() == 0) {
            tableName_tDBOutput_5 = ("MOYEN_LIVRAISON");
        } else {
            tableName_tDBOutput_5 = dbschema_tDBOutput_5 + "." + ("MOYEN_LIVRAISON");
        }
            int rsTruncCountNumber_tDBOutput_5 = 0;
            try(java.sql.Statement stmtTruncCount_tDBOutput_5 = conn_tDBOutput_5.createStatement()) {
                try (java.sql.ResultSet rsTruncCount_tDBOutput_5 = stmtTruncCount_tDBOutput_5.executeQuery("SELECT COUNT(1) FROM " + tableName_tDBOutput_5 + "")) {
                    if(rsTruncCount_tDBOutput_5.next()) {
                        rsTruncCountNumber_tDBOutput_5 = rsTruncCount_tDBOutput_5.getInt(1);
                    }
                }
            }
            try (java.sql.Statement stmtTrunc_tDBOutput_5 = conn_tDBOutput_5.createStatement()) {
                stmtTrunc_tDBOutput_5.executeUpdate("TRUNCATE TABLE " + tableName_tDBOutput_5 + "");
                deletedCount_tDBOutput_5 += rsTruncCountNumber_tDBOutput_5;
            }
                String insert_tDBOutput_5 = "INSERT INTO " + tableName_tDBOutput_5 + " (ID_MOYEN_LIVRAISON,CODE_MOYEN_LIVRAISON,LIBELLE_MOYEN_LIVRAISON) VALUES (?,?,?)";    

                        java.sql.PreparedStatement pstmt_tDBOutput_5 = conn_tDBOutput_5.prepareStatement(insert_tDBOutput_5);
                        resourceMap.put("pstmt_tDBOutput_5", pstmt_tDBOutput_5);





 



/**
 * [tDBOutput_5 begin ] stop
 */



	
	/**
	 * [tBigQueryInput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tBigQueryInput_1", false);
		start_Hash.put("tBigQueryInput_1", System.currentTimeMillis());
		
				tStatCatcher_1.addMessage("begin","tBigQueryInput_1");
				tStatCatcher_1Process(globalMap);
			
	
	currentComponent="tBigQueryInput_1";

	
		int tos_count_tBigQueryInput_1 = 0;
		
	
	

		
class ServiceAccountBigQueryUtil_tBigQueryInput_1 {
	private com.google.cloud.bigquery.BigQuery bigQuery;
	private boolean useLargeResult;
	private String tempTable;

	public ServiceAccountBigQueryUtil_tBigQueryInput_1() {
		this.useLargeResult = false;
	}

	private com.google.cloud.bigquery.BigQuery buildBigQuery() throws java.io.IOException {
		if (bigQuery != null) {
			return bigQuery;
		}
		com.google.auth.oauth2.GoogleCredentials credentials;
		java.io.File credentialsFile = new java.io.File("C:/CC2/Groupe1/4_DATA_BIGQUERY/dsid-cc2-grp1-407520-99e8a6c61c07.json");
		try(java.io.FileInputStream credentialsStream = new java.io.FileInputStream(credentialsFile)) {
			credentials = com.google.auth.oauth2.ServiceAccountCredentials.fromStream(credentialsStream);
		}

		com.google.cloud.bigquery.BigQuery result = com.google.cloud.bigquery.BigQueryOptions.newBuilder()
			.setCredentials(credentials)
			.setProjectId("dsid-cc2-grp1-407520")
			.build()
			.getService();

		return result;
	}

	private com.google.cloud.bigquery.Job buildJob(com.google.cloud.bigquery.BigQuery bigquery, com.google.cloud.bigquery.QueryJobConfiguration queryConfiguration, com.google.cloud.bigquery.JobId jobId) throws InterruptedException {
        globalMap.put("tBigQueryInput_1_JOBID", jobId.getJob());
        com.google.cloud.bigquery.Job job = bigquery.create(com.google.cloud.bigquery.JobInfo.newBuilder(queryConfiguration).setJobId(jobId).build());

		
		job = job.waitFor();

		if (job == null) {
            String message = "tBigQueryInput_1 - Job no longer exists";
            globalMap.put("tBigQueryInput_1_ERROR_MESSAGE", message);
            throw new RuntimeException(message);
		} else if (job.getStatus().getError() != null) {
            com.google.gson.Gson gsonObject = new com.google.gson.Gson();
            globalMap.put("tBigQueryInput_1_STATISTICS", gsonObject.toJson(job.getStatistics()));
            String message = job.getStatus().getError().toString();
            globalMap.put("tBigQueryInput_1_ERROR_MESSAGE", message);
            throw new RuntimeException(message);
		}

		

		return job;
	}

	private com.google.cloud.bigquery.Job executeQuerySmallResult(String query, boolean useLegacySql) throws java.io.IOException, InterruptedException {
		bigQuery = buildBigQuery();
		com.google.cloud.bigquery.QueryJobConfiguration queryConfiguration = com.google.cloud.bigquery.QueryJobConfiguration.newBuilder(query)
			.setUseLegacySql(useLegacySql)
			.build();
		com.google.cloud.bigquery.JobId jobId = com.google.cloud.bigquery.JobId.of("dsid-cc2-grp1-407520", java.util.UUID.randomUUID().toString());
		return buildJob(bigQuery, queryConfiguration, jobId);
	}

	private com.google.cloud.bigquery.Job executeQueryLargeResult(String query, boolean useLegacySql) throws java.io.IOException, InterruptedException {
		bigQuery = buildBigQuery();

		
			com.google.cloud.bigquery.QueryJobConfiguration jobConfDryRun = com.google.cloud.bigquery.QueryJobConfiguration.newBuilder(query)
				.setUseLegacySql(useLegacySql)
				.setDryRun(true)
				.build();
			com.google.cloud.bigquery.Job jobDryRun = bigQuery.create(com.google.cloud.bigquery.JobInfo.of(jobConfDryRun));

			String queryLocation =jobDryRun.getJobId().getLocation();
			String location = queryLocation == null ? "US" : queryLocation;
			String tempDataset = java.util.UUID.randomUUID().toString().replaceAll("-", "")
			+ Integer.toHexString(java.util.concurrent.ThreadLocalRandom.current().nextInt())
			+ Integer.toHexString(java.util.concurrent.ThreadLocalRandom.current().nextInt());

			

			com.google.cloud.bigquery.DatasetInfo datasetInfo = com.google.cloud.bigquery.DatasetInfo.newBuilder(tempDataset).setLocation(location).build();
			com.google.cloud.bigquery.Dataset dataset = bigQuery.create(datasetInfo);
		
		tempTable = java.util.UUID.randomUUID().toString().replaceAll("-", "")
			+ Integer.toHexString(java.util.concurrent.ThreadLocalRandom.current().nextInt())
			+ Integer.toHexString(java.util.concurrent.ThreadLocalRandom.current().nextInt());
		
		com.google.cloud.bigquery.QueryJobConfiguration queryConfiguration = com.google.cloud.bigquery.QueryJobConfiguration.newBuilder(query)
			.setUseLegacySql(useLegacySql)
			.setDryRun(false)
			.setAllowLargeResults(true)
			.setDestinationTable(com.google.cloud.bigquery.TableId.of(tempDataset, tempTable))
			.build();

		com.google.cloud.bigquery.JobId jobId  = com.google.cloud.bigquery.JobId
			.newBuilder().setProject("dsid-cc2-grp1-407520")
			.setJob(java.util.UUID.randomUUID().toString())
			.build();

		
		return buildJob(bigQuery, queryConfiguration, jobId);
	}

	public com.google.cloud.bigquery.Job executeQuery(String query, boolean useLegacySql) throws Exception {

		com.google.cloud.bigquery.Job job;

		
			job = executeQuerySmallResult(query, useLegacySql);
		
		
		

		return job;
	}

    public java.util.List<com.google.cloud.bigquery.Job> getChildJobs(String jobId) throws java.io.IOException {
        return java.util.Optional.ofNullable(buildBigQuery().listJobs(com.google.cloud.bigquery.BigQuery.JobListOption.parentJobId(jobId)))
                    .map(com.google.api.gax.paging.Page::getValues)
                    .flatMap(iterable ->
                            java.util.Optional.ofNullable(java.util.stream.StreamSupport
                                .stream(iterable.spliterator(), false)
                                .collect(java.util.stream.Collectors.toList())))
                    .orElse(java.util.Collections.emptyList());
    }

	public void cleanup() throws Exception {
		if(useLargeResult) {
			
				com.google.cloud.bigquery.DatasetId datasetId = com.google.cloud.bigquery.DatasetId.of("dsid-cc2-grp1-407520", "temp_dataset");
				bigQuery.delete(datasetId, com.google.cloud.bigquery.BigQuery.DatasetDeleteOption.deleteContents());
			
		}
	}

}

		

		ServiceAccountBigQueryUtil_tBigQueryInput_1 serviceAccountBigQueryUtil_tBigQueryInput_1 = new ServiceAccountBigQueryUtil_tBigQueryInput_1();

        try {
                com.google.cloud.bigquery.Job job_tBigQueryInput_1 = serviceAccountBigQueryUtil_tBigQueryInput_1.executeQuery("SELECT id_moyen AS id_moyen_paiement, code_moyen_livraison, libelle_moyen_livraison FROM `dsid-cc2-grp1-407520.dsid_liv_ope_bq.livreur_moyen_livraison`", false);

                com.google.gson.Gson gsonObject_tBigQueryInput_1 = new com.google.gson.Gson();
                globalMap.put("tBigQueryInput_1_STATISTICS", gsonObject_tBigQueryInput_1.toJson(job_tBigQueryInput_1.getStatistics()));
                long nb_line_tBigQueryInput_1 = 0;
                java.util.List<String> child_statistics_tBigQueryInput_1 = null;
                java.util.List<com.google.cloud.bigquery.Job> childJobs_tBigQueryInput_1;
                if(job_tBigQueryInput_1.getStatistics().getNumChildJobs() != null){
                    childJobs_tBigQueryInput_1 = serviceAccountBigQueryUtil_tBigQueryInput_1.getChildJobs(job_tBigQueryInput_1.getJobId().getJob());
                    java.util.Collections.reverse(childJobs_tBigQueryInput_1);
                    child_statistics_tBigQueryInput_1 = new java.util.ArrayList<>();
                } else {
                    childJobs_tBigQueryInput_1 = java.util.Collections.singletonList(job_tBigQueryInput_1);
                }
                for (com.google.cloud.bigquery.Job job_iterable_tBigQueryInput_1 : childJobs_tBigQueryInput_1) {
                    if (child_statistics_tBigQueryInput_1 != null) {
                        child_statistics_tBigQueryInput_1.add(gsonObject_tBigQueryInput_1.toJson(job_iterable_tBigQueryInput_1.getStatistics()));
                    }
                    if (job_iterable_tBigQueryInput_1.getStatus().getError() != null) {
                        globalMap.put("tBigQueryInput_1_ERROR_MESSAGE", job_iterable_tBigQueryInput_1.getStatus().getError().toString());
                        String message_tBigQueryInput_1 = "tBigQueryInput_1 - " + job_iterable_tBigQueryInput_1.getStatus().getError().toString();
                System.err.println(message_tBigQueryInput_1);
                        continue;
                    }

                    com.google.cloud.bigquery.TableResult result_tBigQueryInput_1 = job_iterable_tBigQueryInput_1.getQueryResults();
		//Dynamic start

		
		//Dynamic end
	
		for (com.google.cloud.bigquery.FieldValueList field_tBigQueryInput_1 : result_tBigQueryInput_1.iterateAll()) {
			Object value_tBigQueryInput_1;
			nb_line_tBigQueryInput_1 ++;
	
		int fieldsCount_tBigQueryInput_1 = field_tBigQueryInput_1.size();
		int column_index_tBigQueryInput_1 =0;
		
									column_index_tBigQueryInput_1 = 0;
								
								if(fieldsCount_tBigQueryInput_1 <= column_index_tBigQueryInput_1) {
									row10.ID_MOYEN_LIVRAISON = null;
								} else {
								
								value_tBigQueryInput_1 = field_tBigQueryInput_1.get(column_index_tBigQueryInput_1).getValue();
								
								if(com.google.api.client.util.Data.isNull(value_tBigQueryInput_1)) value_tBigQueryInput_1 = null;

								if(value_tBigQueryInput_1 != null){

									
										row10.ID_MOYEN_LIVRAISON = ParserUtils.parseTo_BigDecimal(value_tBigQueryInput_1.toString());
									
								}else{
									row10.ID_MOYEN_LIVRAISON = null;
								}
								}
							
									column_index_tBigQueryInput_1 = 1;
								
								if(fieldsCount_tBigQueryInput_1 <= column_index_tBigQueryInput_1) {
									row10.CODE_MOYEN_LIVRAISON = null;
								} else {
								
								value_tBigQueryInput_1 = field_tBigQueryInput_1.get(column_index_tBigQueryInput_1).getValue();
								
								if(com.google.api.client.util.Data.isNull(value_tBigQueryInput_1)) value_tBigQueryInput_1 = null;

								if(value_tBigQueryInput_1 != null){

									
										row10.CODE_MOYEN_LIVRAISON = value_tBigQueryInput_1.toString();
									
								}else{
									row10.CODE_MOYEN_LIVRAISON = null;
								}
								}
							
									column_index_tBigQueryInput_1 = 2;
								
								if(fieldsCount_tBigQueryInput_1 <= column_index_tBigQueryInput_1) {
									row10.LIBELLE_MOYEN_LIVRAISON = null;
								} else {
								
								value_tBigQueryInput_1 = field_tBigQueryInput_1.get(column_index_tBigQueryInput_1).getValue();
								
								if(com.google.api.client.util.Data.isNull(value_tBigQueryInput_1)) value_tBigQueryInput_1 = null;

								if(value_tBigQueryInput_1 != null){

									
										row10.LIBELLE_MOYEN_LIVRAISON = value_tBigQueryInput_1.toString();
									
								}else{
									row10.LIBELLE_MOYEN_LIVRAISON = null;
								}
								}
							

 



/**
 * [tBigQueryInput_1 begin ] stop
 */
	
	/**
	 * [tBigQueryInput_1 main ] start
	 */

	

	
	
	currentComponent="tBigQueryInput_1";

	

 


	tos_count_tBigQueryInput_1++;

/**
 * [tBigQueryInput_1 main ] stop
 */
	
	/**
	 * [tBigQueryInput_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tBigQueryInput_1";

	

 



/**
 * [tBigQueryInput_1 process_data_begin ] stop
 */

	
	/**
	 * [tDBOutput_5 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_5";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row10"
						
						);
					}
					



        whetherReject_tDBOutput_5 = false;
                        pstmt_tDBOutput_5.setBigDecimal(1, row10.ID_MOYEN_LIVRAISON);

                        if(row10.CODE_MOYEN_LIVRAISON == null) {
pstmt_tDBOutput_5.setNull(2, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_5.setString(2, row10.CODE_MOYEN_LIVRAISON);
}

                        if(row10.LIBELLE_MOYEN_LIVRAISON == null) {
pstmt_tDBOutput_5.setNull(3, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_5.setString(3, row10.LIBELLE_MOYEN_LIVRAISON);
}

                pstmt_tDBOutput_5.addBatch();
                nb_line_tDBOutput_5++;
                batchSizeCounter_tDBOutput_5++;
            if(!whetherReject_tDBOutput_5) {
            }
            if (batchSize_tDBOutput_5 > 0 &&  batchSize_tDBOutput_5 <= batchSizeCounter_tDBOutput_5) {
                try {
                    pstmt_tDBOutput_5.executeBatch();
                }catch (java.sql.BatchUpdateException e_tDBOutput_5){
globalMap.put("tDBOutput_5_ERROR_MESSAGE",e_tDBOutput_5.getMessage());
			        java.sql.SQLException ne_tDBOutput_5 = e_tDBOutput_5.getNextException(),sqle_tDBOutput_5=null;
			    	String errormessage_tDBOutput_5;
					if (ne_tDBOutput_5 != null) {
						// build new exception to provide the original cause
						sqle_tDBOutput_5 = new java.sql.SQLException(e_tDBOutput_5.getMessage() + "\ncaused by: " + ne_tDBOutput_5.getMessage(), ne_tDBOutput_5.getSQLState(), ne_tDBOutput_5.getErrorCode(), ne_tDBOutput_5);
						errormessage_tDBOutput_5 = sqle_tDBOutput_5.getMessage();
					}else{
						errormessage_tDBOutput_5 = e_tDBOutput_5.getMessage();
					}
	            	
	                	System.err.println(errormessage_tDBOutput_5);
	            	
	        	}
                tmp_batchUpdateCount_tDBOutput_5 = pstmt_tDBOutput_5.getUpdateCount();
                    insertedCount_tDBOutput_5
                += (tmp_batchUpdateCount_tDBOutput_5!=-1?tmp_batchUpdateCount_tDBOutput_5:0);
                rowsToCommitCount_tDBOutput_5 += (tmp_batchUpdateCount_tDBOutput_5!=-1?tmp_batchUpdateCount_tDBOutput_5:0);
                batchSizeCounter_tDBOutput_5 = 0;
            }
                commitCounter_tDBOutput_5++;
                if(commitEvery_tDBOutput_5 <= commitCounter_tDBOutput_5) {
                    if(batchSizeCounter_tDBOutput_5 > 0) {
                        try {
                            pstmt_tDBOutput_5.executeBatch();
                        }catch (java.sql.BatchUpdateException e_tDBOutput_5){
globalMap.put("tDBOutput_5_ERROR_MESSAGE",e_tDBOutput_5.getMessage());
					        java.sql.SQLException ne_tDBOutput_5 = e_tDBOutput_5.getNextException(),sqle_tDBOutput_5=null;
					    	String errormessage_tDBOutput_5;
							if (ne_tDBOutput_5 != null) {
								// build new exception to provide the original cause
								sqle_tDBOutput_5 = new java.sql.SQLException(e_tDBOutput_5.getMessage() + "\ncaused by: " + ne_tDBOutput_5.getMessage(), ne_tDBOutput_5.getSQLState(), ne_tDBOutput_5.getErrorCode(), ne_tDBOutput_5);
								errormessage_tDBOutput_5 = sqle_tDBOutput_5.getMessage();
							}else{
								errormessage_tDBOutput_5 = e_tDBOutput_5.getMessage();
							}
			            	
			                	System.err.println(errormessage_tDBOutput_5);
			            	
			        	}
                        tmp_batchUpdateCount_tDBOutput_5 = pstmt_tDBOutput_5.getUpdateCount();
                            insertedCount_tDBOutput_5
                        += (tmp_batchUpdateCount_tDBOutput_5!=-1?tmp_batchUpdateCount_tDBOutput_5:0);
                        rowsToCommitCount_tDBOutput_5 += (tmp_batchUpdateCount_tDBOutput_5!=-1?tmp_batchUpdateCount_tDBOutput_5:0);
                    }
                    if(rowsToCommitCount_tDBOutput_5 != 0){
                    	
                    }
                    conn_tDBOutput_5.commit();
                    if(rowsToCommitCount_tDBOutput_5 != 0){
                    	
                    	rowsToCommitCount_tDBOutput_5 = 0;
                    }
                    commitCounter_tDBOutput_5=0;
                    	batchSizeCounter_tDBOutput_5=0;
                }

 


	tos_count_tDBOutput_5++;

/**
 * [tDBOutput_5 main ] stop
 */
	
	/**
	 * [tDBOutput_5 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_5";

	

 



/**
 * [tDBOutput_5 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_5 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_5";

	

 



/**
 * [tDBOutput_5 process_data_end ] stop
 */



	
	/**
	 * [tBigQueryInput_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tBigQueryInput_1";

	

 



/**
 * [tBigQueryInput_1 process_data_end ] stop
 */
	
	/**
	 * [tBigQueryInput_1 end ] start
	 */

	

	
	
	currentComponent="tBigQueryInput_1";

	
	
	
            }
            if (child_statistics_tBigQueryInput_1 != null) {
                globalMap.put("tBigQueryInput_1_STATISTICS_CHILD", child_statistics_tBigQueryInput_1.stream().collect(java.util.stream.Collectors.joining(",", "{\"statistics\": [", "]}")));
            }
        //}
}
        } catch (Exception e_tBigQueryInput_1) {
            String message_tBigQueryInput_1 = e_tBigQueryInput_1.getMessage();
                System.err.println(message_tBigQueryInput_1);
            globalMap.put("tBigQueryInput_1_ERROR_MESSAGE", message_tBigQueryInput_1);
            throw e_tBigQueryInput_1;
        } finally {
            serviceAccountBigQueryUtil_tBigQueryInput_1.cleanup();
        }

 

ok_Hash.put("tBigQueryInput_1", true);
end_Hash.put("tBigQueryInput_1", System.currentTimeMillis());

tStatCatcher_1.addMessage("end","tBigQueryInput_1", end_Hash.get("tBigQueryInput_1")-start_Hash.get("tBigQueryInput_1"));
tStatCatcher_1Process(globalMap);



/**
 * [tBigQueryInput_1 end ] stop
 */

	
	/**
	 * [tDBOutput_5 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_5";

	
	



	
        if(batchSizeCounter_tDBOutput_5 > 0) {
            try {
            	if (pstmt_tDBOutput_5 != null) {
					
					pstmt_tDBOutput_5.executeBatch();
					
        	    }
            }catch (java.sql.BatchUpdateException e_tDBOutput_5){
globalMap.put("tDBOutput_5_ERROR_MESSAGE",e_tDBOutput_5.getMessage());
		        java.sql.SQLException ne_tDBOutput_5 = e_tDBOutput_5.getNextException(),sqle_tDBOutput_5=null;
		    	String errormessage_tDBOutput_5;
				if (ne_tDBOutput_5 != null) {
					// build new exception to provide the original cause
					sqle_tDBOutput_5 = new java.sql.SQLException(e_tDBOutput_5.getMessage() + "\ncaused by: " + ne_tDBOutput_5.getMessage(), ne_tDBOutput_5.getSQLState(), ne_tDBOutput_5.getErrorCode(), ne_tDBOutput_5);
					errormessage_tDBOutput_5 = sqle_tDBOutput_5.getMessage();
				}else{
					errormessage_tDBOutput_5 = e_tDBOutput_5.getMessage();
				}
            	
                	System.err.println(errormessage_tDBOutput_5);
            	
        	}
        	if (pstmt_tDBOutput_5 != null) {
            	tmp_batchUpdateCount_tDBOutput_5 = pstmt_tDBOutput_5.getUpdateCount();
    	    	
    	    		insertedCount_tDBOutput_5
    	    	
    	    	+= (tmp_batchUpdateCount_tDBOutput_5!=-1?tmp_batchUpdateCount_tDBOutput_5:0);
				rowsToCommitCount_tDBOutput_5 += (tmp_batchUpdateCount_tDBOutput_5!=-1?tmp_batchUpdateCount_tDBOutput_5:0);
            }
        }
        if(pstmt_tDBOutput_5 != null) {
			
				pstmt_tDBOutput_5.close();
				resourceMap.remove("pstmt_tDBOutput_5");
			
        }
    resourceMap.put("statementClosed_tDBOutput_5", true);
		if(commitCounter_tDBOutput_5 > 0 && rowsToCommitCount_tDBOutput_5 != 0) {
			
		}
		conn_tDBOutput_5.commit();
		if(commitCounter_tDBOutput_5 > 0 && rowsToCommitCount_tDBOutput_5 != 0) {
			
			rowsToCommitCount_tDBOutput_5 = 0;
		}
		commitCounter_tDBOutput_5 = 0;
		
		
		conn_tDBOutput_5 .close();
		
		resourceMap.put("finish_tDBOutput_5", true);
   	

	
	nb_line_deleted_tDBOutput_5=nb_line_deleted_tDBOutput_5+ deletedCount_tDBOutput_5;
	nb_line_update_tDBOutput_5=nb_line_update_tDBOutput_5 + updatedCount_tDBOutput_5;
	nb_line_inserted_tDBOutput_5=nb_line_inserted_tDBOutput_5 + insertedCount_tDBOutput_5;
	nb_line_rejected_tDBOutput_5=nb_line_rejected_tDBOutput_5 + rejectedCount_tDBOutput_5;
	
        globalMap.put("tDBOutput_5_NB_LINE",nb_line_tDBOutput_5);
        globalMap.put("tDBOutput_5_NB_LINE_UPDATED",nb_line_update_tDBOutput_5);
        globalMap.put("tDBOutput_5_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_5);
        globalMap.put("tDBOutput_5_NB_LINE_DELETED",nb_line_deleted_tDBOutput_5);
        globalMap.put("tDBOutput_5_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_5);
    

	



				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row10");
			  	}
			  	
 

ok_Hash.put("tDBOutput_5", true);
end_Hash.put("tDBOutput_5", System.currentTimeMillis());

tStatCatcher_1.addMessage("end","tDBOutput_5", end_Hash.get("tDBOutput_5")-start_Hash.get("tDBOutput_5"));
tStatCatcher_1Process(globalMap);
				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk11", 0, "ok");
				}
				tBigQueryInput_3Process(globalMap);



/**
 * [tDBOutput_5 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tBigQueryInput_1 finally ] start
	 */

	

	
	
	currentComponent="tBigQueryInput_1";

	

 



/**
 * [tBigQueryInput_1 finally ] stop
 */

	
	/**
	 * [tDBOutput_5 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_5";

	



    try {
    if (resourceMap.get("statementClosed_tDBOutput_5") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_5 = null;
                if ((pstmtToClose_tDBOutput_5 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_5")) != null) {
                    pstmtToClose_tDBOutput_5.close();
                }
    }
    } finally {
        if(resourceMap.get("finish_tDBOutput_5") == null){
            java.sql.Connection ctn_tDBOutput_5 = null;
            if((ctn_tDBOutput_5 = (java.sql.Connection)resourceMap.get("conn_tDBOutput_5")) != null){
                try {
                    ctn_tDBOutput_5.close();
                } catch (java.sql.SQLException sqlEx_tDBOutput_5) {
                    String errorMessage_tDBOutput_5 = "failed to close the connection in tDBOutput_5 :" + sqlEx_tDBOutput_5.getMessage();
                    System.err.println(errorMessage_tDBOutput_5);
                }
            }
        }
    }
 



/**
 * [tDBOutput_5 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tBigQueryInput_1_SUBPROCESS_STATE", 1);
	}
	


public static class row11Struct implements routines.system.IPersistableRow<row11Struct> {
    final static byte[] commonByteArrayLock_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ = new byte[0];
    static byte[] commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public BigDecimal ID_LIVREUR;

				public BigDecimal getID_LIVREUR () {
					return this.ID_LIVREUR;
				}
				
			    public BigDecimal ID_MOYEN;

				public BigDecimal getID_MOYEN () {
					return this.ID_MOYEN;
				}
				
			    public String NOM_LIVREUR;

				public String getNOM_LIVREUR () {
					return this.NOM_LIVREUR;
				}
				
			    public String PRENOM_LIVREUR;

				public String getPRENOM_LIVREUR () {
					return this.PRENOM_LIVREUR;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
						result = prime * result + ((this.ID_LIVREUR == null) ? 0 : this.ID_LIVREUR.hashCode());
					
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row11Struct other = (row11Struct) obj;
		
						if (this.ID_LIVREUR == null) {
							if (other.ID_LIVREUR != null)
								return false;
						
						} else if (!this.ID_LIVREUR.equals(other.ID_LIVREUR))
						
							return false;
					

		return true;
    }

	public void copyDataTo(row11Struct other) {

		other.ID_LIVREUR = this.ID_LIVREUR;
	            other.ID_MOYEN = this.ID_MOYEN;
	            other.NOM_LIVREUR = this.NOM_LIVREUR;
	            other.PRENOM_LIVREUR = this.PRENOM_LIVREUR;
	            
	}

	public void copyKeysDataTo(row11Struct other) {

		other.ID_LIVREUR = this.ID_LIVREUR;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ.length == 0) {
   					commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ.length == 0) {
   					commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ) {

        	try {

        		int length = 0;
		
						this.ID_LIVREUR = (BigDecimal) dis.readObject();
					
						this.ID_MOYEN = (BigDecimal) dis.readObject();
					
					this.NOM_LIVREUR = readString(dis);
					
					this.PRENOM_LIVREUR = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_SI_OPE_A_ALIM_SI_OPE_FICHIER_BQ) {

        	try {

        		int length = 0;
		
						this.ID_LIVREUR = (BigDecimal) dis.readObject();
					
						this.ID_MOYEN = (BigDecimal) dis.readObject();
					
					this.NOM_LIVREUR = readString(dis);
					
					this.PRENOM_LIVREUR = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// BigDecimal
				
       			    	dos.writeObject(this.ID_LIVREUR);
					
					// BigDecimal
				
       			    	dos.writeObject(this.ID_MOYEN);
					
					// String
				
						writeString(this.NOM_LIVREUR,dos);
					
					// String
				
						writeString(this.PRENOM_LIVREUR,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// BigDecimal
				
       			    	dos.writeObject(this.ID_LIVREUR);
					
					// BigDecimal
				
       			    	dos.writeObject(this.ID_MOYEN);
					
					// String
				
						writeString(this.NOM_LIVREUR,dos);
					
					// String
				
						writeString(this.PRENOM_LIVREUR,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("ID_LIVREUR="+String.valueOf(ID_LIVREUR));
		sb.append(",ID_MOYEN="+String.valueOf(ID_MOYEN));
		sb.append(",NOM_LIVREUR="+NOM_LIVREUR);
		sb.append(",PRENOM_LIVREUR="+PRENOM_LIVREUR);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row11Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.ID_LIVREUR, other.ID_LIVREUR);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tBigQueryInput_3Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tBigQueryInput_3_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row11Struct row11 = new row11Struct();




	
	/**
	 * [tDBOutput_6 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_6", false);
		start_Hash.put("tDBOutput_6", System.currentTimeMillis());
		
				tStatCatcher_1.addMessage("begin","tDBOutput_6");
				tStatCatcher_1Process(globalMap);
			
	
	currentComponent="tDBOutput_6";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row11");
					}
				
		int tos_count_tDBOutput_6 = 0;
		






    
    int nb_line_tDBOutput_6 = 0;
    int nb_line_update_tDBOutput_6 = 0;
    int nb_line_inserted_tDBOutput_6 = 0;
    int nb_line_deleted_tDBOutput_6 = 0;
    int nb_line_rejected_tDBOutput_6 = 0;

    int tmp_batchUpdateCount_tDBOutput_6 = 0;

    int deletedCount_tDBOutput_6=0;
    int updatedCount_tDBOutput_6=0;
    int insertedCount_tDBOutput_6=0;
    int rowsToCommitCount_tDBOutput_6=0;
    int rejectedCount_tDBOutput_6=0;

    boolean whetherReject_tDBOutput_6 = false;

    java.sql.Connection conn_tDBOutput_6 = null;

    //optional table
    String dbschema_tDBOutput_6 = null;
    String tableName_tDBOutput_6 = null;
                    String driverClass_tDBOutput_6 = "oracle.jdbc.OracleDriver";


                java.lang.Class.forName(driverClass_tDBOutput_6);
                String url_tDBOutput_6 = null;
                    url_tDBOutput_6 = "jdbc:oracle:thin:@(description=(address=(protocol=tcp)(host=" + "" + ")(port=" + "1521" + "))(connect_data=(service_name=" + "XEPDB1" + ")))";
                String dbUser_tDBOutput_6 = "DSID_LIV_OPE";
 
	final String decryptedPassword_tDBOutput_6 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:kE70SwwmQ7B6GlojqfscptCWXaCuQ0OMMMo7MN78XlM=");

                String dbPwd_tDBOutput_6 = decryptedPassword_tDBOutput_6;
                dbschema_tDBOutput_6 = "DSID_LIV_OPE";


                    conn_tDBOutput_6 = java.sql.DriverManager.getConnection(url_tDBOutput_6, dbUser_tDBOutput_6, dbPwd_tDBOutput_6);
        resourceMap.put("conn_tDBOutput_6", conn_tDBOutput_6);
            conn_tDBOutput_6.setAutoCommit(false);
            int commitEvery_tDBOutput_6 = 10000;
            int commitCounter_tDBOutput_6 = 0;
        int batchSize_tDBOutput_6 = 10000;
        int batchSizeCounter_tDBOutput_6=0;
        int count_tDBOutput_6=0;

        if(dbschema_tDBOutput_6 == null || dbschema_tDBOutput_6.trim().length() == 0) {
            tableName_tDBOutput_6 = ("LIVREUR");
        } else {
            tableName_tDBOutput_6 = dbschema_tDBOutput_6 + "." + ("LIVREUR");
        }
            int rsTruncCountNumber_tDBOutput_6 = 0;
            try(java.sql.Statement stmtTruncCount_tDBOutput_6 = conn_tDBOutput_6.createStatement()) {
                try (java.sql.ResultSet rsTruncCount_tDBOutput_6 = stmtTruncCount_tDBOutput_6.executeQuery("SELECT COUNT(1) FROM " + tableName_tDBOutput_6 + "")) {
                    if(rsTruncCount_tDBOutput_6.next()) {
                        rsTruncCountNumber_tDBOutput_6 = rsTruncCount_tDBOutput_6.getInt(1);
                    }
                }
            }
            try (java.sql.Statement stmtTrunc_tDBOutput_6 = conn_tDBOutput_6.createStatement()) {
                stmtTrunc_tDBOutput_6.executeUpdate("TRUNCATE TABLE " + tableName_tDBOutput_6 + "");
                deletedCount_tDBOutput_6 += rsTruncCountNumber_tDBOutput_6;
            }
                String insert_tDBOutput_6 = "INSERT INTO " + tableName_tDBOutput_6 + " (ID_LIVREUR,ID_MOYEN,NOM_LIVREUR,PRENOM_LIVREUR) VALUES (?,?,?,?)";    

                        java.sql.PreparedStatement pstmt_tDBOutput_6 = conn_tDBOutput_6.prepareStatement(insert_tDBOutput_6);
                        resourceMap.put("pstmt_tDBOutput_6", pstmt_tDBOutput_6);





 



/**
 * [tDBOutput_6 begin ] stop
 */



	
	/**
	 * [tBigQueryInput_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tBigQueryInput_3", false);
		start_Hash.put("tBigQueryInput_3", System.currentTimeMillis());
		
				tStatCatcher_1.addMessage("begin","tBigQueryInput_3");
				tStatCatcher_1Process(globalMap);
			
	
	currentComponent="tBigQueryInput_3";

	
		int tos_count_tBigQueryInput_3 = 0;
		
	
	

		
class ServiceAccountBigQueryUtil_tBigQueryInput_3 {
	private com.google.cloud.bigquery.BigQuery bigQuery;
	private boolean useLargeResult;
	private String tempTable;

	public ServiceAccountBigQueryUtil_tBigQueryInput_3() {
		this.useLargeResult = false;
	}

	private com.google.cloud.bigquery.BigQuery buildBigQuery() throws java.io.IOException {
		if (bigQuery != null) {
			return bigQuery;
		}
		com.google.auth.oauth2.GoogleCredentials credentials;
		java.io.File credentialsFile = new java.io.File("C:/CC2/Groupe1/4_DATA_BIGQUERY/dsid-cc2-grp1-407520-99e8a6c61c07.json");
		try(java.io.FileInputStream credentialsStream = new java.io.FileInputStream(credentialsFile)) {
			credentials = com.google.auth.oauth2.ServiceAccountCredentials.fromStream(credentialsStream);
		}

		com.google.cloud.bigquery.BigQuery result = com.google.cloud.bigquery.BigQueryOptions.newBuilder()
			.setCredentials(credentials)
			.setProjectId("dsid-cc2-grp1-407520")
			.build()
			.getService();

		return result;
	}

	private com.google.cloud.bigquery.Job buildJob(com.google.cloud.bigquery.BigQuery bigquery, com.google.cloud.bigquery.QueryJobConfiguration queryConfiguration, com.google.cloud.bigquery.JobId jobId) throws InterruptedException {
        globalMap.put("tBigQueryInput_3_JOBID", jobId.getJob());
        com.google.cloud.bigquery.Job job = bigquery.create(com.google.cloud.bigquery.JobInfo.newBuilder(queryConfiguration).setJobId(jobId).build());

		
		job = job.waitFor();

		if (job == null) {
            String message = "tBigQueryInput_3 - Job no longer exists";
            globalMap.put("tBigQueryInput_3_ERROR_MESSAGE", message);
            throw new RuntimeException(message);
		} else if (job.getStatus().getError() != null) {
            com.google.gson.Gson gsonObject = new com.google.gson.Gson();
            globalMap.put("tBigQueryInput_3_STATISTICS", gsonObject.toJson(job.getStatistics()));
            String message = job.getStatus().getError().toString();
            globalMap.put("tBigQueryInput_3_ERROR_MESSAGE", message);
            throw new RuntimeException(message);
		}

		

		return job;
	}

	private com.google.cloud.bigquery.Job executeQuerySmallResult(String query, boolean useLegacySql) throws java.io.IOException, InterruptedException {
		bigQuery = buildBigQuery();
		com.google.cloud.bigquery.QueryJobConfiguration queryConfiguration = com.google.cloud.bigquery.QueryJobConfiguration.newBuilder(query)
			.setUseLegacySql(useLegacySql)
			.build();
		com.google.cloud.bigquery.JobId jobId = com.google.cloud.bigquery.JobId.of("dsid-cc2-grp1-407520", java.util.UUID.randomUUID().toString());
		return buildJob(bigQuery, queryConfiguration, jobId);
	}

	private com.google.cloud.bigquery.Job executeQueryLargeResult(String query, boolean useLegacySql) throws java.io.IOException, InterruptedException {
		bigQuery = buildBigQuery();

		
			com.google.cloud.bigquery.QueryJobConfiguration jobConfDryRun = com.google.cloud.bigquery.QueryJobConfiguration.newBuilder(query)
				.setUseLegacySql(useLegacySql)
				.setDryRun(true)
				.build();
			com.google.cloud.bigquery.Job jobDryRun = bigQuery.create(com.google.cloud.bigquery.JobInfo.of(jobConfDryRun));

			String queryLocation =jobDryRun.getJobId().getLocation();
			String location = queryLocation == null ? "US" : queryLocation;
			String tempDataset = java.util.UUID.randomUUID().toString().replaceAll("-", "")
			+ Integer.toHexString(java.util.concurrent.ThreadLocalRandom.current().nextInt())
			+ Integer.toHexString(java.util.concurrent.ThreadLocalRandom.current().nextInt());

			

			com.google.cloud.bigquery.DatasetInfo datasetInfo = com.google.cloud.bigquery.DatasetInfo.newBuilder(tempDataset).setLocation(location).build();
			com.google.cloud.bigquery.Dataset dataset = bigQuery.create(datasetInfo);
		
		tempTable = java.util.UUID.randomUUID().toString().replaceAll("-", "")
			+ Integer.toHexString(java.util.concurrent.ThreadLocalRandom.current().nextInt())
			+ Integer.toHexString(java.util.concurrent.ThreadLocalRandom.current().nextInt());
		
		com.google.cloud.bigquery.QueryJobConfiguration queryConfiguration = com.google.cloud.bigquery.QueryJobConfiguration.newBuilder(query)
			.setUseLegacySql(useLegacySql)
			.setDryRun(false)
			.setAllowLargeResults(true)
			.setDestinationTable(com.google.cloud.bigquery.TableId.of(tempDataset, tempTable))
			.build();

		com.google.cloud.bigquery.JobId jobId  = com.google.cloud.bigquery.JobId
			.newBuilder().setProject("dsid-cc2-grp1-407520")
			.setJob(java.util.UUID.randomUUID().toString())
			.build();

		
		return buildJob(bigQuery, queryConfiguration, jobId);
	}

	public com.google.cloud.bigquery.Job executeQuery(String query, boolean useLegacySql) throws Exception {

		com.google.cloud.bigquery.Job job;

		
			job = executeQuerySmallResult(query, useLegacySql);
		
		
		

		return job;
	}

    public java.util.List<com.google.cloud.bigquery.Job> getChildJobs(String jobId) throws java.io.IOException {
        return java.util.Optional.ofNullable(buildBigQuery().listJobs(com.google.cloud.bigquery.BigQuery.JobListOption.parentJobId(jobId)))
                    .map(com.google.api.gax.paging.Page::getValues)
                    .flatMap(iterable ->
                            java.util.Optional.ofNullable(java.util.stream.StreamSupport
                                .stream(iterable.spliterator(), false)
                                .collect(java.util.stream.Collectors.toList())))
                    .orElse(java.util.Collections.emptyList());
    }

	public void cleanup() throws Exception {
		if(useLargeResult) {
			
				com.google.cloud.bigquery.DatasetId datasetId = com.google.cloud.bigquery.DatasetId.of("dsid-cc2-grp1-407520", "temp_dataset");
				bigQuery.delete(datasetId, com.google.cloud.bigquery.BigQuery.DatasetDeleteOption.deleteContents());
			
		}
	}

}

		

		ServiceAccountBigQueryUtil_tBigQueryInput_3 serviceAccountBigQueryUtil_tBigQueryInput_3 = new ServiceAccountBigQueryUtil_tBigQueryInput_3();

        try {
                com.google.cloud.bigquery.Job job_tBigQueryInput_3 = serviceAccountBigQueryUtil_tBigQueryInput_3.executeQuery("SELECT id_livreur, id_moyen, nom_livreur, prenom_livreur FROM `dsid-cc2-grp1-407520.dsid_liv_ope_bq.livreur_moyen_livraison`", false);

                com.google.gson.Gson gsonObject_tBigQueryInput_3 = new com.google.gson.Gson();
                globalMap.put("tBigQueryInput_3_STATISTICS", gsonObject_tBigQueryInput_3.toJson(job_tBigQueryInput_3.getStatistics()));
                long nb_line_tBigQueryInput_3 = 0;
                java.util.List<String> child_statistics_tBigQueryInput_3 = null;
                java.util.List<com.google.cloud.bigquery.Job> childJobs_tBigQueryInput_3;
                if(job_tBigQueryInput_3.getStatistics().getNumChildJobs() != null){
                    childJobs_tBigQueryInput_3 = serviceAccountBigQueryUtil_tBigQueryInput_3.getChildJobs(job_tBigQueryInput_3.getJobId().getJob());
                    java.util.Collections.reverse(childJobs_tBigQueryInput_3);
                    child_statistics_tBigQueryInput_3 = new java.util.ArrayList<>();
                } else {
                    childJobs_tBigQueryInput_3 = java.util.Collections.singletonList(job_tBigQueryInput_3);
                }
                for (com.google.cloud.bigquery.Job job_iterable_tBigQueryInput_3 : childJobs_tBigQueryInput_3) {
                    if (child_statistics_tBigQueryInput_3 != null) {
                        child_statistics_tBigQueryInput_3.add(gsonObject_tBigQueryInput_3.toJson(job_iterable_tBigQueryInput_3.getStatistics()));
                    }
                    if (job_iterable_tBigQueryInput_3.getStatus().getError() != null) {
                        globalMap.put("tBigQueryInput_3_ERROR_MESSAGE", job_iterable_tBigQueryInput_3.getStatus().getError().toString());
                        String message_tBigQueryInput_3 = "tBigQueryInput_3 - " + job_iterable_tBigQueryInput_3.getStatus().getError().toString();
                System.err.println(message_tBigQueryInput_3);
                        continue;
                    }

                    com.google.cloud.bigquery.TableResult result_tBigQueryInput_3 = job_iterable_tBigQueryInput_3.getQueryResults();
		//Dynamic start

		
		//Dynamic end
	
		for (com.google.cloud.bigquery.FieldValueList field_tBigQueryInput_3 : result_tBigQueryInput_3.iterateAll()) {
			Object value_tBigQueryInput_3;
			nb_line_tBigQueryInput_3 ++;
	
		int fieldsCount_tBigQueryInput_3 = field_tBigQueryInput_3.size();
		int column_index_tBigQueryInput_3 =0;
		
									column_index_tBigQueryInput_3 = 0;
								
								if(fieldsCount_tBigQueryInput_3 <= column_index_tBigQueryInput_3) {
									row11.ID_LIVREUR = null;
								} else {
								
								value_tBigQueryInput_3 = field_tBigQueryInput_3.get(column_index_tBigQueryInput_3).getValue();
								
								if(com.google.api.client.util.Data.isNull(value_tBigQueryInput_3)) value_tBigQueryInput_3 = null;

								if(value_tBigQueryInput_3 != null){

									
										row11.ID_LIVREUR = ParserUtils.parseTo_BigDecimal(value_tBigQueryInput_3.toString());
									
								}else{
									row11.ID_LIVREUR = null;
								}
								}
							
									column_index_tBigQueryInput_3 = 1;
								
								if(fieldsCount_tBigQueryInput_3 <= column_index_tBigQueryInput_3) {
									row11.ID_MOYEN = null;
								} else {
								
								value_tBigQueryInput_3 = field_tBigQueryInput_3.get(column_index_tBigQueryInput_3).getValue();
								
								if(com.google.api.client.util.Data.isNull(value_tBigQueryInput_3)) value_tBigQueryInput_3 = null;

								if(value_tBigQueryInput_3 != null){

									
										row11.ID_MOYEN = ParserUtils.parseTo_BigDecimal(value_tBigQueryInput_3.toString());
									
								}else{
									row11.ID_MOYEN = null;
								}
								}
							
									column_index_tBigQueryInput_3 = 2;
								
								if(fieldsCount_tBigQueryInput_3 <= column_index_tBigQueryInput_3) {
									row11.NOM_LIVREUR = null;
								} else {
								
								value_tBigQueryInput_3 = field_tBigQueryInput_3.get(column_index_tBigQueryInput_3).getValue();
								
								if(com.google.api.client.util.Data.isNull(value_tBigQueryInput_3)) value_tBigQueryInput_3 = null;

								if(value_tBigQueryInput_3 != null){

									
										row11.NOM_LIVREUR = value_tBigQueryInput_3.toString();
									
								}else{
									row11.NOM_LIVREUR = null;
								}
								}
							
									column_index_tBigQueryInput_3 = 3;
								
								if(fieldsCount_tBigQueryInput_3 <= column_index_tBigQueryInput_3) {
									row11.PRENOM_LIVREUR = null;
								} else {
								
								value_tBigQueryInput_3 = field_tBigQueryInput_3.get(column_index_tBigQueryInput_3).getValue();
								
								if(com.google.api.client.util.Data.isNull(value_tBigQueryInput_3)) value_tBigQueryInput_3 = null;

								if(value_tBigQueryInput_3 != null){

									
										row11.PRENOM_LIVREUR = value_tBigQueryInput_3.toString();
									
								}else{
									row11.PRENOM_LIVREUR = null;
								}
								}
							

 



/**
 * [tBigQueryInput_3 begin ] stop
 */
	
	/**
	 * [tBigQueryInput_3 main ] start
	 */

	

	
	
	currentComponent="tBigQueryInput_3";

	

 


	tos_count_tBigQueryInput_3++;

/**
 * [tBigQueryInput_3 main ] stop
 */
	
	/**
	 * [tBigQueryInput_3 process_data_begin ] start
	 */

	

	
	
	currentComponent="tBigQueryInput_3";

	

 



/**
 * [tBigQueryInput_3 process_data_begin ] stop
 */

	
	/**
	 * [tDBOutput_6 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_6";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row11"
						
						);
					}
					



        whetherReject_tDBOutput_6 = false;
                        pstmt_tDBOutput_6.setBigDecimal(1, row11.ID_LIVREUR);

                        pstmt_tDBOutput_6.setBigDecimal(2, row11.ID_MOYEN);

                        if(row11.NOM_LIVREUR == null) {
pstmt_tDBOutput_6.setNull(3, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_6.setString(3, row11.NOM_LIVREUR);
}

                        if(row11.PRENOM_LIVREUR == null) {
pstmt_tDBOutput_6.setNull(4, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_6.setString(4, row11.PRENOM_LIVREUR);
}

                pstmt_tDBOutput_6.addBatch();
                nb_line_tDBOutput_6++;
                batchSizeCounter_tDBOutput_6++;
            if (batchSize_tDBOutput_6 > 0 &&  batchSize_tDBOutput_6 <= batchSizeCounter_tDBOutput_6) {
                try {
                    pstmt_tDBOutput_6.executeBatch();
                }catch (java.sql.BatchUpdateException e_tDBOutput_6){
globalMap.put("tDBOutput_6_ERROR_MESSAGE",e_tDBOutput_6.getMessage());
			        java.sql.SQLException ne_tDBOutput_6 = e_tDBOutput_6.getNextException(),sqle_tDBOutput_6=null;
			    	String errormessage_tDBOutput_6;
					if (ne_tDBOutput_6 != null) {
						// build new exception to provide the original cause
						sqle_tDBOutput_6 = new java.sql.SQLException(e_tDBOutput_6.getMessage() + "\ncaused by: " + ne_tDBOutput_6.getMessage(), ne_tDBOutput_6.getSQLState(), ne_tDBOutput_6.getErrorCode(), ne_tDBOutput_6);
						errormessage_tDBOutput_6 = sqle_tDBOutput_6.getMessage();
					}else{
						errormessage_tDBOutput_6 = e_tDBOutput_6.getMessage();
					}
	            	
	                	System.err.println(errormessage_tDBOutput_6);
	            	
	        	}
                tmp_batchUpdateCount_tDBOutput_6 = pstmt_tDBOutput_6.getUpdateCount();
                    insertedCount_tDBOutput_6
                += (tmp_batchUpdateCount_tDBOutput_6!=-1?tmp_batchUpdateCount_tDBOutput_6:0);
                rowsToCommitCount_tDBOutput_6 += (tmp_batchUpdateCount_tDBOutput_6!=-1?tmp_batchUpdateCount_tDBOutput_6:0);
                batchSizeCounter_tDBOutput_6 = 0;
            }
                commitCounter_tDBOutput_6++;
                if(commitEvery_tDBOutput_6 <= commitCounter_tDBOutput_6) {
                    if(batchSizeCounter_tDBOutput_6 > 0) {
                        try {
                            pstmt_tDBOutput_6.executeBatch();
                        }catch (java.sql.BatchUpdateException e_tDBOutput_6){
globalMap.put("tDBOutput_6_ERROR_MESSAGE",e_tDBOutput_6.getMessage());
					        java.sql.SQLException ne_tDBOutput_6 = e_tDBOutput_6.getNextException(),sqle_tDBOutput_6=null;
					    	String errormessage_tDBOutput_6;
							if (ne_tDBOutput_6 != null) {
								// build new exception to provide the original cause
								sqle_tDBOutput_6 = new java.sql.SQLException(e_tDBOutput_6.getMessage() + "\ncaused by: " + ne_tDBOutput_6.getMessage(), ne_tDBOutput_6.getSQLState(), ne_tDBOutput_6.getErrorCode(), ne_tDBOutput_6);
								errormessage_tDBOutput_6 = sqle_tDBOutput_6.getMessage();
							}else{
								errormessage_tDBOutput_6 = e_tDBOutput_6.getMessage();
							}
			            	
			                	System.err.println(errormessage_tDBOutput_6);
			            	
			        	}
                        tmp_batchUpdateCount_tDBOutput_6 = pstmt_tDBOutput_6.getUpdateCount();
                            insertedCount_tDBOutput_6
                        += (tmp_batchUpdateCount_tDBOutput_6!=-1?tmp_batchUpdateCount_tDBOutput_6:0);
                        rowsToCommitCount_tDBOutput_6 += (tmp_batchUpdateCount_tDBOutput_6!=-1?tmp_batchUpdateCount_tDBOutput_6:0);
                    }
                    if(rowsToCommitCount_tDBOutput_6 != 0){
                    	
                    }
                    conn_tDBOutput_6.commit();
                    if(rowsToCommitCount_tDBOutput_6 != 0){
                    	
                    	rowsToCommitCount_tDBOutput_6 = 0;
                    }
                    commitCounter_tDBOutput_6=0;
                    	batchSizeCounter_tDBOutput_6=0;
                }

 


	tos_count_tDBOutput_6++;

/**
 * [tDBOutput_6 main ] stop
 */
	
	/**
	 * [tDBOutput_6 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_6";

	

 



/**
 * [tDBOutput_6 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_6 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_6";

	

 



/**
 * [tDBOutput_6 process_data_end ] stop
 */



	
	/**
	 * [tBigQueryInput_3 process_data_end ] start
	 */

	

	
	
	currentComponent="tBigQueryInput_3";

	

 



/**
 * [tBigQueryInput_3 process_data_end ] stop
 */
	
	/**
	 * [tBigQueryInput_3 end ] start
	 */

	

	
	
	currentComponent="tBigQueryInput_3";

	
	
	
            }
            if (child_statistics_tBigQueryInput_3 != null) {
                globalMap.put("tBigQueryInput_3_STATISTICS_CHILD", child_statistics_tBigQueryInput_3.stream().collect(java.util.stream.Collectors.joining(",", "{\"statistics\": [", "]}")));
            }
        //}
}
        } catch (Exception e_tBigQueryInput_3) {
            String message_tBigQueryInput_3 = e_tBigQueryInput_3.getMessage();
                System.err.println(message_tBigQueryInput_3);
            globalMap.put("tBigQueryInput_3_ERROR_MESSAGE", message_tBigQueryInput_3);
            throw e_tBigQueryInput_3;
        } finally {
            serviceAccountBigQueryUtil_tBigQueryInput_3.cleanup();
        }

 

ok_Hash.put("tBigQueryInput_3", true);
end_Hash.put("tBigQueryInput_3", System.currentTimeMillis());

tStatCatcher_1.addMessage("end","tBigQueryInput_3", end_Hash.get("tBigQueryInput_3")-start_Hash.get("tBigQueryInput_3"));
tStatCatcher_1Process(globalMap);



/**
 * [tBigQueryInput_3 end ] stop
 */

	
	/**
	 * [tDBOutput_6 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_6";

	
	



	
        if(batchSizeCounter_tDBOutput_6 > 0) {
            try {
            	if (pstmt_tDBOutput_6 != null) {
					
					pstmt_tDBOutput_6.executeBatch();
					
        	    }
            }catch (java.sql.BatchUpdateException e_tDBOutput_6){
globalMap.put("tDBOutput_6_ERROR_MESSAGE",e_tDBOutput_6.getMessage());
		        java.sql.SQLException ne_tDBOutput_6 = e_tDBOutput_6.getNextException(),sqle_tDBOutput_6=null;
		    	String errormessage_tDBOutput_6;
				if (ne_tDBOutput_6 != null) {
					// build new exception to provide the original cause
					sqle_tDBOutput_6 = new java.sql.SQLException(e_tDBOutput_6.getMessage() + "\ncaused by: " + ne_tDBOutput_6.getMessage(), ne_tDBOutput_6.getSQLState(), ne_tDBOutput_6.getErrorCode(), ne_tDBOutput_6);
					errormessage_tDBOutput_6 = sqle_tDBOutput_6.getMessage();
				}else{
					errormessage_tDBOutput_6 = e_tDBOutput_6.getMessage();
				}
            	
                	System.err.println(errormessage_tDBOutput_6);
            	
        	}
        	if (pstmt_tDBOutput_6 != null) {
            	tmp_batchUpdateCount_tDBOutput_6 = pstmt_tDBOutput_6.getUpdateCount();
    	    	
    	    		insertedCount_tDBOutput_6
    	    	
    	    	+= (tmp_batchUpdateCount_tDBOutput_6!=-1?tmp_batchUpdateCount_tDBOutput_6:0);
				rowsToCommitCount_tDBOutput_6 += (tmp_batchUpdateCount_tDBOutput_6!=-1?tmp_batchUpdateCount_tDBOutput_6:0);
            }
        }
        if(pstmt_tDBOutput_6 != null) {
			
				pstmt_tDBOutput_6.close();
				resourceMap.remove("pstmt_tDBOutput_6");
			
        }
    resourceMap.put("statementClosed_tDBOutput_6", true);
		if(commitCounter_tDBOutput_6 > 0 && rowsToCommitCount_tDBOutput_6 != 0) {
			
		}
		conn_tDBOutput_6.commit();
		if(commitCounter_tDBOutput_6 > 0 && rowsToCommitCount_tDBOutput_6 != 0) {
			
			rowsToCommitCount_tDBOutput_6 = 0;
		}
		commitCounter_tDBOutput_6 = 0;
		
		
		conn_tDBOutput_6 .close();
		
		resourceMap.put("finish_tDBOutput_6", true);
   	

	
	nb_line_deleted_tDBOutput_6=nb_line_deleted_tDBOutput_6+ deletedCount_tDBOutput_6;
	nb_line_update_tDBOutput_6=nb_line_update_tDBOutput_6 + updatedCount_tDBOutput_6;
	nb_line_inserted_tDBOutput_6=nb_line_inserted_tDBOutput_6 + insertedCount_tDBOutput_6;
	nb_line_rejected_tDBOutput_6=nb_line_rejected_tDBOutput_6 + rejectedCount_tDBOutput_6;
	
        globalMap.put("tDBOutput_6_NB_LINE",nb_line_tDBOutput_6);
        globalMap.put("tDBOutput_6_NB_LINE_UPDATED",nb_line_update_tDBOutput_6);
        globalMap.put("tDBOutput_6_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_6);
        globalMap.put("tDBOutput_6_NB_LINE_DELETED",nb_line_deleted_tDBOutput_6);
        globalMap.put("tDBOutput_6_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_6);
    

	



				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row11");
			  	}
			  	
 

ok_Hash.put("tDBOutput_6", true);
end_Hash.put("tDBOutput_6", System.currentTimeMillis());

tStatCatcher_1.addMessage("end","tDBOutput_6", end_Hash.get("tDBOutput_6")-start_Hash.get("tDBOutput_6"));
tStatCatcher_1Process(globalMap);



/**
 * [tDBOutput_6 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tBigQueryInput_3 finally ] start
	 */

	

	
	
	currentComponent="tBigQueryInput_3";

	

 



/**
 * [tBigQueryInput_3 finally ] stop
 */

	
	/**
	 * [tDBOutput_6 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_6";

	



    try {
    if (resourceMap.get("statementClosed_tDBOutput_6") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_6 = null;
                if ((pstmtToClose_tDBOutput_6 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_6")) != null) {
                    pstmtToClose_tDBOutput_6.close();
                }
    }
    } finally {
        if(resourceMap.get("finish_tDBOutput_6") == null){
            java.sql.Connection ctn_tDBOutput_6 = null;
            if((ctn_tDBOutput_6 = (java.sql.Connection)resourceMap.get("conn_tDBOutput_6")) != null){
                try {
                    ctn_tDBOutput_6.close();
                } catch (java.sql.SQLException sqlEx_tDBOutput_6) {
                    String errorMessage_tDBOutput_6 = "failed to close the connection in tDBOutput_6 :" + sqlEx_tDBOutput_6.getMessage();
                    System.err.println(errorMessage_tDBOutput_6);
                }
            }
        }
    }
 



/**
 * [tDBOutput_6 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tBigQueryInput_3_SUBPROCESS_STATE", 1);
	}
	
    public String resuming_logs_dir_path = null;
    public String resuming_checkpoint_path = null;
    public String parent_part_launcher = null;
    private String resumeEntryMethodName = null;
    private boolean globalResumeTicket = false;

    public boolean watch = false;
    // portStats is null, it means don't execute the statistics
    public Integer portStats = null;
    public int portTraces = 4334;
    public String clientHost;
    public String defaultClientHost = "localhost";
    public String contextStr = "Default";
    public boolean isDefaultContext = true;
    public String pid = "0";
    public String rootPid = null;
    public String fatherPid = null;
    public String fatherNode = null;
    public long startTime = 0;
    public boolean isChildJob = false;
    public String log4jLevel = "";
    
    private boolean enableLogStash;

    private boolean execStat = true;

    private ThreadLocal<java.util.Map<String, String>> threadLocal = new ThreadLocal<java.util.Map<String, String>>() {
        protected java.util.Map<String, String> initialValue() {
            java.util.Map<String,String> threadRunResultMap = new java.util.HashMap<String, String>();
            threadRunResultMap.put("errorCode", null);
            threadRunResultMap.put("status", "");
            return threadRunResultMap;
        };
    };


    protected PropertiesWithType context_param = new PropertiesWithType();
    public java.util.Map<String, Object> parentContextMap = new java.util.HashMap<String, Object>();

    public String status= "";
    

    public static void main(String[] args){
        final A_ALIM_SI_OPE_FICHIER_BQ A_ALIM_SI_OPE_FICHIER_BQClass = new A_ALIM_SI_OPE_FICHIER_BQ();

        int exitCode = A_ALIM_SI_OPE_FICHIER_BQClass.runJobInTOS(args);

        System.exit(exitCode);
    }


    public String[][] runJob(String[] args) {

        int exitCode = runJobInTOS(args);
        String[][] bufferValue = new String[][] { { Integer.toString(exitCode) } };

        return bufferValue;
    }

    public boolean hastBufferOutputComponent() {
		boolean hastBufferOutput = false;
    	
        return hastBufferOutput;
    }

    public int runJobInTOS(String[] args) {
	   	// reset status
	   	status = "";
	   	
        String lastStr = "";
        for (String arg : args) {
            if (arg.equalsIgnoreCase("--context_param")) {
                lastStr = arg;
            } else if (lastStr.equals("")) {
                evalParam(arg);
            } else {
                evalParam(lastStr + " " + arg);
                lastStr = "";
            }
        }
        enableLogStash = "true".equalsIgnoreCase(System.getProperty("audit.enabled"));

    	
    	

        if(clientHost == null) {
            clientHost = defaultClientHost;
        }

        if(pid == null || "0".equals(pid)) {
            pid = TalendString.getAsciiRandomString(6);
        }

        if (rootPid==null) {
            rootPid = pid;
        }
        if (fatherPid==null) {
            fatherPid = pid;
        }else{
            isChildJob = true;
        }

        if (portStats != null) {
            // portStats = -1; //for testing
            if (portStats < 0 || portStats > 65535) {
                // issue:10869, the portStats is invalid, so this client socket can't open
                System.err.println("The statistics socket port " + portStats + " is invalid.");
                execStat = false;
            }
        } else {
            execStat = false;
        }
        boolean inOSGi = routines.system.BundleUtils.inOSGi();

        if (inOSGi) {
            java.util.Dictionary<String, Object> jobProperties = routines.system.BundleUtils.getJobProperties(jobName);

            if (jobProperties != null && jobProperties.get("context") != null) {
                contextStr = (String)jobProperties.get("context");
            }
        }

        try {
            //call job/subjob with an existing context, like: --context=production. if without this parameter, there will use the default context instead.
            java.io.InputStream inContext = A_ALIM_SI_OPE_FICHIER_BQ.class.getClassLoader().getResourceAsStream("alimentation_si_ope/a_alim_si_ope_fichier_bq_0_1/contexts/" + contextStr + ".properties");
            if (inContext == null) {
                inContext = A_ALIM_SI_OPE_FICHIER_BQ.class.getClassLoader().getResourceAsStream("config/contexts/" + contextStr + ".properties");
            }
            if (inContext != null) {
                try {
                    //defaultProps is in order to keep the original context value
                    if(context != null && context.isEmpty()) {
	                defaultProps.load(inContext);
	                context = new ContextProperties(defaultProps);
                    }
                } finally {
                    inContext.close();
                }
            } else if (!isDefaultContext) {
                //print info and job continue to run, for case: context_param is not empty.
                System.err.println("Could not find the context " + contextStr);
            }

            if(!context_param.isEmpty()) {
                context.putAll(context_param);
				//set types for params from parentJobs
				for (Object key: context_param.keySet()){
					String context_key = key.toString();
					String context_type = context_param.getContextType(context_key);
					context.setContextType(context_key, context_type);

				}
            }
            class ContextProcessing {
                private void processContext_0() {
                } 
                public void processAllContext() {
                        processContext_0();
                }
            }

            new ContextProcessing().processAllContext();
        } catch (java.io.IOException ie) {
            System.err.println("Could not load context "+contextStr);
            ie.printStackTrace();
        }

        // get context value from parent directly
        if (parentContextMap != null && !parentContextMap.isEmpty()) {
        }

        //Resume: init the resumeUtil
        resumeEntryMethodName = ResumeUtil.getResumeEntryMethodName(resuming_checkpoint_path);
        resumeUtil = new ResumeUtil(resuming_logs_dir_path, isChildJob, rootPid);
        resumeUtil.initCommonInfo(pid, rootPid, fatherPid, projectName, jobName, contextStr, jobVersion);

		List<String> parametersToEncrypt = new java.util.ArrayList<String>();
        //Resume: jobStart
        resumeUtil.addLog("JOB_STARTED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","","","",resumeUtil.convertToJsonText(context,parametersToEncrypt));

if(execStat) {
    try {
        runStat.openSocket(!isChildJob);
        runStat.setAllPID(rootPid, fatherPid, pid, jobName);
        runStat.startThreadStat(clientHost, portStats);
        runStat.updateStatOnJob(RunStat.JOBSTART, fatherNode);
    } catch (java.io.IOException ioException) {
        ioException.printStackTrace();
    }
}



	
	    java.util.concurrent.ConcurrentHashMap<Object, Object> concurrentHashMap = new java.util.concurrent.ConcurrentHashMap<Object, Object>();
	    globalMap.put("concurrentHashMap", concurrentHashMap);
	

    long startUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
    long endUsedMemory = 0;
    long end = 0;

    startTime = System.currentTimeMillis();
        tStatCatcher_1.addMessage("begin");


this.globalResumeTicket = true;//to run tPreJob




        try {
            tStatCatcher_1Process(globalMap);
        } catch (java.lang.Exception e) {
            e.printStackTrace();
        }

this.globalResumeTicket = false;//to run others jobs

try {
errorCode = null;tDBRow_8Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tDBRow_8) {
globalMap.put("tDBRow_8_SUBPROCESS_STATE", -1);

e_tDBRow_8.printStackTrace();

}
try {
errorCode = null;tDBRow_3Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tDBRow_3) {
globalMap.put("tDBRow_3_SUBPROCESS_STATE", -1);

e_tDBRow_3.printStackTrace();

}

this.globalResumeTicket = true;//to run tPostJob




        end = System.currentTimeMillis();

        if (watch) {
            System.out.println((end-startTime)+" milliseconds");
        }

        endUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        if (false) {
            System.out.println((endUsedMemory - startUsedMemory) + " bytes memory increase when running : A_ALIM_SI_OPE_FICHIER_BQ");
        }
        tStatCatcher_1.addMessage(status==""?"end":status, (end-startTime));
        try {
            tStatCatcher_1Process(globalMap);
        } catch (java.lang.Exception e) {
            e.printStackTrace();
        }



if (execStat) {
    runStat.updateStatOnJob(RunStat.JOBEND, fatherNode);
    runStat.stopThreadStat();
}
    int returnCode = 0;


    if(errorCode == null) {
         returnCode = status != null && status.equals("failure") ? 1 : 0;
    } else {
         returnCode = errorCode.intValue();
    }
    resumeUtil.addLog("JOB_ENDED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","" + returnCode,"","","");

    return returnCode;

  }

    // only for OSGi env
    public void destroy() {


    }














    private java.util.Map<String, Object> getSharedConnections4REST() {
        java.util.Map<String, Object> connections = new java.util.HashMap<String, Object>();






        return connections;
    }

    private void evalParam(String arg) {
        if (arg.startsWith("--resuming_logs_dir_path")) {
            resuming_logs_dir_path = arg.substring(25);
        } else if (arg.startsWith("--resuming_checkpoint_path")) {
            resuming_checkpoint_path = arg.substring(27);
        } else if (arg.startsWith("--parent_part_launcher")) {
            parent_part_launcher = arg.substring(23);
        } else if (arg.startsWith("--watch")) {
            watch = true;
        } else if (arg.startsWith("--stat_port=")) {
            String portStatsStr = arg.substring(12);
            if (portStatsStr != null && !portStatsStr.equals("null")) {
                portStats = Integer.parseInt(portStatsStr);
            }
        } else if (arg.startsWith("--trace_port=")) {
            portTraces = Integer.parseInt(arg.substring(13));
        } else if (arg.startsWith("--client_host=")) {
            clientHost = arg.substring(14);
        } else if (arg.startsWith("--context=")) {
            contextStr = arg.substring(10);
            isDefaultContext = false;
        } else if (arg.startsWith("--father_pid=")) {
            fatherPid = arg.substring(13);
        } else if (arg.startsWith("--root_pid=")) {
            rootPid = arg.substring(11);
        } else if (arg.startsWith("--father_node=")) {
            fatherNode = arg.substring(14);
        } else if (arg.startsWith("--pid=")) {
            pid = arg.substring(6);
        } else if (arg.startsWith("--context_type")) {
            String keyValue = arg.substring(15);
			int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.setContextType(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.setContextType(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }

            }

		} else if (arg.startsWith("--context_param")) {
            String keyValue = arg.substring(16);
            int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.put(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.put(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }
            }
        } else if (arg.startsWith("--log4jLevel=")) {
            log4jLevel = arg.substring(13);
		} else if (arg.startsWith("--audit.enabled") && arg.contains("=")) {//for trunjob call
		    final int equal = arg.indexOf('=');
			final String key = arg.substring("--".length(), equal);
			System.setProperty(key, arg.substring(equal + 1));
		}
    }
    
    private static final String NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY = "<TALEND_NULL>";

    private final String[][] escapeChars = {
        {"\\\\","\\"},{"\\n","\n"},{"\\'","\'"},{"\\r","\r"},
        {"\\f","\f"},{"\\b","\b"},{"\\t","\t"}
        };
    private String replaceEscapeChars (String keyValue) {

		if (keyValue == null || ("").equals(keyValue.trim())) {
			return keyValue;
		}

		StringBuilder result = new StringBuilder();
		int currIndex = 0;
		while (currIndex < keyValue.length()) {
			int index = -1;
			// judege if the left string includes escape chars
			for (String[] strArray : escapeChars) {
				index = keyValue.indexOf(strArray[0],currIndex);
				if (index>=0) {

					result.append(keyValue.substring(currIndex, index + strArray[0].length()).replace(strArray[0], strArray[1]));
					currIndex = index + strArray[0].length();
					break;
				}
			}
			// if the left string doesn't include escape chars, append the left into the result
			if (index < 0) {
				result.append(keyValue.substring(currIndex));
				currIndex = currIndex + keyValue.length();
			}
		}

		return result.toString();
    }

    public Integer getErrorCode() {
        return errorCode;
    }


    public String getStatus() {
        return status;
    }

    ResumeUtil resumeUtil = null;
}
/************************************************************************************************
 *     416227 characters generated by Talend Open Studio for Data Integration 
 *     on the 16 janvier 2024 à 01:12:39 CET
 ************************************************************************************************/