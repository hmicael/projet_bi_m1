// ============================================================================
//
// Copyright (c) 2006-2015, Talend SA
//
// Ce code source a été automatiquement généré par_Talend Open Studio for Data Integration
// / Soumis à la Licence Apache, Version 2.0 (la "Licence") ;
// votre utilisation de ce fichier doit respecter les termes de la Licence.
// Vous pouvez obtenir une copie de la Licence sur
// http://www.apache.org/licenses/LICENSE-2.0
// 
// Sauf lorsqu'explicitement prévu par la loi en vigueur ou accepté par écrit, le logiciel
// distribué sous la Licence est distribué "TEL QUEL",
// SANS GARANTIE OU CONDITION D'AUCUNE SORTE, expresse ou implicite.
// Consultez la Licence pour connaître la terminologie spécifique régissant les autorisations et
// les limites prévues par la Licence.


package alimentation_dm1.c_alim_ods_rejet_0_1;

import routines.Numeric;
import routines.DataOperation;
import routines.TalendDataGenerator;
import routines.TalendStringUtil;
import routines.TalendString;
import routines.StringHandling;
import routines.Relational;
import routines.TalendDate;
import routines.Mathematical;
import routines.system.*;
import routines.system.api.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.math.BigDecimal;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.util.Comparator;
 





@SuppressWarnings("unused")

/**
 * Job: C_ALIM_ODS_REJET Purpose: Job pour alimenter rejet et ods<br>
 * Description: Job pour alimenter rejet et ods <br>
 * @author user@talend.com
 * @version 8.0.1.20211109_1610
 * @status 
 */
public class C_ALIM_ODS_REJET implements TalendJob {

protected static void logIgnoredError(String message, Throwable cause) {
       System.err.println(message);
       if (cause != null) {
               cause.printStackTrace();
       }

}


	public final Object obj = new Object();

	// for transmiting parameters purpose
	private Object valueObject = null;

	public Object getValueObject() {
		return this.valueObject;
	}

	public void setValueObject(Object valueObject) {
		this.valueObject = valueObject;
	}
	
	private final static String defaultCharset = java.nio.charset.Charset.defaultCharset().name();

	
	private final static String utf8Charset = "UTF-8";
	//contains type for every context property
	public class PropertiesWithType extends java.util.Properties {
		private static final long serialVersionUID = 1L;
		private java.util.Map<String,String> propertyTypes = new java.util.HashMap<>();
		
		public PropertiesWithType(java.util.Properties properties){
			super(properties);
		}
		public PropertiesWithType(){
			super();
		}
		
		public void setContextType(String key, String type) {
			propertyTypes.put(key,type);
		}
	
		public String getContextType(String key) {
			return propertyTypes.get(key);
		}
	}
	
	// create and load default properties
	private java.util.Properties defaultProps = new java.util.Properties();
	// create application properties with default
	public class ContextProperties extends PropertiesWithType {

		private static final long serialVersionUID = 1L;

		public ContextProperties(java.util.Properties properties){
			super(properties);
		}
		public ContextProperties(){
			super();
		}

		public void synchronizeContext(){
			
		}
		
		//if the stored or passed value is "<TALEND_NULL>" string, it mean null
		public String getStringValue(String key) {
			String origin_value = this.getProperty(key);
			if(NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY.equals(origin_value)) {
				return null;
			}
			return origin_value;
		}

	}
	protected ContextProperties context = new ContextProperties(); // will be instanciated by MS.
	public ContextProperties getContext() {
		return this.context;
	}
	private final String jobVersion = "0.1";
	private final String jobName = "C_ALIM_ODS_REJET";
	private final String projectName = "ALIMENTATION_DM1";
	public Integer errorCode = null;
	private String currentComponent = "";
	
		private final java.util.Map<String, Object> globalMap = new java.util.HashMap<String, Object>();
        private final static java.util.Map<String, Object> junitGlobalMap = new java.util.HashMap<String, Object>();
	
		private final java.util.Map<String, Long> start_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Long> end_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Boolean> ok_Hash = new java.util.HashMap<String, Boolean>();
		public  final java.util.List<String[]> globalBuffer = new java.util.ArrayList<String[]>();
	

private RunStat runStat = new RunStat();

	// OSGi DataSource
	private final static String KEY_DB_DATASOURCES = "KEY_DB_DATASOURCES";
	
	private final static String KEY_DB_DATASOURCES_RAW = "KEY_DB_DATASOURCES_RAW";

	public void setDataSources(java.util.Map<String, javax.sql.DataSource> dataSources) {
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		for (java.util.Map.Entry<String, javax.sql.DataSource> dataSourceEntry : dataSources.entrySet()) {
			talendDataSources.put(dataSourceEntry.getKey(), new routines.system.TalendDataSource(dataSourceEntry.getValue()));
		}
		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}
	
	public void setDataSourceReferences(List serviceReferences) throws Exception{
		
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		java.util.Map<String, javax.sql.DataSource> dataSources = new java.util.HashMap<String, javax.sql.DataSource>();
		
		for (java.util.Map.Entry<String, javax.sql.DataSource> entry : BundleUtils.getServices(serviceReferences,  javax.sql.DataSource.class).entrySet()) {
                    dataSources.put(entry.getKey(), entry.getValue());
                    talendDataSources.put(entry.getKey(), new routines.system.TalendDataSource(entry.getValue()));
		}

		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}

	StatCatcherUtils tStatCatcher_1 = new StatCatcherUtils("_JFpQEKTSEe6Y29G3fOuWUQ", "0.1");

private final java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
private final java.io.PrintStream errorMessagePS = new java.io.PrintStream(new java.io.BufferedOutputStream(baos));

public String getExceptionStackTrace() {
	if ("failure".equals(this.getStatus())) {
		errorMessagePS.flush();
		return baos.toString();
	}
	return null;
}

private Exception exception;

public Exception getException() {
	if ("failure".equals(this.getStatus())) {
		return this.exception;
	}
	return null;
}

private class TalendException extends Exception {

	private static final long serialVersionUID = 1L;

	private java.util.Map<String, Object> globalMap = null;
	private Exception e = null;
	private String currentComponent = null;
	private String virtualComponentName = null;
	
	public void setVirtualComponentName (String virtualComponentName){
		this.virtualComponentName = virtualComponentName;
	}

	private TalendException(Exception e, String errorComponent, final java.util.Map<String, Object> globalMap) {
		this.currentComponent= errorComponent;
		this.globalMap = globalMap;
		this.e = e;
	}

	public Exception getException() {
		return this.e;
	}

	public String getCurrentComponent() {
		return this.currentComponent;
	}

	
    public String getExceptionCauseMessage(Exception e){
        Throwable cause = e;
        String message = null;
        int i = 10;
        while (null != cause && 0 < i--) {
            message = cause.getMessage();
            if (null == message) {
                cause = cause.getCause();
            } else {
                break;          
            }
        }
        if (null == message) {
            message = e.getClass().getName();
        }   
        return message;
    }

	@Override
	public void printStackTrace() {
		if (!(e instanceof TalendException || e instanceof TDieException)) {
			if(virtualComponentName!=null && currentComponent.indexOf(virtualComponentName+"_")==0){
				globalMap.put(virtualComponentName+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			}
			globalMap.put(currentComponent+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			System.err.println("Exception in component " + currentComponent + " (" + jobName + ")");
		}
		if (!(e instanceof TDieException)) {
			if(e instanceof TalendException){
				e.printStackTrace();
			} else {
				e.printStackTrace();
				e.printStackTrace(errorMessagePS);
				C_ALIM_ODS_REJET.this.exception = e;
			}
		}
		if (!(e instanceof TalendException)) {
		try {
			for (java.lang.reflect.Method m : this.getClass().getEnclosingClass().getMethods()) {
				if (m.getName().compareTo(currentComponent + "_error") == 0) {
					m.invoke(C_ALIM_ODS_REJET.this, new Object[] { e , currentComponent, globalMap});
					break;
				}
			}

			if(!(e instanceof TDieException)){
			}
		} catch (Exception e) {
			this.e.printStackTrace();
		}
		}
	}
}

			public void tStatCatcher_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tStatCatcher_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tStatCatcher_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBRow_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
							tStatCatcher_1.addMessage("failure",errorComponent, end_Hash.get(errorComponent)-start_Hash.get(errorComponent));
							tStatCatcher_1Process(globalMap);
							
				status = "failure";
				
					tDBRow_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBInput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
							tStatCatcher_1.addMessage("failure",errorComponent, end_Hash.get(errorComponent)-start_Hash.get(errorComponent));
							tStatCatcher_1Process(globalMap);
							
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tUniqRow_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
							tStatCatcher_1.addMessage("failure",errorComponent, end_Hash.get(errorComponent)-start_Hash.get(errorComponent));
							tStatCatcher_1Process(globalMap);
							
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFilterRow_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
							tStatCatcher_1.addMessage("failure",errorComponent, end_Hash.get(errorComponent)-start_Hash.get(errorComponent));
							tStatCatcher_1Process(globalMap);
							
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMap_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
							tStatCatcher_1.addMessage("failure",errorComponent, end_Hash.get(errorComponent)-start_Hash.get(errorComponent));
							tStatCatcher_1Process(globalMap);
							
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
							tStatCatcher_1.addMessage("failure",errorComponent, end_Hash.get(errorComponent)-start_Hash.get(errorComponent));
							tStatCatcher_1Process(globalMap);
							
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMap_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
							tStatCatcher_1.addMessage("failure",errorComponent, end_Hash.get(errorComponent)-start_Hash.get(errorComponent));
							tStatCatcher_1Process(globalMap);
							
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
							tStatCatcher_1.addMessage("failure",errorComponent, end_Hash.get(errorComponent)-start_Hash.get(errorComponent));
							tStatCatcher_1Process(globalMap);
							
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMap_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
							tStatCatcher_1.addMessage("failure",errorComponent, end_Hash.get(errorComponent)-start_Hash.get(errorComponent));
							tStatCatcher_1Process(globalMap);
							
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
							tStatCatcher_1.addMessage("failure",errorComponent, end_Hash.get(errorComponent)-start_Hash.get(errorComponent));
							tStatCatcher_1Process(globalMap);
							
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tStatCatcher_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBRow_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBInput_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
	






public static class row1Struct implements routines.system.IPersistableRow<row1Struct> {
    final static byte[] commonByteArrayLock_ALIMENTATION_DM1_C_ALIM_ODS_REJET = new byte[0];
    static byte[] commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET = new byte[0];

	
			    public java.util.Date moment;

				public java.util.Date getMoment () {
					return this.moment;
				}
				
			    public String pid;

				public String getPid () {
					return this.pid;
				}
				
			    public String father_pid;

				public String getFather_pid () {
					return this.father_pid;
				}
				
			    public String root_pid;

				public String getRoot_pid () {
					return this.root_pid;
				}
				
			    public Long system_pid;

				public Long getSystem_pid () {
					return this.system_pid;
				}
				
			    public String project;

				public String getProject () {
					return this.project;
				}
				
			    public String job;

				public String getJob () {
					return this.job;
				}
				
			    public String job_repository_id;

				public String getJob_repository_id () {
					return this.job_repository_id;
				}
				
			    public String job_version;

				public String getJob_version () {
					return this.job_version;
				}
				
			    public String context;

				public String getContext () {
					return this.context;
				}
				
			    public String origin;

				public String getOrigin () {
					return this.origin;
				}
				
			    public String message_type;

				public String getMessage_type () {
					return this.message_type;
				}
				
			    public String message;

				public String getMessage () {
					return this.message;
				}
				
			    public Long duration;

				public Long getDuration () {
					return this.duration;
				}
				



	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET.length == 0) {
   					commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET.length == 0) {
   					commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_DM1_C_ALIM_ODS_REJET) {

        	try {

        		int length = 0;
		
					this.moment = readDate(dis);
					
					this.pid = readString(dis);
					
					this.father_pid = readString(dis);
					
					this.root_pid = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.system_pid = null;
           				} else {
           			    	this.system_pid = dis.readLong();
           				}
					
					this.project = readString(dis);
					
					this.job = readString(dis);
					
					this.job_repository_id = readString(dis);
					
					this.job_version = readString(dis);
					
					this.context = readString(dis);
					
					this.origin = readString(dis);
					
					this.message_type = readString(dis);
					
					this.message = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.duration = null;
           				} else {
           			    	this.duration = dis.readLong();
           				}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_DM1_C_ALIM_ODS_REJET) {

        	try {

        		int length = 0;
		
					this.moment = readDate(dis);
					
					this.pid = readString(dis);
					
					this.father_pid = readString(dis);
					
					this.root_pid = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.system_pid = null;
           				} else {
           			    	this.system_pid = dis.readLong();
           				}
					
					this.project = readString(dis);
					
					this.job = readString(dis);
					
					this.job_repository_id = readString(dis);
					
					this.job_version = readString(dis);
					
					this.context = readString(dis);
					
					this.origin = readString(dis);
					
					this.message_type = readString(dis);
					
					this.message = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.duration = null;
           				} else {
           			    	this.duration = dis.readLong();
           				}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// java.util.Date
				
						writeDate(this.moment,dos);
					
					// String
				
						writeString(this.pid,dos);
					
					// String
				
						writeString(this.father_pid,dos);
					
					// String
				
						writeString(this.root_pid,dos);
					
					// Long
				
						if(this.system_pid == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.system_pid);
		            	}
					
					// String
				
						writeString(this.project,dos);
					
					// String
				
						writeString(this.job,dos);
					
					// String
				
						writeString(this.job_repository_id,dos);
					
					// String
				
						writeString(this.job_version,dos);
					
					// String
				
						writeString(this.context,dos);
					
					// String
				
						writeString(this.origin,dos);
					
					// String
				
						writeString(this.message_type,dos);
					
					// String
				
						writeString(this.message,dos);
					
					// Long
				
						if(this.duration == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.duration);
		            	}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// java.util.Date
				
						writeDate(this.moment,dos);
					
					// String
				
						writeString(this.pid,dos);
					
					// String
				
						writeString(this.father_pid,dos);
					
					// String
				
						writeString(this.root_pid,dos);
					
					// Long
				
						if(this.system_pid == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.system_pid);
		            	}
					
					// String
				
						writeString(this.project,dos);
					
					// String
				
						writeString(this.job,dos);
					
					// String
				
						writeString(this.job_repository_id,dos);
					
					// String
				
						writeString(this.job_version,dos);
					
					// String
				
						writeString(this.context,dos);
					
					// String
				
						writeString(this.origin,dos);
					
					// String
				
						writeString(this.message_type,dos);
					
					// String
				
						writeString(this.message,dos);
					
					// Long
				
						if(this.duration == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.duration);
		            	}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("moment="+String.valueOf(moment));
		sb.append(",pid="+pid);
		sb.append(",father_pid="+father_pid);
		sb.append(",root_pid="+root_pid);
		sb.append(",system_pid="+String.valueOf(system_pid));
		sb.append(",project="+project);
		sb.append(",job="+job);
		sb.append(",job_repository_id="+job_repository_id);
		sb.append(",job_version="+job_version);
		sb.append(",context="+context);
		sb.append(",origin="+origin);
		sb.append(",message_type="+message_type);
		sb.append(",message="+message);
		sb.append(",duration="+String.valueOf(duration));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row1Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tStatCatcher_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tStatCatcher_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row1Struct row1 = new row1Struct();




	
	/**
	 * [tDBOutput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_1", false);
		start_Hash.put("tDBOutput_1", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_1";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row1");
					}
				
		int tos_count_tDBOutput_1 = 0;
		





String dbschema_tDBOutput_1 = null;
	dbschema_tDBOutput_1 = "dsid_liv_met";
	

String tableName_tDBOutput_1 = null;
if(dbschema_tDBOutput_1 == null || dbschema_tDBOutput_1.trim().length() == 0) {
	tableName_tDBOutput_1 = ("JOB_STATS");
} else {
	tableName_tDBOutput_1 = dbschema_tDBOutput_1 + "\".\"" + ("JOB_STATS");
}


int nb_line_tDBOutput_1 = 0;
int nb_line_update_tDBOutput_1 = 0;
int nb_line_inserted_tDBOutput_1 = 0;
int nb_line_deleted_tDBOutput_1 = 0;
int nb_line_rejected_tDBOutput_1 = 0;

int deletedCount_tDBOutput_1=0;
int updatedCount_tDBOutput_1=0;
int insertedCount_tDBOutput_1=0;
int rowsToCommitCount_tDBOutput_1=0;
int rejectedCount_tDBOutput_1=0;

boolean whetherReject_tDBOutput_1 = false;

java.sql.Connection conn_tDBOutput_1 = null;
String dbUser_tDBOutput_1 = null;

	
    java.lang.Class.forName("org.postgresql.Driver");
    
        String url_tDBOutput_1 = "jdbc:postgresql://"+""+":"+"5432"+"/"+"postgres";
    dbUser_tDBOutput_1 = "dsid_cc2_tos_rw";
 
	final String decryptedPassword_tDBOutput_1 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:OQITG6bVOaaSbtg1R7tmBFRh/TMaiblUAxfpCai1hVw=");

    String dbPwd_tDBOutput_1 = decryptedPassword_tDBOutput_1;

    conn_tDBOutput_1 = java.sql.DriverManager.getConnection(url_tDBOutput_1,dbUser_tDBOutput_1,dbPwd_tDBOutput_1);
	
	resourceMap.put("conn_tDBOutput_1", conn_tDBOutput_1);
        conn_tDBOutput_1.setAutoCommit(false);
        int commitEvery_tDBOutput_1 = 10000;
        int commitCounter_tDBOutput_1 = 0;


   int batchSize_tDBOutput_1 = 10000;
   int batchSizeCounter_tDBOutput_1=0;

int count_tDBOutput_1=0;
	    String insert_tDBOutput_1 = "INSERT INTO \"" + tableName_tDBOutput_1 + "\" (\"moment\",\"pid\",\"father_pid\",\"root_pid\",\"system_pid\",\"project\",\"job\",\"job_repository_id\",\"job_version\",\"context\",\"origin\",\"message_type\",\"message\",\"duration\") VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
	    
	    java.sql.PreparedStatement pstmt_tDBOutput_1 = conn_tDBOutput_1.prepareStatement(insert_tDBOutput_1);
	    resourceMap.put("pstmt_tDBOutput_1", pstmt_tDBOutput_1);
	    

 



/**
 * [tDBOutput_1 begin ] stop
 */



	
	/**
	 * [tStatCatcher_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tStatCatcher_1", false);
		start_Hash.put("tStatCatcher_1", System.currentTimeMillis());
		
	
	currentComponent="tStatCatcher_1";

	
		int tos_count_tStatCatcher_1 = 0;
		

	for (StatCatcherUtils.StatCatcherMessage scm : tStatCatcher_1.getMessages()) {
		row1.pid = pid;
		row1.root_pid = rootPid;
		row1.father_pid = fatherPid;	
    	row1.project = projectName;
    	row1.job = jobName;
    	row1.context = contextStr;
		row1.origin = (scm.getOrigin()==null || scm.getOrigin().length()<1 ? null : scm.getOrigin());
		row1.message = scm.getMessage();
		row1.duration = scm.getDuration();
		row1.moment = scm.getMoment();
		row1.message_type = scm.getMessageType();
		row1.job_version = scm.getJobVersion();
		row1.job_repository_id = scm.getJobId();
		row1.system_pid = scm.getSystemPid();

 



/**
 * [tStatCatcher_1 begin ] stop
 */
	
	/**
	 * [tStatCatcher_1 main ] start
	 */

	

	
	
	currentComponent="tStatCatcher_1";

	

 


	tos_count_tStatCatcher_1++;

/**
 * [tStatCatcher_1 main ] stop
 */
	
	/**
	 * [tStatCatcher_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tStatCatcher_1";

	

 



/**
 * [tStatCatcher_1 process_data_begin ] stop
 */

	
	/**
	 * [tDBOutput_1 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row1"
						
						);
					}
					



        whetherReject_tDBOutput_1 = false;
                    if(row1.moment != null) {
pstmt_tDBOutput_1.setTimestamp(1, new java.sql.Timestamp(row1.moment.getTime()));
} else {
pstmt_tDBOutput_1.setNull(1, java.sql.Types.TIMESTAMP);
}

                    if(row1.pid == null) {
pstmt_tDBOutput_1.setNull(2, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(2, row1.pid);
}

                    if(row1.father_pid == null) {
pstmt_tDBOutput_1.setNull(3, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(3, row1.father_pid);
}

                    if(row1.root_pid == null) {
pstmt_tDBOutput_1.setNull(4, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(4, row1.root_pid);
}

                    if(row1.system_pid == null) {
pstmt_tDBOutput_1.setNull(5, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_1.setLong(5, row1.system_pid);
}

                    if(row1.project == null) {
pstmt_tDBOutput_1.setNull(6, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(6, row1.project);
}

                    if(row1.job == null) {
pstmt_tDBOutput_1.setNull(7, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(7, row1.job);
}

                    if(row1.job_repository_id == null) {
pstmt_tDBOutput_1.setNull(8, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(8, row1.job_repository_id);
}

                    if(row1.job_version == null) {
pstmt_tDBOutput_1.setNull(9, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(9, row1.job_version);
}

                    if(row1.context == null) {
pstmt_tDBOutput_1.setNull(10, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(10, row1.context);
}

                    if(row1.origin == null) {
pstmt_tDBOutput_1.setNull(11, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(11, row1.origin);
}

                    if(row1.message_type == null) {
pstmt_tDBOutput_1.setNull(12, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(12, row1.message_type);
}

                    if(row1.message == null) {
pstmt_tDBOutput_1.setNull(13, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(13, row1.message);
}

                    if(row1.duration == null) {
pstmt_tDBOutput_1.setNull(14, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_1.setLong(14, row1.duration);
}

			
    		pstmt_tDBOutput_1.addBatch();
    		nb_line_tDBOutput_1++;
    		  
    		  
    		  batchSizeCounter_tDBOutput_1++;
    		  
    			if ((batchSize_tDBOutput_1 > 0) && (batchSize_tDBOutput_1 <= batchSizeCounter_tDBOutput_1)) {
                try {
						int countSum_tDBOutput_1 = 0;
						    
						for(int countEach_tDBOutput_1: pstmt_tDBOutput_1.executeBatch()) {
							countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
						}
				    	rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
				    	
				    		insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
				    	
            	    	batchSizeCounter_tDBOutput_1 = 0;
                }catch (java.sql.BatchUpdateException e_tDBOutput_1){
globalMap.put("tDBOutput_1_ERROR_MESSAGE",e_tDBOutput_1.getMessage());
				    	java.sql.SQLException ne_tDBOutput_1 = e_tDBOutput_1.getNextException(),sqle_tDBOutput_1=null;
				    	String errormessage_tDBOutput_1;
						if (ne_tDBOutput_1 != null) {
							// build new exception to provide the original cause
							sqle_tDBOutput_1 = new java.sql.SQLException(e_tDBOutput_1.getMessage() + "\ncaused by: " + ne_tDBOutput_1.getMessage(), ne_tDBOutput_1.getSQLState(), ne_tDBOutput_1.getErrorCode(), ne_tDBOutput_1);
							errormessage_tDBOutput_1 = sqle_tDBOutput_1.getMessage();
						}else{
							errormessage_tDBOutput_1 = e_tDBOutput_1.getMessage();
						}
				    	
				    	int countSum_tDBOutput_1 = 0;
						for(int countEach_tDBOutput_1: e_tDBOutput_1.getUpdateCounts()) {
							countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
						}
						rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
						
				    		insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
				    	
				    	System.err.println(errormessage_tDBOutput_1);
				    	
					}
    			}
    		
    		    commitCounter_tDBOutput_1++;
                if(commitEvery_tDBOutput_1 <= commitCounter_tDBOutput_1) {
                if ((batchSize_tDBOutput_1 > 0) && (batchSizeCounter_tDBOutput_1 > 0)) {
                try {
                		int countSum_tDBOutput_1 = 0;
                		    
						for(int countEach_tDBOutput_1: pstmt_tDBOutput_1.executeBatch()) {
							countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
						}
            	    	rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
            	    	
            	    		insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
            	    	
                batchSizeCounter_tDBOutput_1 = 0;
               }catch (java.sql.BatchUpdateException e_tDBOutput_1){
globalMap.put("tDBOutput_1_ERROR_MESSAGE",e_tDBOutput_1.getMessage());
			    	java.sql.SQLException ne_tDBOutput_1 = e_tDBOutput_1.getNextException(),sqle_tDBOutput_1=null;
			    	String errormessage_tDBOutput_1;
					if (ne_tDBOutput_1 != null) {
						// build new exception to provide the original cause
						sqle_tDBOutput_1 = new java.sql.SQLException(e_tDBOutput_1.getMessage() + "\ncaused by: " + ne_tDBOutput_1.getMessage(), ne_tDBOutput_1.getSQLState(), ne_tDBOutput_1.getErrorCode(), ne_tDBOutput_1);
						errormessage_tDBOutput_1 = sqle_tDBOutput_1.getMessage();
					}else{
						errormessage_tDBOutput_1 = e_tDBOutput_1.getMessage();
					}
			    	
			    	int countSum_tDBOutput_1 = 0;
					for(int countEach_tDBOutput_1: e_tDBOutput_1.getUpdateCounts()) {
						countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
					}
					rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
					
			    		insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
			    	
			    	System.err.println(errormessage_tDBOutput_1);
			    	
				}
            }
                    if(rowsToCommitCount_tDBOutput_1 != 0){
                    	
                    }
                    conn_tDBOutput_1.commit();
                    if(rowsToCommitCount_tDBOutput_1 != 0){
                    	
                    	rowsToCommitCount_tDBOutput_1 = 0;
                    }
                    commitCounter_tDBOutput_1=0;
                }

 


	tos_count_tDBOutput_1++;

/**
 * [tDBOutput_1 main ] stop
 */
	
	/**
	 * [tDBOutput_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";

	

 



/**
 * [tDBOutput_1 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";

	

 



/**
 * [tDBOutput_1 process_data_end ] stop
 */



	
	/**
	 * [tStatCatcher_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tStatCatcher_1";

	

 



/**
 * [tStatCatcher_1 process_data_end ] stop
 */
	
	/**
	 * [tStatCatcher_1 end ] start
	 */

	

	
	
	currentComponent="tStatCatcher_1";

	

	}


 

ok_Hash.put("tStatCatcher_1", true);
end_Hash.put("tStatCatcher_1", System.currentTimeMillis());




/**
 * [tStatCatcher_1 end ] stop
 */

	
	/**
	 * [tDBOutput_1 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";

	



	    try {
				int countSum_tDBOutput_1 = 0;
				if (pstmt_tDBOutput_1 != null && batchSizeCounter_tDBOutput_1 > 0) {
						
					for(int countEach_tDBOutput_1: pstmt_tDBOutput_1.executeBatch()) {
						countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
					}
					rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
						
				}
		    	
		    		insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
		    	
	    }catch (java.sql.BatchUpdateException e_tDBOutput_1){
globalMap.put("tDBOutput_1_ERROR_MESSAGE",e_tDBOutput_1.getMessage());
	    	java.sql.SQLException ne_tDBOutput_1 = e_tDBOutput_1.getNextException(),sqle_tDBOutput_1=null;
	    	String errormessage_tDBOutput_1;
			if (ne_tDBOutput_1 != null) {
				// build new exception to provide the original cause
				sqle_tDBOutput_1 = new java.sql.SQLException(e_tDBOutput_1.getMessage() + "\ncaused by: " + ne_tDBOutput_1.getMessage(), ne_tDBOutput_1.getSQLState(), ne_tDBOutput_1.getErrorCode(), ne_tDBOutput_1);
				errormessage_tDBOutput_1 = sqle_tDBOutput_1.getMessage();
			}else{
				errormessage_tDBOutput_1 = e_tDBOutput_1.getMessage();
			}
	    	
	    	int countSum_tDBOutput_1 = 0;
			for(int countEach_tDBOutput_1: e_tDBOutput_1.getUpdateCounts()) {
				countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
			}
			rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
			
	    		insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
	    	
	    	System.err.println(errormessage_tDBOutput_1);
	    	
		}
	    
        if(pstmt_tDBOutput_1 != null) {
        		
            pstmt_tDBOutput_1.close();
            resourceMap.remove("pstmt_tDBOutput_1");
        }
    resourceMap.put("statementClosed_tDBOutput_1", true);
			if(rowsToCommitCount_tDBOutput_1 != 0){
				
			}
			conn_tDBOutput_1.commit();
			if(rowsToCommitCount_tDBOutput_1 != 0){
				
				rowsToCommitCount_tDBOutput_1 = 0;
			}
			commitCounter_tDBOutput_1 = 0;
		
    	conn_tDBOutput_1 .close();
    	
    	resourceMap.put("finish_tDBOutput_1", true);
    	

	nb_line_deleted_tDBOutput_1=nb_line_deleted_tDBOutput_1+ deletedCount_tDBOutput_1;
	nb_line_update_tDBOutput_1=nb_line_update_tDBOutput_1 + updatedCount_tDBOutput_1;
	nb_line_inserted_tDBOutput_1=nb_line_inserted_tDBOutput_1 + insertedCount_tDBOutput_1;
	nb_line_rejected_tDBOutput_1=nb_line_rejected_tDBOutput_1 + rejectedCount_tDBOutput_1;
	
        globalMap.put("tDBOutput_1_NB_LINE",nb_line_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_UPDATED",nb_line_update_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_DELETED",nb_line_deleted_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_1);
    

	


				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row1");
			  	}
			  	
 

ok_Hash.put("tDBOutput_1", true);
end_Hash.put("tDBOutput_1", System.currentTimeMillis());




/**
 * [tDBOutput_1 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tStatCatcher_1 finally ] start
	 */

	

	
	
	currentComponent="tStatCatcher_1";

	

 



/**
 * [tStatCatcher_1 finally ] stop
 */

	
	/**
	 * [tDBOutput_1 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";

	



    try {
    if (resourceMap.get("statementClosed_tDBOutput_1") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_1 = null;
                if ((pstmtToClose_tDBOutput_1 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_1")) != null) {
                    pstmtToClose_tDBOutput_1.close();
                }
    }
    } finally {
        if(resourceMap.get("finish_tDBOutput_1") == null){
            java.sql.Connection ctn_tDBOutput_1 = null;
            if((ctn_tDBOutput_1 = (java.sql.Connection)resourceMap.get("conn_tDBOutput_1")) != null){
                try {
                    ctn_tDBOutput_1.close();
                } catch (java.sql.SQLException sqlEx_tDBOutput_1) {
                    String errorMessage_tDBOutput_1 = "failed to close the connection in tDBOutput_1 :" + sqlEx_tDBOutput_1.getMessage();
                    System.err.println(errorMessage_tDBOutput_1);
                }
            }
        }
    }
 



/**
 * [tDBOutput_1 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tStatCatcher_1_SUBPROCESS_STATE", 1);
	}
	

public void tDBRow_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBRow_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tDBRow_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBRow_1", false);
		start_Hash.put("tDBRow_1", System.currentTimeMillis());
		
				tStatCatcher_1.addMessage("begin","tDBRow_1");
				tStatCatcher_1Process(globalMap);
			
	
	currentComponent="tDBRow_1";

	
		int tos_count_tDBRow_1 = 0;
		

	java.sql.Connection conn_tDBRow_1 = null;
	String query_tDBRow_1 = "";
	boolean whetherReject_tDBRow_1 = false;
			String driverClass_tDBRow_1 = "org.postgresql.Driver";
		    java.lang.Class jdbcclazz_tDBRow_1 = java.lang.Class.forName(driverClass_tDBRow_1);
		
				String url_tDBRow_1 = "jdbc:postgresql://"+""+":"+"5432"+"/"+"postgres";
				
					String dbUser_tDBRow_1 = "dsid_cc2_tos_rw";
	        
            		
            		
            		 
	final String decryptedPassword_tDBRow_1 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:2+UydHNm2mwevldtR6PtY2+vscfIsBgynbfuTeOyOfI=");
        		   	
        	        String dbPwd_tDBRow_1 = decryptedPassword_tDBRow_1;
	        
					
			conn_tDBRow_1 = java.sql.DriverManager.getConnection(url_tDBRow_1,dbUser_tDBRow_1,dbPwd_tDBRow_1);
		
        resourceMap.put("conn_tDBRow_1", conn_tDBRow_1);
					if(conn_tDBRow_1.getAutoCommit()) {
						
				conn_tDBRow_1.setAutoCommit(false);
			
					}        
					int commitEvery_tDBRow_1 = 10000;
					int commitCounter_tDBRow_1 = 0;
				
        java.sql.Statement stmt_tDBRow_1 = conn_tDBRow_1.createStatement();
        resourceMap.put("stmt_tDBRow_1", stmt_tDBRow_1);


 



/**
 * [tDBRow_1 begin ] stop
 */
	
	/**
	 * [tDBRow_1 main ] start
	 */

	

	
	
	currentComponent="tDBRow_1";

	

query_tDBRow_1 = "TRUNCATE TABLE dsid_liv_wrk.dm1_rejet";
whetherReject_tDBRow_1 = false;
globalMap.put("tDBRow_1_QUERY",query_tDBRow_1);
try {
		stmt_tDBRow_1.execute(query_tDBRow_1);
		
	} catch (java.lang.Exception e) {
		whetherReject_tDBRow_1 = true;
		
				System.err.print(e.getMessage());
				globalMap.put("tDBRow_1_ERROR_MESSAGE", e.getMessage());
				
	}
	
	if(!whetherReject_tDBRow_1) {
		
	}
	
		commitCounter_tDBRow_1++;
		if(commitEvery_tDBRow_1 <= commitCounter_tDBRow_1) {
			
			conn_tDBRow_1.commit();
			
			commitCounter_tDBRow_1=0;
		}
		

 


	tos_count_tDBRow_1++;

/**
 * [tDBRow_1 main ] stop
 */
	
	/**
	 * [tDBRow_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBRow_1";

	

 



/**
 * [tDBRow_1 process_data_begin ] stop
 */
	
	/**
	 * [tDBRow_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBRow_1";

	

 



/**
 * [tDBRow_1 process_data_end ] stop
 */
	
	/**
	 * [tDBRow_1 end ] start
	 */

	

	
	
	currentComponent="tDBRow_1";

	

	
        stmt_tDBRow_1.close();
        resourceMap.remove("stmt_tDBRow_1");
    resourceMap.put("statementClosed_tDBRow_1", true);
		if(commitEvery_tDBRow_1>commitCounter_tDBRow_1){

			
			conn_tDBRow_1.commit();
			
	
			commitCounter_tDBRow_1=0;
	
		}
			conn_tDBRow_1.close();
			
			if("com.mysql.cj.jdbc.Driver".equals((String)globalMap.get("driverClass_"))
			    && routines.system.BundleUtils.inOSGi()) {
			        Class.forName("com.mysql.cj.jdbc.AbandonedConnectionCleanupThread").
			            getMethod("checkedShutdown").invoke(null, (Object[]) null);
			}
			
    resourceMap.put("finish_tDBRow_1", true);
 

ok_Hash.put("tDBRow_1", true);
end_Hash.put("tDBRow_1", System.currentTimeMillis());

tStatCatcher_1.addMessage("end","tDBRow_1", end_Hash.get("tDBRow_1")-start_Hash.get("tDBRow_1"));
tStatCatcher_1Process(globalMap);
				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk2", 0, "ok");
				}
				tDBInput_1Process(globalMap);



/**
 * [tDBRow_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBRow_1 finally ] start
	 */

	

	
	
	currentComponent="tDBRow_1";

	

try {
    if (resourceMap.get("statementClosed_tDBRow_1") == null) {
            java.sql.Statement stmtToClose_tDBRow_1 = null;
            if ((stmtToClose_tDBRow_1 = (java.sql.Statement) resourceMap.remove("stmt_tDBRow_1")) != null) {
                stmtToClose_tDBRow_1.close();
            }
    }
} finally {
        if(resourceMap.get("finish_tDBRow_1") == null){
            java.sql.Connection ctn_tDBRow_1 = null;
            if((ctn_tDBRow_1 = (java.sql.Connection)resourceMap.get("conn_tDBRow_1")) != null){
                try {
                    ctn_tDBRow_1.close();
                } catch (java.sql.SQLException sqlEx_tDBRow_1) {
                    String errorMessage_tDBRow_1 = "failed to close the connection in tDBRow_1 :" + sqlEx_tDBRow_1.getMessage();
                    System.err.println(errorMessage_tDBRow_1);
                }
            }
        }
    }
 



/**
 * [tDBRow_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBRow_1_SUBPROCESS_STATE", 1);
	}
	


public static class alimt_rejet_doublonsStruct implements routines.system.IPersistableRow<alimt_rejet_doublonsStruct> {
    final static byte[] commonByteArrayLock_ALIMENTATION_DM1_C_ALIM_ODS_REJET = new byte[0];
    static byte[] commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int id_rejet_dm1;

				public int getId_rejet_dm1 () {
					return this.id_rejet_dm1;
				}
				
			    public Integer id_preparation;

				public Integer getId_preparation () {
					return this.id_preparation;
				}
				
			    public java.util.Date date_debut_preparation;

				public java.util.Date getDate_debut_preparation () {
					return this.date_debut_preparation;
				}
				
			    public java.util.Date date_fin_preparation;

				public java.util.Date getDate_fin_preparation () {
					return this.date_fin_preparation;
				}
				
			    public Integer id_moyen_paiement;

				public Integer getId_moyen_paiement () {
					return this.id_moyen_paiement;
				}
				
			    public String code_moyen_paiement;

				public String getCode_moyen_paiement () {
					return this.code_moyen_paiement;
				}
				
			    public String livelle_moyen_paiement;

				public String getLivelle_moyen_paiement () {
					return this.livelle_moyen_paiement;
				}
				
			    public Integer id_menu;

				public Integer getId_menu () {
					return this.id_menu;
				}
				
			    public String code_menu;

				public String getCode_menu () {
					return this.code_menu;
				}
				
			    public String libelle_menu;

				public String getLibelle_menu () {
					return this.libelle_menu;
				}
				
			    public Integer nombre_articles;

				public Integer getNombre_articles () {
					return this.nombre_articles;
				}
				
			    public BigDecimal temps_theo_preparation;

				public BigDecimal getTemps_theo_preparation () {
					return this.temps_theo_preparation;
				}
				
			    public Integer id_commande;

				public Integer getId_commande () {
					return this.id_commande;
				}
				
			    public Integer numero_commande;

				public Integer getNumero_commande () {
					return this.numero_commande;
				}
				
			    public java.util.Date date_commande;

				public java.util.Date getDate_commande () {
					return this.date_commande;
				}
				
			    public Float montant_total;

				public Float getMontant_total () {
					return this.montant_total;
				}
				
			    public Integer id_adresse_norm_restaurant;

				public Integer getId_adresse_norm_restaurant () {
					return this.id_adresse_norm_restaurant;
				}
				
			    public String numero_voie_restau;

				public String getNumero_voie_restau () {
					return this.numero_voie_restau;
				}
				
			    public String nom_voie_restau;

				public String getNom_voie_restau () {
					return this.nom_voie_restau;
				}
				
			    public String code_postal_restau;

				public String getCode_postal_restau () {
					return this.code_postal_restau;
				}
				
			    public String nom_ville_restau;

				public String getNom_ville_restau () {
					return this.nom_ville_restau;
				}
				
			    public String longitude_restau;

				public String getLongitude_restau () {
					return this.longitude_restau;
				}
				
			    public String latitude_restau;

				public String getLatitude_restau () {
					return this.latitude_restau;
				}
				
			    public Integer id_adresse_restaurant;

				public Integer getId_adresse_restaurant () {
					return this.id_adresse_restaurant;
				}
				
			    public String adresse_restaurant;

				public String getAdresse_restaurant () {
					return this.adresse_restaurant;
				}
				
			    public Integer id_restaurant;

				public Integer getId_restaurant () {
					return this.id_restaurant;
				}
				
			    public String code_restaurant;

				public String getCode_restaurant () {
					return this.code_restaurant;
				}
				
			    public String raison_sociale_restaurant;

				public String getRaison_sociale_restaurant () {
					return this.raison_sociale_restaurant;
				}
				
			    public Integer id_adresse_norm_client;

				public Integer getId_adresse_norm_client () {
					return this.id_adresse_norm_client;
				}
				
			    public String numero_voie;

				public String getNumero_voie () {
					return this.numero_voie;
				}
				
			    public String nom_voie;

				public String getNom_voie () {
					return this.nom_voie;
				}
				
			    public String code_postal;

				public String getCode_postal () {
					return this.code_postal;
				}
				
			    public String nom_ville;

				public String getNom_ville () {
					return this.nom_ville;
				}
				
			    public String longitude;

				public String getLongitude () {
					return this.longitude;
				}
				
			    public String latitude;

				public String getLatitude () {
					return this.latitude;
				}
				
			    public Integer id_adresse_client;

				public Integer getId_adresse_client () {
					return this.id_adresse_client;
				}
				
			    public String adresse_client;

				public String getAdresse_client () {
					return this.adresse_client;
				}
				
			    public Integer id_client;

				public Integer getId_client () {
					return this.id_client;
				}
				
			    public String nom_client;

				public String getNom_client () {
					return this.nom_client;
				}
				
			    public String prenom_client;

				public String getPrenom_client () {
					return this.prenom_client;
				}
				
			    public String type_rejet;

				public String getType_rejet () {
					return this.type_rejet;
				}
				
			    public String message_log;

				public String getMessage_log () {
					return this.message_log;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.id_rejet_dm1;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final alimt_rejet_doublonsStruct other = (alimt_rejet_doublonsStruct) obj;
		
						if (this.id_rejet_dm1 != other.id_rejet_dm1)
							return false;
					

		return true;
    }

	public void copyDataTo(alimt_rejet_doublonsStruct other) {

		other.id_rejet_dm1 = this.id_rejet_dm1;
	            other.id_preparation = this.id_preparation;
	            other.date_debut_preparation = this.date_debut_preparation;
	            other.date_fin_preparation = this.date_fin_preparation;
	            other.id_moyen_paiement = this.id_moyen_paiement;
	            other.code_moyen_paiement = this.code_moyen_paiement;
	            other.livelle_moyen_paiement = this.livelle_moyen_paiement;
	            other.id_menu = this.id_menu;
	            other.code_menu = this.code_menu;
	            other.libelle_menu = this.libelle_menu;
	            other.nombre_articles = this.nombre_articles;
	            other.temps_theo_preparation = this.temps_theo_preparation;
	            other.id_commande = this.id_commande;
	            other.numero_commande = this.numero_commande;
	            other.date_commande = this.date_commande;
	            other.montant_total = this.montant_total;
	            other.id_adresse_norm_restaurant = this.id_adresse_norm_restaurant;
	            other.numero_voie_restau = this.numero_voie_restau;
	            other.nom_voie_restau = this.nom_voie_restau;
	            other.code_postal_restau = this.code_postal_restau;
	            other.nom_ville_restau = this.nom_ville_restau;
	            other.longitude_restau = this.longitude_restau;
	            other.latitude_restau = this.latitude_restau;
	            other.id_adresse_restaurant = this.id_adresse_restaurant;
	            other.adresse_restaurant = this.adresse_restaurant;
	            other.id_restaurant = this.id_restaurant;
	            other.code_restaurant = this.code_restaurant;
	            other.raison_sociale_restaurant = this.raison_sociale_restaurant;
	            other.id_adresse_norm_client = this.id_adresse_norm_client;
	            other.numero_voie = this.numero_voie;
	            other.nom_voie = this.nom_voie;
	            other.code_postal = this.code_postal;
	            other.nom_ville = this.nom_ville;
	            other.longitude = this.longitude;
	            other.latitude = this.latitude;
	            other.id_adresse_client = this.id_adresse_client;
	            other.adresse_client = this.adresse_client;
	            other.id_client = this.id_client;
	            other.nom_client = this.nom_client;
	            other.prenom_client = this.prenom_client;
	            other.type_rejet = this.type_rejet;
	            other.message_log = this.message_log;
	            
	}

	public void copyKeysDataTo(alimt_rejet_doublonsStruct other) {

		other.id_rejet_dm1 = this.id_rejet_dm1;
	            	
	}



	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET.length == 0) {
   					commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET.length == 0) {
   					commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_DM1_C_ALIM_ODS_REJET) {

        	try {

        		int length = 0;
		
			        this.id_rejet_dm1 = dis.readInt();
					
						this.id_preparation = readInteger(dis);
					
					this.date_debut_preparation = readDate(dis);
					
					this.date_fin_preparation = readDate(dis);
					
						this.id_moyen_paiement = readInteger(dis);
					
					this.code_moyen_paiement = readString(dis);
					
					this.livelle_moyen_paiement = readString(dis);
					
						this.id_menu = readInteger(dis);
					
					this.code_menu = readString(dis);
					
					this.libelle_menu = readString(dis);
					
						this.nombre_articles = readInteger(dis);
					
						this.temps_theo_preparation = (BigDecimal) dis.readObject();
					
						this.id_commande = readInteger(dis);
					
						this.numero_commande = readInteger(dis);
					
					this.date_commande = readDate(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.montant_total = null;
           				} else {
           			    	this.montant_total = dis.readFloat();
           				}
					
						this.id_adresse_norm_restaurant = readInteger(dis);
					
					this.numero_voie_restau = readString(dis);
					
					this.nom_voie_restau = readString(dis);
					
					this.code_postal_restau = readString(dis);
					
					this.nom_ville_restau = readString(dis);
					
					this.longitude_restau = readString(dis);
					
					this.latitude_restau = readString(dis);
					
						this.id_adresse_restaurant = readInteger(dis);
					
					this.adresse_restaurant = readString(dis);
					
						this.id_restaurant = readInteger(dis);
					
					this.code_restaurant = readString(dis);
					
					this.raison_sociale_restaurant = readString(dis);
					
						this.id_adresse_norm_client = readInteger(dis);
					
					this.numero_voie = readString(dis);
					
					this.nom_voie = readString(dis);
					
					this.code_postal = readString(dis);
					
					this.nom_ville = readString(dis);
					
					this.longitude = readString(dis);
					
					this.latitude = readString(dis);
					
						this.id_adresse_client = readInteger(dis);
					
					this.adresse_client = readString(dis);
					
						this.id_client = readInteger(dis);
					
					this.nom_client = readString(dis);
					
					this.prenom_client = readString(dis);
					
					this.type_rejet = readString(dis);
					
					this.message_log = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_DM1_C_ALIM_ODS_REJET) {

        	try {

        		int length = 0;
		
			        this.id_rejet_dm1 = dis.readInt();
					
						this.id_preparation = readInteger(dis);
					
					this.date_debut_preparation = readDate(dis);
					
					this.date_fin_preparation = readDate(dis);
					
						this.id_moyen_paiement = readInteger(dis);
					
					this.code_moyen_paiement = readString(dis);
					
					this.livelle_moyen_paiement = readString(dis);
					
						this.id_menu = readInteger(dis);
					
					this.code_menu = readString(dis);
					
					this.libelle_menu = readString(dis);
					
						this.nombre_articles = readInteger(dis);
					
						this.temps_theo_preparation = (BigDecimal) dis.readObject();
					
						this.id_commande = readInteger(dis);
					
						this.numero_commande = readInteger(dis);
					
					this.date_commande = readDate(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.montant_total = null;
           				} else {
           			    	this.montant_total = dis.readFloat();
           				}
					
						this.id_adresse_norm_restaurant = readInteger(dis);
					
					this.numero_voie_restau = readString(dis);
					
					this.nom_voie_restau = readString(dis);
					
					this.code_postal_restau = readString(dis);
					
					this.nom_ville_restau = readString(dis);
					
					this.longitude_restau = readString(dis);
					
					this.latitude_restau = readString(dis);
					
						this.id_adresse_restaurant = readInteger(dis);
					
					this.adresse_restaurant = readString(dis);
					
						this.id_restaurant = readInteger(dis);
					
					this.code_restaurant = readString(dis);
					
					this.raison_sociale_restaurant = readString(dis);
					
						this.id_adresse_norm_client = readInteger(dis);
					
					this.numero_voie = readString(dis);
					
					this.nom_voie = readString(dis);
					
					this.code_postal = readString(dis);
					
					this.nom_ville = readString(dis);
					
					this.longitude = readString(dis);
					
					this.latitude = readString(dis);
					
						this.id_adresse_client = readInteger(dis);
					
					this.adresse_client = readString(dis);
					
						this.id_client = readInteger(dis);
					
					this.nom_client = readString(dis);
					
					this.prenom_client = readString(dis);
					
					this.type_rejet = readString(dis);
					
					this.message_log = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id_rejet_dm1);
					
					// Integer
				
						writeInteger(this.id_preparation,dos);
					
					// java.util.Date
				
						writeDate(this.date_debut_preparation,dos);
					
					// java.util.Date
				
						writeDate(this.date_fin_preparation,dos);
					
					// Integer
				
						writeInteger(this.id_moyen_paiement,dos);
					
					// String
				
						writeString(this.code_moyen_paiement,dos);
					
					// String
				
						writeString(this.livelle_moyen_paiement,dos);
					
					// Integer
				
						writeInteger(this.id_menu,dos);
					
					// String
				
						writeString(this.code_menu,dos);
					
					// String
				
						writeString(this.libelle_menu,dos);
					
					// Integer
				
						writeInteger(this.nombre_articles,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.temps_theo_preparation);
					
					// Integer
				
						writeInteger(this.id_commande,dos);
					
					// Integer
				
						writeInteger(this.numero_commande,dos);
					
					// java.util.Date
				
						writeDate(this.date_commande,dos);
					
					// Float
				
						if(this.montant_total == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.montant_total);
		            	}
					
					// Integer
				
						writeInteger(this.id_adresse_norm_restaurant,dos);
					
					// String
				
						writeString(this.numero_voie_restau,dos);
					
					// String
				
						writeString(this.nom_voie_restau,dos);
					
					// String
				
						writeString(this.code_postal_restau,dos);
					
					// String
				
						writeString(this.nom_ville_restau,dos);
					
					// String
				
						writeString(this.longitude_restau,dos);
					
					// String
				
						writeString(this.latitude_restau,dos);
					
					// Integer
				
						writeInteger(this.id_adresse_restaurant,dos);
					
					// String
				
						writeString(this.adresse_restaurant,dos);
					
					// Integer
				
						writeInteger(this.id_restaurant,dos);
					
					// String
				
						writeString(this.code_restaurant,dos);
					
					// String
				
						writeString(this.raison_sociale_restaurant,dos);
					
					// Integer
				
						writeInteger(this.id_adresse_norm_client,dos);
					
					// String
				
						writeString(this.numero_voie,dos);
					
					// String
				
						writeString(this.nom_voie,dos);
					
					// String
				
						writeString(this.code_postal,dos);
					
					// String
				
						writeString(this.nom_ville,dos);
					
					// String
				
						writeString(this.longitude,dos);
					
					// String
				
						writeString(this.latitude,dos);
					
					// Integer
				
						writeInteger(this.id_adresse_client,dos);
					
					// String
				
						writeString(this.adresse_client,dos);
					
					// Integer
				
						writeInteger(this.id_client,dos);
					
					// String
				
						writeString(this.nom_client,dos);
					
					// String
				
						writeString(this.prenom_client,dos);
					
					// String
				
						writeString(this.type_rejet,dos);
					
					// String
				
						writeString(this.message_log,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id_rejet_dm1);
					
					// Integer
				
						writeInteger(this.id_preparation,dos);
					
					// java.util.Date
				
						writeDate(this.date_debut_preparation,dos);
					
					// java.util.Date
				
						writeDate(this.date_fin_preparation,dos);
					
					// Integer
				
						writeInteger(this.id_moyen_paiement,dos);
					
					// String
				
						writeString(this.code_moyen_paiement,dos);
					
					// String
				
						writeString(this.livelle_moyen_paiement,dos);
					
					// Integer
				
						writeInteger(this.id_menu,dos);
					
					// String
				
						writeString(this.code_menu,dos);
					
					// String
				
						writeString(this.libelle_menu,dos);
					
					// Integer
				
						writeInteger(this.nombre_articles,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.temps_theo_preparation);
					
					// Integer
				
						writeInteger(this.id_commande,dos);
					
					// Integer
				
						writeInteger(this.numero_commande,dos);
					
					// java.util.Date
				
						writeDate(this.date_commande,dos);
					
					// Float
				
						if(this.montant_total == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.montant_total);
		            	}
					
					// Integer
				
						writeInteger(this.id_adresse_norm_restaurant,dos);
					
					// String
				
						writeString(this.numero_voie_restau,dos);
					
					// String
				
						writeString(this.nom_voie_restau,dos);
					
					// String
				
						writeString(this.code_postal_restau,dos);
					
					// String
				
						writeString(this.nom_ville_restau,dos);
					
					// String
				
						writeString(this.longitude_restau,dos);
					
					// String
				
						writeString(this.latitude_restau,dos);
					
					// Integer
				
						writeInteger(this.id_adresse_restaurant,dos);
					
					// String
				
						writeString(this.adresse_restaurant,dos);
					
					// Integer
				
						writeInteger(this.id_restaurant,dos);
					
					// String
				
						writeString(this.code_restaurant,dos);
					
					// String
				
						writeString(this.raison_sociale_restaurant,dos);
					
					// Integer
				
						writeInteger(this.id_adresse_norm_client,dos);
					
					// String
				
						writeString(this.numero_voie,dos);
					
					// String
				
						writeString(this.nom_voie,dos);
					
					// String
				
						writeString(this.code_postal,dos);
					
					// String
				
						writeString(this.nom_ville,dos);
					
					// String
				
						writeString(this.longitude,dos);
					
					// String
				
						writeString(this.latitude,dos);
					
					// Integer
				
						writeInteger(this.id_adresse_client,dos);
					
					// String
				
						writeString(this.adresse_client,dos);
					
					// Integer
				
						writeInteger(this.id_client,dos);
					
					// String
				
						writeString(this.nom_client,dos);
					
					// String
				
						writeString(this.prenom_client,dos);
					
					// String
				
						writeString(this.type_rejet,dos);
					
					// String
				
						writeString(this.message_log,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id_rejet_dm1="+String.valueOf(id_rejet_dm1));
		sb.append(",id_preparation="+String.valueOf(id_preparation));
		sb.append(",date_debut_preparation="+String.valueOf(date_debut_preparation));
		sb.append(",date_fin_preparation="+String.valueOf(date_fin_preparation));
		sb.append(",id_moyen_paiement="+String.valueOf(id_moyen_paiement));
		sb.append(",code_moyen_paiement="+code_moyen_paiement);
		sb.append(",livelle_moyen_paiement="+livelle_moyen_paiement);
		sb.append(",id_menu="+String.valueOf(id_menu));
		sb.append(",code_menu="+code_menu);
		sb.append(",libelle_menu="+libelle_menu);
		sb.append(",nombre_articles="+String.valueOf(nombre_articles));
		sb.append(",temps_theo_preparation="+String.valueOf(temps_theo_preparation));
		sb.append(",id_commande="+String.valueOf(id_commande));
		sb.append(",numero_commande="+String.valueOf(numero_commande));
		sb.append(",date_commande="+String.valueOf(date_commande));
		sb.append(",montant_total="+String.valueOf(montant_total));
		sb.append(",id_adresse_norm_restaurant="+String.valueOf(id_adresse_norm_restaurant));
		sb.append(",numero_voie_restau="+numero_voie_restau);
		sb.append(",nom_voie_restau="+nom_voie_restau);
		sb.append(",code_postal_restau="+code_postal_restau);
		sb.append(",nom_ville_restau="+nom_ville_restau);
		sb.append(",longitude_restau="+longitude_restau);
		sb.append(",latitude_restau="+latitude_restau);
		sb.append(",id_adresse_restaurant="+String.valueOf(id_adresse_restaurant));
		sb.append(",adresse_restaurant="+adresse_restaurant);
		sb.append(",id_restaurant="+String.valueOf(id_restaurant));
		sb.append(",code_restaurant="+code_restaurant);
		sb.append(",raison_sociale_restaurant="+raison_sociale_restaurant);
		sb.append(",id_adresse_norm_client="+String.valueOf(id_adresse_norm_client));
		sb.append(",numero_voie="+numero_voie);
		sb.append(",nom_voie="+nom_voie);
		sb.append(",code_postal="+code_postal);
		sb.append(",nom_ville="+nom_ville);
		sb.append(",longitude="+longitude);
		sb.append(",latitude="+latitude);
		sb.append(",id_adresse_client="+String.valueOf(id_adresse_client));
		sb.append(",adresse_client="+adresse_client);
		sb.append(",id_client="+String.valueOf(id_client));
		sb.append(",nom_client="+nom_client);
		sb.append(",prenom_client="+prenom_client);
		sb.append(",type_rejet="+type_rejet);
		sb.append(",message_log="+message_log);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(alimt_rejet_doublonsStruct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.id_rejet_dm1, other.id_rejet_dm1);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class alim_rejet_code_posta_restauStruct implements routines.system.IPersistableRow<alim_rejet_code_posta_restauStruct> {
    final static byte[] commonByteArrayLock_ALIMENTATION_DM1_C_ALIM_ODS_REJET = new byte[0];
    static byte[] commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int id_rejet_dm1;

				public int getId_rejet_dm1 () {
					return this.id_rejet_dm1;
				}
				
			    public Integer id_preparation;

				public Integer getId_preparation () {
					return this.id_preparation;
				}
				
			    public java.util.Date date_debut_preparation;

				public java.util.Date getDate_debut_preparation () {
					return this.date_debut_preparation;
				}
				
			    public java.util.Date date_fin_preparation;

				public java.util.Date getDate_fin_preparation () {
					return this.date_fin_preparation;
				}
				
			    public Integer id_moyen_paiement;

				public Integer getId_moyen_paiement () {
					return this.id_moyen_paiement;
				}
				
			    public String code_moyen_paiement;

				public String getCode_moyen_paiement () {
					return this.code_moyen_paiement;
				}
				
			    public String livelle_moyen_paiement;

				public String getLivelle_moyen_paiement () {
					return this.livelle_moyen_paiement;
				}
				
			    public Integer id_menu;

				public Integer getId_menu () {
					return this.id_menu;
				}
				
			    public String code_menu;

				public String getCode_menu () {
					return this.code_menu;
				}
				
			    public String libelle_menu;

				public String getLibelle_menu () {
					return this.libelle_menu;
				}
				
			    public Integer nombre_articles;

				public Integer getNombre_articles () {
					return this.nombre_articles;
				}
				
			    public BigDecimal temps_theo_preparation;

				public BigDecimal getTemps_theo_preparation () {
					return this.temps_theo_preparation;
				}
				
			    public Integer id_commande;

				public Integer getId_commande () {
					return this.id_commande;
				}
				
			    public Integer numero_commande;

				public Integer getNumero_commande () {
					return this.numero_commande;
				}
				
			    public java.util.Date date_commande;

				public java.util.Date getDate_commande () {
					return this.date_commande;
				}
				
			    public Float montant_total;

				public Float getMontant_total () {
					return this.montant_total;
				}
				
			    public Integer id_adresse_norm_restaurant;

				public Integer getId_adresse_norm_restaurant () {
					return this.id_adresse_norm_restaurant;
				}
				
			    public String numero_voie_restau;

				public String getNumero_voie_restau () {
					return this.numero_voie_restau;
				}
				
			    public String nom_voie_restau;

				public String getNom_voie_restau () {
					return this.nom_voie_restau;
				}
				
			    public String code_postal_restau;

				public String getCode_postal_restau () {
					return this.code_postal_restau;
				}
				
			    public String nom_ville_restau;

				public String getNom_ville_restau () {
					return this.nom_ville_restau;
				}
				
			    public String longitude_restau;

				public String getLongitude_restau () {
					return this.longitude_restau;
				}
				
			    public String latitude_restau;

				public String getLatitude_restau () {
					return this.latitude_restau;
				}
				
			    public Integer id_adresse_restaurant;

				public Integer getId_adresse_restaurant () {
					return this.id_adresse_restaurant;
				}
				
			    public String adresse_restaurant;

				public String getAdresse_restaurant () {
					return this.adresse_restaurant;
				}
				
			    public Integer id_restaurant;

				public Integer getId_restaurant () {
					return this.id_restaurant;
				}
				
			    public String code_restaurant;

				public String getCode_restaurant () {
					return this.code_restaurant;
				}
				
			    public String raison_sociale_restaurant;

				public String getRaison_sociale_restaurant () {
					return this.raison_sociale_restaurant;
				}
				
			    public Integer id_adresse_norm_client;

				public Integer getId_adresse_norm_client () {
					return this.id_adresse_norm_client;
				}
				
			    public String numero_voie;

				public String getNumero_voie () {
					return this.numero_voie;
				}
				
			    public String nom_voie;

				public String getNom_voie () {
					return this.nom_voie;
				}
				
			    public String code_postal;

				public String getCode_postal () {
					return this.code_postal;
				}
				
			    public String nom_ville;

				public String getNom_ville () {
					return this.nom_ville;
				}
				
			    public String longitude;

				public String getLongitude () {
					return this.longitude;
				}
				
			    public String latitude;

				public String getLatitude () {
					return this.latitude;
				}
				
			    public Integer id_adresse_client;

				public Integer getId_adresse_client () {
					return this.id_adresse_client;
				}
				
			    public String adresse_client;

				public String getAdresse_client () {
					return this.adresse_client;
				}
				
			    public Integer id_client;

				public Integer getId_client () {
					return this.id_client;
				}
				
			    public String nom_client;

				public String getNom_client () {
					return this.nom_client;
				}
				
			    public String prenom_client;

				public String getPrenom_client () {
					return this.prenom_client;
				}
				
			    public String type_rejet;

				public String getType_rejet () {
					return this.type_rejet;
				}
				
			    public String message_log;

				public String getMessage_log () {
					return this.message_log;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.id_rejet_dm1;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final alim_rejet_code_posta_restauStruct other = (alim_rejet_code_posta_restauStruct) obj;
		
						if (this.id_rejet_dm1 != other.id_rejet_dm1)
							return false;
					

		return true;
    }

	public void copyDataTo(alim_rejet_code_posta_restauStruct other) {

		other.id_rejet_dm1 = this.id_rejet_dm1;
	            other.id_preparation = this.id_preparation;
	            other.date_debut_preparation = this.date_debut_preparation;
	            other.date_fin_preparation = this.date_fin_preparation;
	            other.id_moyen_paiement = this.id_moyen_paiement;
	            other.code_moyen_paiement = this.code_moyen_paiement;
	            other.livelle_moyen_paiement = this.livelle_moyen_paiement;
	            other.id_menu = this.id_menu;
	            other.code_menu = this.code_menu;
	            other.libelle_menu = this.libelle_menu;
	            other.nombre_articles = this.nombre_articles;
	            other.temps_theo_preparation = this.temps_theo_preparation;
	            other.id_commande = this.id_commande;
	            other.numero_commande = this.numero_commande;
	            other.date_commande = this.date_commande;
	            other.montant_total = this.montant_total;
	            other.id_adresse_norm_restaurant = this.id_adresse_norm_restaurant;
	            other.numero_voie_restau = this.numero_voie_restau;
	            other.nom_voie_restau = this.nom_voie_restau;
	            other.code_postal_restau = this.code_postal_restau;
	            other.nom_ville_restau = this.nom_ville_restau;
	            other.longitude_restau = this.longitude_restau;
	            other.latitude_restau = this.latitude_restau;
	            other.id_adresse_restaurant = this.id_adresse_restaurant;
	            other.adresse_restaurant = this.adresse_restaurant;
	            other.id_restaurant = this.id_restaurant;
	            other.code_restaurant = this.code_restaurant;
	            other.raison_sociale_restaurant = this.raison_sociale_restaurant;
	            other.id_adresse_norm_client = this.id_adresse_norm_client;
	            other.numero_voie = this.numero_voie;
	            other.nom_voie = this.nom_voie;
	            other.code_postal = this.code_postal;
	            other.nom_ville = this.nom_ville;
	            other.longitude = this.longitude;
	            other.latitude = this.latitude;
	            other.id_adresse_client = this.id_adresse_client;
	            other.adresse_client = this.adresse_client;
	            other.id_client = this.id_client;
	            other.nom_client = this.nom_client;
	            other.prenom_client = this.prenom_client;
	            other.type_rejet = this.type_rejet;
	            other.message_log = this.message_log;
	            
	}

	public void copyKeysDataTo(alim_rejet_code_posta_restauStruct other) {

		other.id_rejet_dm1 = this.id_rejet_dm1;
	            	
	}



	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET.length == 0) {
   					commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET.length == 0) {
   					commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_DM1_C_ALIM_ODS_REJET) {

        	try {

        		int length = 0;
		
			        this.id_rejet_dm1 = dis.readInt();
					
						this.id_preparation = readInteger(dis);
					
					this.date_debut_preparation = readDate(dis);
					
					this.date_fin_preparation = readDate(dis);
					
						this.id_moyen_paiement = readInteger(dis);
					
					this.code_moyen_paiement = readString(dis);
					
					this.livelle_moyen_paiement = readString(dis);
					
						this.id_menu = readInteger(dis);
					
					this.code_menu = readString(dis);
					
					this.libelle_menu = readString(dis);
					
						this.nombre_articles = readInteger(dis);
					
						this.temps_theo_preparation = (BigDecimal) dis.readObject();
					
						this.id_commande = readInteger(dis);
					
						this.numero_commande = readInteger(dis);
					
					this.date_commande = readDate(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.montant_total = null;
           				} else {
           			    	this.montant_total = dis.readFloat();
           				}
					
						this.id_adresse_norm_restaurant = readInteger(dis);
					
					this.numero_voie_restau = readString(dis);
					
					this.nom_voie_restau = readString(dis);
					
					this.code_postal_restau = readString(dis);
					
					this.nom_ville_restau = readString(dis);
					
					this.longitude_restau = readString(dis);
					
					this.latitude_restau = readString(dis);
					
						this.id_adresse_restaurant = readInteger(dis);
					
					this.adresse_restaurant = readString(dis);
					
						this.id_restaurant = readInteger(dis);
					
					this.code_restaurant = readString(dis);
					
					this.raison_sociale_restaurant = readString(dis);
					
						this.id_adresse_norm_client = readInteger(dis);
					
					this.numero_voie = readString(dis);
					
					this.nom_voie = readString(dis);
					
					this.code_postal = readString(dis);
					
					this.nom_ville = readString(dis);
					
					this.longitude = readString(dis);
					
					this.latitude = readString(dis);
					
						this.id_adresse_client = readInteger(dis);
					
					this.adresse_client = readString(dis);
					
						this.id_client = readInteger(dis);
					
					this.nom_client = readString(dis);
					
					this.prenom_client = readString(dis);
					
					this.type_rejet = readString(dis);
					
					this.message_log = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_DM1_C_ALIM_ODS_REJET) {

        	try {

        		int length = 0;
		
			        this.id_rejet_dm1 = dis.readInt();
					
						this.id_preparation = readInteger(dis);
					
					this.date_debut_preparation = readDate(dis);
					
					this.date_fin_preparation = readDate(dis);
					
						this.id_moyen_paiement = readInteger(dis);
					
					this.code_moyen_paiement = readString(dis);
					
					this.livelle_moyen_paiement = readString(dis);
					
						this.id_menu = readInteger(dis);
					
					this.code_menu = readString(dis);
					
					this.libelle_menu = readString(dis);
					
						this.nombre_articles = readInteger(dis);
					
						this.temps_theo_preparation = (BigDecimal) dis.readObject();
					
						this.id_commande = readInteger(dis);
					
						this.numero_commande = readInteger(dis);
					
					this.date_commande = readDate(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.montant_total = null;
           				} else {
           			    	this.montant_total = dis.readFloat();
           				}
					
						this.id_adresse_norm_restaurant = readInteger(dis);
					
					this.numero_voie_restau = readString(dis);
					
					this.nom_voie_restau = readString(dis);
					
					this.code_postal_restau = readString(dis);
					
					this.nom_ville_restau = readString(dis);
					
					this.longitude_restau = readString(dis);
					
					this.latitude_restau = readString(dis);
					
						this.id_adresse_restaurant = readInteger(dis);
					
					this.adresse_restaurant = readString(dis);
					
						this.id_restaurant = readInteger(dis);
					
					this.code_restaurant = readString(dis);
					
					this.raison_sociale_restaurant = readString(dis);
					
						this.id_adresse_norm_client = readInteger(dis);
					
					this.numero_voie = readString(dis);
					
					this.nom_voie = readString(dis);
					
					this.code_postal = readString(dis);
					
					this.nom_ville = readString(dis);
					
					this.longitude = readString(dis);
					
					this.latitude = readString(dis);
					
						this.id_adresse_client = readInteger(dis);
					
					this.adresse_client = readString(dis);
					
						this.id_client = readInteger(dis);
					
					this.nom_client = readString(dis);
					
					this.prenom_client = readString(dis);
					
					this.type_rejet = readString(dis);
					
					this.message_log = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id_rejet_dm1);
					
					// Integer
				
						writeInteger(this.id_preparation,dos);
					
					// java.util.Date
				
						writeDate(this.date_debut_preparation,dos);
					
					// java.util.Date
				
						writeDate(this.date_fin_preparation,dos);
					
					// Integer
				
						writeInteger(this.id_moyen_paiement,dos);
					
					// String
				
						writeString(this.code_moyen_paiement,dos);
					
					// String
				
						writeString(this.livelle_moyen_paiement,dos);
					
					// Integer
				
						writeInteger(this.id_menu,dos);
					
					// String
				
						writeString(this.code_menu,dos);
					
					// String
				
						writeString(this.libelle_menu,dos);
					
					// Integer
				
						writeInteger(this.nombre_articles,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.temps_theo_preparation);
					
					// Integer
				
						writeInteger(this.id_commande,dos);
					
					// Integer
				
						writeInteger(this.numero_commande,dos);
					
					// java.util.Date
				
						writeDate(this.date_commande,dos);
					
					// Float
				
						if(this.montant_total == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.montant_total);
		            	}
					
					// Integer
				
						writeInteger(this.id_adresse_norm_restaurant,dos);
					
					// String
				
						writeString(this.numero_voie_restau,dos);
					
					// String
				
						writeString(this.nom_voie_restau,dos);
					
					// String
				
						writeString(this.code_postal_restau,dos);
					
					// String
				
						writeString(this.nom_ville_restau,dos);
					
					// String
				
						writeString(this.longitude_restau,dos);
					
					// String
				
						writeString(this.latitude_restau,dos);
					
					// Integer
				
						writeInteger(this.id_adresse_restaurant,dos);
					
					// String
				
						writeString(this.adresse_restaurant,dos);
					
					// Integer
				
						writeInteger(this.id_restaurant,dos);
					
					// String
				
						writeString(this.code_restaurant,dos);
					
					// String
				
						writeString(this.raison_sociale_restaurant,dos);
					
					// Integer
				
						writeInteger(this.id_adresse_norm_client,dos);
					
					// String
				
						writeString(this.numero_voie,dos);
					
					// String
				
						writeString(this.nom_voie,dos);
					
					// String
				
						writeString(this.code_postal,dos);
					
					// String
				
						writeString(this.nom_ville,dos);
					
					// String
				
						writeString(this.longitude,dos);
					
					// String
				
						writeString(this.latitude,dos);
					
					// Integer
				
						writeInteger(this.id_adresse_client,dos);
					
					// String
				
						writeString(this.adresse_client,dos);
					
					// Integer
				
						writeInteger(this.id_client,dos);
					
					// String
				
						writeString(this.nom_client,dos);
					
					// String
				
						writeString(this.prenom_client,dos);
					
					// String
				
						writeString(this.type_rejet,dos);
					
					// String
				
						writeString(this.message_log,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id_rejet_dm1);
					
					// Integer
				
						writeInteger(this.id_preparation,dos);
					
					// java.util.Date
				
						writeDate(this.date_debut_preparation,dos);
					
					// java.util.Date
				
						writeDate(this.date_fin_preparation,dos);
					
					// Integer
				
						writeInteger(this.id_moyen_paiement,dos);
					
					// String
				
						writeString(this.code_moyen_paiement,dos);
					
					// String
				
						writeString(this.livelle_moyen_paiement,dos);
					
					// Integer
				
						writeInteger(this.id_menu,dos);
					
					// String
				
						writeString(this.code_menu,dos);
					
					// String
				
						writeString(this.libelle_menu,dos);
					
					// Integer
				
						writeInteger(this.nombre_articles,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.temps_theo_preparation);
					
					// Integer
				
						writeInteger(this.id_commande,dos);
					
					// Integer
				
						writeInteger(this.numero_commande,dos);
					
					// java.util.Date
				
						writeDate(this.date_commande,dos);
					
					// Float
				
						if(this.montant_total == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.montant_total);
		            	}
					
					// Integer
				
						writeInteger(this.id_adresse_norm_restaurant,dos);
					
					// String
				
						writeString(this.numero_voie_restau,dos);
					
					// String
				
						writeString(this.nom_voie_restau,dos);
					
					// String
				
						writeString(this.code_postal_restau,dos);
					
					// String
				
						writeString(this.nom_ville_restau,dos);
					
					// String
				
						writeString(this.longitude_restau,dos);
					
					// String
				
						writeString(this.latitude_restau,dos);
					
					// Integer
				
						writeInteger(this.id_adresse_restaurant,dos);
					
					// String
				
						writeString(this.adresse_restaurant,dos);
					
					// Integer
				
						writeInteger(this.id_restaurant,dos);
					
					// String
				
						writeString(this.code_restaurant,dos);
					
					// String
				
						writeString(this.raison_sociale_restaurant,dos);
					
					// Integer
				
						writeInteger(this.id_adresse_norm_client,dos);
					
					// String
				
						writeString(this.numero_voie,dos);
					
					// String
				
						writeString(this.nom_voie,dos);
					
					// String
				
						writeString(this.code_postal,dos);
					
					// String
				
						writeString(this.nom_ville,dos);
					
					// String
				
						writeString(this.longitude,dos);
					
					// String
				
						writeString(this.latitude,dos);
					
					// Integer
				
						writeInteger(this.id_adresse_client,dos);
					
					// String
				
						writeString(this.adresse_client,dos);
					
					// Integer
				
						writeInteger(this.id_client,dos);
					
					// String
				
						writeString(this.nom_client,dos);
					
					// String
				
						writeString(this.prenom_client,dos);
					
					// String
				
						writeString(this.type_rejet,dos);
					
					// String
				
						writeString(this.message_log,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id_rejet_dm1="+String.valueOf(id_rejet_dm1));
		sb.append(",id_preparation="+String.valueOf(id_preparation));
		sb.append(",date_debut_preparation="+String.valueOf(date_debut_preparation));
		sb.append(",date_fin_preparation="+String.valueOf(date_fin_preparation));
		sb.append(",id_moyen_paiement="+String.valueOf(id_moyen_paiement));
		sb.append(",code_moyen_paiement="+code_moyen_paiement);
		sb.append(",livelle_moyen_paiement="+livelle_moyen_paiement);
		sb.append(",id_menu="+String.valueOf(id_menu));
		sb.append(",code_menu="+code_menu);
		sb.append(",libelle_menu="+libelle_menu);
		sb.append(",nombre_articles="+String.valueOf(nombre_articles));
		sb.append(",temps_theo_preparation="+String.valueOf(temps_theo_preparation));
		sb.append(",id_commande="+String.valueOf(id_commande));
		sb.append(",numero_commande="+String.valueOf(numero_commande));
		sb.append(",date_commande="+String.valueOf(date_commande));
		sb.append(",montant_total="+String.valueOf(montant_total));
		sb.append(",id_adresse_norm_restaurant="+String.valueOf(id_adresse_norm_restaurant));
		sb.append(",numero_voie_restau="+numero_voie_restau);
		sb.append(",nom_voie_restau="+nom_voie_restau);
		sb.append(",code_postal_restau="+code_postal_restau);
		sb.append(",nom_ville_restau="+nom_ville_restau);
		sb.append(",longitude_restau="+longitude_restau);
		sb.append(",latitude_restau="+latitude_restau);
		sb.append(",id_adresse_restaurant="+String.valueOf(id_adresse_restaurant));
		sb.append(",adresse_restaurant="+adresse_restaurant);
		sb.append(",id_restaurant="+String.valueOf(id_restaurant));
		sb.append(",code_restaurant="+code_restaurant);
		sb.append(",raison_sociale_restaurant="+raison_sociale_restaurant);
		sb.append(",id_adresse_norm_client="+String.valueOf(id_adresse_norm_client));
		sb.append(",numero_voie="+numero_voie);
		sb.append(",nom_voie="+nom_voie);
		sb.append(",code_postal="+code_postal);
		sb.append(",nom_ville="+nom_ville);
		sb.append(",longitude="+longitude);
		sb.append(",latitude="+latitude);
		sb.append(",id_adresse_client="+String.valueOf(id_adresse_client));
		sb.append(",adresse_client="+adresse_client);
		sb.append(",id_client="+String.valueOf(id_client));
		sb.append(",nom_client="+nom_client);
		sb.append(",prenom_client="+prenom_client);
		sb.append(",type_rejet="+type_rejet);
		sb.append(",message_log="+message_log);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(alim_rejet_code_posta_restauStruct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.id_rejet_dm1, other.id_rejet_dm1);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class alim_odsStruct implements routines.system.IPersistableRow<alim_odsStruct> {
    final static byte[] commonByteArrayLock_ALIMENTATION_DM1_C_ALIM_ODS_REJET = new byte[0];
    static byte[] commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int id_ods_dm1;

				public int getId_ods_dm1 () {
					return this.id_ods_dm1;
				}
				
			    public Integer id_preparation;

				public Integer getId_preparation () {
					return this.id_preparation;
				}
				
			    public java.util.Date date_debut_preparation;

				public java.util.Date getDate_debut_preparation () {
					return this.date_debut_preparation;
				}
				
			    public java.util.Date date_fin_preparation;

				public java.util.Date getDate_fin_preparation () {
					return this.date_fin_preparation;
				}
				
			    public BigDecimal temps_reel_preparation;

				public BigDecimal getTemps_reel_preparation () {
					return this.temps_reel_preparation;
				}
				
			    public Integer id_moyen_paiement;

				public Integer getId_moyen_paiement () {
					return this.id_moyen_paiement;
				}
				
			    public String code_moyen_paiement;

				public String getCode_moyen_paiement () {
					return this.code_moyen_paiement;
				}
				
			    public String livelle_moyen_paiement;

				public String getLivelle_moyen_paiement () {
					return this.livelle_moyen_paiement;
				}
				
			    public Integer id_menu;

				public Integer getId_menu () {
					return this.id_menu;
				}
				
			    public String code_menu;

				public String getCode_menu () {
					return this.code_menu;
				}
				
			    public String libelle_menu;

				public String getLibelle_menu () {
					return this.libelle_menu;
				}
				
			    public Integer nombre_articles;

				public Integer getNombre_articles () {
					return this.nombre_articles;
				}
				
			    public BigDecimal temps_theo_preparation;

				public BigDecimal getTemps_theo_preparation () {
					return this.temps_theo_preparation;
				}
				
			    public Integer id_commande;

				public Integer getId_commande () {
					return this.id_commande;
				}
				
			    public Integer numero_commande;

				public Integer getNumero_commande () {
					return this.numero_commande;
				}
				
			    public java.util.Date date_commande;

				public java.util.Date getDate_commande () {
					return this.date_commande;
				}
				
			    public Float montant_total;

				public Float getMontant_total () {
					return this.montant_total;
				}
				
			    public Integer id_adresse_norm_restaurant;

				public Integer getId_adresse_norm_restaurant () {
					return this.id_adresse_norm_restaurant;
				}
				
			    public String numero_voie_restau;

				public String getNumero_voie_restau () {
					return this.numero_voie_restau;
				}
				
			    public String nom_voie_restau;

				public String getNom_voie_restau () {
					return this.nom_voie_restau;
				}
				
			    public String code_postal_restau;

				public String getCode_postal_restau () {
					return this.code_postal_restau;
				}
				
			    public String nom_ville_restau;

				public String getNom_ville_restau () {
					return this.nom_ville_restau;
				}
				
			    public String longitude_restau;

				public String getLongitude_restau () {
					return this.longitude_restau;
				}
				
			    public String latitude_restau;

				public String getLatitude_restau () {
					return this.latitude_restau;
				}
				
			    public Integer id_adresse_restaurant;

				public Integer getId_adresse_restaurant () {
					return this.id_adresse_restaurant;
				}
				
			    public String adresse_restaurant;

				public String getAdresse_restaurant () {
					return this.adresse_restaurant;
				}
				
			    public Integer id_restaurant;

				public Integer getId_restaurant () {
					return this.id_restaurant;
				}
				
			    public String code_restaurant;

				public String getCode_restaurant () {
					return this.code_restaurant;
				}
				
			    public String raison_sociale_restaurant;

				public String getRaison_sociale_restaurant () {
					return this.raison_sociale_restaurant;
				}
				
			    public Integer id_adresse_norm_client;

				public Integer getId_adresse_norm_client () {
					return this.id_adresse_norm_client;
				}
				
			    public String numero_voie;

				public String getNumero_voie () {
					return this.numero_voie;
				}
				
			    public String nom_voie;

				public String getNom_voie () {
					return this.nom_voie;
				}
				
			    public String code_postal;

				public String getCode_postal () {
					return this.code_postal;
				}
				
			    public String nom_ville;

				public String getNom_ville () {
					return this.nom_ville;
				}
				
			    public String longitude;

				public String getLongitude () {
					return this.longitude;
				}
				
			    public String latitude;

				public String getLatitude () {
					return this.latitude;
				}
				
			    public Integer id_adresse_client;

				public Integer getId_adresse_client () {
					return this.id_adresse_client;
				}
				
			    public String adresse_client;

				public String getAdresse_client () {
					return this.adresse_client;
				}
				
			    public Integer id_client;

				public Integer getId_client () {
					return this.id_client;
				}
				
			    public String nom_client;

				public String getNom_client () {
					return this.nom_client;
				}
				
			    public String prenom_client;

				public String getPrenom_client () {
					return this.prenom_client;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.id_ods_dm1;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final alim_odsStruct other = (alim_odsStruct) obj;
		
						if (this.id_ods_dm1 != other.id_ods_dm1)
							return false;
					

		return true;
    }

	public void copyDataTo(alim_odsStruct other) {

		other.id_ods_dm1 = this.id_ods_dm1;
	            other.id_preparation = this.id_preparation;
	            other.date_debut_preparation = this.date_debut_preparation;
	            other.date_fin_preparation = this.date_fin_preparation;
	            other.temps_reel_preparation = this.temps_reel_preparation;
	            other.id_moyen_paiement = this.id_moyen_paiement;
	            other.code_moyen_paiement = this.code_moyen_paiement;
	            other.livelle_moyen_paiement = this.livelle_moyen_paiement;
	            other.id_menu = this.id_menu;
	            other.code_menu = this.code_menu;
	            other.libelle_menu = this.libelle_menu;
	            other.nombre_articles = this.nombre_articles;
	            other.temps_theo_preparation = this.temps_theo_preparation;
	            other.id_commande = this.id_commande;
	            other.numero_commande = this.numero_commande;
	            other.date_commande = this.date_commande;
	            other.montant_total = this.montant_total;
	            other.id_adresse_norm_restaurant = this.id_adresse_norm_restaurant;
	            other.numero_voie_restau = this.numero_voie_restau;
	            other.nom_voie_restau = this.nom_voie_restau;
	            other.code_postal_restau = this.code_postal_restau;
	            other.nom_ville_restau = this.nom_ville_restau;
	            other.longitude_restau = this.longitude_restau;
	            other.latitude_restau = this.latitude_restau;
	            other.id_adresse_restaurant = this.id_adresse_restaurant;
	            other.adresse_restaurant = this.adresse_restaurant;
	            other.id_restaurant = this.id_restaurant;
	            other.code_restaurant = this.code_restaurant;
	            other.raison_sociale_restaurant = this.raison_sociale_restaurant;
	            other.id_adresse_norm_client = this.id_adresse_norm_client;
	            other.numero_voie = this.numero_voie;
	            other.nom_voie = this.nom_voie;
	            other.code_postal = this.code_postal;
	            other.nom_ville = this.nom_ville;
	            other.longitude = this.longitude;
	            other.latitude = this.latitude;
	            other.id_adresse_client = this.id_adresse_client;
	            other.adresse_client = this.adresse_client;
	            other.id_client = this.id_client;
	            other.nom_client = this.nom_client;
	            other.prenom_client = this.prenom_client;
	            
	}

	public void copyKeysDataTo(alim_odsStruct other) {

		other.id_ods_dm1 = this.id_ods_dm1;
	            	
	}



	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET.length == 0) {
   					commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET.length == 0) {
   					commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_DM1_C_ALIM_ODS_REJET) {

        	try {

        		int length = 0;
		
			        this.id_ods_dm1 = dis.readInt();
					
						this.id_preparation = readInteger(dis);
					
					this.date_debut_preparation = readDate(dis);
					
					this.date_fin_preparation = readDate(dis);
					
						this.temps_reel_preparation = (BigDecimal) dis.readObject();
					
						this.id_moyen_paiement = readInteger(dis);
					
					this.code_moyen_paiement = readString(dis);
					
					this.livelle_moyen_paiement = readString(dis);
					
						this.id_menu = readInteger(dis);
					
					this.code_menu = readString(dis);
					
					this.libelle_menu = readString(dis);
					
						this.nombre_articles = readInteger(dis);
					
						this.temps_theo_preparation = (BigDecimal) dis.readObject();
					
						this.id_commande = readInteger(dis);
					
						this.numero_commande = readInteger(dis);
					
					this.date_commande = readDate(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.montant_total = null;
           				} else {
           			    	this.montant_total = dis.readFloat();
           				}
					
						this.id_adresse_norm_restaurant = readInteger(dis);
					
					this.numero_voie_restau = readString(dis);
					
					this.nom_voie_restau = readString(dis);
					
					this.code_postal_restau = readString(dis);
					
					this.nom_ville_restau = readString(dis);
					
					this.longitude_restau = readString(dis);
					
					this.latitude_restau = readString(dis);
					
						this.id_adresse_restaurant = readInteger(dis);
					
					this.adresse_restaurant = readString(dis);
					
						this.id_restaurant = readInteger(dis);
					
					this.code_restaurant = readString(dis);
					
					this.raison_sociale_restaurant = readString(dis);
					
						this.id_adresse_norm_client = readInteger(dis);
					
					this.numero_voie = readString(dis);
					
					this.nom_voie = readString(dis);
					
					this.code_postal = readString(dis);
					
					this.nom_ville = readString(dis);
					
					this.longitude = readString(dis);
					
					this.latitude = readString(dis);
					
						this.id_adresse_client = readInteger(dis);
					
					this.adresse_client = readString(dis);
					
						this.id_client = readInteger(dis);
					
					this.nom_client = readString(dis);
					
					this.prenom_client = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_DM1_C_ALIM_ODS_REJET) {

        	try {

        		int length = 0;
		
			        this.id_ods_dm1 = dis.readInt();
					
						this.id_preparation = readInteger(dis);
					
					this.date_debut_preparation = readDate(dis);
					
					this.date_fin_preparation = readDate(dis);
					
						this.temps_reel_preparation = (BigDecimal) dis.readObject();
					
						this.id_moyen_paiement = readInteger(dis);
					
					this.code_moyen_paiement = readString(dis);
					
					this.livelle_moyen_paiement = readString(dis);
					
						this.id_menu = readInteger(dis);
					
					this.code_menu = readString(dis);
					
					this.libelle_menu = readString(dis);
					
						this.nombre_articles = readInteger(dis);
					
						this.temps_theo_preparation = (BigDecimal) dis.readObject();
					
						this.id_commande = readInteger(dis);
					
						this.numero_commande = readInteger(dis);
					
					this.date_commande = readDate(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.montant_total = null;
           				} else {
           			    	this.montant_total = dis.readFloat();
           				}
					
						this.id_adresse_norm_restaurant = readInteger(dis);
					
					this.numero_voie_restau = readString(dis);
					
					this.nom_voie_restau = readString(dis);
					
					this.code_postal_restau = readString(dis);
					
					this.nom_ville_restau = readString(dis);
					
					this.longitude_restau = readString(dis);
					
					this.latitude_restau = readString(dis);
					
						this.id_adresse_restaurant = readInteger(dis);
					
					this.adresse_restaurant = readString(dis);
					
						this.id_restaurant = readInteger(dis);
					
					this.code_restaurant = readString(dis);
					
					this.raison_sociale_restaurant = readString(dis);
					
						this.id_adresse_norm_client = readInteger(dis);
					
					this.numero_voie = readString(dis);
					
					this.nom_voie = readString(dis);
					
					this.code_postal = readString(dis);
					
					this.nom_ville = readString(dis);
					
					this.longitude = readString(dis);
					
					this.latitude = readString(dis);
					
						this.id_adresse_client = readInteger(dis);
					
					this.adresse_client = readString(dis);
					
						this.id_client = readInteger(dis);
					
					this.nom_client = readString(dis);
					
					this.prenom_client = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id_ods_dm1);
					
					// Integer
				
						writeInteger(this.id_preparation,dos);
					
					// java.util.Date
				
						writeDate(this.date_debut_preparation,dos);
					
					// java.util.Date
				
						writeDate(this.date_fin_preparation,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.temps_reel_preparation);
					
					// Integer
				
						writeInteger(this.id_moyen_paiement,dos);
					
					// String
				
						writeString(this.code_moyen_paiement,dos);
					
					// String
				
						writeString(this.livelle_moyen_paiement,dos);
					
					// Integer
				
						writeInteger(this.id_menu,dos);
					
					// String
				
						writeString(this.code_menu,dos);
					
					// String
				
						writeString(this.libelle_menu,dos);
					
					// Integer
				
						writeInteger(this.nombre_articles,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.temps_theo_preparation);
					
					// Integer
				
						writeInteger(this.id_commande,dos);
					
					// Integer
				
						writeInteger(this.numero_commande,dos);
					
					// java.util.Date
				
						writeDate(this.date_commande,dos);
					
					// Float
				
						if(this.montant_total == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.montant_total);
		            	}
					
					// Integer
				
						writeInteger(this.id_adresse_norm_restaurant,dos);
					
					// String
				
						writeString(this.numero_voie_restau,dos);
					
					// String
				
						writeString(this.nom_voie_restau,dos);
					
					// String
				
						writeString(this.code_postal_restau,dos);
					
					// String
				
						writeString(this.nom_ville_restau,dos);
					
					// String
				
						writeString(this.longitude_restau,dos);
					
					// String
				
						writeString(this.latitude_restau,dos);
					
					// Integer
				
						writeInteger(this.id_adresse_restaurant,dos);
					
					// String
				
						writeString(this.adresse_restaurant,dos);
					
					// Integer
				
						writeInteger(this.id_restaurant,dos);
					
					// String
				
						writeString(this.code_restaurant,dos);
					
					// String
				
						writeString(this.raison_sociale_restaurant,dos);
					
					// Integer
				
						writeInteger(this.id_adresse_norm_client,dos);
					
					// String
				
						writeString(this.numero_voie,dos);
					
					// String
				
						writeString(this.nom_voie,dos);
					
					// String
				
						writeString(this.code_postal,dos);
					
					// String
				
						writeString(this.nom_ville,dos);
					
					// String
				
						writeString(this.longitude,dos);
					
					// String
				
						writeString(this.latitude,dos);
					
					// Integer
				
						writeInteger(this.id_adresse_client,dos);
					
					// String
				
						writeString(this.adresse_client,dos);
					
					// Integer
				
						writeInteger(this.id_client,dos);
					
					// String
				
						writeString(this.nom_client,dos);
					
					// String
				
						writeString(this.prenom_client,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id_ods_dm1);
					
					// Integer
				
						writeInteger(this.id_preparation,dos);
					
					// java.util.Date
				
						writeDate(this.date_debut_preparation,dos);
					
					// java.util.Date
				
						writeDate(this.date_fin_preparation,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.temps_reel_preparation);
					
					// Integer
				
						writeInteger(this.id_moyen_paiement,dos);
					
					// String
				
						writeString(this.code_moyen_paiement,dos);
					
					// String
				
						writeString(this.livelle_moyen_paiement,dos);
					
					// Integer
				
						writeInteger(this.id_menu,dos);
					
					// String
				
						writeString(this.code_menu,dos);
					
					// String
				
						writeString(this.libelle_menu,dos);
					
					// Integer
				
						writeInteger(this.nombre_articles,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.temps_theo_preparation);
					
					// Integer
				
						writeInteger(this.id_commande,dos);
					
					// Integer
				
						writeInteger(this.numero_commande,dos);
					
					// java.util.Date
				
						writeDate(this.date_commande,dos);
					
					// Float
				
						if(this.montant_total == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.montant_total);
		            	}
					
					// Integer
				
						writeInteger(this.id_adresse_norm_restaurant,dos);
					
					// String
				
						writeString(this.numero_voie_restau,dos);
					
					// String
				
						writeString(this.nom_voie_restau,dos);
					
					// String
				
						writeString(this.code_postal_restau,dos);
					
					// String
				
						writeString(this.nom_ville_restau,dos);
					
					// String
				
						writeString(this.longitude_restau,dos);
					
					// String
				
						writeString(this.latitude_restau,dos);
					
					// Integer
				
						writeInteger(this.id_adresse_restaurant,dos);
					
					// String
				
						writeString(this.adresse_restaurant,dos);
					
					// Integer
				
						writeInteger(this.id_restaurant,dos);
					
					// String
				
						writeString(this.code_restaurant,dos);
					
					// String
				
						writeString(this.raison_sociale_restaurant,dos);
					
					// Integer
				
						writeInteger(this.id_adresse_norm_client,dos);
					
					// String
				
						writeString(this.numero_voie,dos);
					
					// String
				
						writeString(this.nom_voie,dos);
					
					// String
				
						writeString(this.code_postal,dos);
					
					// String
				
						writeString(this.nom_ville,dos);
					
					// String
				
						writeString(this.longitude,dos);
					
					// String
				
						writeString(this.latitude,dos);
					
					// Integer
				
						writeInteger(this.id_adresse_client,dos);
					
					// String
				
						writeString(this.adresse_client,dos);
					
					// Integer
				
						writeInteger(this.id_client,dos);
					
					// String
				
						writeString(this.nom_client,dos);
					
					// String
				
						writeString(this.prenom_client,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id_ods_dm1="+String.valueOf(id_ods_dm1));
		sb.append(",id_preparation="+String.valueOf(id_preparation));
		sb.append(",date_debut_preparation="+String.valueOf(date_debut_preparation));
		sb.append(",date_fin_preparation="+String.valueOf(date_fin_preparation));
		sb.append(",temps_reel_preparation="+String.valueOf(temps_reel_preparation));
		sb.append(",id_moyen_paiement="+String.valueOf(id_moyen_paiement));
		sb.append(",code_moyen_paiement="+code_moyen_paiement);
		sb.append(",livelle_moyen_paiement="+livelle_moyen_paiement);
		sb.append(",id_menu="+String.valueOf(id_menu));
		sb.append(",code_menu="+code_menu);
		sb.append(",libelle_menu="+libelle_menu);
		sb.append(",nombre_articles="+String.valueOf(nombre_articles));
		sb.append(",temps_theo_preparation="+String.valueOf(temps_theo_preparation));
		sb.append(",id_commande="+String.valueOf(id_commande));
		sb.append(",numero_commande="+String.valueOf(numero_commande));
		sb.append(",date_commande="+String.valueOf(date_commande));
		sb.append(",montant_total="+String.valueOf(montant_total));
		sb.append(",id_adresse_norm_restaurant="+String.valueOf(id_adresse_norm_restaurant));
		sb.append(",numero_voie_restau="+numero_voie_restau);
		sb.append(",nom_voie_restau="+nom_voie_restau);
		sb.append(",code_postal_restau="+code_postal_restau);
		sb.append(",nom_ville_restau="+nom_ville_restau);
		sb.append(",longitude_restau="+longitude_restau);
		sb.append(",latitude_restau="+latitude_restau);
		sb.append(",id_adresse_restaurant="+String.valueOf(id_adresse_restaurant));
		sb.append(",adresse_restaurant="+adresse_restaurant);
		sb.append(",id_restaurant="+String.valueOf(id_restaurant));
		sb.append(",code_restaurant="+code_restaurant);
		sb.append(",raison_sociale_restaurant="+raison_sociale_restaurant);
		sb.append(",id_adresse_norm_client="+String.valueOf(id_adresse_norm_client));
		sb.append(",numero_voie="+numero_voie);
		sb.append(",nom_voie="+nom_voie);
		sb.append(",code_postal="+code_postal);
		sb.append(",nom_ville="+nom_ville);
		sb.append(",longitude="+longitude);
		sb.append(",latitude="+latitude);
		sb.append(",id_adresse_client="+String.valueOf(id_adresse_client));
		sb.append(",adresse_client="+adresse_client);
		sb.append(",id_client="+String.valueOf(id_client));
		sb.append(",nom_client="+nom_client);
		sb.append(",prenom_client="+prenom_client);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(alim_odsStruct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.id_ods_dm1, other.id_ods_dm1);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row5Struct implements routines.system.IPersistableRow<row5Struct> {
    final static byte[] commonByteArrayLock_ALIMENTATION_DM1_C_ALIM_ODS_REJET = new byte[0];
    static byte[] commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET = new byte[0];

	
			    public int id_staging_dm1;

				public int getId_staging_dm1 () {
					return this.id_staging_dm1;
				}
				
			    public Integer id_preparation;

				public Integer getId_preparation () {
					return this.id_preparation;
				}
				
			    public java.util.Date date_debut_preparation;

				public java.util.Date getDate_debut_preparation () {
					return this.date_debut_preparation;
				}
				
			    public java.util.Date date_fin_preparation;

				public java.util.Date getDate_fin_preparation () {
					return this.date_fin_preparation;
				}
				
			    public Integer id_moyen_paiement;

				public Integer getId_moyen_paiement () {
					return this.id_moyen_paiement;
				}
				
			    public String code_moyen_paiement;

				public String getCode_moyen_paiement () {
					return this.code_moyen_paiement;
				}
				
			    public String livelle_moyen_paiement;

				public String getLivelle_moyen_paiement () {
					return this.livelle_moyen_paiement;
				}
				
			    public Integer id_menu;

				public Integer getId_menu () {
					return this.id_menu;
				}
				
			    public String code_menu;

				public String getCode_menu () {
					return this.code_menu;
				}
				
			    public String libelle_menu;

				public String getLibelle_menu () {
					return this.libelle_menu;
				}
				
			    public Integer nombre_articles;

				public Integer getNombre_articles () {
					return this.nombre_articles;
				}
				
			    public BigDecimal temps_theo_preparation;

				public BigDecimal getTemps_theo_preparation () {
					return this.temps_theo_preparation;
				}
				
			    public Integer id_commande;

				public Integer getId_commande () {
					return this.id_commande;
				}
				
			    public Integer numero_commande;

				public Integer getNumero_commande () {
					return this.numero_commande;
				}
				
			    public java.util.Date date_commande;

				public java.util.Date getDate_commande () {
					return this.date_commande;
				}
				
			    public Float montant_total;

				public Float getMontant_total () {
					return this.montant_total;
				}
				
			    public Integer id_adresse_norm_restaurant;

				public Integer getId_adresse_norm_restaurant () {
					return this.id_adresse_norm_restaurant;
				}
				
			    public String numero_voie_restau;

				public String getNumero_voie_restau () {
					return this.numero_voie_restau;
				}
				
			    public String nom_voie_restau;

				public String getNom_voie_restau () {
					return this.nom_voie_restau;
				}
				
			    public String code_postal_restau;

				public String getCode_postal_restau () {
					return this.code_postal_restau;
				}
				
			    public String nom_ville_restau;

				public String getNom_ville_restau () {
					return this.nom_ville_restau;
				}
				
			    public String longitude_restau;

				public String getLongitude_restau () {
					return this.longitude_restau;
				}
				
			    public String latitude_restau;

				public String getLatitude_restau () {
					return this.latitude_restau;
				}
				
			    public Integer id_adresse_restaurant;

				public Integer getId_adresse_restaurant () {
					return this.id_adresse_restaurant;
				}
				
			    public String adresse_restaurant;

				public String getAdresse_restaurant () {
					return this.adresse_restaurant;
				}
				
			    public Integer id_restaurant;

				public Integer getId_restaurant () {
					return this.id_restaurant;
				}
				
			    public String code_restaurant;

				public String getCode_restaurant () {
					return this.code_restaurant;
				}
				
			    public String raison_sociale_restaurant;

				public String getRaison_sociale_restaurant () {
					return this.raison_sociale_restaurant;
				}
				
			    public Integer id_adresse_norm_client;

				public Integer getId_adresse_norm_client () {
					return this.id_adresse_norm_client;
				}
				
			    public String numero_voie;

				public String getNumero_voie () {
					return this.numero_voie;
				}
				
			    public String nom_voie;

				public String getNom_voie () {
					return this.nom_voie;
				}
				
			    public String code_postal;

				public String getCode_postal () {
					return this.code_postal;
				}
				
			    public String nom_ville;

				public String getNom_ville () {
					return this.nom_ville;
				}
				
			    public String longitude;

				public String getLongitude () {
					return this.longitude;
				}
				
			    public String latitude;

				public String getLatitude () {
					return this.latitude;
				}
				
			    public Integer id_adresse_client;

				public Integer getId_adresse_client () {
					return this.id_adresse_client;
				}
				
			    public String adresse_client;

				public String getAdresse_client () {
					return this.adresse_client;
				}
				
			    public Integer id_client;

				public Integer getId_client () {
					return this.id_client;
				}
				
			    public String nom_client;

				public String getNom_client () {
					return this.nom_client;
				}
				
			    public String prenom_client;

				public String getPrenom_client () {
					return this.prenom_client;
				}
				


	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET.length == 0) {
   					commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET.length == 0) {
   					commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_DM1_C_ALIM_ODS_REJET) {

        	try {

        		int length = 0;
		
			        this.id_staging_dm1 = dis.readInt();
					
						this.id_preparation = readInteger(dis);
					
					this.date_debut_preparation = readDate(dis);
					
					this.date_fin_preparation = readDate(dis);
					
						this.id_moyen_paiement = readInteger(dis);
					
					this.code_moyen_paiement = readString(dis);
					
					this.livelle_moyen_paiement = readString(dis);
					
						this.id_menu = readInteger(dis);
					
					this.code_menu = readString(dis);
					
					this.libelle_menu = readString(dis);
					
						this.nombre_articles = readInteger(dis);
					
						this.temps_theo_preparation = (BigDecimal) dis.readObject();
					
						this.id_commande = readInteger(dis);
					
						this.numero_commande = readInteger(dis);
					
					this.date_commande = readDate(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.montant_total = null;
           				} else {
           			    	this.montant_total = dis.readFloat();
           				}
					
						this.id_adresse_norm_restaurant = readInteger(dis);
					
					this.numero_voie_restau = readString(dis);
					
					this.nom_voie_restau = readString(dis);
					
					this.code_postal_restau = readString(dis);
					
					this.nom_ville_restau = readString(dis);
					
					this.longitude_restau = readString(dis);
					
					this.latitude_restau = readString(dis);
					
						this.id_adresse_restaurant = readInteger(dis);
					
					this.adresse_restaurant = readString(dis);
					
						this.id_restaurant = readInteger(dis);
					
					this.code_restaurant = readString(dis);
					
					this.raison_sociale_restaurant = readString(dis);
					
						this.id_adresse_norm_client = readInteger(dis);
					
					this.numero_voie = readString(dis);
					
					this.nom_voie = readString(dis);
					
					this.code_postal = readString(dis);
					
					this.nom_ville = readString(dis);
					
					this.longitude = readString(dis);
					
					this.latitude = readString(dis);
					
						this.id_adresse_client = readInteger(dis);
					
					this.adresse_client = readString(dis);
					
						this.id_client = readInteger(dis);
					
					this.nom_client = readString(dis);
					
					this.prenom_client = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_DM1_C_ALIM_ODS_REJET) {

        	try {

        		int length = 0;
		
			        this.id_staging_dm1 = dis.readInt();
					
						this.id_preparation = readInteger(dis);
					
					this.date_debut_preparation = readDate(dis);
					
					this.date_fin_preparation = readDate(dis);
					
						this.id_moyen_paiement = readInteger(dis);
					
					this.code_moyen_paiement = readString(dis);
					
					this.livelle_moyen_paiement = readString(dis);
					
						this.id_menu = readInteger(dis);
					
					this.code_menu = readString(dis);
					
					this.libelle_menu = readString(dis);
					
						this.nombre_articles = readInteger(dis);
					
						this.temps_theo_preparation = (BigDecimal) dis.readObject();
					
						this.id_commande = readInteger(dis);
					
						this.numero_commande = readInteger(dis);
					
					this.date_commande = readDate(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.montant_total = null;
           				} else {
           			    	this.montant_total = dis.readFloat();
           				}
					
						this.id_adresse_norm_restaurant = readInteger(dis);
					
					this.numero_voie_restau = readString(dis);
					
					this.nom_voie_restau = readString(dis);
					
					this.code_postal_restau = readString(dis);
					
					this.nom_ville_restau = readString(dis);
					
					this.longitude_restau = readString(dis);
					
					this.latitude_restau = readString(dis);
					
						this.id_adresse_restaurant = readInteger(dis);
					
					this.adresse_restaurant = readString(dis);
					
						this.id_restaurant = readInteger(dis);
					
					this.code_restaurant = readString(dis);
					
					this.raison_sociale_restaurant = readString(dis);
					
						this.id_adresse_norm_client = readInteger(dis);
					
					this.numero_voie = readString(dis);
					
					this.nom_voie = readString(dis);
					
					this.code_postal = readString(dis);
					
					this.nom_ville = readString(dis);
					
					this.longitude = readString(dis);
					
					this.latitude = readString(dis);
					
						this.id_adresse_client = readInteger(dis);
					
					this.adresse_client = readString(dis);
					
						this.id_client = readInteger(dis);
					
					this.nom_client = readString(dis);
					
					this.prenom_client = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id_staging_dm1);
					
					// Integer
				
						writeInteger(this.id_preparation,dos);
					
					// java.util.Date
				
						writeDate(this.date_debut_preparation,dos);
					
					// java.util.Date
				
						writeDate(this.date_fin_preparation,dos);
					
					// Integer
				
						writeInteger(this.id_moyen_paiement,dos);
					
					// String
				
						writeString(this.code_moyen_paiement,dos);
					
					// String
				
						writeString(this.livelle_moyen_paiement,dos);
					
					// Integer
				
						writeInteger(this.id_menu,dos);
					
					// String
				
						writeString(this.code_menu,dos);
					
					// String
				
						writeString(this.libelle_menu,dos);
					
					// Integer
				
						writeInteger(this.nombre_articles,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.temps_theo_preparation);
					
					// Integer
				
						writeInteger(this.id_commande,dos);
					
					// Integer
				
						writeInteger(this.numero_commande,dos);
					
					// java.util.Date
				
						writeDate(this.date_commande,dos);
					
					// Float
				
						if(this.montant_total == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.montant_total);
		            	}
					
					// Integer
				
						writeInteger(this.id_adresse_norm_restaurant,dos);
					
					// String
				
						writeString(this.numero_voie_restau,dos);
					
					// String
				
						writeString(this.nom_voie_restau,dos);
					
					// String
				
						writeString(this.code_postal_restau,dos);
					
					// String
				
						writeString(this.nom_ville_restau,dos);
					
					// String
				
						writeString(this.longitude_restau,dos);
					
					// String
				
						writeString(this.latitude_restau,dos);
					
					// Integer
				
						writeInteger(this.id_adresse_restaurant,dos);
					
					// String
				
						writeString(this.adresse_restaurant,dos);
					
					// Integer
				
						writeInteger(this.id_restaurant,dos);
					
					// String
				
						writeString(this.code_restaurant,dos);
					
					// String
				
						writeString(this.raison_sociale_restaurant,dos);
					
					// Integer
				
						writeInteger(this.id_adresse_norm_client,dos);
					
					// String
				
						writeString(this.numero_voie,dos);
					
					// String
				
						writeString(this.nom_voie,dos);
					
					// String
				
						writeString(this.code_postal,dos);
					
					// String
				
						writeString(this.nom_ville,dos);
					
					// String
				
						writeString(this.longitude,dos);
					
					// String
				
						writeString(this.latitude,dos);
					
					// Integer
				
						writeInteger(this.id_adresse_client,dos);
					
					// String
				
						writeString(this.adresse_client,dos);
					
					// Integer
				
						writeInteger(this.id_client,dos);
					
					// String
				
						writeString(this.nom_client,dos);
					
					// String
				
						writeString(this.prenom_client,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id_staging_dm1);
					
					// Integer
				
						writeInteger(this.id_preparation,dos);
					
					// java.util.Date
				
						writeDate(this.date_debut_preparation,dos);
					
					// java.util.Date
				
						writeDate(this.date_fin_preparation,dos);
					
					// Integer
				
						writeInteger(this.id_moyen_paiement,dos);
					
					// String
				
						writeString(this.code_moyen_paiement,dos);
					
					// String
				
						writeString(this.livelle_moyen_paiement,dos);
					
					// Integer
				
						writeInteger(this.id_menu,dos);
					
					// String
				
						writeString(this.code_menu,dos);
					
					// String
				
						writeString(this.libelle_menu,dos);
					
					// Integer
				
						writeInteger(this.nombre_articles,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.temps_theo_preparation);
					
					// Integer
				
						writeInteger(this.id_commande,dos);
					
					// Integer
				
						writeInteger(this.numero_commande,dos);
					
					// java.util.Date
				
						writeDate(this.date_commande,dos);
					
					// Float
				
						if(this.montant_total == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.montant_total);
		            	}
					
					// Integer
				
						writeInteger(this.id_adresse_norm_restaurant,dos);
					
					// String
				
						writeString(this.numero_voie_restau,dos);
					
					// String
				
						writeString(this.nom_voie_restau,dos);
					
					// String
				
						writeString(this.code_postal_restau,dos);
					
					// String
				
						writeString(this.nom_ville_restau,dos);
					
					// String
				
						writeString(this.longitude_restau,dos);
					
					// String
				
						writeString(this.latitude_restau,dos);
					
					// Integer
				
						writeInteger(this.id_adresse_restaurant,dos);
					
					// String
				
						writeString(this.adresse_restaurant,dos);
					
					// Integer
				
						writeInteger(this.id_restaurant,dos);
					
					// String
				
						writeString(this.code_restaurant,dos);
					
					// String
				
						writeString(this.raison_sociale_restaurant,dos);
					
					// Integer
				
						writeInteger(this.id_adresse_norm_client,dos);
					
					// String
				
						writeString(this.numero_voie,dos);
					
					// String
				
						writeString(this.nom_voie,dos);
					
					// String
				
						writeString(this.code_postal,dos);
					
					// String
				
						writeString(this.nom_ville,dos);
					
					// String
				
						writeString(this.longitude,dos);
					
					// String
				
						writeString(this.latitude,dos);
					
					// Integer
				
						writeInteger(this.id_adresse_client,dos);
					
					// String
				
						writeString(this.adresse_client,dos);
					
					// Integer
				
						writeInteger(this.id_client,dos);
					
					// String
				
						writeString(this.nom_client,dos);
					
					// String
				
						writeString(this.prenom_client,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id_staging_dm1="+String.valueOf(id_staging_dm1));
		sb.append(",id_preparation="+String.valueOf(id_preparation));
		sb.append(",date_debut_preparation="+String.valueOf(date_debut_preparation));
		sb.append(",date_fin_preparation="+String.valueOf(date_fin_preparation));
		sb.append(",id_moyen_paiement="+String.valueOf(id_moyen_paiement));
		sb.append(",code_moyen_paiement="+code_moyen_paiement);
		sb.append(",livelle_moyen_paiement="+livelle_moyen_paiement);
		sb.append(",id_menu="+String.valueOf(id_menu));
		sb.append(",code_menu="+code_menu);
		sb.append(",libelle_menu="+libelle_menu);
		sb.append(",nombre_articles="+String.valueOf(nombre_articles));
		sb.append(",temps_theo_preparation="+String.valueOf(temps_theo_preparation));
		sb.append(",id_commande="+String.valueOf(id_commande));
		sb.append(",numero_commande="+String.valueOf(numero_commande));
		sb.append(",date_commande="+String.valueOf(date_commande));
		sb.append(",montant_total="+String.valueOf(montant_total));
		sb.append(",id_adresse_norm_restaurant="+String.valueOf(id_adresse_norm_restaurant));
		sb.append(",numero_voie_restau="+numero_voie_restau);
		sb.append(",nom_voie_restau="+nom_voie_restau);
		sb.append(",code_postal_restau="+code_postal_restau);
		sb.append(",nom_ville_restau="+nom_ville_restau);
		sb.append(",longitude_restau="+longitude_restau);
		sb.append(",latitude_restau="+latitude_restau);
		sb.append(",id_adresse_restaurant="+String.valueOf(id_adresse_restaurant));
		sb.append(",adresse_restaurant="+adresse_restaurant);
		sb.append(",id_restaurant="+String.valueOf(id_restaurant));
		sb.append(",code_restaurant="+code_restaurant);
		sb.append(",raison_sociale_restaurant="+raison_sociale_restaurant);
		sb.append(",id_adresse_norm_client="+String.valueOf(id_adresse_norm_client));
		sb.append(",numero_voie="+numero_voie);
		sb.append(",nom_voie="+nom_voie);
		sb.append(",code_postal="+code_postal);
		sb.append(",nom_ville="+nom_ville);
		sb.append(",longitude="+longitude);
		sb.append(",latitude="+latitude);
		sb.append(",id_adresse_client="+String.valueOf(id_adresse_client));
		sb.append(",adresse_client="+adresse_client);
		sb.append(",id_client="+String.valueOf(id_client));
		sb.append(",nom_client="+nom_client);
		sb.append(",prenom_client="+prenom_client);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row5Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row6Struct implements routines.system.IPersistableRow<row6Struct> {
    final static byte[] commonByteArrayLock_ALIMENTATION_DM1_C_ALIM_ODS_REJET = new byte[0];
    static byte[] commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET = new byte[0];

	
			    public int id_staging_dm1;

				public int getId_staging_dm1 () {
					return this.id_staging_dm1;
				}
				
			    public Integer id_preparation;

				public Integer getId_preparation () {
					return this.id_preparation;
				}
				
			    public java.util.Date date_debut_preparation;

				public java.util.Date getDate_debut_preparation () {
					return this.date_debut_preparation;
				}
				
			    public java.util.Date date_fin_preparation;

				public java.util.Date getDate_fin_preparation () {
					return this.date_fin_preparation;
				}
				
			    public Integer id_moyen_paiement;

				public Integer getId_moyen_paiement () {
					return this.id_moyen_paiement;
				}
				
			    public String code_moyen_paiement;

				public String getCode_moyen_paiement () {
					return this.code_moyen_paiement;
				}
				
			    public String livelle_moyen_paiement;

				public String getLivelle_moyen_paiement () {
					return this.livelle_moyen_paiement;
				}
				
			    public Integer id_menu;

				public Integer getId_menu () {
					return this.id_menu;
				}
				
			    public String code_menu;

				public String getCode_menu () {
					return this.code_menu;
				}
				
			    public String libelle_menu;

				public String getLibelle_menu () {
					return this.libelle_menu;
				}
				
			    public Integer nombre_articles;

				public Integer getNombre_articles () {
					return this.nombre_articles;
				}
				
			    public BigDecimal temps_theo_preparation;

				public BigDecimal getTemps_theo_preparation () {
					return this.temps_theo_preparation;
				}
				
			    public Integer id_commande;

				public Integer getId_commande () {
					return this.id_commande;
				}
				
			    public Integer numero_commande;

				public Integer getNumero_commande () {
					return this.numero_commande;
				}
				
			    public java.util.Date date_commande;

				public java.util.Date getDate_commande () {
					return this.date_commande;
				}
				
			    public Float montant_total;

				public Float getMontant_total () {
					return this.montant_total;
				}
				
			    public Integer id_adresse_norm_restaurant;

				public Integer getId_adresse_norm_restaurant () {
					return this.id_adresse_norm_restaurant;
				}
				
			    public String numero_voie_restau;

				public String getNumero_voie_restau () {
					return this.numero_voie_restau;
				}
				
			    public String nom_voie_restau;

				public String getNom_voie_restau () {
					return this.nom_voie_restau;
				}
				
			    public String code_postal_restau;

				public String getCode_postal_restau () {
					return this.code_postal_restau;
				}
				
			    public String nom_ville_restau;

				public String getNom_ville_restau () {
					return this.nom_ville_restau;
				}
				
			    public String longitude_restau;

				public String getLongitude_restau () {
					return this.longitude_restau;
				}
				
			    public String latitude_restau;

				public String getLatitude_restau () {
					return this.latitude_restau;
				}
				
			    public Integer id_adresse_restaurant;

				public Integer getId_adresse_restaurant () {
					return this.id_adresse_restaurant;
				}
				
			    public String adresse_restaurant;

				public String getAdresse_restaurant () {
					return this.adresse_restaurant;
				}
				
			    public Integer id_restaurant;

				public Integer getId_restaurant () {
					return this.id_restaurant;
				}
				
			    public String code_restaurant;

				public String getCode_restaurant () {
					return this.code_restaurant;
				}
				
			    public String raison_sociale_restaurant;

				public String getRaison_sociale_restaurant () {
					return this.raison_sociale_restaurant;
				}
				
			    public Integer id_adresse_norm_client;

				public Integer getId_adresse_norm_client () {
					return this.id_adresse_norm_client;
				}
				
			    public String numero_voie;

				public String getNumero_voie () {
					return this.numero_voie;
				}
				
			    public String nom_voie;

				public String getNom_voie () {
					return this.nom_voie;
				}
				
			    public String code_postal;

				public String getCode_postal () {
					return this.code_postal;
				}
				
			    public String nom_ville;

				public String getNom_ville () {
					return this.nom_ville;
				}
				
			    public String longitude;

				public String getLongitude () {
					return this.longitude;
				}
				
			    public String latitude;

				public String getLatitude () {
					return this.latitude;
				}
				
			    public Integer id_adresse_client;

				public Integer getId_adresse_client () {
					return this.id_adresse_client;
				}
				
			    public String adresse_client;

				public String getAdresse_client () {
					return this.adresse_client;
				}
				
			    public Integer id_client;

				public Integer getId_client () {
					return this.id_client;
				}
				
			    public String nom_client;

				public String getNom_client () {
					return this.nom_client;
				}
				
			    public String prenom_client;

				public String getPrenom_client () {
					return this.prenom_client;
				}
				


	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET.length == 0) {
   					commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET.length == 0) {
   					commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_DM1_C_ALIM_ODS_REJET) {

        	try {

        		int length = 0;
		
			        this.id_staging_dm1 = dis.readInt();
					
						this.id_preparation = readInteger(dis);
					
					this.date_debut_preparation = readDate(dis);
					
					this.date_fin_preparation = readDate(dis);
					
						this.id_moyen_paiement = readInteger(dis);
					
					this.code_moyen_paiement = readString(dis);
					
					this.livelle_moyen_paiement = readString(dis);
					
						this.id_menu = readInteger(dis);
					
					this.code_menu = readString(dis);
					
					this.libelle_menu = readString(dis);
					
						this.nombre_articles = readInteger(dis);
					
						this.temps_theo_preparation = (BigDecimal) dis.readObject();
					
						this.id_commande = readInteger(dis);
					
						this.numero_commande = readInteger(dis);
					
					this.date_commande = readDate(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.montant_total = null;
           				} else {
           			    	this.montant_total = dis.readFloat();
           				}
					
						this.id_adresse_norm_restaurant = readInteger(dis);
					
					this.numero_voie_restau = readString(dis);
					
					this.nom_voie_restau = readString(dis);
					
					this.code_postal_restau = readString(dis);
					
					this.nom_ville_restau = readString(dis);
					
					this.longitude_restau = readString(dis);
					
					this.latitude_restau = readString(dis);
					
						this.id_adresse_restaurant = readInteger(dis);
					
					this.adresse_restaurant = readString(dis);
					
						this.id_restaurant = readInteger(dis);
					
					this.code_restaurant = readString(dis);
					
					this.raison_sociale_restaurant = readString(dis);
					
						this.id_adresse_norm_client = readInteger(dis);
					
					this.numero_voie = readString(dis);
					
					this.nom_voie = readString(dis);
					
					this.code_postal = readString(dis);
					
					this.nom_ville = readString(dis);
					
					this.longitude = readString(dis);
					
					this.latitude = readString(dis);
					
						this.id_adresse_client = readInteger(dis);
					
					this.adresse_client = readString(dis);
					
						this.id_client = readInteger(dis);
					
					this.nom_client = readString(dis);
					
					this.prenom_client = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_DM1_C_ALIM_ODS_REJET) {

        	try {

        		int length = 0;
		
			        this.id_staging_dm1 = dis.readInt();
					
						this.id_preparation = readInteger(dis);
					
					this.date_debut_preparation = readDate(dis);
					
					this.date_fin_preparation = readDate(dis);
					
						this.id_moyen_paiement = readInteger(dis);
					
					this.code_moyen_paiement = readString(dis);
					
					this.livelle_moyen_paiement = readString(dis);
					
						this.id_menu = readInteger(dis);
					
					this.code_menu = readString(dis);
					
					this.libelle_menu = readString(dis);
					
						this.nombre_articles = readInteger(dis);
					
						this.temps_theo_preparation = (BigDecimal) dis.readObject();
					
						this.id_commande = readInteger(dis);
					
						this.numero_commande = readInteger(dis);
					
					this.date_commande = readDate(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.montant_total = null;
           				} else {
           			    	this.montant_total = dis.readFloat();
           				}
					
						this.id_adresse_norm_restaurant = readInteger(dis);
					
					this.numero_voie_restau = readString(dis);
					
					this.nom_voie_restau = readString(dis);
					
					this.code_postal_restau = readString(dis);
					
					this.nom_ville_restau = readString(dis);
					
					this.longitude_restau = readString(dis);
					
					this.latitude_restau = readString(dis);
					
						this.id_adresse_restaurant = readInteger(dis);
					
					this.adresse_restaurant = readString(dis);
					
						this.id_restaurant = readInteger(dis);
					
					this.code_restaurant = readString(dis);
					
					this.raison_sociale_restaurant = readString(dis);
					
						this.id_adresse_norm_client = readInteger(dis);
					
					this.numero_voie = readString(dis);
					
					this.nom_voie = readString(dis);
					
					this.code_postal = readString(dis);
					
					this.nom_ville = readString(dis);
					
					this.longitude = readString(dis);
					
					this.latitude = readString(dis);
					
						this.id_adresse_client = readInteger(dis);
					
					this.adresse_client = readString(dis);
					
						this.id_client = readInteger(dis);
					
					this.nom_client = readString(dis);
					
					this.prenom_client = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id_staging_dm1);
					
					// Integer
				
						writeInteger(this.id_preparation,dos);
					
					// java.util.Date
				
						writeDate(this.date_debut_preparation,dos);
					
					// java.util.Date
				
						writeDate(this.date_fin_preparation,dos);
					
					// Integer
				
						writeInteger(this.id_moyen_paiement,dos);
					
					// String
				
						writeString(this.code_moyen_paiement,dos);
					
					// String
				
						writeString(this.livelle_moyen_paiement,dos);
					
					// Integer
				
						writeInteger(this.id_menu,dos);
					
					// String
				
						writeString(this.code_menu,dos);
					
					// String
				
						writeString(this.libelle_menu,dos);
					
					// Integer
				
						writeInteger(this.nombre_articles,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.temps_theo_preparation);
					
					// Integer
				
						writeInteger(this.id_commande,dos);
					
					// Integer
				
						writeInteger(this.numero_commande,dos);
					
					// java.util.Date
				
						writeDate(this.date_commande,dos);
					
					// Float
				
						if(this.montant_total == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.montant_total);
		            	}
					
					// Integer
				
						writeInteger(this.id_adresse_norm_restaurant,dos);
					
					// String
				
						writeString(this.numero_voie_restau,dos);
					
					// String
				
						writeString(this.nom_voie_restau,dos);
					
					// String
				
						writeString(this.code_postal_restau,dos);
					
					// String
				
						writeString(this.nom_ville_restau,dos);
					
					// String
				
						writeString(this.longitude_restau,dos);
					
					// String
				
						writeString(this.latitude_restau,dos);
					
					// Integer
				
						writeInteger(this.id_adresse_restaurant,dos);
					
					// String
				
						writeString(this.adresse_restaurant,dos);
					
					// Integer
				
						writeInteger(this.id_restaurant,dos);
					
					// String
				
						writeString(this.code_restaurant,dos);
					
					// String
				
						writeString(this.raison_sociale_restaurant,dos);
					
					// Integer
				
						writeInteger(this.id_adresse_norm_client,dos);
					
					// String
				
						writeString(this.numero_voie,dos);
					
					// String
				
						writeString(this.nom_voie,dos);
					
					// String
				
						writeString(this.code_postal,dos);
					
					// String
				
						writeString(this.nom_ville,dos);
					
					// String
				
						writeString(this.longitude,dos);
					
					// String
				
						writeString(this.latitude,dos);
					
					// Integer
				
						writeInteger(this.id_adresse_client,dos);
					
					// String
				
						writeString(this.adresse_client,dos);
					
					// Integer
				
						writeInteger(this.id_client,dos);
					
					// String
				
						writeString(this.nom_client,dos);
					
					// String
				
						writeString(this.prenom_client,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id_staging_dm1);
					
					// Integer
				
						writeInteger(this.id_preparation,dos);
					
					// java.util.Date
				
						writeDate(this.date_debut_preparation,dos);
					
					// java.util.Date
				
						writeDate(this.date_fin_preparation,dos);
					
					// Integer
				
						writeInteger(this.id_moyen_paiement,dos);
					
					// String
				
						writeString(this.code_moyen_paiement,dos);
					
					// String
				
						writeString(this.livelle_moyen_paiement,dos);
					
					// Integer
				
						writeInteger(this.id_menu,dos);
					
					// String
				
						writeString(this.code_menu,dos);
					
					// String
				
						writeString(this.libelle_menu,dos);
					
					// Integer
				
						writeInteger(this.nombre_articles,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.temps_theo_preparation);
					
					// Integer
				
						writeInteger(this.id_commande,dos);
					
					// Integer
				
						writeInteger(this.numero_commande,dos);
					
					// java.util.Date
				
						writeDate(this.date_commande,dos);
					
					// Float
				
						if(this.montant_total == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.montant_total);
		            	}
					
					// Integer
				
						writeInteger(this.id_adresse_norm_restaurant,dos);
					
					// String
				
						writeString(this.numero_voie_restau,dos);
					
					// String
				
						writeString(this.nom_voie_restau,dos);
					
					// String
				
						writeString(this.code_postal_restau,dos);
					
					// String
				
						writeString(this.nom_ville_restau,dos);
					
					// String
				
						writeString(this.longitude_restau,dos);
					
					// String
				
						writeString(this.latitude_restau,dos);
					
					// Integer
				
						writeInteger(this.id_adresse_restaurant,dos);
					
					// String
				
						writeString(this.adresse_restaurant,dos);
					
					// Integer
				
						writeInteger(this.id_restaurant,dos);
					
					// String
				
						writeString(this.code_restaurant,dos);
					
					// String
				
						writeString(this.raison_sociale_restaurant,dos);
					
					// Integer
				
						writeInteger(this.id_adresse_norm_client,dos);
					
					// String
				
						writeString(this.numero_voie,dos);
					
					// String
				
						writeString(this.nom_voie,dos);
					
					// String
				
						writeString(this.code_postal,dos);
					
					// String
				
						writeString(this.nom_ville,dos);
					
					// String
				
						writeString(this.longitude,dos);
					
					// String
				
						writeString(this.latitude,dos);
					
					// Integer
				
						writeInteger(this.id_adresse_client,dos);
					
					// String
				
						writeString(this.adresse_client,dos);
					
					// Integer
				
						writeInteger(this.id_client,dos);
					
					// String
				
						writeString(this.nom_client,dos);
					
					// String
				
						writeString(this.prenom_client,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id_staging_dm1="+String.valueOf(id_staging_dm1));
		sb.append(",id_preparation="+String.valueOf(id_preparation));
		sb.append(",date_debut_preparation="+String.valueOf(date_debut_preparation));
		sb.append(",date_fin_preparation="+String.valueOf(date_fin_preparation));
		sb.append(",id_moyen_paiement="+String.valueOf(id_moyen_paiement));
		sb.append(",code_moyen_paiement="+code_moyen_paiement);
		sb.append(",livelle_moyen_paiement="+livelle_moyen_paiement);
		sb.append(",id_menu="+String.valueOf(id_menu));
		sb.append(",code_menu="+code_menu);
		sb.append(",libelle_menu="+libelle_menu);
		sb.append(",nombre_articles="+String.valueOf(nombre_articles));
		sb.append(",temps_theo_preparation="+String.valueOf(temps_theo_preparation));
		sb.append(",id_commande="+String.valueOf(id_commande));
		sb.append(",numero_commande="+String.valueOf(numero_commande));
		sb.append(",date_commande="+String.valueOf(date_commande));
		sb.append(",montant_total="+String.valueOf(montant_total));
		sb.append(",id_adresse_norm_restaurant="+String.valueOf(id_adresse_norm_restaurant));
		sb.append(",numero_voie_restau="+numero_voie_restau);
		sb.append(",nom_voie_restau="+nom_voie_restau);
		sb.append(",code_postal_restau="+code_postal_restau);
		sb.append(",nom_ville_restau="+nom_ville_restau);
		sb.append(",longitude_restau="+longitude_restau);
		sb.append(",latitude_restau="+latitude_restau);
		sb.append(",id_adresse_restaurant="+String.valueOf(id_adresse_restaurant));
		sb.append(",adresse_restaurant="+adresse_restaurant);
		sb.append(",id_restaurant="+String.valueOf(id_restaurant));
		sb.append(",code_restaurant="+code_restaurant);
		sb.append(",raison_sociale_restaurant="+raison_sociale_restaurant);
		sb.append(",id_adresse_norm_client="+String.valueOf(id_adresse_norm_client));
		sb.append(",numero_voie="+numero_voie);
		sb.append(",nom_voie="+nom_voie);
		sb.append(",code_postal="+code_postal);
		sb.append(",nom_ville="+nom_ville);
		sb.append(",longitude="+longitude);
		sb.append(",latitude="+latitude);
		sb.append(",id_adresse_client="+String.valueOf(id_adresse_client));
		sb.append(",adresse_client="+adresse_client);
		sb.append(",id_client="+String.valueOf(id_client));
		sb.append(",nom_client="+nom_client);
		sb.append(",prenom_client="+prenom_client);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row6Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row4Struct implements routines.system.IPersistableRow<row4Struct> {
    final static byte[] commonByteArrayLock_ALIMENTATION_DM1_C_ALIM_ODS_REJET = new byte[0];
    static byte[] commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int id_staging_dm1;

				public int getId_staging_dm1 () {
					return this.id_staging_dm1;
				}
				
			    public Integer id_preparation;

				public Integer getId_preparation () {
					return this.id_preparation;
				}
				
			    public java.util.Date date_debut_preparation;

				public java.util.Date getDate_debut_preparation () {
					return this.date_debut_preparation;
				}
				
			    public java.util.Date date_fin_preparation;

				public java.util.Date getDate_fin_preparation () {
					return this.date_fin_preparation;
				}
				
			    public Integer id_moyen_paiement;

				public Integer getId_moyen_paiement () {
					return this.id_moyen_paiement;
				}
				
			    public String code_moyen_paiement;

				public String getCode_moyen_paiement () {
					return this.code_moyen_paiement;
				}
				
			    public String livelle_moyen_paiement;

				public String getLivelle_moyen_paiement () {
					return this.livelle_moyen_paiement;
				}
				
			    public Integer id_menu;

				public Integer getId_menu () {
					return this.id_menu;
				}
				
			    public String code_menu;

				public String getCode_menu () {
					return this.code_menu;
				}
				
			    public String libelle_menu;

				public String getLibelle_menu () {
					return this.libelle_menu;
				}
				
			    public Integer nombre_articles;

				public Integer getNombre_articles () {
					return this.nombre_articles;
				}
				
			    public BigDecimal temps_theo_preparation;

				public BigDecimal getTemps_theo_preparation () {
					return this.temps_theo_preparation;
				}
				
			    public Integer id_commande;

				public Integer getId_commande () {
					return this.id_commande;
				}
				
			    public Integer numero_commande;

				public Integer getNumero_commande () {
					return this.numero_commande;
				}
				
			    public java.util.Date date_commande;

				public java.util.Date getDate_commande () {
					return this.date_commande;
				}
				
			    public Float montant_total;

				public Float getMontant_total () {
					return this.montant_total;
				}
				
			    public Integer id_adresse_norm_restaurant;

				public Integer getId_adresse_norm_restaurant () {
					return this.id_adresse_norm_restaurant;
				}
				
			    public String numero_voie_restau;

				public String getNumero_voie_restau () {
					return this.numero_voie_restau;
				}
				
			    public String nom_voie_restau;

				public String getNom_voie_restau () {
					return this.nom_voie_restau;
				}
				
			    public String code_postal_restau;

				public String getCode_postal_restau () {
					return this.code_postal_restau;
				}
				
			    public String nom_ville_restau;

				public String getNom_ville_restau () {
					return this.nom_ville_restau;
				}
				
			    public String longitude_restau;

				public String getLongitude_restau () {
					return this.longitude_restau;
				}
				
			    public String latitude_restau;

				public String getLatitude_restau () {
					return this.latitude_restau;
				}
				
			    public Integer id_adresse_restaurant;

				public Integer getId_adresse_restaurant () {
					return this.id_adresse_restaurant;
				}
				
			    public String adresse_restaurant;

				public String getAdresse_restaurant () {
					return this.adresse_restaurant;
				}
				
			    public Integer id_restaurant;

				public Integer getId_restaurant () {
					return this.id_restaurant;
				}
				
			    public String code_restaurant;

				public String getCode_restaurant () {
					return this.code_restaurant;
				}
				
			    public String raison_sociale_restaurant;

				public String getRaison_sociale_restaurant () {
					return this.raison_sociale_restaurant;
				}
				
			    public Integer id_adresse_norm_client;

				public Integer getId_adresse_norm_client () {
					return this.id_adresse_norm_client;
				}
				
			    public String numero_voie;

				public String getNumero_voie () {
					return this.numero_voie;
				}
				
			    public String nom_voie;

				public String getNom_voie () {
					return this.nom_voie;
				}
				
			    public String code_postal;

				public String getCode_postal () {
					return this.code_postal;
				}
				
			    public String nom_ville;

				public String getNom_ville () {
					return this.nom_ville;
				}
				
			    public String longitude;

				public String getLongitude () {
					return this.longitude;
				}
				
			    public String latitude;

				public String getLatitude () {
					return this.latitude;
				}
				
			    public Integer id_adresse_client;

				public Integer getId_adresse_client () {
					return this.id_adresse_client;
				}
				
			    public String adresse_client;

				public String getAdresse_client () {
					return this.adresse_client;
				}
				
			    public Integer id_client;

				public Integer getId_client () {
					return this.id_client;
				}
				
			    public String nom_client;

				public String getNom_client () {
					return this.nom_client;
				}
				
			    public String prenom_client;

				public String getPrenom_client () {
					return this.prenom_client;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.id_staging_dm1;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row4Struct other = (row4Struct) obj;
		
						if (this.id_staging_dm1 != other.id_staging_dm1)
							return false;
					

		return true;
    }

	public void copyDataTo(row4Struct other) {

		other.id_staging_dm1 = this.id_staging_dm1;
	            other.id_preparation = this.id_preparation;
	            other.date_debut_preparation = this.date_debut_preparation;
	            other.date_fin_preparation = this.date_fin_preparation;
	            other.id_moyen_paiement = this.id_moyen_paiement;
	            other.code_moyen_paiement = this.code_moyen_paiement;
	            other.livelle_moyen_paiement = this.livelle_moyen_paiement;
	            other.id_menu = this.id_menu;
	            other.code_menu = this.code_menu;
	            other.libelle_menu = this.libelle_menu;
	            other.nombre_articles = this.nombre_articles;
	            other.temps_theo_preparation = this.temps_theo_preparation;
	            other.id_commande = this.id_commande;
	            other.numero_commande = this.numero_commande;
	            other.date_commande = this.date_commande;
	            other.montant_total = this.montant_total;
	            other.id_adresse_norm_restaurant = this.id_adresse_norm_restaurant;
	            other.numero_voie_restau = this.numero_voie_restau;
	            other.nom_voie_restau = this.nom_voie_restau;
	            other.code_postal_restau = this.code_postal_restau;
	            other.nom_ville_restau = this.nom_ville_restau;
	            other.longitude_restau = this.longitude_restau;
	            other.latitude_restau = this.latitude_restau;
	            other.id_adresse_restaurant = this.id_adresse_restaurant;
	            other.adresse_restaurant = this.adresse_restaurant;
	            other.id_restaurant = this.id_restaurant;
	            other.code_restaurant = this.code_restaurant;
	            other.raison_sociale_restaurant = this.raison_sociale_restaurant;
	            other.id_adresse_norm_client = this.id_adresse_norm_client;
	            other.numero_voie = this.numero_voie;
	            other.nom_voie = this.nom_voie;
	            other.code_postal = this.code_postal;
	            other.nom_ville = this.nom_ville;
	            other.longitude = this.longitude;
	            other.latitude = this.latitude;
	            other.id_adresse_client = this.id_adresse_client;
	            other.adresse_client = this.adresse_client;
	            other.id_client = this.id_client;
	            other.nom_client = this.nom_client;
	            other.prenom_client = this.prenom_client;
	            
	}

	public void copyKeysDataTo(row4Struct other) {

		other.id_staging_dm1 = this.id_staging_dm1;
	            	
	}



	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET.length == 0) {
   					commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET.length == 0) {
   					commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_DM1_C_ALIM_ODS_REJET) {

        	try {

        		int length = 0;
		
			        this.id_staging_dm1 = dis.readInt();
					
						this.id_preparation = readInteger(dis);
					
					this.date_debut_preparation = readDate(dis);
					
					this.date_fin_preparation = readDate(dis);
					
						this.id_moyen_paiement = readInteger(dis);
					
					this.code_moyen_paiement = readString(dis);
					
					this.livelle_moyen_paiement = readString(dis);
					
						this.id_menu = readInteger(dis);
					
					this.code_menu = readString(dis);
					
					this.libelle_menu = readString(dis);
					
						this.nombre_articles = readInteger(dis);
					
						this.temps_theo_preparation = (BigDecimal) dis.readObject();
					
						this.id_commande = readInteger(dis);
					
						this.numero_commande = readInteger(dis);
					
					this.date_commande = readDate(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.montant_total = null;
           				} else {
           			    	this.montant_total = dis.readFloat();
           				}
					
						this.id_adresse_norm_restaurant = readInteger(dis);
					
					this.numero_voie_restau = readString(dis);
					
					this.nom_voie_restau = readString(dis);
					
					this.code_postal_restau = readString(dis);
					
					this.nom_ville_restau = readString(dis);
					
					this.longitude_restau = readString(dis);
					
					this.latitude_restau = readString(dis);
					
						this.id_adresse_restaurant = readInteger(dis);
					
					this.adresse_restaurant = readString(dis);
					
						this.id_restaurant = readInteger(dis);
					
					this.code_restaurant = readString(dis);
					
					this.raison_sociale_restaurant = readString(dis);
					
						this.id_adresse_norm_client = readInteger(dis);
					
					this.numero_voie = readString(dis);
					
					this.nom_voie = readString(dis);
					
					this.code_postal = readString(dis);
					
					this.nom_ville = readString(dis);
					
					this.longitude = readString(dis);
					
					this.latitude = readString(dis);
					
						this.id_adresse_client = readInteger(dis);
					
					this.adresse_client = readString(dis);
					
						this.id_client = readInteger(dis);
					
					this.nom_client = readString(dis);
					
					this.prenom_client = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_DM1_C_ALIM_ODS_REJET) {

        	try {

        		int length = 0;
		
			        this.id_staging_dm1 = dis.readInt();
					
						this.id_preparation = readInteger(dis);
					
					this.date_debut_preparation = readDate(dis);
					
					this.date_fin_preparation = readDate(dis);
					
						this.id_moyen_paiement = readInteger(dis);
					
					this.code_moyen_paiement = readString(dis);
					
					this.livelle_moyen_paiement = readString(dis);
					
						this.id_menu = readInteger(dis);
					
					this.code_menu = readString(dis);
					
					this.libelle_menu = readString(dis);
					
						this.nombre_articles = readInteger(dis);
					
						this.temps_theo_preparation = (BigDecimal) dis.readObject();
					
						this.id_commande = readInteger(dis);
					
						this.numero_commande = readInteger(dis);
					
					this.date_commande = readDate(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.montant_total = null;
           				} else {
           			    	this.montant_total = dis.readFloat();
           				}
					
						this.id_adresse_norm_restaurant = readInteger(dis);
					
					this.numero_voie_restau = readString(dis);
					
					this.nom_voie_restau = readString(dis);
					
					this.code_postal_restau = readString(dis);
					
					this.nom_ville_restau = readString(dis);
					
					this.longitude_restau = readString(dis);
					
					this.latitude_restau = readString(dis);
					
						this.id_adresse_restaurant = readInteger(dis);
					
					this.adresse_restaurant = readString(dis);
					
						this.id_restaurant = readInteger(dis);
					
					this.code_restaurant = readString(dis);
					
					this.raison_sociale_restaurant = readString(dis);
					
						this.id_adresse_norm_client = readInteger(dis);
					
					this.numero_voie = readString(dis);
					
					this.nom_voie = readString(dis);
					
					this.code_postal = readString(dis);
					
					this.nom_ville = readString(dis);
					
					this.longitude = readString(dis);
					
					this.latitude = readString(dis);
					
						this.id_adresse_client = readInteger(dis);
					
					this.adresse_client = readString(dis);
					
						this.id_client = readInteger(dis);
					
					this.nom_client = readString(dis);
					
					this.prenom_client = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id_staging_dm1);
					
					// Integer
				
						writeInteger(this.id_preparation,dos);
					
					// java.util.Date
				
						writeDate(this.date_debut_preparation,dos);
					
					// java.util.Date
				
						writeDate(this.date_fin_preparation,dos);
					
					// Integer
				
						writeInteger(this.id_moyen_paiement,dos);
					
					// String
				
						writeString(this.code_moyen_paiement,dos);
					
					// String
				
						writeString(this.livelle_moyen_paiement,dos);
					
					// Integer
				
						writeInteger(this.id_menu,dos);
					
					// String
				
						writeString(this.code_menu,dos);
					
					// String
				
						writeString(this.libelle_menu,dos);
					
					// Integer
				
						writeInteger(this.nombre_articles,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.temps_theo_preparation);
					
					// Integer
				
						writeInteger(this.id_commande,dos);
					
					// Integer
				
						writeInteger(this.numero_commande,dos);
					
					// java.util.Date
				
						writeDate(this.date_commande,dos);
					
					// Float
				
						if(this.montant_total == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.montant_total);
		            	}
					
					// Integer
				
						writeInteger(this.id_adresse_norm_restaurant,dos);
					
					// String
				
						writeString(this.numero_voie_restau,dos);
					
					// String
				
						writeString(this.nom_voie_restau,dos);
					
					// String
				
						writeString(this.code_postal_restau,dos);
					
					// String
				
						writeString(this.nom_ville_restau,dos);
					
					// String
				
						writeString(this.longitude_restau,dos);
					
					// String
				
						writeString(this.latitude_restau,dos);
					
					// Integer
				
						writeInteger(this.id_adresse_restaurant,dos);
					
					// String
				
						writeString(this.adresse_restaurant,dos);
					
					// Integer
				
						writeInteger(this.id_restaurant,dos);
					
					// String
				
						writeString(this.code_restaurant,dos);
					
					// String
				
						writeString(this.raison_sociale_restaurant,dos);
					
					// Integer
				
						writeInteger(this.id_adresse_norm_client,dos);
					
					// String
				
						writeString(this.numero_voie,dos);
					
					// String
				
						writeString(this.nom_voie,dos);
					
					// String
				
						writeString(this.code_postal,dos);
					
					// String
				
						writeString(this.nom_ville,dos);
					
					// String
				
						writeString(this.longitude,dos);
					
					// String
				
						writeString(this.latitude,dos);
					
					// Integer
				
						writeInteger(this.id_adresse_client,dos);
					
					// String
				
						writeString(this.adresse_client,dos);
					
					// Integer
				
						writeInteger(this.id_client,dos);
					
					// String
				
						writeString(this.nom_client,dos);
					
					// String
				
						writeString(this.prenom_client,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id_staging_dm1);
					
					// Integer
				
						writeInteger(this.id_preparation,dos);
					
					// java.util.Date
				
						writeDate(this.date_debut_preparation,dos);
					
					// java.util.Date
				
						writeDate(this.date_fin_preparation,dos);
					
					// Integer
				
						writeInteger(this.id_moyen_paiement,dos);
					
					// String
				
						writeString(this.code_moyen_paiement,dos);
					
					// String
				
						writeString(this.livelle_moyen_paiement,dos);
					
					// Integer
				
						writeInteger(this.id_menu,dos);
					
					// String
				
						writeString(this.code_menu,dos);
					
					// String
				
						writeString(this.libelle_menu,dos);
					
					// Integer
				
						writeInteger(this.nombre_articles,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.temps_theo_preparation);
					
					// Integer
				
						writeInteger(this.id_commande,dos);
					
					// Integer
				
						writeInteger(this.numero_commande,dos);
					
					// java.util.Date
				
						writeDate(this.date_commande,dos);
					
					// Float
				
						if(this.montant_total == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.montant_total);
		            	}
					
					// Integer
				
						writeInteger(this.id_adresse_norm_restaurant,dos);
					
					// String
				
						writeString(this.numero_voie_restau,dos);
					
					// String
				
						writeString(this.nom_voie_restau,dos);
					
					// String
				
						writeString(this.code_postal_restau,dos);
					
					// String
				
						writeString(this.nom_ville_restau,dos);
					
					// String
				
						writeString(this.longitude_restau,dos);
					
					// String
				
						writeString(this.latitude_restau,dos);
					
					// Integer
				
						writeInteger(this.id_adresse_restaurant,dos);
					
					// String
				
						writeString(this.adresse_restaurant,dos);
					
					// Integer
				
						writeInteger(this.id_restaurant,dos);
					
					// String
				
						writeString(this.code_restaurant,dos);
					
					// String
				
						writeString(this.raison_sociale_restaurant,dos);
					
					// Integer
				
						writeInteger(this.id_adresse_norm_client,dos);
					
					// String
				
						writeString(this.numero_voie,dos);
					
					// String
				
						writeString(this.nom_voie,dos);
					
					// String
				
						writeString(this.code_postal,dos);
					
					// String
				
						writeString(this.nom_ville,dos);
					
					// String
				
						writeString(this.longitude,dos);
					
					// String
				
						writeString(this.latitude,dos);
					
					// Integer
				
						writeInteger(this.id_adresse_client,dos);
					
					// String
				
						writeString(this.adresse_client,dos);
					
					// Integer
				
						writeInteger(this.id_client,dos);
					
					// String
				
						writeString(this.nom_client,dos);
					
					// String
				
						writeString(this.prenom_client,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id_staging_dm1="+String.valueOf(id_staging_dm1));
		sb.append(",id_preparation="+String.valueOf(id_preparation));
		sb.append(",date_debut_preparation="+String.valueOf(date_debut_preparation));
		sb.append(",date_fin_preparation="+String.valueOf(date_fin_preparation));
		sb.append(",id_moyen_paiement="+String.valueOf(id_moyen_paiement));
		sb.append(",code_moyen_paiement="+code_moyen_paiement);
		sb.append(",livelle_moyen_paiement="+livelle_moyen_paiement);
		sb.append(",id_menu="+String.valueOf(id_menu));
		sb.append(",code_menu="+code_menu);
		sb.append(",libelle_menu="+libelle_menu);
		sb.append(",nombre_articles="+String.valueOf(nombre_articles));
		sb.append(",temps_theo_preparation="+String.valueOf(temps_theo_preparation));
		sb.append(",id_commande="+String.valueOf(id_commande));
		sb.append(",numero_commande="+String.valueOf(numero_commande));
		sb.append(",date_commande="+String.valueOf(date_commande));
		sb.append(",montant_total="+String.valueOf(montant_total));
		sb.append(",id_adresse_norm_restaurant="+String.valueOf(id_adresse_norm_restaurant));
		sb.append(",numero_voie_restau="+numero_voie_restau);
		sb.append(",nom_voie_restau="+nom_voie_restau);
		sb.append(",code_postal_restau="+code_postal_restau);
		sb.append(",nom_ville_restau="+nom_ville_restau);
		sb.append(",longitude_restau="+longitude_restau);
		sb.append(",latitude_restau="+latitude_restau);
		sb.append(",id_adresse_restaurant="+String.valueOf(id_adresse_restaurant));
		sb.append(",adresse_restaurant="+adresse_restaurant);
		sb.append(",id_restaurant="+String.valueOf(id_restaurant));
		sb.append(",code_restaurant="+code_restaurant);
		sb.append(",raison_sociale_restaurant="+raison_sociale_restaurant);
		sb.append(",id_adresse_norm_client="+String.valueOf(id_adresse_norm_client));
		sb.append(",numero_voie="+numero_voie);
		sb.append(",nom_voie="+nom_voie);
		sb.append(",code_postal="+code_postal);
		sb.append(",nom_ville="+nom_ville);
		sb.append(",longitude="+longitude);
		sb.append(",latitude="+latitude);
		sb.append(",id_adresse_client="+String.valueOf(id_adresse_client));
		sb.append(",adresse_client="+adresse_client);
		sb.append(",id_client="+String.valueOf(id_client));
		sb.append(",nom_client="+nom_client);
		sb.append(",prenom_client="+prenom_client);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row4Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.id_staging_dm1, other.id_staging_dm1);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row3Struct implements routines.system.IPersistableRow<row3Struct> {
    final static byte[] commonByteArrayLock_ALIMENTATION_DM1_C_ALIM_ODS_REJET = new byte[0];
    static byte[] commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET = new byte[0];

	
			    public int id_staging_dm1;

				public int getId_staging_dm1 () {
					return this.id_staging_dm1;
				}
				
			    public Integer id_preparation;

				public Integer getId_preparation () {
					return this.id_preparation;
				}
				
			    public java.util.Date date_debut_preparation;

				public java.util.Date getDate_debut_preparation () {
					return this.date_debut_preparation;
				}
				
			    public java.util.Date date_fin_preparation;

				public java.util.Date getDate_fin_preparation () {
					return this.date_fin_preparation;
				}
				
			    public Integer id_moyen_paiement;

				public Integer getId_moyen_paiement () {
					return this.id_moyen_paiement;
				}
				
			    public String code_moyen_paiement;

				public String getCode_moyen_paiement () {
					return this.code_moyen_paiement;
				}
				
			    public String livelle_moyen_paiement;

				public String getLivelle_moyen_paiement () {
					return this.livelle_moyen_paiement;
				}
				
			    public Integer id_menu;

				public Integer getId_menu () {
					return this.id_menu;
				}
				
			    public String code_menu;

				public String getCode_menu () {
					return this.code_menu;
				}
				
			    public String libelle_menu;

				public String getLibelle_menu () {
					return this.libelle_menu;
				}
				
			    public Integer nombre_articles;

				public Integer getNombre_articles () {
					return this.nombre_articles;
				}
				
			    public BigDecimal temps_theo_preparation;

				public BigDecimal getTemps_theo_preparation () {
					return this.temps_theo_preparation;
				}
				
			    public Integer id_commande;

				public Integer getId_commande () {
					return this.id_commande;
				}
				
			    public Integer numero_commande;

				public Integer getNumero_commande () {
					return this.numero_commande;
				}
				
			    public java.util.Date date_commande;

				public java.util.Date getDate_commande () {
					return this.date_commande;
				}
				
			    public Float montant_total;

				public Float getMontant_total () {
					return this.montant_total;
				}
				
			    public Integer id_adresse_norm_restaurant;

				public Integer getId_adresse_norm_restaurant () {
					return this.id_adresse_norm_restaurant;
				}
				
			    public String numero_voie_restau;

				public String getNumero_voie_restau () {
					return this.numero_voie_restau;
				}
				
			    public String nom_voie_restau;

				public String getNom_voie_restau () {
					return this.nom_voie_restau;
				}
				
			    public String code_postal_restau;

				public String getCode_postal_restau () {
					return this.code_postal_restau;
				}
				
			    public String nom_ville_restau;

				public String getNom_ville_restau () {
					return this.nom_ville_restau;
				}
				
			    public String longitude_restau;

				public String getLongitude_restau () {
					return this.longitude_restau;
				}
				
			    public String latitude_restau;

				public String getLatitude_restau () {
					return this.latitude_restau;
				}
				
			    public Integer id_adresse_restaurant;

				public Integer getId_adresse_restaurant () {
					return this.id_adresse_restaurant;
				}
				
			    public String adresse_restaurant;

				public String getAdresse_restaurant () {
					return this.adresse_restaurant;
				}
				
			    public Integer id_restaurant;

				public Integer getId_restaurant () {
					return this.id_restaurant;
				}
				
			    public String code_restaurant;

				public String getCode_restaurant () {
					return this.code_restaurant;
				}
				
			    public String raison_sociale_restaurant;

				public String getRaison_sociale_restaurant () {
					return this.raison_sociale_restaurant;
				}
				
			    public Integer id_adresse_norm_client;

				public Integer getId_adresse_norm_client () {
					return this.id_adresse_norm_client;
				}
				
			    public String numero_voie;

				public String getNumero_voie () {
					return this.numero_voie;
				}
				
			    public String nom_voie;

				public String getNom_voie () {
					return this.nom_voie;
				}
				
			    public String code_postal;

				public String getCode_postal () {
					return this.code_postal;
				}
				
			    public String nom_ville;

				public String getNom_ville () {
					return this.nom_ville;
				}
				
			    public String longitude;

				public String getLongitude () {
					return this.longitude;
				}
				
			    public String latitude;

				public String getLatitude () {
					return this.latitude;
				}
				
			    public Integer id_adresse_client;

				public Integer getId_adresse_client () {
					return this.id_adresse_client;
				}
				
			    public String adresse_client;

				public String getAdresse_client () {
					return this.adresse_client;
				}
				
			    public Integer id_client;

				public Integer getId_client () {
					return this.id_client;
				}
				
			    public String nom_client;

				public String getNom_client () {
					return this.nom_client;
				}
				
			    public String prenom_client;

				public String getPrenom_client () {
					return this.prenom_client;
				}
				


	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET.length == 0) {
   					commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET.length == 0) {
   					commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_DM1_C_ALIM_ODS_REJET) {

        	try {

        		int length = 0;
		
			        this.id_staging_dm1 = dis.readInt();
					
						this.id_preparation = readInteger(dis);
					
					this.date_debut_preparation = readDate(dis);
					
					this.date_fin_preparation = readDate(dis);
					
						this.id_moyen_paiement = readInteger(dis);
					
					this.code_moyen_paiement = readString(dis);
					
					this.livelle_moyen_paiement = readString(dis);
					
						this.id_menu = readInteger(dis);
					
					this.code_menu = readString(dis);
					
					this.libelle_menu = readString(dis);
					
						this.nombre_articles = readInteger(dis);
					
						this.temps_theo_preparation = (BigDecimal) dis.readObject();
					
						this.id_commande = readInteger(dis);
					
						this.numero_commande = readInteger(dis);
					
					this.date_commande = readDate(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.montant_total = null;
           				} else {
           			    	this.montant_total = dis.readFloat();
           				}
					
						this.id_adresse_norm_restaurant = readInteger(dis);
					
					this.numero_voie_restau = readString(dis);
					
					this.nom_voie_restau = readString(dis);
					
					this.code_postal_restau = readString(dis);
					
					this.nom_ville_restau = readString(dis);
					
					this.longitude_restau = readString(dis);
					
					this.latitude_restau = readString(dis);
					
						this.id_adresse_restaurant = readInteger(dis);
					
					this.adresse_restaurant = readString(dis);
					
						this.id_restaurant = readInteger(dis);
					
					this.code_restaurant = readString(dis);
					
					this.raison_sociale_restaurant = readString(dis);
					
						this.id_adresse_norm_client = readInteger(dis);
					
					this.numero_voie = readString(dis);
					
					this.nom_voie = readString(dis);
					
					this.code_postal = readString(dis);
					
					this.nom_ville = readString(dis);
					
					this.longitude = readString(dis);
					
					this.latitude = readString(dis);
					
						this.id_adresse_client = readInteger(dis);
					
					this.adresse_client = readString(dis);
					
						this.id_client = readInteger(dis);
					
					this.nom_client = readString(dis);
					
					this.prenom_client = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_DM1_C_ALIM_ODS_REJET) {

        	try {

        		int length = 0;
		
			        this.id_staging_dm1 = dis.readInt();
					
						this.id_preparation = readInteger(dis);
					
					this.date_debut_preparation = readDate(dis);
					
					this.date_fin_preparation = readDate(dis);
					
						this.id_moyen_paiement = readInteger(dis);
					
					this.code_moyen_paiement = readString(dis);
					
					this.livelle_moyen_paiement = readString(dis);
					
						this.id_menu = readInteger(dis);
					
					this.code_menu = readString(dis);
					
					this.libelle_menu = readString(dis);
					
						this.nombre_articles = readInteger(dis);
					
						this.temps_theo_preparation = (BigDecimal) dis.readObject();
					
						this.id_commande = readInteger(dis);
					
						this.numero_commande = readInteger(dis);
					
					this.date_commande = readDate(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.montant_total = null;
           				} else {
           			    	this.montant_total = dis.readFloat();
           				}
					
						this.id_adresse_norm_restaurant = readInteger(dis);
					
					this.numero_voie_restau = readString(dis);
					
					this.nom_voie_restau = readString(dis);
					
					this.code_postal_restau = readString(dis);
					
					this.nom_ville_restau = readString(dis);
					
					this.longitude_restau = readString(dis);
					
					this.latitude_restau = readString(dis);
					
						this.id_adresse_restaurant = readInteger(dis);
					
					this.adresse_restaurant = readString(dis);
					
						this.id_restaurant = readInteger(dis);
					
					this.code_restaurant = readString(dis);
					
					this.raison_sociale_restaurant = readString(dis);
					
						this.id_adresse_norm_client = readInteger(dis);
					
					this.numero_voie = readString(dis);
					
					this.nom_voie = readString(dis);
					
					this.code_postal = readString(dis);
					
					this.nom_ville = readString(dis);
					
					this.longitude = readString(dis);
					
					this.latitude = readString(dis);
					
						this.id_adresse_client = readInteger(dis);
					
					this.adresse_client = readString(dis);
					
						this.id_client = readInteger(dis);
					
					this.nom_client = readString(dis);
					
					this.prenom_client = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id_staging_dm1);
					
					// Integer
				
						writeInteger(this.id_preparation,dos);
					
					// java.util.Date
				
						writeDate(this.date_debut_preparation,dos);
					
					// java.util.Date
				
						writeDate(this.date_fin_preparation,dos);
					
					// Integer
				
						writeInteger(this.id_moyen_paiement,dos);
					
					// String
				
						writeString(this.code_moyen_paiement,dos);
					
					// String
				
						writeString(this.livelle_moyen_paiement,dos);
					
					// Integer
				
						writeInteger(this.id_menu,dos);
					
					// String
				
						writeString(this.code_menu,dos);
					
					// String
				
						writeString(this.libelle_menu,dos);
					
					// Integer
				
						writeInteger(this.nombre_articles,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.temps_theo_preparation);
					
					// Integer
				
						writeInteger(this.id_commande,dos);
					
					// Integer
				
						writeInteger(this.numero_commande,dos);
					
					// java.util.Date
				
						writeDate(this.date_commande,dos);
					
					// Float
				
						if(this.montant_total == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.montant_total);
		            	}
					
					// Integer
				
						writeInteger(this.id_adresse_norm_restaurant,dos);
					
					// String
				
						writeString(this.numero_voie_restau,dos);
					
					// String
				
						writeString(this.nom_voie_restau,dos);
					
					// String
				
						writeString(this.code_postal_restau,dos);
					
					// String
				
						writeString(this.nom_ville_restau,dos);
					
					// String
				
						writeString(this.longitude_restau,dos);
					
					// String
				
						writeString(this.latitude_restau,dos);
					
					// Integer
				
						writeInteger(this.id_adresse_restaurant,dos);
					
					// String
				
						writeString(this.adresse_restaurant,dos);
					
					// Integer
				
						writeInteger(this.id_restaurant,dos);
					
					// String
				
						writeString(this.code_restaurant,dos);
					
					// String
				
						writeString(this.raison_sociale_restaurant,dos);
					
					// Integer
				
						writeInteger(this.id_adresse_norm_client,dos);
					
					// String
				
						writeString(this.numero_voie,dos);
					
					// String
				
						writeString(this.nom_voie,dos);
					
					// String
				
						writeString(this.code_postal,dos);
					
					// String
				
						writeString(this.nom_ville,dos);
					
					// String
				
						writeString(this.longitude,dos);
					
					// String
				
						writeString(this.latitude,dos);
					
					// Integer
				
						writeInteger(this.id_adresse_client,dos);
					
					// String
				
						writeString(this.adresse_client,dos);
					
					// Integer
				
						writeInteger(this.id_client,dos);
					
					// String
				
						writeString(this.nom_client,dos);
					
					// String
				
						writeString(this.prenom_client,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id_staging_dm1);
					
					// Integer
				
						writeInteger(this.id_preparation,dos);
					
					// java.util.Date
				
						writeDate(this.date_debut_preparation,dos);
					
					// java.util.Date
				
						writeDate(this.date_fin_preparation,dos);
					
					// Integer
				
						writeInteger(this.id_moyen_paiement,dos);
					
					// String
				
						writeString(this.code_moyen_paiement,dos);
					
					// String
				
						writeString(this.livelle_moyen_paiement,dos);
					
					// Integer
				
						writeInteger(this.id_menu,dos);
					
					// String
				
						writeString(this.code_menu,dos);
					
					// String
				
						writeString(this.libelle_menu,dos);
					
					// Integer
				
						writeInteger(this.nombre_articles,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.temps_theo_preparation);
					
					// Integer
				
						writeInteger(this.id_commande,dos);
					
					// Integer
				
						writeInteger(this.numero_commande,dos);
					
					// java.util.Date
				
						writeDate(this.date_commande,dos);
					
					// Float
				
						if(this.montant_total == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.montant_total);
		            	}
					
					// Integer
				
						writeInteger(this.id_adresse_norm_restaurant,dos);
					
					// String
				
						writeString(this.numero_voie_restau,dos);
					
					// String
				
						writeString(this.nom_voie_restau,dos);
					
					// String
				
						writeString(this.code_postal_restau,dos);
					
					// String
				
						writeString(this.nom_ville_restau,dos);
					
					// String
				
						writeString(this.longitude_restau,dos);
					
					// String
				
						writeString(this.latitude_restau,dos);
					
					// Integer
				
						writeInteger(this.id_adresse_restaurant,dos);
					
					// String
				
						writeString(this.adresse_restaurant,dos);
					
					// Integer
				
						writeInteger(this.id_restaurant,dos);
					
					// String
				
						writeString(this.code_restaurant,dos);
					
					// String
				
						writeString(this.raison_sociale_restaurant,dos);
					
					// Integer
				
						writeInteger(this.id_adresse_norm_client,dos);
					
					// String
				
						writeString(this.numero_voie,dos);
					
					// String
				
						writeString(this.nom_voie,dos);
					
					// String
				
						writeString(this.code_postal,dos);
					
					// String
				
						writeString(this.nom_ville,dos);
					
					// String
				
						writeString(this.longitude,dos);
					
					// String
				
						writeString(this.latitude,dos);
					
					// Integer
				
						writeInteger(this.id_adresse_client,dos);
					
					// String
				
						writeString(this.adresse_client,dos);
					
					// Integer
				
						writeInteger(this.id_client,dos);
					
					// String
				
						writeString(this.nom_client,dos);
					
					// String
				
						writeString(this.prenom_client,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id_staging_dm1="+String.valueOf(id_staging_dm1));
		sb.append(",id_preparation="+String.valueOf(id_preparation));
		sb.append(",date_debut_preparation="+String.valueOf(date_debut_preparation));
		sb.append(",date_fin_preparation="+String.valueOf(date_fin_preparation));
		sb.append(",id_moyen_paiement="+String.valueOf(id_moyen_paiement));
		sb.append(",code_moyen_paiement="+code_moyen_paiement);
		sb.append(",livelle_moyen_paiement="+livelle_moyen_paiement);
		sb.append(",id_menu="+String.valueOf(id_menu));
		sb.append(",code_menu="+code_menu);
		sb.append(",libelle_menu="+libelle_menu);
		sb.append(",nombre_articles="+String.valueOf(nombre_articles));
		sb.append(",temps_theo_preparation="+String.valueOf(temps_theo_preparation));
		sb.append(",id_commande="+String.valueOf(id_commande));
		sb.append(",numero_commande="+String.valueOf(numero_commande));
		sb.append(",date_commande="+String.valueOf(date_commande));
		sb.append(",montant_total="+String.valueOf(montant_total));
		sb.append(",id_adresse_norm_restaurant="+String.valueOf(id_adresse_norm_restaurant));
		sb.append(",numero_voie_restau="+numero_voie_restau);
		sb.append(",nom_voie_restau="+nom_voie_restau);
		sb.append(",code_postal_restau="+code_postal_restau);
		sb.append(",nom_ville_restau="+nom_ville_restau);
		sb.append(",longitude_restau="+longitude_restau);
		sb.append(",latitude_restau="+latitude_restau);
		sb.append(",id_adresse_restaurant="+String.valueOf(id_adresse_restaurant));
		sb.append(",adresse_restaurant="+adresse_restaurant);
		sb.append(",id_restaurant="+String.valueOf(id_restaurant));
		sb.append(",code_restaurant="+code_restaurant);
		sb.append(",raison_sociale_restaurant="+raison_sociale_restaurant);
		sb.append(",id_adresse_norm_client="+String.valueOf(id_adresse_norm_client));
		sb.append(",numero_voie="+numero_voie);
		sb.append(",nom_voie="+nom_voie);
		sb.append(",code_postal="+code_postal);
		sb.append(",nom_ville="+nom_ville);
		sb.append(",longitude="+longitude);
		sb.append(",latitude="+latitude);
		sb.append(",id_adresse_client="+String.valueOf(id_adresse_client));
		sb.append(",adresse_client="+adresse_client);
		sb.append(",id_client="+String.valueOf(id_client));
		sb.append(",nom_client="+nom_client);
		sb.append(",prenom_client="+prenom_client);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row3Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row2Struct implements routines.system.IPersistableRow<row2Struct> {
    final static byte[] commonByteArrayLock_ALIMENTATION_DM1_C_ALIM_ODS_REJET = new byte[0];
    static byte[] commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int id_staging_dm1;

				public int getId_staging_dm1 () {
					return this.id_staging_dm1;
				}
				
			    public Integer id_preparation;

				public Integer getId_preparation () {
					return this.id_preparation;
				}
				
			    public java.util.Date date_debut_preparation;

				public java.util.Date getDate_debut_preparation () {
					return this.date_debut_preparation;
				}
				
			    public java.util.Date date_fin_preparation;

				public java.util.Date getDate_fin_preparation () {
					return this.date_fin_preparation;
				}
				
			    public Integer id_moyen_paiement;

				public Integer getId_moyen_paiement () {
					return this.id_moyen_paiement;
				}
				
			    public String code_moyen_paiement;

				public String getCode_moyen_paiement () {
					return this.code_moyen_paiement;
				}
				
			    public String livelle_moyen_paiement;

				public String getLivelle_moyen_paiement () {
					return this.livelle_moyen_paiement;
				}
				
			    public Integer id_menu;

				public Integer getId_menu () {
					return this.id_menu;
				}
				
			    public String code_menu;

				public String getCode_menu () {
					return this.code_menu;
				}
				
			    public String libelle_menu;

				public String getLibelle_menu () {
					return this.libelle_menu;
				}
				
			    public Integer nombre_articles;

				public Integer getNombre_articles () {
					return this.nombre_articles;
				}
				
			    public BigDecimal temps_theo_preparation;

				public BigDecimal getTemps_theo_preparation () {
					return this.temps_theo_preparation;
				}
				
			    public Integer id_commande;

				public Integer getId_commande () {
					return this.id_commande;
				}
				
			    public Integer numero_commande;

				public Integer getNumero_commande () {
					return this.numero_commande;
				}
				
			    public java.util.Date date_commande;

				public java.util.Date getDate_commande () {
					return this.date_commande;
				}
				
			    public Float montant_total;

				public Float getMontant_total () {
					return this.montant_total;
				}
				
			    public Integer id_adresse_norm_restaurant;

				public Integer getId_adresse_norm_restaurant () {
					return this.id_adresse_norm_restaurant;
				}
				
			    public String numero_voie_restau;

				public String getNumero_voie_restau () {
					return this.numero_voie_restau;
				}
				
			    public String nom_voie_restau;

				public String getNom_voie_restau () {
					return this.nom_voie_restau;
				}
				
			    public String code_postal_restau;

				public String getCode_postal_restau () {
					return this.code_postal_restau;
				}
				
			    public String nom_ville_restau;

				public String getNom_ville_restau () {
					return this.nom_ville_restau;
				}
				
			    public String longitude_restau;

				public String getLongitude_restau () {
					return this.longitude_restau;
				}
				
			    public String latitude_restau;

				public String getLatitude_restau () {
					return this.latitude_restau;
				}
				
			    public Integer id_adresse_restaurant;

				public Integer getId_adresse_restaurant () {
					return this.id_adresse_restaurant;
				}
				
			    public String adresse_restaurant;

				public String getAdresse_restaurant () {
					return this.adresse_restaurant;
				}
				
			    public Integer id_restaurant;

				public Integer getId_restaurant () {
					return this.id_restaurant;
				}
				
			    public String code_restaurant;

				public String getCode_restaurant () {
					return this.code_restaurant;
				}
				
			    public String raison_sociale_restaurant;

				public String getRaison_sociale_restaurant () {
					return this.raison_sociale_restaurant;
				}
				
			    public Integer id_adresse_norm_client;

				public Integer getId_adresse_norm_client () {
					return this.id_adresse_norm_client;
				}
				
			    public String numero_voie;

				public String getNumero_voie () {
					return this.numero_voie;
				}
				
			    public String nom_voie;

				public String getNom_voie () {
					return this.nom_voie;
				}
				
			    public String code_postal;

				public String getCode_postal () {
					return this.code_postal;
				}
				
			    public String nom_ville;

				public String getNom_ville () {
					return this.nom_ville;
				}
				
			    public String longitude;

				public String getLongitude () {
					return this.longitude;
				}
				
			    public String latitude;

				public String getLatitude () {
					return this.latitude;
				}
				
			    public Integer id_adresse_client;

				public Integer getId_adresse_client () {
					return this.id_adresse_client;
				}
				
			    public String adresse_client;

				public String getAdresse_client () {
					return this.adresse_client;
				}
				
			    public Integer id_client;

				public Integer getId_client () {
					return this.id_client;
				}
				
			    public String nom_client;

				public String getNom_client () {
					return this.nom_client;
				}
				
			    public String prenom_client;

				public String getPrenom_client () {
					return this.prenom_client;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.id_staging_dm1;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row2Struct other = (row2Struct) obj;
		
						if (this.id_staging_dm1 != other.id_staging_dm1)
							return false;
					

		return true;
    }

	public void copyDataTo(row2Struct other) {

		other.id_staging_dm1 = this.id_staging_dm1;
	            other.id_preparation = this.id_preparation;
	            other.date_debut_preparation = this.date_debut_preparation;
	            other.date_fin_preparation = this.date_fin_preparation;
	            other.id_moyen_paiement = this.id_moyen_paiement;
	            other.code_moyen_paiement = this.code_moyen_paiement;
	            other.livelle_moyen_paiement = this.livelle_moyen_paiement;
	            other.id_menu = this.id_menu;
	            other.code_menu = this.code_menu;
	            other.libelle_menu = this.libelle_menu;
	            other.nombre_articles = this.nombre_articles;
	            other.temps_theo_preparation = this.temps_theo_preparation;
	            other.id_commande = this.id_commande;
	            other.numero_commande = this.numero_commande;
	            other.date_commande = this.date_commande;
	            other.montant_total = this.montant_total;
	            other.id_adresse_norm_restaurant = this.id_adresse_norm_restaurant;
	            other.numero_voie_restau = this.numero_voie_restau;
	            other.nom_voie_restau = this.nom_voie_restau;
	            other.code_postal_restau = this.code_postal_restau;
	            other.nom_ville_restau = this.nom_ville_restau;
	            other.longitude_restau = this.longitude_restau;
	            other.latitude_restau = this.latitude_restau;
	            other.id_adresse_restaurant = this.id_adresse_restaurant;
	            other.adresse_restaurant = this.adresse_restaurant;
	            other.id_restaurant = this.id_restaurant;
	            other.code_restaurant = this.code_restaurant;
	            other.raison_sociale_restaurant = this.raison_sociale_restaurant;
	            other.id_adresse_norm_client = this.id_adresse_norm_client;
	            other.numero_voie = this.numero_voie;
	            other.nom_voie = this.nom_voie;
	            other.code_postal = this.code_postal;
	            other.nom_ville = this.nom_ville;
	            other.longitude = this.longitude;
	            other.latitude = this.latitude;
	            other.id_adresse_client = this.id_adresse_client;
	            other.adresse_client = this.adresse_client;
	            other.id_client = this.id_client;
	            other.nom_client = this.nom_client;
	            other.prenom_client = this.prenom_client;
	            
	}

	public void copyKeysDataTo(row2Struct other) {

		other.id_staging_dm1 = this.id_staging_dm1;
	            	
	}



	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET.length == 0) {
   					commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET.length == 0) {
   					commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_DM1_C_ALIM_ODS_REJET, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_DM1_C_ALIM_ODS_REJET) {

        	try {

        		int length = 0;
		
			        this.id_staging_dm1 = dis.readInt();
					
						this.id_preparation = readInteger(dis);
					
					this.date_debut_preparation = readDate(dis);
					
					this.date_fin_preparation = readDate(dis);
					
						this.id_moyen_paiement = readInteger(dis);
					
					this.code_moyen_paiement = readString(dis);
					
					this.livelle_moyen_paiement = readString(dis);
					
						this.id_menu = readInteger(dis);
					
					this.code_menu = readString(dis);
					
					this.libelle_menu = readString(dis);
					
						this.nombre_articles = readInteger(dis);
					
						this.temps_theo_preparation = (BigDecimal) dis.readObject();
					
						this.id_commande = readInteger(dis);
					
						this.numero_commande = readInteger(dis);
					
					this.date_commande = readDate(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.montant_total = null;
           				} else {
           			    	this.montant_total = dis.readFloat();
           				}
					
						this.id_adresse_norm_restaurant = readInteger(dis);
					
					this.numero_voie_restau = readString(dis);
					
					this.nom_voie_restau = readString(dis);
					
					this.code_postal_restau = readString(dis);
					
					this.nom_ville_restau = readString(dis);
					
					this.longitude_restau = readString(dis);
					
					this.latitude_restau = readString(dis);
					
						this.id_adresse_restaurant = readInteger(dis);
					
					this.adresse_restaurant = readString(dis);
					
						this.id_restaurant = readInteger(dis);
					
					this.code_restaurant = readString(dis);
					
					this.raison_sociale_restaurant = readString(dis);
					
						this.id_adresse_norm_client = readInteger(dis);
					
					this.numero_voie = readString(dis);
					
					this.nom_voie = readString(dis);
					
					this.code_postal = readString(dis);
					
					this.nom_ville = readString(dis);
					
					this.longitude = readString(dis);
					
					this.latitude = readString(dis);
					
						this.id_adresse_client = readInteger(dis);
					
					this.adresse_client = readString(dis);
					
						this.id_client = readInteger(dis);
					
					this.nom_client = readString(dis);
					
					this.prenom_client = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_DM1_C_ALIM_ODS_REJET) {

        	try {

        		int length = 0;
		
			        this.id_staging_dm1 = dis.readInt();
					
						this.id_preparation = readInteger(dis);
					
					this.date_debut_preparation = readDate(dis);
					
					this.date_fin_preparation = readDate(dis);
					
						this.id_moyen_paiement = readInteger(dis);
					
					this.code_moyen_paiement = readString(dis);
					
					this.livelle_moyen_paiement = readString(dis);
					
						this.id_menu = readInteger(dis);
					
					this.code_menu = readString(dis);
					
					this.libelle_menu = readString(dis);
					
						this.nombre_articles = readInteger(dis);
					
						this.temps_theo_preparation = (BigDecimal) dis.readObject();
					
						this.id_commande = readInteger(dis);
					
						this.numero_commande = readInteger(dis);
					
					this.date_commande = readDate(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.montant_total = null;
           				} else {
           			    	this.montant_total = dis.readFloat();
           				}
					
						this.id_adresse_norm_restaurant = readInteger(dis);
					
					this.numero_voie_restau = readString(dis);
					
					this.nom_voie_restau = readString(dis);
					
					this.code_postal_restau = readString(dis);
					
					this.nom_ville_restau = readString(dis);
					
					this.longitude_restau = readString(dis);
					
					this.latitude_restau = readString(dis);
					
						this.id_adresse_restaurant = readInteger(dis);
					
					this.adresse_restaurant = readString(dis);
					
						this.id_restaurant = readInteger(dis);
					
					this.code_restaurant = readString(dis);
					
					this.raison_sociale_restaurant = readString(dis);
					
						this.id_adresse_norm_client = readInteger(dis);
					
					this.numero_voie = readString(dis);
					
					this.nom_voie = readString(dis);
					
					this.code_postal = readString(dis);
					
					this.nom_ville = readString(dis);
					
					this.longitude = readString(dis);
					
					this.latitude = readString(dis);
					
						this.id_adresse_client = readInteger(dis);
					
					this.adresse_client = readString(dis);
					
						this.id_client = readInteger(dis);
					
					this.nom_client = readString(dis);
					
					this.prenom_client = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id_staging_dm1);
					
					// Integer
				
						writeInteger(this.id_preparation,dos);
					
					// java.util.Date
				
						writeDate(this.date_debut_preparation,dos);
					
					// java.util.Date
				
						writeDate(this.date_fin_preparation,dos);
					
					// Integer
				
						writeInteger(this.id_moyen_paiement,dos);
					
					// String
				
						writeString(this.code_moyen_paiement,dos);
					
					// String
				
						writeString(this.livelle_moyen_paiement,dos);
					
					// Integer
				
						writeInteger(this.id_menu,dos);
					
					// String
				
						writeString(this.code_menu,dos);
					
					// String
				
						writeString(this.libelle_menu,dos);
					
					// Integer
				
						writeInteger(this.nombre_articles,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.temps_theo_preparation);
					
					// Integer
				
						writeInteger(this.id_commande,dos);
					
					// Integer
				
						writeInteger(this.numero_commande,dos);
					
					// java.util.Date
				
						writeDate(this.date_commande,dos);
					
					// Float
				
						if(this.montant_total == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.montant_total);
		            	}
					
					// Integer
				
						writeInteger(this.id_adresse_norm_restaurant,dos);
					
					// String
				
						writeString(this.numero_voie_restau,dos);
					
					// String
				
						writeString(this.nom_voie_restau,dos);
					
					// String
				
						writeString(this.code_postal_restau,dos);
					
					// String
				
						writeString(this.nom_ville_restau,dos);
					
					// String
				
						writeString(this.longitude_restau,dos);
					
					// String
				
						writeString(this.latitude_restau,dos);
					
					// Integer
				
						writeInteger(this.id_adresse_restaurant,dos);
					
					// String
				
						writeString(this.adresse_restaurant,dos);
					
					// Integer
				
						writeInteger(this.id_restaurant,dos);
					
					// String
				
						writeString(this.code_restaurant,dos);
					
					// String
				
						writeString(this.raison_sociale_restaurant,dos);
					
					// Integer
				
						writeInteger(this.id_adresse_norm_client,dos);
					
					// String
				
						writeString(this.numero_voie,dos);
					
					// String
				
						writeString(this.nom_voie,dos);
					
					// String
				
						writeString(this.code_postal,dos);
					
					// String
				
						writeString(this.nom_ville,dos);
					
					// String
				
						writeString(this.longitude,dos);
					
					// String
				
						writeString(this.latitude,dos);
					
					// Integer
				
						writeInteger(this.id_adresse_client,dos);
					
					// String
				
						writeString(this.adresse_client,dos);
					
					// Integer
				
						writeInteger(this.id_client,dos);
					
					// String
				
						writeString(this.nom_client,dos);
					
					// String
				
						writeString(this.prenom_client,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id_staging_dm1);
					
					// Integer
				
						writeInteger(this.id_preparation,dos);
					
					// java.util.Date
				
						writeDate(this.date_debut_preparation,dos);
					
					// java.util.Date
				
						writeDate(this.date_fin_preparation,dos);
					
					// Integer
				
						writeInteger(this.id_moyen_paiement,dos);
					
					// String
				
						writeString(this.code_moyen_paiement,dos);
					
					// String
				
						writeString(this.livelle_moyen_paiement,dos);
					
					// Integer
				
						writeInteger(this.id_menu,dos);
					
					// String
				
						writeString(this.code_menu,dos);
					
					// String
				
						writeString(this.libelle_menu,dos);
					
					// Integer
				
						writeInteger(this.nombre_articles,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.temps_theo_preparation);
					
					// Integer
				
						writeInteger(this.id_commande,dos);
					
					// Integer
				
						writeInteger(this.numero_commande,dos);
					
					// java.util.Date
				
						writeDate(this.date_commande,dos);
					
					// Float
				
						if(this.montant_total == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.montant_total);
		            	}
					
					// Integer
				
						writeInteger(this.id_adresse_norm_restaurant,dos);
					
					// String
				
						writeString(this.numero_voie_restau,dos);
					
					// String
				
						writeString(this.nom_voie_restau,dos);
					
					// String
				
						writeString(this.code_postal_restau,dos);
					
					// String
				
						writeString(this.nom_ville_restau,dos);
					
					// String
				
						writeString(this.longitude_restau,dos);
					
					// String
				
						writeString(this.latitude_restau,dos);
					
					// Integer
				
						writeInteger(this.id_adresse_restaurant,dos);
					
					// String
				
						writeString(this.adresse_restaurant,dos);
					
					// Integer
				
						writeInteger(this.id_restaurant,dos);
					
					// String
				
						writeString(this.code_restaurant,dos);
					
					// String
				
						writeString(this.raison_sociale_restaurant,dos);
					
					// Integer
				
						writeInteger(this.id_adresse_norm_client,dos);
					
					// String
				
						writeString(this.numero_voie,dos);
					
					// String
				
						writeString(this.nom_voie,dos);
					
					// String
				
						writeString(this.code_postal,dos);
					
					// String
				
						writeString(this.nom_ville,dos);
					
					// String
				
						writeString(this.longitude,dos);
					
					// String
				
						writeString(this.latitude,dos);
					
					// Integer
				
						writeInteger(this.id_adresse_client,dos);
					
					// String
				
						writeString(this.adresse_client,dos);
					
					// Integer
				
						writeInteger(this.id_client,dos);
					
					// String
				
						writeString(this.nom_client,dos);
					
					// String
				
						writeString(this.prenom_client,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id_staging_dm1="+String.valueOf(id_staging_dm1));
		sb.append(",id_preparation="+String.valueOf(id_preparation));
		sb.append(",date_debut_preparation="+String.valueOf(date_debut_preparation));
		sb.append(",date_fin_preparation="+String.valueOf(date_fin_preparation));
		sb.append(",id_moyen_paiement="+String.valueOf(id_moyen_paiement));
		sb.append(",code_moyen_paiement="+code_moyen_paiement);
		sb.append(",livelle_moyen_paiement="+livelle_moyen_paiement);
		sb.append(",id_menu="+String.valueOf(id_menu));
		sb.append(",code_menu="+code_menu);
		sb.append(",libelle_menu="+libelle_menu);
		sb.append(",nombre_articles="+String.valueOf(nombre_articles));
		sb.append(",temps_theo_preparation="+String.valueOf(temps_theo_preparation));
		sb.append(",id_commande="+String.valueOf(id_commande));
		sb.append(",numero_commande="+String.valueOf(numero_commande));
		sb.append(",date_commande="+String.valueOf(date_commande));
		sb.append(",montant_total="+String.valueOf(montant_total));
		sb.append(",id_adresse_norm_restaurant="+String.valueOf(id_adresse_norm_restaurant));
		sb.append(",numero_voie_restau="+numero_voie_restau);
		sb.append(",nom_voie_restau="+nom_voie_restau);
		sb.append(",code_postal_restau="+code_postal_restau);
		sb.append(",nom_ville_restau="+nom_ville_restau);
		sb.append(",longitude_restau="+longitude_restau);
		sb.append(",latitude_restau="+latitude_restau);
		sb.append(",id_adresse_restaurant="+String.valueOf(id_adresse_restaurant));
		sb.append(",adresse_restaurant="+adresse_restaurant);
		sb.append(",id_restaurant="+String.valueOf(id_restaurant));
		sb.append(",code_restaurant="+code_restaurant);
		sb.append(",raison_sociale_restaurant="+raison_sociale_restaurant);
		sb.append(",id_adresse_norm_client="+String.valueOf(id_adresse_norm_client));
		sb.append(",numero_voie="+numero_voie);
		sb.append(",nom_voie="+nom_voie);
		sb.append(",code_postal="+code_postal);
		sb.append(",nom_ville="+nom_ville);
		sb.append(",longitude="+longitude);
		sb.append(",latitude="+latitude);
		sb.append(",id_adresse_client="+String.valueOf(id_adresse_client));
		sb.append(",adresse_client="+adresse_client);
		sb.append(",id_client="+String.valueOf(id_client));
		sb.append(",nom_client="+nom_client);
		sb.append(",prenom_client="+prenom_client);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row2Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.id_staging_dm1, other.id_staging_dm1);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tDBInput_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBInput_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row2Struct row2 = new row2Struct();
row4Struct row4 = new row4Struct();
row5Struct row5 = new row5Struct();
alim_odsStruct alim_ods = new alim_odsStruct();
row6Struct row6 = new row6Struct();
alim_rejet_code_posta_restauStruct alim_rejet_code_posta_restau = new alim_rejet_code_posta_restauStruct();
row3Struct row3 = new row3Struct();
alimt_rejet_doublonsStruct alimt_rejet_doublons = new alimt_rejet_doublonsStruct();







	
	/**
	 * [tDBOutput_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_4", false);
		start_Hash.put("tDBOutput_4", System.currentTimeMillis());
		
				tStatCatcher_1.addMessage("begin","tDBOutput_4");
				tStatCatcher_1Process(globalMap);
			
	
	currentComponent="tDBOutput_4";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"alim_ods");
					}
				
		int tos_count_tDBOutput_4 = 0;
		





String dbschema_tDBOutput_4 = null;
	dbschema_tDBOutput_4 = "dsid_liv_wrk";
	

String tableName_tDBOutput_4 = null;
if(dbschema_tDBOutput_4 == null || dbschema_tDBOutput_4.trim().length() == 0) {
	tableName_tDBOutput_4 = ("dm1_ods");
} else {
	tableName_tDBOutput_4 = dbschema_tDBOutput_4 + "\".\"" + ("dm1_ods");
}


int nb_line_tDBOutput_4 = 0;
int nb_line_update_tDBOutput_4 = 0;
int nb_line_inserted_tDBOutput_4 = 0;
int nb_line_deleted_tDBOutput_4 = 0;
int nb_line_rejected_tDBOutput_4 = 0;

int deletedCount_tDBOutput_4=0;
int updatedCount_tDBOutput_4=0;
int insertedCount_tDBOutput_4=0;
int rowsToCommitCount_tDBOutput_4=0;
int rejectedCount_tDBOutput_4=0;

boolean whetherReject_tDBOutput_4 = false;

java.sql.Connection conn_tDBOutput_4 = null;
String dbUser_tDBOutput_4 = null;

	
    java.lang.Class.forName("org.postgresql.Driver");
    
        String url_tDBOutput_4 = "jdbc:postgresql://"+""+":"+"5432"+"/"+"postgres";
    dbUser_tDBOutput_4 = "dsid_cc2_tos_rw";
 
	final String decryptedPassword_tDBOutput_4 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:TwQFUyV0tdiszzoekqk7q0I+Hw8C7sW0n48cQsQm+dE=");

    String dbPwd_tDBOutput_4 = decryptedPassword_tDBOutput_4;

    conn_tDBOutput_4 = java.sql.DriverManager.getConnection(url_tDBOutput_4,dbUser_tDBOutput_4,dbPwd_tDBOutput_4);
	
	resourceMap.put("conn_tDBOutput_4", conn_tDBOutput_4);
        conn_tDBOutput_4.setAutoCommit(false);
        int commitEvery_tDBOutput_4 = 10000;
        int commitCounter_tDBOutput_4 = 0;


   int batchSize_tDBOutput_4 = 10000;
   int batchSizeCounter_tDBOutput_4=0;

int count_tDBOutput_4=0;
            int rsTruncCountNumber_tDBOutput_4 = 0;
            try(java.sql.Statement stmtTruncCount_tDBOutput_4 = conn_tDBOutput_4.createStatement()) {
                try (java.sql.ResultSet rsTruncCount_tDBOutput_4 = stmtTruncCount_tDBOutput_4.executeQuery("SELECT COUNT(1) FROM \"" + tableName_tDBOutput_4 + "\"")) {
                    if(rsTruncCount_tDBOutput_4.next()) {
                        rsTruncCountNumber_tDBOutput_4 = rsTruncCount_tDBOutput_4.getInt(1);
                    }
                }
            }
            try (java.sql.Statement stmtTrunc_tDBOutput_4 = conn_tDBOutput_4.createStatement()) {
                stmtTrunc_tDBOutput_4.executeUpdate("TRUNCATE TABLE \"" + tableName_tDBOutput_4 + "\"");
                deletedCount_tDBOutput_4 += rsTruncCountNumber_tDBOutput_4;
            }
	    String insert_tDBOutput_4 = "INSERT INTO \"" + tableName_tDBOutput_4 + "\" (\"" + "id_ods_dm1" + "\",\"id_preparation\",\"date_debut_preparation\",\"date_fin_preparation\",\"temps_reel_preparation\",\"id_moyen_paiement\",\"code_moyen_paiement\",\"livelle_moyen_paiement\",\"id_menu\",\"code_menu\",\"libelle_menu\",\"nombre_articles\",\"temps_theo_preparation\",\"id_commande\",\"numero_commande\",\"date_commande\",\"montant_total\",\"id_adresse_norm_restaurant\",\"numero_voie_restau\",\"nom_voie_restau\",\"code_postal_restau\",\"nom_ville_restau\",\"longitude_restau\",\"latitude_restau\",\"id_adresse_restaurant\",\"adresse_restaurant\",\"id_restaurant\",\"code_restaurant\",\"raison_sociale_restaurant\",\"id_adresse_norm_client\",\"numero_voie\",\"nom_voie\",\"code_postal\",\"nom_ville\",\"longitude\",\"latitude\",\"id_adresse_client\",\"adresse_client\",\"id_client\",\"nom_client\",\"prenom_client\") VALUES (" + "nextval('dsid_liv_wrk.seq_id_ods_dm1')" + ",?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
	    
	    java.sql.PreparedStatement pstmt_tDBOutput_4 = conn_tDBOutput_4.prepareStatement(insert_tDBOutput_4);
	    resourceMap.put("pstmt_tDBOutput_4", pstmt_tDBOutput_4);
	    

 



/**
 * [tDBOutput_4 begin ] stop
 */



	
	/**
	 * [tMap_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tMap_2", false);
		start_Hash.put("tMap_2", System.currentTimeMillis());
		
				tStatCatcher_1.addMessage("begin","tMap_2");
				tStatCatcher_1Process(globalMap);
			
	
	currentComponent="tMap_2";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row5");
					}
				
		int tos_count_tMap_2 = 0;
		




// ###############################
// # Lookup's keys initialization
// ###############################        

// ###############################
// # Vars initialization
class  Var__tMap_2__Struct  {
}
Var__tMap_2__Struct Var__tMap_2 = new Var__tMap_2__Struct();
// ###############################

// ###############################
// # Outputs initialization
alim_odsStruct alim_ods_tmp = new alim_odsStruct();
// ###############################

        
        



        









 



/**
 * [tMap_2 begin ] stop
 */





	
	/**
	 * [tDBOutput_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_3", false);
		start_Hash.put("tDBOutput_3", System.currentTimeMillis());
		
				tStatCatcher_1.addMessage("begin","tDBOutput_3");
				tStatCatcher_1Process(globalMap);
			
	
	currentComponent="tDBOutput_3";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"alim_rejet_code_posta_restau");
					}
				
		int tos_count_tDBOutput_3 = 0;
		





String dbschema_tDBOutput_3 = null;
	dbschema_tDBOutput_3 = "dsid_liv_wrk";
	

String tableName_tDBOutput_3 = null;
if(dbschema_tDBOutput_3 == null || dbschema_tDBOutput_3.trim().length() == 0) {
	tableName_tDBOutput_3 = ("dm1_rejet");
} else {
	tableName_tDBOutput_3 = dbschema_tDBOutput_3 + "\".\"" + ("dm1_rejet");
}


int nb_line_tDBOutput_3 = 0;
int nb_line_update_tDBOutput_3 = 0;
int nb_line_inserted_tDBOutput_3 = 0;
int nb_line_deleted_tDBOutput_3 = 0;
int nb_line_rejected_tDBOutput_3 = 0;

int deletedCount_tDBOutput_3=0;
int updatedCount_tDBOutput_3=0;
int insertedCount_tDBOutput_3=0;
int rowsToCommitCount_tDBOutput_3=0;
int rejectedCount_tDBOutput_3=0;

boolean whetherReject_tDBOutput_3 = false;

java.sql.Connection conn_tDBOutput_3 = null;
String dbUser_tDBOutput_3 = null;

	
    java.lang.Class.forName("org.postgresql.Driver");
    
        String url_tDBOutput_3 = "jdbc:postgresql://"+""+":"+"5432"+"/"+"postgres";
    dbUser_tDBOutput_3 = "dsid_cc2_tos_rw";
 
	final String decryptedPassword_tDBOutput_3 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:WfnD5isGrGOAdp2cP7puelpKj2VX/uQVfnXR086XUR0=");

    String dbPwd_tDBOutput_3 = decryptedPassword_tDBOutput_3;

    conn_tDBOutput_3 = java.sql.DriverManager.getConnection(url_tDBOutput_3,dbUser_tDBOutput_3,dbPwd_tDBOutput_3);
	
	resourceMap.put("conn_tDBOutput_3", conn_tDBOutput_3);
        conn_tDBOutput_3.setAutoCommit(false);
        int commitEvery_tDBOutput_3 = 10000;
        int commitCounter_tDBOutput_3 = 0;


   int batchSize_tDBOutput_3 = 10000;
   int batchSizeCounter_tDBOutput_3=0;

int count_tDBOutput_3=0;
	    String insert_tDBOutput_3 = "INSERT INTO \"" + tableName_tDBOutput_3 + "\" (\"" + "id_rejet_dm1" + "\",\"id_preparation\",\"date_debut_preparation\",\"date_fin_preparation\",\"id_moyen_paiement\",\"code_moyen_paiement\",\"livelle_moyen_paiement\",\"id_menu\",\"code_menu\",\"libelle_menu\",\"nombre_articles\",\"temps_theo_preparation\",\"id_commande\",\"numero_commande\",\"date_commande\",\"montant_total\",\"id_adresse_norm_restaurant\",\"numero_voie_restau\",\"nom_voie_restau\",\"code_postal_restau\",\"nom_ville_restau\",\"longitude_restau\",\"latitude_restau\",\"id_adresse_restaurant\",\"adresse_restaurant\",\"id_restaurant\",\"code_restaurant\",\"raison_sociale_restaurant\",\"id_adresse_norm_client\",\"numero_voie\",\"nom_voie\",\"code_postal\",\"nom_ville\",\"longitude\",\"latitude\",\"id_adresse_client\",\"adresse_client\",\"id_client\",\"nom_client\",\"prenom_client\",\"type_rejet\",\"message_log\") VALUES (" + "nextval('dsid_liv_wrk.seq_id_rejet_dm1')" + ",?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
	    
	    java.sql.PreparedStatement pstmt_tDBOutput_3 = conn_tDBOutput_3.prepareStatement(insert_tDBOutput_3);
	    resourceMap.put("pstmt_tDBOutput_3", pstmt_tDBOutput_3);
	    

 



/**
 * [tDBOutput_3 begin ] stop
 */



	
	/**
	 * [tMap_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tMap_3", false);
		start_Hash.put("tMap_3", System.currentTimeMillis());
		
				tStatCatcher_1.addMessage("begin","tMap_3");
				tStatCatcher_1Process(globalMap);
			
	
	currentComponent="tMap_3";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row6");
					}
				
		int tos_count_tMap_3 = 0;
		




// ###############################
// # Lookup's keys initialization
// ###############################        

// ###############################
// # Vars initialization
class  Var__tMap_3__Struct  {
}
Var__tMap_3__Struct Var__tMap_3 = new Var__tMap_3__Struct();
// ###############################

// ###############################
// # Outputs initialization
alim_rejet_code_posta_restauStruct alim_rejet_code_posta_restau_tmp = new alim_rejet_code_posta_restauStruct();
// ###############################

        
        



        









 



/**
 * [tMap_3 begin ] stop
 */



	
	/**
	 * [tFilterRow_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tFilterRow_1", false);
		start_Hash.put("tFilterRow_1", System.currentTimeMillis());
		
				tStatCatcher_1.addMessage("begin","tFilterRow_1");
				tStatCatcher_1Process(globalMap);
			
	
	currentComponent="tFilterRow_1";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row4");
					}
				
		int tos_count_tFilterRow_1 = 0;
		
    int nb_line_tFilterRow_1 = 0;
    int nb_line_ok_tFilterRow_1 = 0;
    int nb_line_reject_tFilterRow_1 = 0;

    class Operator_tFilterRow_1 {
      private String sErrorMsg = "";
      private boolean bMatchFlag = true;
      private String sUnionFlag = "&&";

      public Operator_tFilterRow_1(String unionFlag){
        sUnionFlag = unionFlag;
        bMatchFlag =  "||".equals(unionFlag) ? false : true;
      }

      public String getErrorMsg() {
        if (sErrorMsg != null && sErrorMsg.length() > 1)
          return sErrorMsg.substring(1);
        else 
          return null;
      }

      public boolean getMatchFlag() {
        return bMatchFlag;
      }

      public void matches(boolean partMatched, String reason) {
        // no need to care about the next judgement
        if ("||".equals(sUnionFlag) && bMatchFlag){
          return;
        }

        if (!partMatched) {
          sErrorMsg += "|" + reason;
        }

        if ("||".equals(sUnionFlag))
          bMatchFlag = bMatchFlag || partMatched;
        else
          bMatchFlag = bMatchFlag && partMatched;
      }
    }

 



/**
 * [tFilterRow_1 begin ] stop
 */





	
	/**
	 * [tDBOutput_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_2", false);
		start_Hash.put("tDBOutput_2", System.currentTimeMillis());
		
				tStatCatcher_1.addMessage("begin","tDBOutput_2");
				tStatCatcher_1Process(globalMap);
			
	
	currentComponent="tDBOutput_2";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"alimt_rejet_doublons");
					}
				
		int tos_count_tDBOutput_2 = 0;
		





String dbschema_tDBOutput_2 = null;
	dbschema_tDBOutput_2 = "dsid_liv_wrk";
	

String tableName_tDBOutput_2 = null;
if(dbschema_tDBOutput_2 == null || dbschema_tDBOutput_2.trim().length() == 0) {
	tableName_tDBOutput_2 = ("dm1_rejet");
} else {
	tableName_tDBOutput_2 = dbschema_tDBOutput_2 + "\".\"" + ("dm1_rejet");
}


int nb_line_tDBOutput_2 = 0;
int nb_line_update_tDBOutput_2 = 0;
int nb_line_inserted_tDBOutput_2 = 0;
int nb_line_deleted_tDBOutput_2 = 0;
int nb_line_rejected_tDBOutput_2 = 0;

int deletedCount_tDBOutput_2=0;
int updatedCount_tDBOutput_2=0;
int insertedCount_tDBOutput_2=0;
int rowsToCommitCount_tDBOutput_2=0;
int rejectedCount_tDBOutput_2=0;

boolean whetherReject_tDBOutput_2 = false;

java.sql.Connection conn_tDBOutput_2 = null;
String dbUser_tDBOutput_2 = null;

	
    java.lang.Class.forName("org.postgresql.Driver");
    
        String url_tDBOutput_2 = "jdbc:postgresql://"+""+":"+"5432"+"/"+"postgres";
    dbUser_tDBOutput_2 = "dsid_cc2_tos_rw";
 
	final String decryptedPassword_tDBOutput_2 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:qFbGPWXmr+eLTF59fzsQNnd7w0HWb6cGabyU4LP7h1w=");

    String dbPwd_tDBOutput_2 = decryptedPassword_tDBOutput_2;

    conn_tDBOutput_2 = java.sql.DriverManager.getConnection(url_tDBOutput_2,dbUser_tDBOutput_2,dbPwd_tDBOutput_2);
	
	resourceMap.put("conn_tDBOutput_2", conn_tDBOutput_2);
        conn_tDBOutput_2.setAutoCommit(false);
        int commitEvery_tDBOutput_2 = 10000;
        int commitCounter_tDBOutput_2 = 0;


   int batchSize_tDBOutput_2 = 10000;
   int batchSizeCounter_tDBOutput_2=0;

int count_tDBOutput_2=0;
	    String insert_tDBOutput_2 = "INSERT INTO \"" + tableName_tDBOutput_2 + "\" (\"" + "id_rejet_dm1" + "\",\"id_preparation\",\"date_debut_preparation\",\"date_fin_preparation\",\"id_moyen_paiement\",\"code_moyen_paiement\",\"livelle_moyen_paiement\",\"id_menu\",\"code_menu\",\"libelle_menu\",\"nombre_articles\",\"temps_theo_preparation\",\"id_commande\",\"numero_commande\",\"date_commande\",\"montant_total\",\"id_adresse_norm_restaurant\",\"numero_voie_restau\",\"nom_voie_restau\",\"code_postal_restau\",\"nom_ville_restau\",\"longitude_restau\",\"latitude_restau\",\"id_adresse_restaurant\",\"adresse_restaurant\",\"id_restaurant\",\"code_restaurant\",\"raison_sociale_restaurant\",\"id_adresse_norm_client\",\"numero_voie\",\"nom_voie\",\"code_postal\",\"nom_ville\",\"longitude\",\"latitude\",\"id_adresse_client\",\"adresse_client\",\"id_client\",\"nom_client\",\"prenom_client\",\"type_rejet\",\"message_log\") VALUES (" + "nextval('dsid_liv_wrk.seq_id_rejet_dm1')" + ",?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
	    
	    java.sql.PreparedStatement pstmt_tDBOutput_2 = conn_tDBOutput_2.prepareStatement(insert_tDBOutput_2);
	    resourceMap.put("pstmt_tDBOutput_2", pstmt_tDBOutput_2);
	    

 



/**
 * [tDBOutput_2 begin ] stop
 */



	
	/**
	 * [tMap_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tMap_1", false);
		start_Hash.put("tMap_1", System.currentTimeMillis());
		
				tStatCatcher_1.addMessage("begin","tMap_1");
				tStatCatcher_1Process(globalMap);
			
	
	currentComponent="tMap_1";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row3");
					}
				
		int tos_count_tMap_1 = 0;
		




// ###############################
// # Lookup's keys initialization
// ###############################        

// ###############################
// # Vars initialization
class  Var__tMap_1__Struct  {
}
Var__tMap_1__Struct Var__tMap_1 = new Var__tMap_1__Struct();
// ###############################

// ###############################
// # Outputs initialization
alimt_rejet_doublonsStruct alimt_rejet_doublons_tmp = new alimt_rejet_doublonsStruct();
// ###############################

        
        



        









 



/**
 * [tMap_1 begin ] stop
 */



	
	/**
	 * [tUniqRow_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tUniqRow_1", false);
		start_Hash.put("tUniqRow_1", System.currentTimeMillis());
		
				tStatCatcher_1.addMessage("begin","tUniqRow_1");
				tStatCatcher_1Process(globalMap);
			
	
	currentComponent="tUniqRow_1";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row2");
					}
				
		int tos_count_tUniqRow_1 = 0;
		

	
		class KeyStruct_tUniqRow_1 {
	
			private static final int DEFAULT_HASHCODE = 1;
		    private static final int PRIME = 31;
		    private int hashCode = DEFAULT_HASHCODE;
		    public boolean hashCodeDirty = true;
	
	        
					java.util.Date date_debut_preparation;
					java.util.Date date_fin_preparation;
					Integer id_moyen_paiement;
					String code_moyen_paiement;
					String livelle_moyen_paiement;
					Integer id_menu;
					String code_menu;
					String libelle_menu;
					Integer nombre_articles;
					BigDecimal temps_theo_preparation;
					Integer id_commande;
					Integer numero_commande;
					java.util.Date date_commande;
					Float montant_total;
					Integer id_adresse_norm_restaurant;
					String numero_voie_restau;
					String nom_voie_restau;
					String code_postal_restau;
					String nom_ville_restau;
					String longitude_restau;
					String latitude_restau;
					Integer id_adresse_restaurant;
					String adresse_restaurant;
					Integer id_restaurant;
					String code_restaurant;
					String raison_sociale_restaurant;
					Integer id_adresse_norm_client;
					String numero_voie;
					String nom_voie;
					String code_postal;
					String nom_ville;
					String longitude;
					String latitude;
					Integer id_adresse_client;
					String adresse_client;
					Integer id_client;
					String nom_client;
					String prenom_client;        
	        
		    @Override
			public int hashCode() {
				if (this.hashCodeDirty) {
					final int prime = PRIME;
					int result = DEFAULT_HASHCODE;
			
								result = prime * result + ((this.date_debut_preparation == null) ? 0 : this.date_debut_preparation.hashCode());
								
								result = prime * result + ((this.date_fin_preparation == null) ? 0 : this.date_fin_preparation.hashCode());
								
								result = prime * result + ((this.id_moyen_paiement == null) ? 0 : this.id_moyen_paiement.hashCode());
								
								result = prime * result + ((this.code_moyen_paiement == null) ? 0 : this.code_moyen_paiement.hashCode());
								
								result = prime * result + ((this.livelle_moyen_paiement == null) ? 0 : this.livelle_moyen_paiement.hashCode());
								
								result = prime * result + ((this.id_menu == null) ? 0 : this.id_menu.hashCode());
								
								result = prime * result + ((this.code_menu == null) ? 0 : this.code_menu.hashCode());
								
								result = prime * result + ((this.libelle_menu == null) ? 0 : this.libelle_menu.hashCode());
								
								result = prime * result + ((this.nombre_articles == null) ? 0 : this.nombre_articles.hashCode());
								
								result = prime * result + ((this.temps_theo_preparation == null) ? 0 : this.temps_theo_preparation.hashCode());
								
								result = prime * result + ((this.id_commande == null) ? 0 : this.id_commande.hashCode());
								
								result = prime * result + ((this.numero_commande == null) ? 0 : this.numero_commande.hashCode());
								
								result = prime * result + ((this.date_commande == null) ? 0 : this.date_commande.hashCode());
								
								result = prime * result + ((this.montant_total == null) ? 0 : this.montant_total.hashCode());
								
								result = prime * result + ((this.id_adresse_norm_restaurant == null) ? 0 : this.id_adresse_norm_restaurant.hashCode());
								
								result = prime * result + ((this.numero_voie_restau == null) ? 0 : this.numero_voie_restau.hashCode());
								
								result = prime * result + ((this.nom_voie_restau == null) ? 0 : this.nom_voie_restau.hashCode());
								
								result = prime * result + ((this.code_postal_restau == null) ? 0 : this.code_postal_restau.hashCode());
								
								result = prime * result + ((this.nom_ville_restau == null) ? 0 : this.nom_ville_restau.hashCode());
								
								result = prime * result + ((this.longitude_restau == null) ? 0 : this.longitude_restau.hashCode());
								
								result = prime * result + ((this.latitude_restau == null) ? 0 : this.latitude_restau.hashCode());
								
								result = prime * result + ((this.id_adresse_restaurant == null) ? 0 : this.id_adresse_restaurant.hashCode());
								
								result = prime * result + ((this.adresse_restaurant == null) ? 0 : this.adresse_restaurant.hashCode());
								
								result = prime * result + ((this.id_restaurant == null) ? 0 : this.id_restaurant.hashCode());
								
								result = prime * result + ((this.code_restaurant == null) ? 0 : this.code_restaurant.hashCode());
								
								result = prime * result + ((this.raison_sociale_restaurant == null) ? 0 : this.raison_sociale_restaurant.hashCode());
								
								result = prime * result + ((this.id_adresse_norm_client == null) ? 0 : this.id_adresse_norm_client.hashCode());
								
								result = prime * result + ((this.numero_voie == null) ? 0 : this.numero_voie.hashCode());
								
								result = prime * result + ((this.nom_voie == null) ? 0 : this.nom_voie.hashCode());
								
								result = prime * result + ((this.code_postal == null) ? 0 : this.code_postal.hashCode());
								
								result = prime * result + ((this.nom_ville == null) ? 0 : this.nom_ville.hashCode());
								
								result = prime * result + ((this.longitude == null) ? 0 : this.longitude.hashCode());
								
								result = prime * result + ((this.latitude == null) ? 0 : this.latitude.hashCode());
								
								result = prime * result + ((this.id_adresse_client == null) ? 0 : this.id_adresse_client.hashCode());
								
								result = prime * result + ((this.adresse_client == null) ? 0 : this.adresse_client.hashCode());
								
								result = prime * result + ((this.id_client == null) ? 0 : this.id_client.hashCode());
								
								result = prime * result + ((this.nom_client == null) ? 0 : this.nom_client.hashCode());
								
								result = prime * result + ((this.prenom_client == null) ? 0 : this.prenom_client.hashCode());
								
		    		this.hashCode = result;
		    		this.hashCodeDirty = false;		
				}
				return this.hashCode;
			}
			
			@Override
			public boolean equals(Object obj) {
				if (this == obj) return true;
				if (obj == null) return false;
				if (getClass() != obj.getClass()) return false;
				final KeyStruct_tUniqRow_1 other = (KeyStruct_tUniqRow_1) obj;
				
									if (this.date_debut_preparation == null) {
										if (other.date_debut_preparation != null) 
											return false;
								
									} else if (!this.date_debut_preparation.equals(other.date_debut_preparation))
								 
										return false;
								
									if (this.date_fin_preparation == null) {
										if (other.date_fin_preparation != null) 
											return false;
								
									} else if (!this.date_fin_preparation.equals(other.date_fin_preparation))
								 
										return false;
								
									if (this.id_moyen_paiement == null) {
										if (other.id_moyen_paiement != null) 
											return false;
								
									} else if (!this.id_moyen_paiement.equals(other.id_moyen_paiement))
								 
										return false;
								
									if (this.code_moyen_paiement == null) {
										if (other.code_moyen_paiement != null) 
											return false;
								
									} else if (!this.code_moyen_paiement.equals(other.code_moyen_paiement))
								 
										return false;
								
									if (this.livelle_moyen_paiement == null) {
										if (other.livelle_moyen_paiement != null) 
											return false;
								
									} else if (!this.livelle_moyen_paiement.equals(other.livelle_moyen_paiement))
								 
										return false;
								
									if (this.id_menu == null) {
										if (other.id_menu != null) 
											return false;
								
									} else if (!this.id_menu.equals(other.id_menu))
								 
										return false;
								
									if (this.code_menu == null) {
										if (other.code_menu != null) 
											return false;
								
									} else if (!this.code_menu.equals(other.code_menu))
								 
										return false;
								
									if (this.libelle_menu == null) {
										if (other.libelle_menu != null) 
											return false;
								
									} else if (!this.libelle_menu.equals(other.libelle_menu))
								 
										return false;
								
									if (this.nombre_articles == null) {
										if (other.nombre_articles != null) 
											return false;
								
									} else if (!this.nombre_articles.equals(other.nombre_articles))
								 
										return false;
								
									if (this.temps_theo_preparation == null) {
										if (other.temps_theo_preparation != null) 
											return false;
								
									} else if (!this.temps_theo_preparation.equals(other.temps_theo_preparation))
								 
										return false;
								
									if (this.id_commande == null) {
										if (other.id_commande != null) 
											return false;
								
									} else if (!this.id_commande.equals(other.id_commande))
								 
										return false;
								
									if (this.numero_commande == null) {
										if (other.numero_commande != null) 
											return false;
								
									} else if (!this.numero_commande.equals(other.numero_commande))
								 
										return false;
								
									if (this.date_commande == null) {
										if (other.date_commande != null) 
											return false;
								
									} else if (!this.date_commande.equals(other.date_commande))
								 
										return false;
								
									if (this.montant_total == null) {
										if (other.montant_total != null) 
											return false;
								
									} else if (!this.montant_total.equals(other.montant_total))
								 
										return false;
								
									if (this.id_adresse_norm_restaurant == null) {
										if (other.id_adresse_norm_restaurant != null) 
											return false;
								
									} else if (!this.id_adresse_norm_restaurant.equals(other.id_adresse_norm_restaurant))
								 
										return false;
								
									if (this.numero_voie_restau == null) {
										if (other.numero_voie_restau != null) 
											return false;
								
									} else if (!this.numero_voie_restau.equals(other.numero_voie_restau))
								 
										return false;
								
									if (this.nom_voie_restau == null) {
										if (other.nom_voie_restau != null) 
											return false;
								
									} else if (!this.nom_voie_restau.equals(other.nom_voie_restau))
								 
										return false;
								
									if (this.code_postal_restau == null) {
										if (other.code_postal_restau != null) 
											return false;
								
									} else if (!this.code_postal_restau.equals(other.code_postal_restau))
								 
										return false;
								
									if (this.nom_ville_restau == null) {
										if (other.nom_ville_restau != null) 
											return false;
								
									} else if (!this.nom_ville_restau.equals(other.nom_ville_restau))
								 
										return false;
								
									if (this.longitude_restau == null) {
										if (other.longitude_restau != null) 
											return false;
								
									} else if (!this.longitude_restau.equals(other.longitude_restau))
								 
										return false;
								
									if (this.latitude_restau == null) {
										if (other.latitude_restau != null) 
											return false;
								
									} else if (!this.latitude_restau.equals(other.latitude_restau))
								 
										return false;
								
									if (this.id_adresse_restaurant == null) {
										if (other.id_adresse_restaurant != null) 
											return false;
								
									} else if (!this.id_adresse_restaurant.equals(other.id_adresse_restaurant))
								 
										return false;
								
									if (this.adresse_restaurant == null) {
										if (other.adresse_restaurant != null) 
											return false;
								
									} else if (!this.adresse_restaurant.equals(other.adresse_restaurant))
								 
										return false;
								
									if (this.id_restaurant == null) {
										if (other.id_restaurant != null) 
											return false;
								
									} else if (!this.id_restaurant.equals(other.id_restaurant))
								 
										return false;
								
									if (this.code_restaurant == null) {
										if (other.code_restaurant != null) 
											return false;
								
									} else if (!this.code_restaurant.equals(other.code_restaurant))
								 
										return false;
								
									if (this.raison_sociale_restaurant == null) {
										if (other.raison_sociale_restaurant != null) 
											return false;
								
									} else if (!this.raison_sociale_restaurant.equals(other.raison_sociale_restaurant))
								 
										return false;
								
									if (this.id_adresse_norm_client == null) {
										if (other.id_adresse_norm_client != null) 
											return false;
								
									} else if (!this.id_adresse_norm_client.equals(other.id_adresse_norm_client))
								 
										return false;
								
									if (this.numero_voie == null) {
										if (other.numero_voie != null) 
											return false;
								
									} else if (!this.numero_voie.equals(other.numero_voie))
								 
										return false;
								
									if (this.nom_voie == null) {
										if (other.nom_voie != null) 
											return false;
								
									} else if (!this.nom_voie.equals(other.nom_voie))
								 
										return false;
								
									if (this.code_postal == null) {
										if (other.code_postal != null) 
											return false;
								
									} else if (!this.code_postal.equals(other.code_postal))
								 
										return false;
								
									if (this.nom_ville == null) {
										if (other.nom_ville != null) 
											return false;
								
									} else if (!this.nom_ville.equals(other.nom_ville))
								 
										return false;
								
									if (this.longitude == null) {
										if (other.longitude != null) 
											return false;
								
									} else if (!this.longitude.equals(other.longitude))
								 
										return false;
								
									if (this.latitude == null) {
										if (other.latitude != null) 
											return false;
								
									} else if (!this.latitude.equals(other.latitude))
								 
										return false;
								
									if (this.id_adresse_client == null) {
										if (other.id_adresse_client != null) 
											return false;
								
									} else if (!this.id_adresse_client.equals(other.id_adresse_client))
								 
										return false;
								
									if (this.adresse_client == null) {
										if (other.adresse_client != null) 
											return false;
								
									} else if (!this.adresse_client.equals(other.adresse_client))
								 
										return false;
								
									if (this.id_client == null) {
										if (other.id_client != null) 
											return false;
								
									} else if (!this.id_client.equals(other.id_client))
								 
										return false;
								
									if (this.nom_client == null) {
										if (other.nom_client != null) 
											return false;
								
									} else if (!this.nom_client.equals(other.nom_client))
								 
										return false;
								
									if (this.prenom_client == null) {
										if (other.prenom_client != null) 
											return false;
								
									} else if (!this.prenom_client.equals(other.prenom_client))
								 
										return false;
								
				
				return true;
			}
	  
	        
		}

	
int nb_uniques_tUniqRow_1 = 0;
int nb_duplicates_tUniqRow_1 = 0;
KeyStruct_tUniqRow_1 finder_tUniqRow_1 = new KeyStruct_tUniqRow_1();
java.util.Set<KeyStruct_tUniqRow_1> keystUniqRow_1 = new java.util.HashSet<KeyStruct_tUniqRow_1>(); 

 



/**
 * [tUniqRow_1 begin ] stop
 */



	
	/**
	 * [tDBInput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBInput_1", false);
		start_Hash.put("tDBInput_1", System.currentTimeMillis());
		
				tStatCatcher_1.addMessage("begin","tDBInput_1");
				tStatCatcher_1Process(globalMap);
			
	
	currentComponent="tDBInput_1";

	
		int tos_count_tDBInput_1 = 0;
		
	
    
	
		    int nb_line_tDBInput_1 = 0;
		    java.sql.Connection conn_tDBInput_1 = null;
				String driverClass_tDBInput_1 = "org.postgresql.Driver";
			    java.lang.Class jdbcclazz_tDBInput_1 = java.lang.Class.forName(driverClass_tDBInput_1);
				String dbUser_tDBInput_1 = "dsid_cc2_tos_rw";
				
				 
	final String decryptedPassword_tDBInput_1 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:rZahXx8B1JqWxYm9JNbcNW5OlQrVVbaVysDmcoBFnq8=");
				
				String dbPwd_tDBInput_1 = decryptedPassword_tDBInput_1;
				
				String url_tDBInput_1 = "jdbc:postgresql://" + "" + ":" + "5432" + "/" + "postgres";
				
				conn_tDBInput_1 = java.sql.DriverManager.getConnection(url_tDBInput_1,dbUser_tDBInput_1,dbPwd_tDBInput_1);
		        
				conn_tDBInput_1.setAutoCommit(false);
			
		    
			java.sql.Statement stmt_tDBInput_1 = conn_tDBInput_1.createStatement();

		    String dbquery_tDBInput_1 = "SELECT \n  \"dsid_liv_wrk\".\"dm1_staging\".\"id_staging_dm1\", \n  \"dsid_liv_wrk\".\"dm1_staging\".\"id_preparation\", "
+"\n  \"dsid_liv_wrk\".\"dm1_staging\".\"date_debut_preparation\", \n  \"dsid_liv_wrk\".\"dm1_staging\".\"date_fin_preparati"
+"on\", \n  \"dsid_liv_wrk\".\"dm1_staging\".\"id_moyen_paiement\", \n  \"dsid_liv_wrk\".\"dm1_staging\".\"code_moyen_paieme"
+"nt\", \n  \"dsid_liv_wrk\".\"dm1_staging\".\"livelle_moyen_paiement\", \n  \"dsid_liv_wrk\".\"dm1_staging\".\"id_menu\", \n"
+"  \"dsid_liv_wrk\".\"dm1_staging\".\"code_menu\", \n  \"dsid_liv_wrk\".\"dm1_staging\".\"libelle_menu\", \n  \"dsid_liv_wr"
+"k\".\"dm1_staging\".\"nombre_articles\", \n  \"dsid_liv_wrk\".\"dm1_staging\".\"temps_theo_preparation\", \n  \"dsid_liv_w"
+"rk\".\"dm1_staging\".\"id_commande\", \n  \"dsid_liv_wrk\".\"dm1_staging\".\"numero_commande\", \n  \"dsid_liv_wrk\".\"dm1"
+"_staging\".\"date_commande\", \n  \"dsid_liv_wrk\".\"dm1_staging\".\"montant_total\", \n  \"dsid_liv_wrk\".\"dm1_staging\""
+".\"id_adresse_norm_restaurant\", \n  \"dsid_liv_wrk\".\"dm1_staging\".\"numero_voie_restau\", \n  \"dsid_liv_wrk\".\"dm1_s"
+"taging\".\"nom_voie_restau\", \n  \"dsid_liv_wrk\".\"dm1_staging\".\"code_postal_restau\", \n  \"dsid_liv_wrk\".\"dm1_stag"
+"ing\".\"nom_ville_restau\", \n  \"dsid_liv_wrk\".\"dm1_staging\".\"longitude_restau\", \n  \"dsid_liv_wrk\".\"dm1_staging"
+"\".\"latitude_restau\", \n  \"dsid_liv_wrk\".\"dm1_staging\".\"id_adresse_restaurant\", \n  \"dsid_liv_wrk\".\"dm1_staging"
+"\".\"adresse_restaurant\", \n  \"dsid_liv_wrk\".\"dm1_staging\".\"id_restaurant\", \n  \"dsid_liv_wrk\".\"dm1_staging\".\""
+"code_restaurant\", \n  \"dsid_liv_wrk\".\"dm1_staging\".\"raison_sociale_restaurant\", \n  \"dsid_liv_wrk\".\"dm1_staging"
+"\".\"id_adresse_norm_client\", \n  \"dsid_liv_wrk\".\"dm1_staging\".\"numero_voie\", \n  \"dsid_liv_wrk\".\"dm1_staging\"."
+"\"nom_voie\", \n  \"dsid_liv_wrk\".\"dm1_staging\".\"code_postal\", \n  \"dsid_liv_wrk\".\"dm1_staging\".\"nom_ville\", \n "
+" \"dsid_liv_wrk\".\"dm1_staging\".\"longitude\", \n  \"dsid_liv_wrk\".\"dm1_staging\".\"latitude\", \n  \"dsid_liv_wrk\"."
+"\"dm1_staging\".\"id_adresse_client\", \n  \"dsid_liv_wrk\".\"dm1_staging\".\"adresse_client\", \n  \"dsid_liv_wrk\".\"dm1"
+"_staging\".\"id_client\", \n  \"dsid_liv_wrk\".\"dm1_staging\".\"nom_client\", \n  \"dsid_liv_wrk\".\"dm1_staging\".\"pren"
+"om_client\"\nFROM \"dsid_liv_wrk\".\"dm1_staging\"";
		    

            	globalMap.put("tDBInput_1_QUERY",dbquery_tDBInput_1);
		    java.sql.ResultSet rs_tDBInput_1 = null;

		    try {
		    	rs_tDBInput_1 = stmt_tDBInput_1.executeQuery(dbquery_tDBInput_1);
		    	java.sql.ResultSetMetaData rsmd_tDBInput_1 = rs_tDBInput_1.getMetaData();
		    	int colQtyInRs_tDBInput_1 = rsmd_tDBInput_1.getColumnCount();

		    String tmpContent_tDBInput_1 = null;
		    
		    
		    while (rs_tDBInput_1.next()) {
		        nb_line_tDBInput_1++;
		        
							if(colQtyInRs_tDBInput_1 < 1) {
								row2.id_staging_dm1 = 0;
							} else {
		                          
            row2.id_staging_dm1 = rs_tDBInput_1.getInt(1);
            if(rs_tDBInput_1.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 2) {
								row2.id_preparation = null;
							} else {
		                          
            row2.id_preparation = rs_tDBInput_1.getInt(2);
            if(rs_tDBInput_1.wasNull()){
                    row2.id_preparation = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 3) {
								row2.date_debut_preparation = null;
							} else {
										
			row2.date_debut_preparation = routines.system.JDBCUtil.getDate(rs_tDBInput_1, 3);
		                    }
							if(colQtyInRs_tDBInput_1 < 4) {
								row2.date_fin_preparation = null;
							} else {
										
			row2.date_fin_preparation = routines.system.JDBCUtil.getDate(rs_tDBInput_1, 4);
		                    }
							if(colQtyInRs_tDBInput_1 < 5) {
								row2.id_moyen_paiement = null;
							} else {
		                          
            row2.id_moyen_paiement = rs_tDBInput_1.getInt(5);
            if(rs_tDBInput_1.wasNull()){
                    row2.id_moyen_paiement = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 6) {
								row2.code_moyen_paiement = null;
							} else {
	                         		
        	row2.code_moyen_paiement = routines.system.JDBCUtil.getString(rs_tDBInput_1, 6, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 7) {
								row2.livelle_moyen_paiement = null;
							} else {
	                         		
        	row2.livelle_moyen_paiement = routines.system.JDBCUtil.getString(rs_tDBInput_1, 7, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 8) {
								row2.id_menu = null;
							} else {
		                          
            row2.id_menu = rs_tDBInput_1.getInt(8);
            if(rs_tDBInput_1.wasNull()){
                    row2.id_menu = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 9) {
								row2.code_menu = null;
							} else {
	                         		
        	row2.code_menu = routines.system.JDBCUtil.getString(rs_tDBInput_1, 9, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 10) {
								row2.libelle_menu = null;
							} else {
	                         		
        	row2.libelle_menu = routines.system.JDBCUtil.getString(rs_tDBInput_1, 10, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 11) {
								row2.nombre_articles = null;
							} else {
		                          
            row2.nombre_articles = rs_tDBInput_1.getInt(11);
            if(rs_tDBInput_1.wasNull()){
                    row2.nombre_articles = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 12) {
								row2.temps_theo_preparation = null;
							} else {
		                          
            row2.temps_theo_preparation = rs_tDBInput_1.getBigDecimal(12);
            if(rs_tDBInput_1.wasNull()){
                    row2.temps_theo_preparation = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 13) {
								row2.id_commande = null;
							} else {
		                          
            row2.id_commande = rs_tDBInput_1.getInt(13);
            if(rs_tDBInput_1.wasNull()){
                    row2.id_commande = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 14) {
								row2.numero_commande = null;
							} else {
		                          
            row2.numero_commande = rs_tDBInput_1.getInt(14);
            if(rs_tDBInput_1.wasNull()){
                    row2.numero_commande = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 15) {
								row2.date_commande = null;
							} else {
										
			row2.date_commande = routines.system.JDBCUtil.getDate(rs_tDBInput_1, 15);
		                    }
							if(colQtyInRs_tDBInput_1 < 16) {
								row2.montant_total = null;
							} else {
		                          
            row2.montant_total = rs_tDBInput_1.getFloat(16);
            if(rs_tDBInput_1.wasNull()){
                    row2.montant_total = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 17) {
								row2.id_adresse_norm_restaurant = null;
							} else {
		                          
            row2.id_adresse_norm_restaurant = rs_tDBInput_1.getInt(17);
            if(rs_tDBInput_1.wasNull()){
                    row2.id_adresse_norm_restaurant = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 18) {
								row2.numero_voie_restau = null;
							} else {
	                         		
        	row2.numero_voie_restau = routines.system.JDBCUtil.getString(rs_tDBInput_1, 18, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 19) {
								row2.nom_voie_restau = null;
							} else {
	                         		
        	row2.nom_voie_restau = routines.system.JDBCUtil.getString(rs_tDBInput_1, 19, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 20) {
								row2.code_postal_restau = null;
							} else {
	                         		
        	row2.code_postal_restau = routines.system.JDBCUtil.getString(rs_tDBInput_1, 20, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 21) {
								row2.nom_ville_restau = null;
							} else {
	                         		
        	row2.nom_ville_restau = routines.system.JDBCUtil.getString(rs_tDBInput_1, 21, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 22) {
								row2.longitude_restau = null;
							} else {
	                         		
        	row2.longitude_restau = routines.system.JDBCUtil.getString(rs_tDBInput_1, 22, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 23) {
								row2.latitude_restau = null;
							} else {
	                         		
        	row2.latitude_restau = routines.system.JDBCUtil.getString(rs_tDBInput_1, 23, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 24) {
								row2.id_adresse_restaurant = null;
							} else {
		                          
            row2.id_adresse_restaurant = rs_tDBInput_1.getInt(24);
            if(rs_tDBInput_1.wasNull()){
                    row2.id_adresse_restaurant = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 25) {
								row2.adresse_restaurant = null;
							} else {
	                         		
        	row2.adresse_restaurant = routines.system.JDBCUtil.getString(rs_tDBInput_1, 25, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 26) {
								row2.id_restaurant = null;
							} else {
		                          
            row2.id_restaurant = rs_tDBInput_1.getInt(26);
            if(rs_tDBInput_1.wasNull()){
                    row2.id_restaurant = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 27) {
								row2.code_restaurant = null;
							} else {
	                         		
        	row2.code_restaurant = routines.system.JDBCUtil.getString(rs_tDBInput_1, 27, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 28) {
								row2.raison_sociale_restaurant = null;
							} else {
	                         		
        	row2.raison_sociale_restaurant = routines.system.JDBCUtil.getString(rs_tDBInput_1, 28, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 29) {
								row2.id_adresse_norm_client = null;
							} else {
		                          
            row2.id_adresse_norm_client = rs_tDBInput_1.getInt(29);
            if(rs_tDBInput_1.wasNull()){
                    row2.id_adresse_norm_client = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 30) {
								row2.numero_voie = null;
							} else {
	                         		
        	row2.numero_voie = routines.system.JDBCUtil.getString(rs_tDBInput_1, 30, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 31) {
								row2.nom_voie = null;
							} else {
	                         		
        	row2.nom_voie = routines.system.JDBCUtil.getString(rs_tDBInput_1, 31, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 32) {
								row2.code_postal = null;
							} else {
	                         		
        	row2.code_postal = routines.system.JDBCUtil.getString(rs_tDBInput_1, 32, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 33) {
								row2.nom_ville = null;
							} else {
	                         		
        	row2.nom_ville = routines.system.JDBCUtil.getString(rs_tDBInput_1, 33, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 34) {
								row2.longitude = null;
							} else {
	                         		
        	row2.longitude = routines.system.JDBCUtil.getString(rs_tDBInput_1, 34, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 35) {
								row2.latitude = null;
							} else {
	                         		
        	row2.latitude = routines.system.JDBCUtil.getString(rs_tDBInput_1, 35, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 36) {
								row2.id_adresse_client = null;
							} else {
		                          
            row2.id_adresse_client = rs_tDBInput_1.getInt(36);
            if(rs_tDBInput_1.wasNull()){
                    row2.id_adresse_client = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 37) {
								row2.adresse_client = null;
							} else {
	                         		
        	row2.adresse_client = routines.system.JDBCUtil.getString(rs_tDBInput_1, 37, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 38) {
								row2.id_client = null;
							} else {
		                          
            row2.id_client = rs_tDBInput_1.getInt(38);
            if(rs_tDBInput_1.wasNull()){
                    row2.id_client = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 39) {
								row2.nom_client = null;
							} else {
	                         		
        	row2.nom_client = routines.system.JDBCUtil.getString(rs_tDBInput_1, 39, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 40) {
								row2.prenom_client = null;
							} else {
	                         		
        	row2.prenom_client = routines.system.JDBCUtil.getString(rs_tDBInput_1, 40, false);
		                    }
					


 



/**
 * [tDBInput_1 begin ] stop
 */
	
	/**
	 * [tDBInput_1 main ] start
	 */

	

	
	
	currentComponent="tDBInput_1";

	

 


	tos_count_tDBInput_1++;

/**
 * [tDBInput_1 main ] stop
 */
	
	/**
	 * [tDBInput_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBInput_1";

	

 



/**
 * [tDBInput_1 process_data_begin ] stop
 */

	
	/**
	 * [tUniqRow_1 main ] start
	 */

	

	
	
	currentComponent="tUniqRow_1";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row2"
						
						);
					}
					
row3 = null;			row4 = null;			
finder_tUniqRow_1.date_debut_preparation = row2.date_debut_preparation;
finder_tUniqRow_1.date_fin_preparation = row2.date_fin_preparation;
finder_tUniqRow_1.id_moyen_paiement = row2.id_moyen_paiement;
if(row2.code_moyen_paiement == null){
	finder_tUniqRow_1.code_moyen_paiement = null;
}else{
	finder_tUniqRow_1.code_moyen_paiement = row2.code_moyen_paiement.toLowerCase();
}
if(row2.livelle_moyen_paiement == null){
	finder_tUniqRow_1.livelle_moyen_paiement = null;
}else{
	finder_tUniqRow_1.livelle_moyen_paiement = row2.livelle_moyen_paiement.toLowerCase();
}
finder_tUniqRow_1.id_menu = row2.id_menu;
if(row2.code_menu == null){
	finder_tUniqRow_1.code_menu = null;
}else{
	finder_tUniqRow_1.code_menu = row2.code_menu.toLowerCase();
}
if(row2.libelle_menu == null){
	finder_tUniqRow_1.libelle_menu = null;
}else{
	finder_tUniqRow_1.libelle_menu = row2.libelle_menu.toLowerCase();
}
finder_tUniqRow_1.nombre_articles = row2.nombre_articles;
finder_tUniqRow_1.temps_theo_preparation = row2.temps_theo_preparation;
finder_tUniqRow_1.id_commande = row2.id_commande;
finder_tUniqRow_1.numero_commande = row2.numero_commande;
finder_tUniqRow_1.date_commande = row2.date_commande;
finder_tUniqRow_1.montant_total = row2.montant_total;
finder_tUniqRow_1.id_adresse_norm_restaurant = row2.id_adresse_norm_restaurant;
if(row2.numero_voie_restau == null){
	finder_tUniqRow_1.numero_voie_restau = null;
}else{
	finder_tUniqRow_1.numero_voie_restau = row2.numero_voie_restau.toLowerCase();
}
if(row2.nom_voie_restau == null){
	finder_tUniqRow_1.nom_voie_restau = null;
}else{
	finder_tUniqRow_1.nom_voie_restau = row2.nom_voie_restau.toLowerCase();
}
if(row2.code_postal_restau == null){
	finder_tUniqRow_1.code_postal_restau = null;
}else{
	finder_tUniqRow_1.code_postal_restau = row2.code_postal_restau.toLowerCase();
}
if(row2.nom_ville_restau == null){
	finder_tUniqRow_1.nom_ville_restau = null;
}else{
	finder_tUniqRow_1.nom_ville_restau = row2.nom_ville_restau.toLowerCase();
}
if(row2.longitude_restau == null){
	finder_tUniqRow_1.longitude_restau = null;
}else{
	finder_tUniqRow_1.longitude_restau = row2.longitude_restau.toLowerCase();
}
if(row2.latitude_restau == null){
	finder_tUniqRow_1.latitude_restau = null;
}else{
	finder_tUniqRow_1.latitude_restau = row2.latitude_restau.toLowerCase();
}
finder_tUniqRow_1.id_adresse_restaurant = row2.id_adresse_restaurant;
if(row2.adresse_restaurant == null){
	finder_tUniqRow_1.adresse_restaurant = null;
}else{
	finder_tUniqRow_1.adresse_restaurant = row2.adresse_restaurant.toLowerCase();
}
finder_tUniqRow_1.id_restaurant = row2.id_restaurant;
if(row2.code_restaurant == null){
	finder_tUniqRow_1.code_restaurant = null;
}else{
	finder_tUniqRow_1.code_restaurant = row2.code_restaurant.toLowerCase();
}
if(row2.raison_sociale_restaurant == null){
	finder_tUniqRow_1.raison_sociale_restaurant = null;
}else{
	finder_tUniqRow_1.raison_sociale_restaurant = row2.raison_sociale_restaurant.toLowerCase();
}
finder_tUniqRow_1.id_adresse_norm_client = row2.id_adresse_norm_client;
if(row2.numero_voie == null){
	finder_tUniqRow_1.numero_voie = null;
}else{
	finder_tUniqRow_1.numero_voie = row2.numero_voie.toLowerCase();
}
if(row2.nom_voie == null){
	finder_tUniqRow_1.nom_voie = null;
}else{
	finder_tUniqRow_1.nom_voie = row2.nom_voie.toLowerCase();
}
if(row2.code_postal == null){
	finder_tUniqRow_1.code_postal = null;
}else{
	finder_tUniqRow_1.code_postal = row2.code_postal.toLowerCase();
}
if(row2.nom_ville == null){
	finder_tUniqRow_1.nom_ville = null;
}else{
	finder_tUniqRow_1.nom_ville = row2.nom_ville.toLowerCase();
}
if(row2.longitude == null){
	finder_tUniqRow_1.longitude = null;
}else{
	finder_tUniqRow_1.longitude = row2.longitude.toLowerCase();
}
if(row2.latitude == null){
	finder_tUniqRow_1.latitude = null;
}else{
	finder_tUniqRow_1.latitude = row2.latitude.toLowerCase();
}
finder_tUniqRow_1.id_adresse_client = row2.id_adresse_client;
if(row2.adresse_client == null){
	finder_tUniqRow_1.adresse_client = null;
}else{
	finder_tUniqRow_1.adresse_client = row2.adresse_client.toLowerCase();
}
finder_tUniqRow_1.id_client = row2.id_client;
if(row2.nom_client == null){
	finder_tUniqRow_1.nom_client = null;
}else{
	finder_tUniqRow_1.nom_client = row2.nom_client.toLowerCase();
}
if(row2.prenom_client == null){
	finder_tUniqRow_1.prenom_client = null;
}else{
	finder_tUniqRow_1.prenom_client = row2.prenom_client.toLowerCase();
}	
finder_tUniqRow_1.hashCodeDirty = true;
if (!keystUniqRow_1.contains(finder_tUniqRow_1)) {
		KeyStruct_tUniqRow_1 new_tUniqRow_1 = new KeyStruct_tUniqRow_1();

		
new_tUniqRow_1.date_debut_preparation = row2.date_debut_preparation;
new_tUniqRow_1.date_fin_preparation = row2.date_fin_preparation;
new_tUniqRow_1.id_moyen_paiement = row2.id_moyen_paiement;
if(row2.code_moyen_paiement == null){
	new_tUniqRow_1.code_moyen_paiement = null;
}else{
	new_tUniqRow_1.code_moyen_paiement = row2.code_moyen_paiement.toLowerCase();
}
if(row2.livelle_moyen_paiement == null){
	new_tUniqRow_1.livelle_moyen_paiement = null;
}else{
	new_tUniqRow_1.livelle_moyen_paiement = row2.livelle_moyen_paiement.toLowerCase();
}
new_tUniqRow_1.id_menu = row2.id_menu;
if(row2.code_menu == null){
	new_tUniqRow_1.code_menu = null;
}else{
	new_tUniqRow_1.code_menu = row2.code_menu.toLowerCase();
}
if(row2.libelle_menu == null){
	new_tUniqRow_1.libelle_menu = null;
}else{
	new_tUniqRow_1.libelle_menu = row2.libelle_menu.toLowerCase();
}
new_tUniqRow_1.nombre_articles = row2.nombre_articles;
new_tUniqRow_1.temps_theo_preparation = row2.temps_theo_preparation;
new_tUniqRow_1.id_commande = row2.id_commande;
new_tUniqRow_1.numero_commande = row2.numero_commande;
new_tUniqRow_1.date_commande = row2.date_commande;
new_tUniqRow_1.montant_total = row2.montant_total;
new_tUniqRow_1.id_adresse_norm_restaurant = row2.id_adresse_norm_restaurant;
if(row2.numero_voie_restau == null){
	new_tUniqRow_1.numero_voie_restau = null;
}else{
	new_tUniqRow_1.numero_voie_restau = row2.numero_voie_restau.toLowerCase();
}
if(row2.nom_voie_restau == null){
	new_tUniqRow_1.nom_voie_restau = null;
}else{
	new_tUniqRow_1.nom_voie_restau = row2.nom_voie_restau.toLowerCase();
}
if(row2.code_postal_restau == null){
	new_tUniqRow_1.code_postal_restau = null;
}else{
	new_tUniqRow_1.code_postal_restau = row2.code_postal_restau.toLowerCase();
}
if(row2.nom_ville_restau == null){
	new_tUniqRow_1.nom_ville_restau = null;
}else{
	new_tUniqRow_1.nom_ville_restau = row2.nom_ville_restau.toLowerCase();
}
if(row2.longitude_restau == null){
	new_tUniqRow_1.longitude_restau = null;
}else{
	new_tUniqRow_1.longitude_restau = row2.longitude_restau.toLowerCase();
}
if(row2.latitude_restau == null){
	new_tUniqRow_1.latitude_restau = null;
}else{
	new_tUniqRow_1.latitude_restau = row2.latitude_restau.toLowerCase();
}
new_tUniqRow_1.id_adresse_restaurant = row2.id_adresse_restaurant;
if(row2.adresse_restaurant == null){
	new_tUniqRow_1.adresse_restaurant = null;
}else{
	new_tUniqRow_1.adresse_restaurant = row2.adresse_restaurant.toLowerCase();
}
new_tUniqRow_1.id_restaurant = row2.id_restaurant;
if(row2.code_restaurant == null){
	new_tUniqRow_1.code_restaurant = null;
}else{
	new_tUniqRow_1.code_restaurant = row2.code_restaurant.toLowerCase();
}
if(row2.raison_sociale_restaurant == null){
	new_tUniqRow_1.raison_sociale_restaurant = null;
}else{
	new_tUniqRow_1.raison_sociale_restaurant = row2.raison_sociale_restaurant.toLowerCase();
}
new_tUniqRow_1.id_adresse_norm_client = row2.id_adresse_norm_client;
if(row2.numero_voie == null){
	new_tUniqRow_1.numero_voie = null;
}else{
	new_tUniqRow_1.numero_voie = row2.numero_voie.toLowerCase();
}
if(row2.nom_voie == null){
	new_tUniqRow_1.nom_voie = null;
}else{
	new_tUniqRow_1.nom_voie = row2.nom_voie.toLowerCase();
}
if(row2.code_postal == null){
	new_tUniqRow_1.code_postal = null;
}else{
	new_tUniqRow_1.code_postal = row2.code_postal.toLowerCase();
}
if(row2.nom_ville == null){
	new_tUniqRow_1.nom_ville = null;
}else{
	new_tUniqRow_1.nom_ville = row2.nom_ville.toLowerCase();
}
if(row2.longitude == null){
	new_tUniqRow_1.longitude = null;
}else{
	new_tUniqRow_1.longitude = row2.longitude.toLowerCase();
}
if(row2.latitude == null){
	new_tUniqRow_1.latitude = null;
}else{
	new_tUniqRow_1.latitude = row2.latitude.toLowerCase();
}
new_tUniqRow_1.id_adresse_client = row2.id_adresse_client;
if(row2.adresse_client == null){
	new_tUniqRow_1.adresse_client = null;
}else{
	new_tUniqRow_1.adresse_client = row2.adresse_client.toLowerCase();
}
new_tUniqRow_1.id_client = row2.id_client;
if(row2.nom_client == null){
	new_tUniqRow_1.nom_client = null;
}else{
	new_tUniqRow_1.nom_client = row2.nom_client.toLowerCase();
}
if(row2.prenom_client == null){
	new_tUniqRow_1.prenom_client = null;
}else{
	new_tUniqRow_1.prenom_client = row2.prenom_client.toLowerCase();
}
		
		keystUniqRow_1.add(new_tUniqRow_1);if(row4 == null){ 
	
	row4 = new row4Struct();
}row4.id_staging_dm1 = row2.id_staging_dm1;			row4.id_preparation = row2.id_preparation;			row4.date_debut_preparation = row2.date_debut_preparation;			row4.date_fin_preparation = row2.date_fin_preparation;			row4.id_moyen_paiement = row2.id_moyen_paiement;			row4.code_moyen_paiement = row2.code_moyen_paiement;			row4.livelle_moyen_paiement = row2.livelle_moyen_paiement;			row4.id_menu = row2.id_menu;			row4.code_menu = row2.code_menu;			row4.libelle_menu = row2.libelle_menu;			row4.nombre_articles = row2.nombre_articles;			row4.temps_theo_preparation = row2.temps_theo_preparation;			row4.id_commande = row2.id_commande;			row4.numero_commande = row2.numero_commande;			row4.date_commande = row2.date_commande;			row4.montant_total = row2.montant_total;			row4.id_adresse_norm_restaurant = row2.id_adresse_norm_restaurant;			row4.numero_voie_restau = row2.numero_voie_restau;			row4.nom_voie_restau = row2.nom_voie_restau;			row4.code_postal_restau = row2.code_postal_restau;			row4.nom_ville_restau = row2.nom_ville_restau;			row4.longitude_restau = row2.longitude_restau;			row4.latitude_restau = row2.latitude_restau;			row4.id_adresse_restaurant = row2.id_adresse_restaurant;			row4.adresse_restaurant = row2.adresse_restaurant;			row4.id_restaurant = row2.id_restaurant;			row4.code_restaurant = row2.code_restaurant;			row4.raison_sociale_restaurant = row2.raison_sociale_restaurant;			row4.id_adresse_norm_client = row2.id_adresse_norm_client;			row4.numero_voie = row2.numero_voie;			row4.nom_voie = row2.nom_voie;			row4.code_postal = row2.code_postal;			row4.nom_ville = row2.nom_ville;			row4.longitude = row2.longitude;			row4.latitude = row2.latitude;			row4.id_adresse_client = row2.id_adresse_client;			row4.adresse_client = row2.adresse_client;			row4.id_client = row2.id_client;			row4.nom_client = row2.nom_client;			row4.prenom_client = row2.prenom_client;					
		nb_uniques_tUniqRow_1++;
	} else {
if(row3 == null){ 
	
	row3 = new row3Struct();
}				row3.id_staging_dm1 = row2.id_staging_dm1;			row3.id_preparation = row2.id_preparation;			row3.date_debut_preparation = row2.date_debut_preparation;			row3.date_fin_preparation = row2.date_fin_preparation;			row3.id_moyen_paiement = row2.id_moyen_paiement;			row3.code_moyen_paiement = row2.code_moyen_paiement;			row3.livelle_moyen_paiement = row2.livelle_moyen_paiement;			row3.id_menu = row2.id_menu;			row3.code_menu = row2.code_menu;			row3.libelle_menu = row2.libelle_menu;			row3.nombre_articles = row2.nombre_articles;			row3.temps_theo_preparation = row2.temps_theo_preparation;			row3.id_commande = row2.id_commande;			row3.numero_commande = row2.numero_commande;			row3.date_commande = row2.date_commande;			row3.montant_total = row2.montant_total;			row3.id_adresse_norm_restaurant = row2.id_adresse_norm_restaurant;			row3.numero_voie_restau = row2.numero_voie_restau;			row3.nom_voie_restau = row2.nom_voie_restau;			row3.code_postal_restau = row2.code_postal_restau;			row3.nom_ville_restau = row2.nom_ville_restau;			row3.longitude_restau = row2.longitude_restau;			row3.latitude_restau = row2.latitude_restau;			row3.id_adresse_restaurant = row2.id_adresse_restaurant;			row3.adresse_restaurant = row2.adresse_restaurant;			row3.id_restaurant = row2.id_restaurant;			row3.code_restaurant = row2.code_restaurant;			row3.raison_sociale_restaurant = row2.raison_sociale_restaurant;			row3.id_adresse_norm_client = row2.id_adresse_norm_client;			row3.numero_voie = row2.numero_voie;			row3.nom_voie = row2.nom_voie;			row3.code_postal = row2.code_postal;			row3.nom_ville = row2.nom_ville;			row3.longitude = row2.longitude;			row3.latitude = row2.latitude;			row3.id_adresse_client = row2.id_adresse_client;			row3.adresse_client = row2.adresse_client;			row3.id_client = row2.id_client;			row3.nom_client = row2.nom_client;			row3.prenom_client = row2.prenom_client;			
	  nb_duplicates_tUniqRow_1++;
	}

 


	tos_count_tUniqRow_1++;

/**
 * [tUniqRow_1 main ] stop
 */
	
	/**
	 * [tUniqRow_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tUniqRow_1";

	

 



/**
 * [tUniqRow_1 process_data_begin ] stop
 */
// Start of branch "row4"
if(row4 != null) { 
			row6 = null;



	
	/**
	 * [tFilterRow_1 main ] start
	 */

	

	
	
	currentComponent="tFilterRow_1";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row4"
						
						);
					}
					

          row6 = null;
          row5 = null;
    Operator_tFilterRow_1 ope_tFilterRow_1 = new Operator_tFilterRow_1("&&");
            ope_tFilterRow_1.matches((row4.numero_voie == null? false : row4.numero_voie.compareTo("null") != 0)
                           , "numero_voie.compareTo(\"null\") != 0 failed");
            ope_tFilterRow_1.matches((row4.numero_voie_restau == null? false : row4.numero_voie_restau.compareTo("null") != 0)
                           , "numero_voie_restau.compareTo(\"null\") != 0 failed");
    
    if (ope_tFilterRow_1.getMatchFlag()) {
              if(row5 == null){ 
                row5 = new row5Struct();
              }
               row5.id_staging_dm1 = row4.id_staging_dm1;
               row5.id_preparation = row4.id_preparation;
               row5.date_debut_preparation = row4.date_debut_preparation;
               row5.date_fin_preparation = row4.date_fin_preparation;
               row5.id_moyen_paiement = row4.id_moyen_paiement;
               row5.code_moyen_paiement = row4.code_moyen_paiement;
               row5.livelle_moyen_paiement = row4.livelle_moyen_paiement;
               row5.id_menu = row4.id_menu;
               row5.code_menu = row4.code_menu;
               row5.libelle_menu = row4.libelle_menu;
               row5.nombre_articles = row4.nombre_articles;
               row5.temps_theo_preparation = row4.temps_theo_preparation;
               row5.id_commande = row4.id_commande;
               row5.numero_commande = row4.numero_commande;
               row5.date_commande = row4.date_commande;
               row5.montant_total = row4.montant_total;
               row5.id_adresse_norm_restaurant = row4.id_adresse_norm_restaurant;
               row5.numero_voie_restau = row4.numero_voie_restau;
               row5.nom_voie_restau = row4.nom_voie_restau;
               row5.code_postal_restau = row4.code_postal_restau;
               row5.nom_ville_restau = row4.nom_ville_restau;
               row5.longitude_restau = row4.longitude_restau;
               row5.latitude_restau = row4.latitude_restau;
               row5.id_adresse_restaurant = row4.id_adresse_restaurant;
               row5.adresse_restaurant = row4.adresse_restaurant;
               row5.id_restaurant = row4.id_restaurant;
               row5.code_restaurant = row4.code_restaurant;
               row5.raison_sociale_restaurant = row4.raison_sociale_restaurant;
               row5.id_adresse_norm_client = row4.id_adresse_norm_client;
               row5.numero_voie = row4.numero_voie;
               row5.nom_voie = row4.nom_voie;
               row5.code_postal = row4.code_postal;
               row5.nom_ville = row4.nom_ville;
               row5.longitude = row4.longitude;
               row5.latitude = row4.latitude;
               row5.id_adresse_client = row4.id_adresse_client;
               row5.adresse_client = row4.adresse_client;
               row5.id_client = row4.id_client;
               row5.nom_client = row4.nom_client;
               row5.prenom_client = row4.prenom_client;    
      nb_line_ok_tFilterRow_1++;
    } else {
            if (row6 == null){
              row6 = new row6Struct();
            }
                row6.id_staging_dm1 = row4.id_staging_dm1;
                row6.id_preparation = row4.id_preparation;
                row6.date_debut_preparation = row4.date_debut_preparation;
                row6.date_fin_preparation = row4.date_fin_preparation;
                row6.id_moyen_paiement = row4.id_moyen_paiement;
                row6.code_moyen_paiement = row4.code_moyen_paiement;
                row6.livelle_moyen_paiement = row4.livelle_moyen_paiement;
                row6.id_menu = row4.id_menu;
                row6.code_menu = row4.code_menu;
                row6.libelle_menu = row4.libelle_menu;
                row6.nombre_articles = row4.nombre_articles;
                row6.temps_theo_preparation = row4.temps_theo_preparation;
                row6.id_commande = row4.id_commande;
                row6.numero_commande = row4.numero_commande;
                row6.date_commande = row4.date_commande;
                row6.montant_total = row4.montant_total;
                row6.id_adresse_norm_restaurant = row4.id_adresse_norm_restaurant;
                row6.numero_voie_restau = row4.numero_voie_restau;
                row6.nom_voie_restau = row4.nom_voie_restau;
                row6.code_postal_restau = row4.code_postal_restau;
                row6.nom_ville_restau = row4.nom_ville_restau;
                row6.longitude_restau = row4.longitude_restau;
                row6.latitude_restau = row4.latitude_restau;
                row6.id_adresse_restaurant = row4.id_adresse_restaurant;
                row6.adresse_restaurant = row4.adresse_restaurant;
                row6.id_restaurant = row4.id_restaurant;
                row6.code_restaurant = row4.code_restaurant;
                row6.raison_sociale_restaurant = row4.raison_sociale_restaurant;
                row6.id_adresse_norm_client = row4.id_adresse_norm_client;
                row6.numero_voie = row4.numero_voie;
                row6.nom_voie = row4.nom_voie;
                row6.code_postal = row4.code_postal;
                row6.nom_ville = row4.nom_ville;
                row6.longitude = row4.longitude;
                row6.latitude = row4.latitude;
                row6.id_adresse_client = row4.id_adresse_client;
                row6.adresse_client = row4.adresse_client;
                row6.id_client = row4.id_client;
                row6.nom_client = row4.nom_client;
                row6.prenom_client = row4.prenom_client;
      nb_line_reject_tFilterRow_1++;
    }

nb_line_tFilterRow_1++;

 


	tos_count_tFilterRow_1++;

/**
 * [tFilterRow_1 main ] stop
 */
	
	/**
	 * [tFilterRow_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFilterRow_1";

	

 



/**
 * [tFilterRow_1 process_data_begin ] stop
 */
// Start of branch "row5"
if(row5 != null) { 



	
	/**
	 * [tMap_2 main ] start
	 */

	

	
	
	currentComponent="tMap_2";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row5"
						
						);
					}
					

		
		
		boolean hasCasePrimitiveKeyWithNull_tMap_2 = false;
		

        // ###############################
        // # Input tables (lookups)
		  boolean rejectedInnerJoin_tMap_2 = false;
		  boolean mainRowRejected_tMap_2 = false;
            				    								  
		// ###############################
        { // start of Var scope
        
	        // ###############################
        	// # Vars tables
        
Var__tMap_2__Struct Var = Var__tMap_2;// ###############################
        // ###############################
        // # Output tables

alim_ods = null;


// # Output table : 'alim_ods'
alim_ods_tmp.id_ods_dm1 = 0;
alim_ods_tmp.id_preparation = row5.id_preparation;
alim_ods_tmp.date_debut_preparation = row5.date_debut_preparation;
alim_ods_tmp.date_fin_preparation = row5.date_fin_preparation;
alim_ods_tmp.temps_reel_preparation = new BigDecimal(TalendDate.diffDate(row5.date_fin_preparation,row5.date_debut_preparation,"mm",true) ) ;
alim_ods_tmp.id_moyen_paiement = row5.id_moyen_paiement;
alim_ods_tmp.code_moyen_paiement = row5.code_moyen_paiement;
alim_ods_tmp.livelle_moyen_paiement = row5.livelle_moyen_paiement;
alim_ods_tmp.id_menu = row5.id_menu;
alim_ods_tmp.code_menu = row5.code_menu;
alim_ods_tmp.libelle_menu = row5.libelle_menu;
alim_ods_tmp.nombre_articles = row5.nombre_articles;
alim_ods_tmp.temps_theo_preparation = row5.temps_theo_preparation;
alim_ods_tmp.id_commande = row5.id_commande;
alim_ods_tmp.numero_commande = row5.numero_commande;
alim_ods_tmp.date_commande = row5.date_commande;
alim_ods_tmp.montant_total = row5.montant_total;
alim_ods_tmp.id_adresse_norm_restaurant = row5.id_adresse_norm_restaurant;
alim_ods_tmp.numero_voie_restau = row5.numero_voie_restau;
alim_ods_tmp.nom_voie_restau = row5.nom_voie_restau;
alim_ods_tmp.code_postal_restau = row5.code_postal_restau;
alim_ods_tmp.nom_ville_restau = row5.nom_ville_restau;
alim_ods_tmp.longitude_restau = row5.longitude_restau;
alim_ods_tmp.latitude_restau = row5.latitude_restau;
alim_ods_tmp.id_adresse_restaurant = row5.id_adresse_restaurant;
alim_ods_tmp.adresse_restaurant = row5.adresse_restaurant;
alim_ods_tmp.id_restaurant = row5.id_restaurant;
alim_ods_tmp.code_restaurant = row5.code_restaurant;
alim_ods_tmp.raison_sociale_restaurant = row5.raison_sociale_restaurant;
alim_ods_tmp.id_adresse_norm_client = row5.id_adresse_norm_client;
alim_ods_tmp.numero_voie = row5.numero_voie;
alim_ods_tmp.nom_voie = row5.nom_voie;
alim_ods_tmp.code_postal = row5.code_postal;
alim_ods_tmp.nom_ville = row5.nom_ville;
alim_ods_tmp.longitude = row5.longitude;
alim_ods_tmp.latitude = row5.latitude;
alim_ods_tmp.id_adresse_client = row5.id_adresse_client;
alim_ods_tmp.adresse_client = row5.adresse_client;
alim_ods_tmp.id_client = row5.id_client;
alim_ods_tmp.nom_client = row5.nom_client;
alim_ods_tmp.prenom_client = row5.prenom_client;
alim_ods = alim_ods_tmp;
// ###############################

} // end of Var scope

rejectedInnerJoin_tMap_2 = false;










 


	tos_count_tMap_2++;

/**
 * [tMap_2 main ] stop
 */
	
	/**
	 * [tMap_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tMap_2";

	

 



/**
 * [tMap_2 process_data_begin ] stop
 */
// Start of branch "alim_ods"
if(alim_ods != null) { 



	
	/**
	 * [tDBOutput_4 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_4";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"alim_ods"
						
						);
					}
					



        whetherReject_tDBOutput_4 = false;
                    if(alim_ods.id_preparation == null) {
pstmt_tDBOutput_4.setNull(1, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_4.setInt(1, alim_ods.id_preparation);
}

                    if(alim_ods.date_debut_preparation != null) {
pstmt_tDBOutput_4.setTimestamp(2, new java.sql.Timestamp(alim_ods.date_debut_preparation.getTime()));
} else {
pstmt_tDBOutput_4.setNull(2, java.sql.Types.TIMESTAMP);
}

                    if(alim_ods.date_fin_preparation != null) {
pstmt_tDBOutput_4.setTimestamp(3, new java.sql.Timestamp(alim_ods.date_fin_preparation.getTime()));
} else {
pstmt_tDBOutput_4.setNull(3, java.sql.Types.TIMESTAMP);
}

                    pstmt_tDBOutput_4.setBigDecimal(4, alim_ods.temps_reel_preparation);

                    if(alim_ods.id_moyen_paiement == null) {
pstmt_tDBOutput_4.setNull(5, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_4.setInt(5, alim_ods.id_moyen_paiement);
}

                    if(alim_ods.code_moyen_paiement == null) {
pstmt_tDBOutput_4.setNull(6, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_4.setString(6, alim_ods.code_moyen_paiement);
}

                    if(alim_ods.livelle_moyen_paiement == null) {
pstmt_tDBOutput_4.setNull(7, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_4.setString(7, alim_ods.livelle_moyen_paiement);
}

                    if(alim_ods.id_menu == null) {
pstmt_tDBOutput_4.setNull(8, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_4.setInt(8, alim_ods.id_menu);
}

                    if(alim_ods.code_menu == null) {
pstmt_tDBOutput_4.setNull(9, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_4.setString(9, alim_ods.code_menu);
}

                    if(alim_ods.libelle_menu == null) {
pstmt_tDBOutput_4.setNull(10, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_4.setString(10, alim_ods.libelle_menu);
}

                    if(alim_ods.nombre_articles == null) {
pstmt_tDBOutput_4.setNull(11, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_4.setInt(11, alim_ods.nombre_articles);
}

                    pstmt_tDBOutput_4.setBigDecimal(12, alim_ods.temps_theo_preparation);

                    if(alim_ods.id_commande == null) {
pstmt_tDBOutput_4.setNull(13, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_4.setInt(13, alim_ods.id_commande);
}

                    if(alim_ods.numero_commande == null) {
pstmt_tDBOutput_4.setNull(14, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_4.setInt(14, alim_ods.numero_commande);
}

                    if(alim_ods.date_commande != null) {
pstmt_tDBOutput_4.setTimestamp(15, new java.sql.Timestamp(alim_ods.date_commande.getTime()));
} else {
pstmt_tDBOutput_4.setNull(15, java.sql.Types.TIMESTAMP);
}

                    if(alim_ods.montant_total == null) {
pstmt_tDBOutput_4.setNull(16, java.sql.Types.FLOAT);
} else {pstmt_tDBOutput_4.setFloat(16, alim_ods.montant_total);
}

                    if(alim_ods.id_adresse_norm_restaurant == null) {
pstmt_tDBOutput_4.setNull(17, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_4.setInt(17, alim_ods.id_adresse_norm_restaurant);
}

                    if(alim_ods.numero_voie_restau == null) {
pstmt_tDBOutput_4.setNull(18, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_4.setString(18, alim_ods.numero_voie_restau);
}

                    if(alim_ods.nom_voie_restau == null) {
pstmt_tDBOutput_4.setNull(19, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_4.setString(19, alim_ods.nom_voie_restau);
}

                    if(alim_ods.code_postal_restau == null) {
pstmt_tDBOutput_4.setNull(20, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_4.setString(20, alim_ods.code_postal_restau);
}

                    if(alim_ods.nom_ville_restau == null) {
pstmt_tDBOutput_4.setNull(21, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_4.setString(21, alim_ods.nom_ville_restau);
}

                    if(alim_ods.longitude_restau == null) {
pstmt_tDBOutput_4.setNull(22, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_4.setString(22, alim_ods.longitude_restau);
}

                    if(alim_ods.latitude_restau == null) {
pstmt_tDBOutput_4.setNull(23, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_4.setString(23, alim_ods.latitude_restau);
}

                    if(alim_ods.id_adresse_restaurant == null) {
pstmt_tDBOutput_4.setNull(24, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_4.setInt(24, alim_ods.id_adresse_restaurant);
}

                    if(alim_ods.adresse_restaurant == null) {
pstmt_tDBOutput_4.setNull(25, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_4.setString(25, alim_ods.adresse_restaurant);
}

                    if(alim_ods.id_restaurant == null) {
pstmt_tDBOutput_4.setNull(26, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_4.setInt(26, alim_ods.id_restaurant);
}

                    if(alim_ods.code_restaurant == null) {
pstmt_tDBOutput_4.setNull(27, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_4.setString(27, alim_ods.code_restaurant);
}

                    if(alim_ods.raison_sociale_restaurant == null) {
pstmt_tDBOutput_4.setNull(28, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_4.setString(28, alim_ods.raison_sociale_restaurant);
}

                    if(alim_ods.id_adresse_norm_client == null) {
pstmt_tDBOutput_4.setNull(29, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_4.setInt(29, alim_ods.id_adresse_norm_client);
}

                    if(alim_ods.numero_voie == null) {
pstmt_tDBOutput_4.setNull(30, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_4.setString(30, alim_ods.numero_voie);
}

                    if(alim_ods.nom_voie == null) {
pstmt_tDBOutput_4.setNull(31, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_4.setString(31, alim_ods.nom_voie);
}

                    if(alim_ods.code_postal == null) {
pstmt_tDBOutput_4.setNull(32, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_4.setString(32, alim_ods.code_postal);
}

                    if(alim_ods.nom_ville == null) {
pstmt_tDBOutput_4.setNull(33, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_4.setString(33, alim_ods.nom_ville);
}

                    if(alim_ods.longitude == null) {
pstmt_tDBOutput_4.setNull(34, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_4.setString(34, alim_ods.longitude);
}

                    if(alim_ods.latitude == null) {
pstmt_tDBOutput_4.setNull(35, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_4.setString(35, alim_ods.latitude);
}

                    if(alim_ods.id_adresse_client == null) {
pstmt_tDBOutput_4.setNull(36, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_4.setInt(36, alim_ods.id_adresse_client);
}

                    if(alim_ods.adresse_client == null) {
pstmt_tDBOutput_4.setNull(37, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_4.setString(37, alim_ods.adresse_client);
}

                    if(alim_ods.id_client == null) {
pstmt_tDBOutput_4.setNull(38, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_4.setInt(38, alim_ods.id_client);
}

                    if(alim_ods.nom_client == null) {
pstmt_tDBOutput_4.setNull(39, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_4.setString(39, alim_ods.nom_client);
}

                    if(alim_ods.prenom_client == null) {
pstmt_tDBOutput_4.setNull(40, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_4.setString(40, alim_ods.prenom_client);
}

			
    		pstmt_tDBOutput_4.addBatch();
    		nb_line_tDBOutput_4++;
    		  
    		  
    		  batchSizeCounter_tDBOutput_4++;
    		  
    			if ((batchSize_tDBOutput_4 > 0) && (batchSize_tDBOutput_4 <= batchSizeCounter_tDBOutput_4)) {
                try {
						int countSum_tDBOutput_4 = 0;
						    
						for(int countEach_tDBOutput_4: pstmt_tDBOutput_4.executeBatch()) {
							countSum_tDBOutput_4 += (countEach_tDBOutput_4 < 0 ? 0 : countEach_tDBOutput_4);
						}
				    	rowsToCommitCount_tDBOutput_4 += countSum_tDBOutput_4;
				    	
				    		insertedCount_tDBOutput_4 += countSum_tDBOutput_4;
				    	
            	    	batchSizeCounter_tDBOutput_4 = 0;
                }catch (java.sql.BatchUpdateException e_tDBOutput_4){
globalMap.put("tDBOutput_4_ERROR_MESSAGE",e_tDBOutput_4.getMessage());
				    	java.sql.SQLException ne_tDBOutput_4 = e_tDBOutput_4.getNextException(),sqle_tDBOutput_4=null;
				    	String errormessage_tDBOutput_4;
						if (ne_tDBOutput_4 != null) {
							// build new exception to provide the original cause
							sqle_tDBOutput_4 = new java.sql.SQLException(e_tDBOutput_4.getMessage() + "\ncaused by: " + ne_tDBOutput_4.getMessage(), ne_tDBOutput_4.getSQLState(), ne_tDBOutput_4.getErrorCode(), ne_tDBOutput_4);
							errormessage_tDBOutput_4 = sqle_tDBOutput_4.getMessage();
						}else{
							errormessage_tDBOutput_4 = e_tDBOutput_4.getMessage();
						}
				    	
				    	int countSum_tDBOutput_4 = 0;
						for(int countEach_tDBOutput_4: e_tDBOutput_4.getUpdateCounts()) {
							countSum_tDBOutput_4 += (countEach_tDBOutput_4 < 0 ? 0 : countEach_tDBOutput_4);
						}
						rowsToCommitCount_tDBOutput_4 += countSum_tDBOutput_4;
						
				    		insertedCount_tDBOutput_4 += countSum_tDBOutput_4;
				    	
				    	System.err.println(errormessage_tDBOutput_4);
				    	
					}
    			}
    		
    		    commitCounter_tDBOutput_4++;
                if(commitEvery_tDBOutput_4 <= commitCounter_tDBOutput_4) {
                if ((batchSize_tDBOutput_4 > 0) && (batchSizeCounter_tDBOutput_4 > 0)) {
                try {
                		int countSum_tDBOutput_4 = 0;
                		    
						for(int countEach_tDBOutput_4: pstmt_tDBOutput_4.executeBatch()) {
							countSum_tDBOutput_4 += (countEach_tDBOutput_4 < 0 ? 0 : countEach_tDBOutput_4);
						}
            	    	rowsToCommitCount_tDBOutput_4 += countSum_tDBOutput_4;
            	    	
            	    		insertedCount_tDBOutput_4 += countSum_tDBOutput_4;
            	    	
                batchSizeCounter_tDBOutput_4 = 0;
               }catch (java.sql.BatchUpdateException e_tDBOutput_4){
globalMap.put("tDBOutput_4_ERROR_MESSAGE",e_tDBOutput_4.getMessage());
			    	java.sql.SQLException ne_tDBOutput_4 = e_tDBOutput_4.getNextException(),sqle_tDBOutput_4=null;
			    	String errormessage_tDBOutput_4;
					if (ne_tDBOutput_4 != null) {
						// build new exception to provide the original cause
						sqle_tDBOutput_4 = new java.sql.SQLException(e_tDBOutput_4.getMessage() + "\ncaused by: " + ne_tDBOutput_4.getMessage(), ne_tDBOutput_4.getSQLState(), ne_tDBOutput_4.getErrorCode(), ne_tDBOutput_4);
						errormessage_tDBOutput_4 = sqle_tDBOutput_4.getMessage();
					}else{
						errormessage_tDBOutput_4 = e_tDBOutput_4.getMessage();
					}
			    	
			    	int countSum_tDBOutput_4 = 0;
					for(int countEach_tDBOutput_4: e_tDBOutput_4.getUpdateCounts()) {
						countSum_tDBOutput_4 += (countEach_tDBOutput_4 < 0 ? 0 : countEach_tDBOutput_4);
					}
					rowsToCommitCount_tDBOutput_4 += countSum_tDBOutput_4;
					
			    		insertedCount_tDBOutput_4 += countSum_tDBOutput_4;
			    	
			    	System.err.println(errormessage_tDBOutput_4);
			    	
				}
            }
                    if(rowsToCommitCount_tDBOutput_4 != 0){
                    	
                    }
                    conn_tDBOutput_4.commit();
                    if(rowsToCommitCount_tDBOutput_4 != 0){
                    	
                    	rowsToCommitCount_tDBOutput_4 = 0;
                    }
                    commitCounter_tDBOutput_4=0;
                }

 


	tos_count_tDBOutput_4++;

/**
 * [tDBOutput_4 main ] stop
 */
	
	/**
	 * [tDBOutput_4 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_4";

	

 



/**
 * [tDBOutput_4 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_4 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_4";

	

 



/**
 * [tDBOutput_4 process_data_end ] stop
 */

} // End of branch "alim_ods"




	
	/**
	 * [tMap_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tMap_2";

	

 



/**
 * [tMap_2 process_data_end ] stop
 */

} // End of branch "row5"




// Start of branch "row6"
if(row6 != null) { 



	
	/**
	 * [tMap_3 main ] start
	 */

	

	
	
	currentComponent="tMap_3";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row6"
						
						);
					}
					

		
		
		boolean hasCasePrimitiveKeyWithNull_tMap_3 = false;
		

        // ###############################
        // # Input tables (lookups)
		  boolean rejectedInnerJoin_tMap_3 = false;
		  boolean mainRowRejected_tMap_3 = false;
            				    								  
		// ###############################
        { // start of Var scope
        
	        // ###############################
        	// # Vars tables
        
Var__tMap_3__Struct Var = Var__tMap_3;// ###############################
        // ###############################
        // # Output tables

alim_rejet_code_posta_restau = null;


// # Output table : 'alim_rejet_code_posta_restau'
alim_rejet_code_posta_restau_tmp.id_rejet_dm1 = 0;
alim_rejet_code_posta_restau_tmp.id_preparation = row6.id_preparation;
alim_rejet_code_posta_restau_tmp.date_debut_preparation = row6.date_debut_preparation;
alim_rejet_code_posta_restau_tmp.date_fin_preparation = row6.date_fin_preparation;
alim_rejet_code_posta_restau_tmp.id_moyen_paiement = row6.id_moyen_paiement;
alim_rejet_code_posta_restau_tmp.code_moyen_paiement = row6.code_moyen_paiement;
alim_rejet_code_posta_restau_tmp.livelle_moyen_paiement = row6.livelle_moyen_paiement;
alim_rejet_code_posta_restau_tmp.id_menu = row6.id_menu;
alim_rejet_code_posta_restau_tmp.code_menu = row6.code_menu;
alim_rejet_code_posta_restau_tmp.libelle_menu = row6.libelle_menu;
alim_rejet_code_posta_restau_tmp.nombre_articles = row6.nombre_articles;
alim_rejet_code_posta_restau_tmp.temps_theo_preparation = row6.temps_theo_preparation;
alim_rejet_code_posta_restau_tmp.id_commande = row6.id_commande;
alim_rejet_code_posta_restau_tmp.numero_commande = row6.numero_commande;
alim_rejet_code_posta_restau_tmp.date_commande = row6.date_commande;
alim_rejet_code_posta_restau_tmp.montant_total = row6.montant_total;
alim_rejet_code_posta_restau_tmp.id_adresse_norm_restaurant = row6.id_adresse_norm_restaurant;
alim_rejet_code_posta_restau_tmp.numero_voie_restau = row6.numero_voie_restau;
alim_rejet_code_posta_restau_tmp.nom_voie_restau = row6.nom_voie_restau;
alim_rejet_code_posta_restau_tmp.code_postal_restau = row6.code_postal_restau;
alim_rejet_code_posta_restau_tmp.nom_ville_restau = row6.nom_ville_restau;
alim_rejet_code_posta_restau_tmp.longitude_restau = row6.longitude_restau;
alim_rejet_code_posta_restau_tmp.latitude_restau = row6.latitude_restau;
alim_rejet_code_posta_restau_tmp.id_adresse_restaurant = row6.id_adresse_restaurant;
alim_rejet_code_posta_restau_tmp.adresse_restaurant = row6.adresse_restaurant;
alim_rejet_code_posta_restau_tmp.id_restaurant = row6.id_restaurant;
alim_rejet_code_posta_restau_tmp.code_restaurant = row6.code_restaurant;
alim_rejet_code_posta_restau_tmp.raison_sociale_restaurant = row6.raison_sociale_restaurant;
alim_rejet_code_posta_restau_tmp.id_adresse_norm_client = row6.id_adresse_norm_client;
alim_rejet_code_posta_restau_tmp.numero_voie = row6.numero_voie;
alim_rejet_code_posta_restau_tmp.nom_voie = row6.nom_voie;
alim_rejet_code_posta_restau_tmp.code_postal = row6.code_postal;
alim_rejet_code_posta_restau_tmp.nom_ville = row6.nom_ville;
alim_rejet_code_posta_restau_tmp.longitude = row6.longitude;
alim_rejet_code_posta_restau_tmp.latitude = row6.latitude;
alim_rejet_code_posta_restau_tmp.id_adresse_client = row6.id_adresse_client;
alim_rejet_code_posta_restau_tmp.adresse_client = row6.adresse_client;
alim_rejet_code_posta_restau_tmp.id_client = row6.id_client;
alim_rejet_code_posta_restau_tmp.nom_client = row6.nom_client;
alim_rejet_code_posta_restau_tmp.prenom_client = row6.prenom_client;
alim_rejet_code_posta_restau_tmp.type_rejet = "Rejet numéro voie";
alim_rejet_code_posta_restau_tmp.message_log = "Numéro voie null";
alim_rejet_code_posta_restau = alim_rejet_code_posta_restau_tmp;
// ###############################

} // end of Var scope

rejectedInnerJoin_tMap_3 = false;










 


	tos_count_tMap_3++;

/**
 * [tMap_3 main ] stop
 */
	
	/**
	 * [tMap_3 process_data_begin ] start
	 */

	

	
	
	currentComponent="tMap_3";

	

 



/**
 * [tMap_3 process_data_begin ] stop
 */
// Start of branch "alim_rejet_code_posta_restau"
if(alim_rejet_code_posta_restau != null) { 



	
	/**
	 * [tDBOutput_3 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"alim_rejet_code_posta_restau"
						
						);
					}
					



        whetherReject_tDBOutput_3 = false;
                    if(alim_rejet_code_posta_restau.id_preparation == null) {
pstmt_tDBOutput_3.setNull(1, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_3.setInt(1, alim_rejet_code_posta_restau.id_preparation);
}

                    if(alim_rejet_code_posta_restau.date_debut_preparation != null) {
pstmt_tDBOutput_3.setTimestamp(2, new java.sql.Timestamp(alim_rejet_code_posta_restau.date_debut_preparation.getTime()));
} else {
pstmt_tDBOutput_3.setNull(2, java.sql.Types.TIMESTAMP);
}

                    if(alim_rejet_code_posta_restau.date_fin_preparation != null) {
pstmt_tDBOutput_3.setTimestamp(3, new java.sql.Timestamp(alim_rejet_code_posta_restau.date_fin_preparation.getTime()));
} else {
pstmt_tDBOutput_3.setNull(3, java.sql.Types.TIMESTAMP);
}

                    if(alim_rejet_code_posta_restau.id_moyen_paiement == null) {
pstmt_tDBOutput_3.setNull(4, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_3.setInt(4, alim_rejet_code_posta_restau.id_moyen_paiement);
}

                    if(alim_rejet_code_posta_restau.code_moyen_paiement == null) {
pstmt_tDBOutput_3.setNull(5, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(5, alim_rejet_code_posta_restau.code_moyen_paiement);
}

                    if(alim_rejet_code_posta_restau.livelle_moyen_paiement == null) {
pstmt_tDBOutput_3.setNull(6, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(6, alim_rejet_code_posta_restau.livelle_moyen_paiement);
}

                    if(alim_rejet_code_posta_restau.id_menu == null) {
pstmt_tDBOutput_3.setNull(7, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_3.setInt(7, alim_rejet_code_posta_restau.id_menu);
}

                    if(alim_rejet_code_posta_restau.code_menu == null) {
pstmt_tDBOutput_3.setNull(8, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(8, alim_rejet_code_posta_restau.code_menu);
}

                    if(alim_rejet_code_posta_restau.libelle_menu == null) {
pstmt_tDBOutput_3.setNull(9, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(9, alim_rejet_code_posta_restau.libelle_menu);
}

                    if(alim_rejet_code_posta_restau.nombre_articles == null) {
pstmt_tDBOutput_3.setNull(10, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_3.setInt(10, alim_rejet_code_posta_restau.nombre_articles);
}

                    pstmt_tDBOutput_3.setBigDecimal(11, alim_rejet_code_posta_restau.temps_theo_preparation);

                    if(alim_rejet_code_posta_restau.id_commande == null) {
pstmt_tDBOutput_3.setNull(12, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_3.setInt(12, alim_rejet_code_posta_restau.id_commande);
}

                    if(alim_rejet_code_posta_restau.numero_commande == null) {
pstmt_tDBOutput_3.setNull(13, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_3.setInt(13, alim_rejet_code_posta_restau.numero_commande);
}

                    if(alim_rejet_code_posta_restau.date_commande != null) {
pstmt_tDBOutput_3.setTimestamp(14, new java.sql.Timestamp(alim_rejet_code_posta_restau.date_commande.getTime()));
} else {
pstmt_tDBOutput_3.setNull(14, java.sql.Types.TIMESTAMP);
}

                    if(alim_rejet_code_posta_restau.montant_total == null) {
pstmt_tDBOutput_3.setNull(15, java.sql.Types.FLOAT);
} else {pstmt_tDBOutput_3.setFloat(15, alim_rejet_code_posta_restau.montant_total);
}

                    if(alim_rejet_code_posta_restau.id_adresse_norm_restaurant == null) {
pstmt_tDBOutput_3.setNull(16, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_3.setInt(16, alim_rejet_code_posta_restau.id_adresse_norm_restaurant);
}

                    if(alim_rejet_code_posta_restau.numero_voie_restau == null) {
pstmt_tDBOutput_3.setNull(17, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(17, alim_rejet_code_posta_restau.numero_voie_restau);
}

                    if(alim_rejet_code_posta_restau.nom_voie_restau == null) {
pstmt_tDBOutput_3.setNull(18, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(18, alim_rejet_code_posta_restau.nom_voie_restau);
}

                    if(alim_rejet_code_posta_restau.code_postal_restau == null) {
pstmt_tDBOutput_3.setNull(19, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(19, alim_rejet_code_posta_restau.code_postal_restau);
}

                    if(alim_rejet_code_posta_restau.nom_ville_restau == null) {
pstmt_tDBOutput_3.setNull(20, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(20, alim_rejet_code_posta_restau.nom_ville_restau);
}

                    if(alim_rejet_code_posta_restau.longitude_restau == null) {
pstmt_tDBOutput_3.setNull(21, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(21, alim_rejet_code_posta_restau.longitude_restau);
}

                    if(alim_rejet_code_posta_restau.latitude_restau == null) {
pstmt_tDBOutput_3.setNull(22, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(22, alim_rejet_code_posta_restau.latitude_restau);
}

                    if(alim_rejet_code_posta_restau.id_adresse_restaurant == null) {
pstmt_tDBOutput_3.setNull(23, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_3.setInt(23, alim_rejet_code_posta_restau.id_adresse_restaurant);
}

                    if(alim_rejet_code_posta_restau.adresse_restaurant == null) {
pstmt_tDBOutput_3.setNull(24, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(24, alim_rejet_code_posta_restau.adresse_restaurant);
}

                    if(alim_rejet_code_posta_restau.id_restaurant == null) {
pstmt_tDBOutput_3.setNull(25, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_3.setInt(25, alim_rejet_code_posta_restau.id_restaurant);
}

                    if(alim_rejet_code_posta_restau.code_restaurant == null) {
pstmt_tDBOutput_3.setNull(26, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(26, alim_rejet_code_posta_restau.code_restaurant);
}

                    if(alim_rejet_code_posta_restau.raison_sociale_restaurant == null) {
pstmt_tDBOutput_3.setNull(27, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(27, alim_rejet_code_posta_restau.raison_sociale_restaurant);
}

                    if(alim_rejet_code_posta_restau.id_adresse_norm_client == null) {
pstmt_tDBOutput_3.setNull(28, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_3.setInt(28, alim_rejet_code_posta_restau.id_adresse_norm_client);
}

                    if(alim_rejet_code_posta_restau.numero_voie == null) {
pstmt_tDBOutput_3.setNull(29, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(29, alim_rejet_code_posta_restau.numero_voie);
}

                    if(alim_rejet_code_posta_restau.nom_voie == null) {
pstmt_tDBOutput_3.setNull(30, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(30, alim_rejet_code_posta_restau.nom_voie);
}

                    if(alim_rejet_code_posta_restau.code_postal == null) {
pstmt_tDBOutput_3.setNull(31, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(31, alim_rejet_code_posta_restau.code_postal);
}

                    if(alim_rejet_code_posta_restau.nom_ville == null) {
pstmt_tDBOutput_3.setNull(32, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(32, alim_rejet_code_posta_restau.nom_ville);
}

                    if(alim_rejet_code_posta_restau.longitude == null) {
pstmt_tDBOutput_3.setNull(33, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(33, alim_rejet_code_posta_restau.longitude);
}

                    if(alim_rejet_code_posta_restau.latitude == null) {
pstmt_tDBOutput_3.setNull(34, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(34, alim_rejet_code_posta_restau.latitude);
}

                    if(alim_rejet_code_posta_restau.id_adresse_client == null) {
pstmt_tDBOutput_3.setNull(35, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_3.setInt(35, alim_rejet_code_posta_restau.id_adresse_client);
}

                    if(alim_rejet_code_posta_restau.adresse_client == null) {
pstmt_tDBOutput_3.setNull(36, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(36, alim_rejet_code_posta_restau.adresse_client);
}

                    if(alim_rejet_code_posta_restau.id_client == null) {
pstmt_tDBOutput_3.setNull(37, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_3.setInt(37, alim_rejet_code_posta_restau.id_client);
}

                    if(alim_rejet_code_posta_restau.nom_client == null) {
pstmt_tDBOutput_3.setNull(38, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(38, alim_rejet_code_posta_restau.nom_client);
}

                    if(alim_rejet_code_posta_restau.prenom_client == null) {
pstmt_tDBOutput_3.setNull(39, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(39, alim_rejet_code_posta_restau.prenom_client);
}

                    if(alim_rejet_code_posta_restau.type_rejet == null) {
pstmt_tDBOutput_3.setNull(40, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(40, alim_rejet_code_posta_restau.type_rejet);
}

                    if(alim_rejet_code_posta_restau.message_log == null) {
pstmt_tDBOutput_3.setNull(41, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(41, alim_rejet_code_posta_restau.message_log);
}

			
    		pstmt_tDBOutput_3.addBatch();
    		nb_line_tDBOutput_3++;
    		  
    		  
    		  batchSizeCounter_tDBOutput_3++;
    		  
    			if ((batchSize_tDBOutput_3 > 0) && (batchSize_tDBOutput_3 <= batchSizeCounter_tDBOutput_3)) {
                try {
						int countSum_tDBOutput_3 = 0;
						    
						for(int countEach_tDBOutput_3: pstmt_tDBOutput_3.executeBatch()) {
							countSum_tDBOutput_3 += (countEach_tDBOutput_3 < 0 ? 0 : countEach_tDBOutput_3);
						}
				    	rowsToCommitCount_tDBOutput_3 += countSum_tDBOutput_3;
				    	
				    		insertedCount_tDBOutput_3 += countSum_tDBOutput_3;
				    	
            	    	batchSizeCounter_tDBOutput_3 = 0;
                }catch (java.sql.BatchUpdateException e_tDBOutput_3){
globalMap.put("tDBOutput_3_ERROR_MESSAGE",e_tDBOutput_3.getMessage());
				    	java.sql.SQLException ne_tDBOutput_3 = e_tDBOutput_3.getNextException(),sqle_tDBOutput_3=null;
				    	String errormessage_tDBOutput_3;
						if (ne_tDBOutput_3 != null) {
							// build new exception to provide the original cause
							sqle_tDBOutput_3 = new java.sql.SQLException(e_tDBOutput_3.getMessage() + "\ncaused by: " + ne_tDBOutput_3.getMessage(), ne_tDBOutput_3.getSQLState(), ne_tDBOutput_3.getErrorCode(), ne_tDBOutput_3);
							errormessage_tDBOutput_3 = sqle_tDBOutput_3.getMessage();
						}else{
							errormessage_tDBOutput_3 = e_tDBOutput_3.getMessage();
						}
				    	
				    	int countSum_tDBOutput_3 = 0;
						for(int countEach_tDBOutput_3: e_tDBOutput_3.getUpdateCounts()) {
							countSum_tDBOutput_3 += (countEach_tDBOutput_3 < 0 ? 0 : countEach_tDBOutput_3);
						}
						rowsToCommitCount_tDBOutput_3 += countSum_tDBOutput_3;
						
				    		insertedCount_tDBOutput_3 += countSum_tDBOutput_3;
				    	
				    	System.err.println(errormessage_tDBOutput_3);
				    	
					}
    			}
    		
    		    commitCounter_tDBOutput_3++;
                if(commitEvery_tDBOutput_3 <= commitCounter_tDBOutput_3) {
                if ((batchSize_tDBOutput_3 > 0) && (batchSizeCounter_tDBOutput_3 > 0)) {
                try {
                		int countSum_tDBOutput_3 = 0;
                		    
						for(int countEach_tDBOutput_3: pstmt_tDBOutput_3.executeBatch()) {
							countSum_tDBOutput_3 += (countEach_tDBOutput_3 < 0 ? 0 : countEach_tDBOutput_3);
						}
            	    	rowsToCommitCount_tDBOutput_3 += countSum_tDBOutput_3;
            	    	
            	    		insertedCount_tDBOutput_3 += countSum_tDBOutput_3;
            	    	
                batchSizeCounter_tDBOutput_3 = 0;
               }catch (java.sql.BatchUpdateException e_tDBOutput_3){
globalMap.put("tDBOutput_3_ERROR_MESSAGE",e_tDBOutput_3.getMessage());
			    	java.sql.SQLException ne_tDBOutput_3 = e_tDBOutput_3.getNextException(),sqle_tDBOutput_3=null;
			    	String errormessage_tDBOutput_3;
					if (ne_tDBOutput_3 != null) {
						// build new exception to provide the original cause
						sqle_tDBOutput_3 = new java.sql.SQLException(e_tDBOutput_3.getMessage() + "\ncaused by: " + ne_tDBOutput_3.getMessage(), ne_tDBOutput_3.getSQLState(), ne_tDBOutput_3.getErrorCode(), ne_tDBOutput_3);
						errormessage_tDBOutput_3 = sqle_tDBOutput_3.getMessage();
					}else{
						errormessage_tDBOutput_3 = e_tDBOutput_3.getMessage();
					}
			    	
			    	int countSum_tDBOutput_3 = 0;
					for(int countEach_tDBOutput_3: e_tDBOutput_3.getUpdateCounts()) {
						countSum_tDBOutput_3 += (countEach_tDBOutput_3 < 0 ? 0 : countEach_tDBOutput_3);
					}
					rowsToCommitCount_tDBOutput_3 += countSum_tDBOutput_3;
					
			    		insertedCount_tDBOutput_3 += countSum_tDBOutput_3;
			    	
			    	System.err.println(errormessage_tDBOutput_3);
			    	
				}
            }
                    if(rowsToCommitCount_tDBOutput_3 != 0){
                    	
                    }
                    conn_tDBOutput_3.commit();
                    if(rowsToCommitCount_tDBOutput_3 != 0){
                    	
                    	rowsToCommitCount_tDBOutput_3 = 0;
                    }
                    commitCounter_tDBOutput_3=0;
                }

 


	tos_count_tDBOutput_3++;

/**
 * [tDBOutput_3 main ] stop
 */
	
	/**
	 * [tDBOutput_3 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";

	

 



/**
 * [tDBOutput_3 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_3 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";

	

 



/**
 * [tDBOutput_3 process_data_end ] stop
 */

} // End of branch "alim_rejet_code_posta_restau"




	
	/**
	 * [tMap_3 process_data_end ] start
	 */

	

	
	
	currentComponent="tMap_3";

	

 



/**
 * [tMap_3 process_data_end ] stop
 */

} // End of branch "row6"




	
	/**
	 * [tFilterRow_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tFilterRow_1";

	

 



/**
 * [tFilterRow_1 process_data_end ] stop
 */

} // End of branch "row4"




// Start of branch "row3"
if(row3 != null) { 



	
	/**
	 * [tMap_1 main ] start
	 */

	

	
	
	currentComponent="tMap_1";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row3"
						
						);
					}
					

		
		
		boolean hasCasePrimitiveKeyWithNull_tMap_1 = false;
		

        // ###############################
        // # Input tables (lookups)
		  boolean rejectedInnerJoin_tMap_1 = false;
		  boolean mainRowRejected_tMap_1 = false;
            				    								  
		// ###############################
        { // start of Var scope
        
	        // ###############################
        	// # Vars tables
        
Var__tMap_1__Struct Var = Var__tMap_1;// ###############################
        // ###############################
        // # Output tables

alimt_rejet_doublons = null;


// # Output table : 'alimt_rejet_doublons'
alimt_rejet_doublons_tmp.id_rejet_dm1 = 0;
alimt_rejet_doublons_tmp.id_preparation = row3.id_preparation;
alimt_rejet_doublons_tmp.date_debut_preparation = row3.date_debut_preparation;
alimt_rejet_doublons_tmp.date_fin_preparation = row3.date_fin_preparation;
alimt_rejet_doublons_tmp.id_moyen_paiement = row3.id_moyen_paiement;
alimt_rejet_doublons_tmp.code_moyen_paiement = row3.code_moyen_paiement;
alimt_rejet_doublons_tmp.livelle_moyen_paiement = row3.livelle_moyen_paiement;
alimt_rejet_doublons_tmp.id_menu = row3.id_menu;
alimt_rejet_doublons_tmp.code_menu = row3.code_menu;
alimt_rejet_doublons_tmp.libelle_menu = row3.libelle_menu;
alimt_rejet_doublons_tmp.nombre_articles = row3.nombre_articles;
alimt_rejet_doublons_tmp.temps_theo_preparation = row3.temps_theo_preparation;
alimt_rejet_doublons_tmp.id_commande = row3.id_commande;
alimt_rejet_doublons_tmp.numero_commande = row3.numero_commande;
alimt_rejet_doublons_tmp.date_commande = row3.date_commande;
alimt_rejet_doublons_tmp.montant_total = row3.montant_total;
alimt_rejet_doublons_tmp.id_adresse_norm_restaurant = row3.id_adresse_norm_restaurant;
alimt_rejet_doublons_tmp.numero_voie_restau = row3.numero_voie_restau;
alimt_rejet_doublons_tmp.nom_voie_restau = row3.nom_voie_restau;
alimt_rejet_doublons_tmp.code_postal_restau = row3.code_postal_restau;
alimt_rejet_doublons_tmp.nom_ville_restau = row3.nom_ville_restau;
alimt_rejet_doublons_tmp.longitude_restau = row3.longitude_restau;
alimt_rejet_doublons_tmp.latitude_restau = row3.latitude_restau;
alimt_rejet_doublons_tmp.id_adresse_restaurant = row3.id_adresse_restaurant;
alimt_rejet_doublons_tmp.adresse_restaurant = row3.adresse_restaurant;
alimt_rejet_doublons_tmp.id_restaurant = row3.id_restaurant;
alimt_rejet_doublons_tmp.code_restaurant = row3.code_restaurant;
alimt_rejet_doublons_tmp.raison_sociale_restaurant = row3.raison_sociale_restaurant;
alimt_rejet_doublons_tmp.id_adresse_norm_client = row3.id_adresse_norm_client;
alimt_rejet_doublons_tmp.numero_voie = row3.numero_voie;
alimt_rejet_doublons_tmp.nom_voie = row3.nom_voie;
alimt_rejet_doublons_tmp.code_postal = row3.code_postal;
alimt_rejet_doublons_tmp.nom_ville = row3.nom_ville;
alimt_rejet_doublons_tmp.longitude = row3.longitude;
alimt_rejet_doublons_tmp.latitude = row3.latitude;
alimt_rejet_doublons_tmp.id_adresse_client = row3.id_adresse_client;
alimt_rejet_doublons_tmp.adresse_client = row3.adresse_client;
alimt_rejet_doublons_tmp.id_client = row3.id_client;
alimt_rejet_doublons_tmp.nom_client = row3.nom_client;
alimt_rejet_doublons_tmp.prenom_client = row3.prenom_client;
alimt_rejet_doublons_tmp.type_rejet = "Doubons";
alimt_rejet_doublons_tmp.message_log = "Il y a des lignes en double";
alimt_rejet_doublons = alimt_rejet_doublons_tmp;
// ###############################

} // end of Var scope

rejectedInnerJoin_tMap_1 = false;










 


	tos_count_tMap_1++;

/**
 * [tMap_1 main ] stop
 */
	
	/**
	 * [tMap_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tMap_1";

	

 



/**
 * [tMap_1 process_data_begin ] stop
 */
// Start of branch "alimt_rejet_doublons"
if(alimt_rejet_doublons != null) { 



	
	/**
	 * [tDBOutput_2 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"alimt_rejet_doublons"
						
						);
					}
					



        whetherReject_tDBOutput_2 = false;
                    if(alimt_rejet_doublons.id_preparation == null) {
pstmt_tDBOutput_2.setNull(1, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_2.setInt(1, alimt_rejet_doublons.id_preparation);
}

                    if(alimt_rejet_doublons.date_debut_preparation != null) {
pstmt_tDBOutput_2.setTimestamp(2, new java.sql.Timestamp(alimt_rejet_doublons.date_debut_preparation.getTime()));
} else {
pstmt_tDBOutput_2.setNull(2, java.sql.Types.TIMESTAMP);
}

                    if(alimt_rejet_doublons.date_fin_preparation != null) {
pstmt_tDBOutput_2.setTimestamp(3, new java.sql.Timestamp(alimt_rejet_doublons.date_fin_preparation.getTime()));
} else {
pstmt_tDBOutput_2.setNull(3, java.sql.Types.TIMESTAMP);
}

                    if(alimt_rejet_doublons.id_moyen_paiement == null) {
pstmt_tDBOutput_2.setNull(4, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_2.setInt(4, alimt_rejet_doublons.id_moyen_paiement);
}

                    if(alimt_rejet_doublons.code_moyen_paiement == null) {
pstmt_tDBOutput_2.setNull(5, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(5, alimt_rejet_doublons.code_moyen_paiement);
}

                    if(alimt_rejet_doublons.livelle_moyen_paiement == null) {
pstmt_tDBOutput_2.setNull(6, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(6, alimt_rejet_doublons.livelle_moyen_paiement);
}

                    if(alimt_rejet_doublons.id_menu == null) {
pstmt_tDBOutput_2.setNull(7, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_2.setInt(7, alimt_rejet_doublons.id_menu);
}

                    if(alimt_rejet_doublons.code_menu == null) {
pstmt_tDBOutput_2.setNull(8, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(8, alimt_rejet_doublons.code_menu);
}

                    if(alimt_rejet_doublons.libelle_menu == null) {
pstmt_tDBOutput_2.setNull(9, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(9, alimt_rejet_doublons.libelle_menu);
}

                    if(alimt_rejet_doublons.nombre_articles == null) {
pstmt_tDBOutput_2.setNull(10, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_2.setInt(10, alimt_rejet_doublons.nombre_articles);
}

                    pstmt_tDBOutput_2.setBigDecimal(11, alimt_rejet_doublons.temps_theo_preparation);

                    if(alimt_rejet_doublons.id_commande == null) {
pstmt_tDBOutput_2.setNull(12, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_2.setInt(12, alimt_rejet_doublons.id_commande);
}

                    if(alimt_rejet_doublons.numero_commande == null) {
pstmt_tDBOutput_2.setNull(13, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_2.setInt(13, alimt_rejet_doublons.numero_commande);
}

                    if(alimt_rejet_doublons.date_commande != null) {
pstmt_tDBOutput_2.setTimestamp(14, new java.sql.Timestamp(alimt_rejet_doublons.date_commande.getTime()));
} else {
pstmt_tDBOutput_2.setNull(14, java.sql.Types.TIMESTAMP);
}

                    if(alimt_rejet_doublons.montant_total == null) {
pstmt_tDBOutput_2.setNull(15, java.sql.Types.FLOAT);
} else {pstmt_tDBOutput_2.setFloat(15, alimt_rejet_doublons.montant_total);
}

                    if(alimt_rejet_doublons.id_adresse_norm_restaurant == null) {
pstmt_tDBOutput_2.setNull(16, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_2.setInt(16, alimt_rejet_doublons.id_adresse_norm_restaurant);
}

                    if(alimt_rejet_doublons.numero_voie_restau == null) {
pstmt_tDBOutput_2.setNull(17, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(17, alimt_rejet_doublons.numero_voie_restau);
}

                    if(alimt_rejet_doublons.nom_voie_restau == null) {
pstmt_tDBOutput_2.setNull(18, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(18, alimt_rejet_doublons.nom_voie_restau);
}

                    if(alimt_rejet_doublons.code_postal_restau == null) {
pstmt_tDBOutput_2.setNull(19, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(19, alimt_rejet_doublons.code_postal_restau);
}

                    if(alimt_rejet_doublons.nom_ville_restau == null) {
pstmt_tDBOutput_2.setNull(20, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(20, alimt_rejet_doublons.nom_ville_restau);
}

                    if(alimt_rejet_doublons.longitude_restau == null) {
pstmt_tDBOutput_2.setNull(21, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(21, alimt_rejet_doublons.longitude_restau);
}

                    if(alimt_rejet_doublons.latitude_restau == null) {
pstmt_tDBOutput_2.setNull(22, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(22, alimt_rejet_doublons.latitude_restau);
}

                    if(alimt_rejet_doublons.id_adresse_restaurant == null) {
pstmt_tDBOutput_2.setNull(23, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_2.setInt(23, alimt_rejet_doublons.id_adresse_restaurant);
}

                    if(alimt_rejet_doublons.adresse_restaurant == null) {
pstmt_tDBOutput_2.setNull(24, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(24, alimt_rejet_doublons.adresse_restaurant);
}

                    if(alimt_rejet_doublons.id_restaurant == null) {
pstmt_tDBOutput_2.setNull(25, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_2.setInt(25, alimt_rejet_doublons.id_restaurant);
}

                    if(alimt_rejet_doublons.code_restaurant == null) {
pstmt_tDBOutput_2.setNull(26, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(26, alimt_rejet_doublons.code_restaurant);
}

                    if(alimt_rejet_doublons.raison_sociale_restaurant == null) {
pstmt_tDBOutput_2.setNull(27, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(27, alimt_rejet_doublons.raison_sociale_restaurant);
}

                    if(alimt_rejet_doublons.id_adresse_norm_client == null) {
pstmt_tDBOutput_2.setNull(28, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_2.setInt(28, alimt_rejet_doublons.id_adresse_norm_client);
}

                    if(alimt_rejet_doublons.numero_voie == null) {
pstmt_tDBOutput_2.setNull(29, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(29, alimt_rejet_doublons.numero_voie);
}

                    if(alimt_rejet_doublons.nom_voie == null) {
pstmt_tDBOutput_2.setNull(30, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(30, alimt_rejet_doublons.nom_voie);
}

                    if(alimt_rejet_doublons.code_postal == null) {
pstmt_tDBOutput_2.setNull(31, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(31, alimt_rejet_doublons.code_postal);
}

                    if(alimt_rejet_doublons.nom_ville == null) {
pstmt_tDBOutput_2.setNull(32, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(32, alimt_rejet_doublons.nom_ville);
}

                    if(alimt_rejet_doublons.longitude == null) {
pstmt_tDBOutput_2.setNull(33, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(33, alimt_rejet_doublons.longitude);
}

                    if(alimt_rejet_doublons.latitude == null) {
pstmt_tDBOutput_2.setNull(34, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(34, alimt_rejet_doublons.latitude);
}

                    if(alimt_rejet_doublons.id_adresse_client == null) {
pstmt_tDBOutput_2.setNull(35, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_2.setInt(35, alimt_rejet_doublons.id_adresse_client);
}

                    if(alimt_rejet_doublons.adresse_client == null) {
pstmt_tDBOutput_2.setNull(36, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(36, alimt_rejet_doublons.adresse_client);
}

                    if(alimt_rejet_doublons.id_client == null) {
pstmt_tDBOutput_2.setNull(37, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_2.setInt(37, alimt_rejet_doublons.id_client);
}

                    if(alimt_rejet_doublons.nom_client == null) {
pstmt_tDBOutput_2.setNull(38, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(38, alimt_rejet_doublons.nom_client);
}

                    if(alimt_rejet_doublons.prenom_client == null) {
pstmt_tDBOutput_2.setNull(39, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(39, alimt_rejet_doublons.prenom_client);
}

                    if(alimt_rejet_doublons.type_rejet == null) {
pstmt_tDBOutput_2.setNull(40, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(40, alimt_rejet_doublons.type_rejet);
}

                    if(alimt_rejet_doublons.message_log == null) {
pstmt_tDBOutput_2.setNull(41, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(41, alimt_rejet_doublons.message_log);
}

			
    		pstmt_tDBOutput_2.addBatch();
    		nb_line_tDBOutput_2++;
    		  
    		  
    		  batchSizeCounter_tDBOutput_2++;
    		  
    			if ((batchSize_tDBOutput_2 > 0) && (batchSize_tDBOutput_2 <= batchSizeCounter_tDBOutput_2)) {
                try {
						int countSum_tDBOutput_2 = 0;
						    
						for(int countEach_tDBOutput_2: pstmt_tDBOutput_2.executeBatch()) {
							countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
						}
				    	rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;
				    	
				    		insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
				    	
            	    	batchSizeCounter_tDBOutput_2 = 0;
                }catch (java.sql.BatchUpdateException e_tDBOutput_2){
globalMap.put("tDBOutput_2_ERROR_MESSAGE",e_tDBOutput_2.getMessage());
				    	java.sql.SQLException ne_tDBOutput_2 = e_tDBOutput_2.getNextException(),sqle_tDBOutput_2=null;
				    	String errormessage_tDBOutput_2;
						if (ne_tDBOutput_2 != null) {
							// build new exception to provide the original cause
							sqle_tDBOutput_2 = new java.sql.SQLException(e_tDBOutput_2.getMessage() + "\ncaused by: " + ne_tDBOutput_2.getMessage(), ne_tDBOutput_2.getSQLState(), ne_tDBOutput_2.getErrorCode(), ne_tDBOutput_2);
							errormessage_tDBOutput_2 = sqle_tDBOutput_2.getMessage();
						}else{
							errormessage_tDBOutput_2 = e_tDBOutput_2.getMessage();
						}
				    	
				    	int countSum_tDBOutput_2 = 0;
						for(int countEach_tDBOutput_2: e_tDBOutput_2.getUpdateCounts()) {
							countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
						}
						rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;
						
				    		insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
				    	
				    	System.err.println(errormessage_tDBOutput_2);
				    	
					}
    			}
    		
    		    commitCounter_tDBOutput_2++;
                if(commitEvery_tDBOutput_2 <= commitCounter_tDBOutput_2) {
                if ((batchSize_tDBOutput_2 > 0) && (batchSizeCounter_tDBOutput_2 > 0)) {
                try {
                		int countSum_tDBOutput_2 = 0;
                		    
						for(int countEach_tDBOutput_2: pstmt_tDBOutput_2.executeBatch()) {
							countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
						}
            	    	rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;
            	    	
            	    		insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
            	    	
                batchSizeCounter_tDBOutput_2 = 0;
               }catch (java.sql.BatchUpdateException e_tDBOutput_2){
globalMap.put("tDBOutput_2_ERROR_MESSAGE",e_tDBOutput_2.getMessage());
			    	java.sql.SQLException ne_tDBOutput_2 = e_tDBOutput_2.getNextException(),sqle_tDBOutput_2=null;
			    	String errormessage_tDBOutput_2;
					if (ne_tDBOutput_2 != null) {
						// build new exception to provide the original cause
						sqle_tDBOutput_2 = new java.sql.SQLException(e_tDBOutput_2.getMessage() + "\ncaused by: " + ne_tDBOutput_2.getMessage(), ne_tDBOutput_2.getSQLState(), ne_tDBOutput_2.getErrorCode(), ne_tDBOutput_2);
						errormessage_tDBOutput_2 = sqle_tDBOutput_2.getMessage();
					}else{
						errormessage_tDBOutput_2 = e_tDBOutput_2.getMessage();
					}
			    	
			    	int countSum_tDBOutput_2 = 0;
					for(int countEach_tDBOutput_2: e_tDBOutput_2.getUpdateCounts()) {
						countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
					}
					rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;
					
			    		insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
			    	
			    	System.err.println(errormessage_tDBOutput_2);
			    	
				}
            }
                    if(rowsToCommitCount_tDBOutput_2 != 0){
                    	
                    }
                    conn_tDBOutput_2.commit();
                    if(rowsToCommitCount_tDBOutput_2 != 0){
                    	
                    	rowsToCommitCount_tDBOutput_2 = 0;
                    }
                    commitCounter_tDBOutput_2=0;
                }

 


	tos_count_tDBOutput_2++;

/**
 * [tDBOutput_2 main ] stop
 */
	
	/**
	 * [tDBOutput_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";

	

 



/**
 * [tDBOutput_2 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";

	

 



/**
 * [tDBOutput_2 process_data_end ] stop
 */

} // End of branch "alimt_rejet_doublons"




	
	/**
	 * [tMap_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tMap_1";

	

 



/**
 * [tMap_1 process_data_end ] stop
 */

} // End of branch "row3"




	
	/**
	 * [tUniqRow_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tUniqRow_1";

	

 



/**
 * [tUniqRow_1 process_data_end ] stop
 */



	
	/**
	 * [tDBInput_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBInput_1";

	

 



/**
 * [tDBInput_1 process_data_end ] stop
 */
	
	/**
	 * [tDBInput_1 end ] start
	 */

	

	
	
	currentComponent="tDBInput_1";

	

	}
}finally{
	if (rs_tDBInput_1 != null) {
		rs_tDBInput_1.close();
	}
	if (stmt_tDBInput_1 != null) {
		stmt_tDBInput_1.close();
	}
	if(conn_tDBInput_1 != null && !conn_tDBInput_1.isClosed()) {
		
			conn_tDBInput_1.commit();
			
		
			conn_tDBInput_1.close();
			
			if("com.mysql.cj.jdbc.Driver".equals((String)globalMap.get("driverClass_"))
			    && routines.system.BundleUtils.inOSGi()) {
			        Class.forName("com.mysql.cj.jdbc.AbandonedConnectionCleanupThread").
			            getMethod("checkedShutdown").invoke(null, (Object[]) null);
			}
			
	}
	
}
globalMap.put("tDBInput_1_NB_LINE",nb_line_tDBInput_1);
 

ok_Hash.put("tDBInput_1", true);
end_Hash.put("tDBInput_1", System.currentTimeMillis());

tStatCatcher_1.addMessage("end","tDBInput_1", end_Hash.get("tDBInput_1")-start_Hash.get("tDBInput_1"));
tStatCatcher_1Process(globalMap);



/**
 * [tDBInput_1 end ] stop
 */

	
	/**
	 * [tUniqRow_1 end ] start
	 */

	

	
	
	currentComponent="tUniqRow_1";

	

globalMap.put("tUniqRow_1_NB_UNIQUES",nb_uniques_tUniqRow_1);
globalMap.put("tUniqRow_1_NB_DUPLICATES",nb_duplicates_tUniqRow_1);

				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row2");
			  	}
			  	
 

ok_Hash.put("tUniqRow_1", true);
end_Hash.put("tUniqRow_1", System.currentTimeMillis());

tStatCatcher_1.addMessage("end","tUniqRow_1", end_Hash.get("tUniqRow_1")-start_Hash.get("tUniqRow_1"));
tStatCatcher_1Process(globalMap);



/**
 * [tUniqRow_1 end ] stop
 */

	
	/**
	 * [tFilterRow_1 end ] start
	 */

	

	
	
	currentComponent="tFilterRow_1";

	
    globalMap.put("tFilterRow_1_NB_LINE", nb_line_tFilterRow_1);
    globalMap.put("tFilterRow_1_NB_LINE_OK", nb_line_ok_tFilterRow_1);
    globalMap.put("tFilterRow_1_NB_LINE_REJECT", nb_line_reject_tFilterRow_1);
    

				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row4");
			  	}
			  	
 

ok_Hash.put("tFilterRow_1", true);
end_Hash.put("tFilterRow_1", System.currentTimeMillis());

tStatCatcher_1.addMessage("end","tFilterRow_1", end_Hash.get("tFilterRow_1")-start_Hash.get("tFilterRow_1"));
tStatCatcher_1Process(globalMap);



/**
 * [tFilterRow_1 end ] stop
 */

	
	/**
	 * [tMap_2 end ] start
	 */

	

	
	
	currentComponent="tMap_2";

	


// ###############################
// # Lookup hashes releasing
// ###############################      





				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row5");
			  	}
			  	
 

ok_Hash.put("tMap_2", true);
end_Hash.put("tMap_2", System.currentTimeMillis());

tStatCatcher_1.addMessage("end","tMap_2", end_Hash.get("tMap_2")-start_Hash.get("tMap_2"));
tStatCatcher_1Process(globalMap);



/**
 * [tMap_2 end ] stop
 */

	
	/**
	 * [tDBOutput_4 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_4";

	



	    try {
				int countSum_tDBOutput_4 = 0;
				if (pstmt_tDBOutput_4 != null && batchSizeCounter_tDBOutput_4 > 0) {
						
					for(int countEach_tDBOutput_4: pstmt_tDBOutput_4.executeBatch()) {
						countSum_tDBOutput_4 += (countEach_tDBOutput_4 < 0 ? 0 : countEach_tDBOutput_4);
					}
					rowsToCommitCount_tDBOutput_4 += countSum_tDBOutput_4;
						
				}
		    	
		    		insertedCount_tDBOutput_4 += countSum_tDBOutput_4;
		    	
	    }catch (java.sql.BatchUpdateException e_tDBOutput_4){
globalMap.put("tDBOutput_4_ERROR_MESSAGE",e_tDBOutput_4.getMessage());
	    	java.sql.SQLException ne_tDBOutput_4 = e_tDBOutput_4.getNextException(),sqle_tDBOutput_4=null;
	    	String errormessage_tDBOutput_4;
			if (ne_tDBOutput_4 != null) {
				// build new exception to provide the original cause
				sqle_tDBOutput_4 = new java.sql.SQLException(e_tDBOutput_4.getMessage() + "\ncaused by: " + ne_tDBOutput_4.getMessage(), ne_tDBOutput_4.getSQLState(), ne_tDBOutput_4.getErrorCode(), ne_tDBOutput_4);
				errormessage_tDBOutput_4 = sqle_tDBOutput_4.getMessage();
			}else{
				errormessage_tDBOutput_4 = e_tDBOutput_4.getMessage();
			}
	    	
	    	int countSum_tDBOutput_4 = 0;
			for(int countEach_tDBOutput_4: e_tDBOutput_4.getUpdateCounts()) {
				countSum_tDBOutput_4 += (countEach_tDBOutput_4 < 0 ? 0 : countEach_tDBOutput_4);
			}
			rowsToCommitCount_tDBOutput_4 += countSum_tDBOutput_4;
			
	    		insertedCount_tDBOutput_4 += countSum_tDBOutput_4;
	    	
	    	System.err.println(errormessage_tDBOutput_4);
	    	
		}
	    
        if(pstmt_tDBOutput_4 != null) {
        		
            pstmt_tDBOutput_4.close();
            resourceMap.remove("pstmt_tDBOutput_4");
        }
    resourceMap.put("statementClosed_tDBOutput_4", true);
			if(rowsToCommitCount_tDBOutput_4 != 0){
				
			}
			conn_tDBOutput_4.commit();
			if(rowsToCommitCount_tDBOutput_4 != 0){
				
				rowsToCommitCount_tDBOutput_4 = 0;
			}
			commitCounter_tDBOutput_4 = 0;
		
    	conn_tDBOutput_4 .close();
    	
    	resourceMap.put("finish_tDBOutput_4", true);
    	

	nb_line_deleted_tDBOutput_4=nb_line_deleted_tDBOutput_4+ deletedCount_tDBOutput_4;
	nb_line_update_tDBOutput_4=nb_line_update_tDBOutput_4 + updatedCount_tDBOutput_4;
	nb_line_inserted_tDBOutput_4=nb_line_inserted_tDBOutput_4 + insertedCount_tDBOutput_4;
	nb_line_rejected_tDBOutput_4=nb_line_rejected_tDBOutput_4 + rejectedCount_tDBOutput_4;
	
        globalMap.put("tDBOutput_4_NB_LINE",nb_line_tDBOutput_4);
        globalMap.put("tDBOutput_4_NB_LINE_UPDATED",nb_line_update_tDBOutput_4);
        globalMap.put("tDBOutput_4_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_4);
        globalMap.put("tDBOutput_4_NB_LINE_DELETED",nb_line_deleted_tDBOutput_4);
        globalMap.put("tDBOutput_4_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_4);
    

	


				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"alim_ods");
			  	}
			  	
 

ok_Hash.put("tDBOutput_4", true);
end_Hash.put("tDBOutput_4", System.currentTimeMillis());

tStatCatcher_1.addMessage("end","tDBOutput_4", end_Hash.get("tDBOutput_4")-start_Hash.get("tDBOutput_4"));
tStatCatcher_1Process(globalMap);



/**
 * [tDBOutput_4 end ] stop
 */







	
	/**
	 * [tMap_3 end ] start
	 */

	

	
	
	currentComponent="tMap_3";

	


// ###############################
// # Lookup hashes releasing
// ###############################      





				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row6");
			  	}
			  	
 

ok_Hash.put("tMap_3", true);
end_Hash.put("tMap_3", System.currentTimeMillis());

tStatCatcher_1.addMessage("end","tMap_3", end_Hash.get("tMap_3")-start_Hash.get("tMap_3"));
tStatCatcher_1Process(globalMap);



/**
 * [tMap_3 end ] stop
 */

	
	/**
	 * [tDBOutput_3 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";

	



	    try {
				int countSum_tDBOutput_3 = 0;
				if (pstmt_tDBOutput_3 != null && batchSizeCounter_tDBOutput_3 > 0) {
						
					for(int countEach_tDBOutput_3: pstmt_tDBOutput_3.executeBatch()) {
						countSum_tDBOutput_3 += (countEach_tDBOutput_3 < 0 ? 0 : countEach_tDBOutput_3);
					}
					rowsToCommitCount_tDBOutput_3 += countSum_tDBOutput_3;
						
				}
		    	
		    		insertedCount_tDBOutput_3 += countSum_tDBOutput_3;
		    	
	    }catch (java.sql.BatchUpdateException e_tDBOutput_3){
globalMap.put("tDBOutput_3_ERROR_MESSAGE",e_tDBOutput_3.getMessage());
	    	java.sql.SQLException ne_tDBOutput_3 = e_tDBOutput_3.getNextException(),sqle_tDBOutput_3=null;
	    	String errormessage_tDBOutput_3;
			if (ne_tDBOutput_3 != null) {
				// build new exception to provide the original cause
				sqle_tDBOutput_3 = new java.sql.SQLException(e_tDBOutput_3.getMessage() + "\ncaused by: " + ne_tDBOutput_3.getMessage(), ne_tDBOutput_3.getSQLState(), ne_tDBOutput_3.getErrorCode(), ne_tDBOutput_3);
				errormessage_tDBOutput_3 = sqle_tDBOutput_3.getMessage();
			}else{
				errormessage_tDBOutput_3 = e_tDBOutput_3.getMessage();
			}
	    	
	    	int countSum_tDBOutput_3 = 0;
			for(int countEach_tDBOutput_3: e_tDBOutput_3.getUpdateCounts()) {
				countSum_tDBOutput_3 += (countEach_tDBOutput_3 < 0 ? 0 : countEach_tDBOutput_3);
			}
			rowsToCommitCount_tDBOutput_3 += countSum_tDBOutput_3;
			
	    		insertedCount_tDBOutput_3 += countSum_tDBOutput_3;
	    	
	    	System.err.println(errormessage_tDBOutput_3);
	    	
		}
	    
        if(pstmt_tDBOutput_3 != null) {
        		
            pstmt_tDBOutput_3.close();
            resourceMap.remove("pstmt_tDBOutput_3");
        }
    resourceMap.put("statementClosed_tDBOutput_3", true);
			if(rowsToCommitCount_tDBOutput_3 != 0){
				
			}
			conn_tDBOutput_3.commit();
			if(rowsToCommitCount_tDBOutput_3 != 0){
				
				rowsToCommitCount_tDBOutput_3 = 0;
			}
			commitCounter_tDBOutput_3 = 0;
		
    	conn_tDBOutput_3 .close();
    	
    	resourceMap.put("finish_tDBOutput_3", true);
    	

	nb_line_deleted_tDBOutput_3=nb_line_deleted_tDBOutput_3+ deletedCount_tDBOutput_3;
	nb_line_update_tDBOutput_3=nb_line_update_tDBOutput_3 + updatedCount_tDBOutput_3;
	nb_line_inserted_tDBOutput_3=nb_line_inserted_tDBOutput_3 + insertedCount_tDBOutput_3;
	nb_line_rejected_tDBOutput_3=nb_line_rejected_tDBOutput_3 + rejectedCount_tDBOutput_3;
	
        globalMap.put("tDBOutput_3_NB_LINE",nb_line_tDBOutput_3);
        globalMap.put("tDBOutput_3_NB_LINE_UPDATED",nb_line_update_tDBOutput_3);
        globalMap.put("tDBOutput_3_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_3);
        globalMap.put("tDBOutput_3_NB_LINE_DELETED",nb_line_deleted_tDBOutput_3);
        globalMap.put("tDBOutput_3_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_3);
    

	


				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"alim_rejet_code_posta_restau");
			  	}
			  	
 

ok_Hash.put("tDBOutput_3", true);
end_Hash.put("tDBOutput_3", System.currentTimeMillis());

tStatCatcher_1.addMessage("end","tDBOutput_3", end_Hash.get("tDBOutput_3")-start_Hash.get("tDBOutput_3"));
tStatCatcher_1Process(globalMap);



/**
 * [tDBOutput_3 end ] stop
 */










	
	/**
	 * [tMap_1 end ] start
	 */

	

	
	
	currentComponent="tMap_1";

	


// ###############################
// # Lookup hashes releasing
// ###############################      





				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row3");
			  	}
			  	
 

ok_Hash.put("tMap_1", true);
end_Hash.put("tMap_1", System.currentTimeMillis());

tStatCatcher_1.addMessage("end","tMap_1", end_Hash.get("tMap_1")-start_Hash.get("tMap_1"));
tStatCatcher_1Process(globalMap);



/**
 * [tMap_1 end ] stop
 */

	
	/**
	 * [tDBOutput_2 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";

	



	    try {
				int countSum_tDBOutput_2 = 0;
				if (pstmt_tDBOutput_2 != null && batchSizeCounter_tDBOutput_2 > 0) {
						
					for(int countEach_tDBOutput_2: pstmt_tDBOutput_2.executeBatch()) {
						countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
					}
					rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;
						
				}
		    	
		    		insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
		    	
	    }catch (java.sql.BatchUpdateException e_tDBOutput_2){
globalMap.put("tDBOutput_2_ERROR_MESSAGE",e_tDBOutput_2.getMessage());
	    	java.sql.SQLException ne_tDBOutput_2 = e_tDBOutput_2.getNextException(),sqle_tDBOutput_2=null;
	    	String errormessage_tDBOutput_2;
			if (ne_tDBOutput_2 != null) {
				// build new exception to provide the original cause
				sqle_tDBOutput_2 = new java.sql.SQLException(e_tDBOutput_2.getMessage() + "\ncaused by: " + ne_tDBOutput_2.getMessage(), ne_tDBOutput_2.getSQLState(), ne_tDBOutput_2.getErrorCode(), ne_tDBOutput_2);
				errormessage_tDBOutput_2 = sqle_tDBOutput_2.getMessage();
			}else{
				errormessage_tDBOutput_2 = e_tDBOutput_2.getMessage();
			}
	    	
	    	int countSum_tDBOutput_2 = 0;
			for(int countEach_tDBOutput_2: e_tDBOutput_2.getUpdateCounts()) {
				countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
			}
			rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;
			
	    		insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
	    	
	    	System.err.println(errormessage_tDBOutput_2);
	    	
		}
	    
        if(pstmt_tDBOutput_2 != null) {
        		
            pstmt_tDBOutput_2.close();
            resourceMap.remove("pstmt_tDBOutput_2");
        }
    resourceMap.put("statementClosed_tDBOutput_2", true);
			if(rowsToCommitCount_tDBOutput_2 != 0){
				
			}
			conn_tDBOutput_2.commit();
			if(rowsToCommitCount_tDBOutput_2 != 0){
				
				rowsToCommitCount_tDBOutput_2 = 0;
			}
			commitCounter_tDBOutput_2 = 0;
		
    	conn_tDBOutput_2 .close();
    	
    	resourceMap.put("finish_tDBOutput_2", true);
    	

	nb_line_deleted_tDBOutput_2=nb_line_deleted_tDBOutput_2+ deletedCount_tDBOutput_2;
	nb_line_update_tDBOutput_2=nb_line_update_tDBOutput_2 + updatedCount_tDBOutput_2;
	nb_line_inserted_tDBOutput_2=nb_line_inserted_tDBOutput_2 + insertedCount_tDBOutput_2;
	nb_line_rejected_tDBOutput_2=nb_line_rejected_tDBOutput_2 + rejectedCount_tDBOutput_2;
	
        globalMap.put("tDBOutput_2_NB_LINE",nb_line_tDBOutput_2);
        globalMap.put("tDBOutput_2_NB_LINE_UPDATED",nb_line_update_tDBOutput_2);
        globalMap.put("tDBOutput_2_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_2);
        globalMap.put("tDBOutput_2_NB_LINE_DELETED",nb_line_deleted_tDBOutput_2);
        globalMap.put("tDBOutput_2_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_2);
    

	


				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"alimt_rejet_doublons");
			  	}
			  	
 

ok_Hash.put("tDBOutput_2", true);
end_Hash.put("tDBOutput_2", System.currentTimeMillis());

tStatCatcher_1.addMessage("end","tDBOutput_2", end_Hash.get("tDBOutput_2")-start_Hash.get("tDBOutput_2"));
tStatCatcher_1Process(globalMap);



/**
 * [tDBOutput_2 end ] stop
 */









				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBInput_1 finally ] start
	 */

	

	
	
	currentComponent="tDBInput_1";

	

 



/**
 * [tDBInput_1 finally ] stop
 */

	
	/**
	 * [tUniqRow_1 finally ] start
	 */

	

	
	
	currentComponent="tUniqRow_1";

	

 



/**
 * [tUniqRow_1 finally ] stop
 */

	
	/**
	 * [tFilterRow_1 finally ] start
	 */

	

	
	
	currentComponent="tFilterRow_1";

	

 



/**
 * [tFilterRow_1 finally ] stop
 */

	
	/**
	 * [tMap_2 finally ] start
	 */

	

	
	
	currentComponent="tMap_2";

	

 



/**
 * [tMap_2 finally ] stop
 */

	
	/**
	 * [tDBOutput_4 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_4";

	



    try {
    if (resourceMap.get("statementClosed_tDBOutput_4") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_4 = null;
                if ((pstmtToClose_tDBOutput_4 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_4")) != null) {
                    pstmtToClose_tDBOutput_4.close();
                }
    }
    } finally {
        if(resourceMap.get("finish_tDBOutput_4") == null){
            java.sql.Connection ctn_tDBOutput_4 = null;
            if((ctn_tDBOutput_4 = (java.sql.Connection)resourceMap.get("conn_tDBOutput_4")) != null){
                try {
                    ctn_tDBOutput_4.close();
                } catch (java.sql.SQLException sqlEx_tDBOutput_4) {
                    String errorMessage_tDBOutput_4 = "failed to close the connection in tDBOutput_4 :" + sqlEx_tDBOutput_4.getMessage();
                    System.err.println(errorMessage_tDBOutput_4);
                }
            }
        }
    }
 



/**
 * [tDBOutput_4 finally ] stop
 */







	
	/**
	 * [tMap_3 finally ] start
	 */

	

	
	
	currentComponent="tMap_3";

	

 



/**
 * [tMap_3 finally ] stop
 */

	
	/**
	 * [tDBOutput_3 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";

	



    try {
    if (resourceMap.get("statementClosed_tDBOutput_3") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_3 = null;
                if ((pstmtToClose_tDBOutput_3 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_3")) != null) {
                    pstmtToClose_tDBOutput_3.close();
                }
    }
    } finally {
        if(resourceMap.get("finish_tDBOutput_3") == null){
            java.sql.Connection ctn_tDBOutput_3 = null;
            if((ctn_tDBOutput_3 = (java.sql.Connection)resourceMap.get("conn_tDBOutput_3")) != null){
                try {
                    ctn_tDBOutput_3.close();
                } catch (java.sql.SQLException sqlEx_tDBOutput_3) {
                    String errorMessage_tDBOutput_3 = "failed to close the connection in tDBOutput_3 :" + sqlEx_tDBOutput_3.getMessage();
                    System.err.println(errorMessage_tDBOutput_3);
                }
            }
        }
    }
 



/**
 * [tDBOutput_3 finally ] stop
 */










	
	/**
	 * [tMap_1 finally ] start
	 */

	

	
	
	currentComponent="tMap_1";

	

 



/**
 * [tMap_1 finally ] stop
 */

	
	/**
	 * [tDBOutput_2 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";

	



    try {
    if (resourceMap.get("statementClosed_tDBOutput_2") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_2 = null;
                if ((pstmtToClose_tDBOutput_2 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_2")) != null) {
                    pstmtToClose_tDBOutput_2.close();
                }
    }
    } finally {
        if(resourceMap.get("finish_tDBOutput_2") == null){
            java.sql.Connection ctn_tDBOutput_2 = null;
            if((ctn_tDBOutput_2 = (java.sql.Connection)resourceMap.get("conn_tDBOutput_2")) != null){
                try {
                    ctn_tDBOutput_2.close();
                } catch (java.sql.SQLException sqlEx_tDBOutput_2) {
                    String errorMessage_tDBOutput_2 = "failed to close the connection in tDBOutput_2 :" + sqlEx_tDBOutput_2.getMessage();
                    System.err.println(errorMessage_tDBOutput_2);
                }
            }
        }
    }
 



/**
 * [tDBOutput_2 finally ] stop
 */









				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBInput_1_SUBPROCESS_STATE", 1);
	}
	
    public String resuming_logs_dir_path = null;
    public String resuming_checkpoint_path = null;
    public String parent_part_launcher = null;
    private String resumeEntryMethodName = null;
    private boolean globalResumeTicket = false;

    public boolean watch = false;
    // portStats is null, it means don't execute the statistics
    public Integer portStats = null;
    public int portTraces = 4334;
    public String clientHost;
    public String defaultClientHost = "localhost";
    public String contextStr = "Default";
    public boolean isDefaultContext = true;
    public String pid = "0";
    public String rootPid = null;
    public String fatherPid = null;
    public String fatherNode = null;
    public long startTime = 0;
    public boolean isChildJob = false;
    public String log4jLevel = "";
    
    private boolean enableLogStash;

    private boolean execStat = true;

    private ThreadLocal<java.util.Map<String, String>> threadLocal = new ThreadLocal<java.util.Map<String, String>>() {
        protected java.util.Map<String, String> initialValue() {
            java.util.Map<String,String> threadRunResultMap = new java.util.HashMap<String, String>();
            threadRunResultMap.put("errorCode", null);
            threadRunResultMap.put("status", "");
            return threadRunResultMap;
        };
    };


    protected PropertiesWithType context_param = new PropertiesWithType();
    public java.util.Map<String, Object> parentContextMap = new java.util.HashMap<String, Object>();

    public String status= "";
    

    public static void main(String[] args){
        final C_ALIM_ODS_REJET C_ALIM_ODS_REJETClass = new C_ALIM_ODS_REJET();

        int exitCode = C_ALIM_ODS_REJETClass.runJobInTOS(args);

        System.exit(exitCode);
    }


    public String[][] runJob(String[] args) {

        int exitCode = runJobInTOS(args);
        String[][] bufferValue = new String[][] { { Integer.toString(exitCode) } };

        return bufferValue;
    }

    public boolean hastBufferOutputComponent() {
		boolean hastBufferOutput = false;
    	
        return hastBufferOutput;
    }

    public int runJobInTOS(String[] args) {
	   	// reset status
	   	status = "";
	   	
        String lastStr = "";
        for (String arg : args) {
            if (arg.equalsIgnoreCase("--context_param")) {
                lastStr = arg;
            } else if (lastStr.equals("")) {
                evalParam(arg);
            } else {
                evalParam(lastStr + " " + arg);
                lastStr = "";
            }
        }
        enableLogStash = "true".equalsIgnoreCase(System.getProperty("audit.enabled"));

    	
    	

        if(clientHost == null) {
            clientHost = defaultClientHost;
        }

        if(pid == null || "0".equals(pid)) {
            pid = TalendString.getAsciiRandomString(6);
        }

        if (rootPid==null) {
            rootPid = pid;
        }
        if (fatherPid==null) {
            fatherPid = pid;
        }else{
            isChildJob = true;
        }

        if (portStats != null) {
            // portStats = -1; //for testing
            if (portStats < 0 || portStats > 65535) {
                // issue:10869, the portStats is invalid, so this client socket can't open
                System.err.println("The statistics socket port " + portStats + " is invalid.");
                execStat = false;
            }
        } else {
            execStat = false;
        }
        boolean inOSGi = routines.system.BundleUtils.inOSGi();

        if (inOSGi) {
            java.util.Dictionary<String, Object> jobProperties = routines.system.BundleUtils.getJobProperties(jobName);

            if (jobProperties != null && jobProperties.get("context") != null) {
                contextStr = (String)jobProperties.get("context");
            }
        }

        try {
            //call job/subjob with an existing context, like: --context=production. if without this parameter, there will use the default context instead.
            java.io.InputStream inContext = C_ALIM_ODS_REJET.class.getClassLoader().getResourceAsStream("alimentation_dm1/c_alim_ods_rejet_0_1/contexts/" + contextStr + ".properties");
            if (inContext == null) {
                inContext = C_ALIM_ODS_REJET.class.getClassLoader().getResourceAsStream("config/contexts/" + contextStr + ".properties");
            }
            if (inContext != null) {
                try {
                    //defaultProps is in order to keep the original context value
                    if(context != null && context.isEmpty()) {
	                defaultProps.load(inContext);
	                context = new ContextProperties(defaultProps);
                    }
                } finally {
                    inContext.close();
                }
            } else if (!isDefaultContext) {
                //print info and job continue to run, for case: context_param is not empty.
                System.err.println("Could not find the context " + contextStr);
            }

            if(!context_param.isEmpty()) {
                context.putAll(context_param);
				//set types for params from parentJobs
				for (Object key: context_param.keySet()){
					String context_key = key.toString();
					String context_type = context_param.getContextType(context_key);
					context.setContextType(context_key, context_type);

				}
            }
            class ContextProcessing {
                private void processContext_0() {
                } 
                public void processAllContext() {
                        processContext_0();
                }
            }

            new ContextProcessing().processAllContext();
        } catch (java.io.IOException ie) {
            System.err.println("Could not load context "+contextStr);
            ie.printStackTrace();
        }

        // get context value from parent directly
        if (parentContextMap != null && !parentContextMap.isEmpty()) {
        }

        //Resume: init the resumeUtil
        resumeEntryMethodName = ResumeUtil.getResumeEntryMethodName(resuming_checkpoint_path);
        resumeUtil = new ResumeUtil(resuming_logs_dir_path, isChildJob, rootPid);
        resumeUtil.initCommonInfo(pid, rootPid, fatherPid, projectName, jobName, contextStr, jobVersion);

		List<String> parametersToEncrypt = new java.util.ArrayList<String>();
        //Resume: jobStart
        resumeUtil.addLog("JOB_STARTED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","","","",resumeUtil.convertToJsonText(context,parametersToEncrypt));

if(execStat) {
    try {
        runStat.openSocket(!isChildJob);
        runStat.setAllPID(rootPid, fatherPid, pid, jobName);
        runStat.startThreadStat(clientHost, portStats);
        runStat.updateStatOnJob(RunStat.JOBSTART, fatherNode);
    } catch (java.io.IOException ioException) {
        ioException.printStackTrace();
    }
}



	
	    java.util.concurrent.ConcurrentHashMap<Object, Object> concurrentHashMap = new java.util.concurrent.ConcurrentHashMap<Object, Object>();
	    globalMap.put("concurrentHashMap", concurrentHashMap);
	

    long startUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
    long endUsedMemory = 0;
    long end = 0;

    startTime = System.currentTimeMillis();
        tStatCatcher_1.addMessage("begin");


this.globalResumeTicket = true;//to run tPreJob




        try {
            tStatCatcher_1Process(globalMap);
        } catch (java.lang.Exception e) {
            e.printStackTrace();
        }

this.globalResumeTicket = false;//to run others jobs

try {
errorCode = null;tDBRow_1Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tDBRow_1) {
globalMap.put("tDBRow_1_SUBPROCESS_STATE", -1);

e_tDBRow_1.printStackTrace();

}

this.globalResumeTicket = true;//to run tPostJob




        end = System.currentTimeMillis();

        if (watch) {
            System.out.println((end-startTime)+" milliseconds");
        }

        endUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        if (false) {
            System.out.println((endUsedMemory - startUsedMemory) + " bytes memory increase when running : C_ALIM_ODS_REJET");
        }
        tStatCatcher_1.addMessage(status==""?"end":status, (end-startTime));
        try {
            tStatCatcher_1Process(globalMap);
        } catch (java.lang.Exception e) {
            e.printStackTrace();
        }



if (execStat) {
    runStat.updateStatOnJob(RunStat.JOBEND, fatherNode);
    runStat.stopThreadStat();
}
    int returnCode = 0;


    if(errorCode == null) {
         returnCode = status != null && status.equals("failure") ? 1 : 0;
    } else {
         returnCode = errorCode.intValue();
    }
    resumeUtil.addLog("JOB_ENDED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","" + returnCode,"","","");

    return returnCode;

  }

    // only for OSGi env
    public void destroy() {


    }














    private java.util.Map<String, Object> getSharedConnections4REST() {
        java.util.Map<String, Object> connections = new java.util.HashMap<String, Object>();






        return connections;
    }

    private void evalParam(String arg) {
        if (arg.startsWith("--resuming_logs_dir_path")) {
            resuming_logs_dir_path = arg.substring(25);
        } else if (arg.startsWith("--resuming_checkpoint_path")) {
            resuming_checkpoint_path = arg.substring(27);
        } else if (arg.startsWith("--parent_part_launcher")) {
            parent_part_launcher = arg.substring(23);
        } else if (arg.startsWith("--watch")) {
            watch = true;
        } else if (arg.startsWith("--stat_port=")) {
            String portStatsStr = arg.substring(12);
            if (portStatsStr != null && !portStatsStr.equals("null")) {
                portStats = Integer.parseInt(portStatsStr);
            }
        } else if (arg.startsWith("--trace_port=")) {
            portTraces = Integer.parseInt(arg.substring(13));
        } else if (arg.startsWith("--client_host=")) {
            clientHost = arg.substring(14);
        } else if (arg.startsWith("--context=")) {
            contextStr = arg.substring(10);
            isDefaultContext = false;
        } else if (arg.startsWith("--father_pid=")) {
            fatherPid = arg.substring(13);
        } else if (arg.startsWith("--root_pid=")) {
            rootPid = arg.substring(11);
        } else if (arg.startsWith("--father_node=")) {
            fatherNode = arg.substring(14);
        } else if (arg.startsWith("--pid=")) {
            pid = arg.substring(6);
        } else if (arg.startsWith("--context_type")) {
            String keyValue = arg.substring(15);
			int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.setContextType(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.setContextType(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }

            }

		} else if (arg.startsWith("--context_param")) {
            String keyValue = arg.substring(16);
            int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.put(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.put(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }
            }
        } else if (arg.startsWith("--log4jLevel=")) {
            log4jLevel = arg.substring(13);
		} else if (arg.startsWith("--audit.enabled") && arg.contains("=")) {//for trunjob call
		    final int equal = arg.indexOf('=');
			final String key = arg.substring("--".length(), equal);
			System.setProperty(key, arg.substring(equal + 1));
		}
    }
    
    private static final String NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY = "<TALEND_NULL>";

    private final String[][] escapeChars = {
        {"\\\\","\\"},{"\\n","\n"},{"\\'","\'"},{"\\r","\r"},
        {"\\f","\f"},{"\\b","\b"},{"\\t","\t"}
        };
    private String replaceEscapeChars (String keyValue) {

		if (keyValue == null || ("").equals(keyValue.trim())) {
			return keyValue;
		}

		StringBuilder result = new StringBuilder();
		int currIndex = 0;
		while (currIndex < keyValue.length()) {
			int index = -1;
			// judege if the left string includes escape chars
			for (String[] strArray : escapeChars) {
				index = keyValue.indexOf(strArray[0],currIndex);
				if (index>=0) {

					result.append(keyValue.substring(currIndex, index + strArray[0].length()).replace(strArray[0], strArray[1]));
					currIndex = index + strArray[0].length();
					break;
				}
			}
			// if the left string doesn't include escape chars, append the left into the result
			if (index < 0) {
				result.append(keyValue.substring(currIndex));
				currIndex = currIndex + keyValue.length();
			}
		}

		return result.toString();
    }

    public Integer getErrorCode() {
        return errorCode;
    }


    public String getStatus() {
        return status;
    }

    ResumeUtil resumeUtil = null;
}
/************************************************************************************************
 *     436544 characters generated by Talend Open Studio for Data Integration 
 *     on the 18 janvier 2024 à 23:35:22 CET
 ************************************************************************************************/