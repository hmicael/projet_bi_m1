// ============================================================================
//
// Copyright (c) 2006-2015, Talend SA
//
// Ce code source a été automatiquement généré par_Talend Open Studio for Data Integration
// / Soumis à la Licence Apache, Version 2.0 (la "Licence") ;
// votre utilisation de ce fichier doit respecter les termes de la Licence.
// Vous pouvez obtenir une copie de la Licence sur
// http://www.apache.org/licenses/LICENSE-2.0
// 
// Sauf lorsqu'explicitement prévu par la loi en vigueur ou accepté par écrit, le logiciel
// distribué sous la Licence est distribué "TEL QUEL",
// SANS GARANTIE OU CONDITION D'AUCUNE SORTE, expresse ou implicite.
// Consultez la Licence pour connaître la terminologie spécifique régissant les autorisations et
// les limites prévues par la Licence.


package alimentation_dm1.a_generer_excel_0_1;

import routines.Numeric;
import routines.DataOperation;
import routines.TalendDataGenerator;
import routines.TalendStringUtil;
import routines.TalendString;
import routines.StringHandling;
import routines.Relational;
import routines.TalendDate;
import routines.Mathematical;
import routines.system.*;
import routines.system.api.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.math.BigDecimal;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.util.Comparator;
 





@SuppressWarnings("unused")

/**
 * Job: A_GENERER_EXCEL Purpose: Job qui génére un fichier ecel<br>
 * Description: Job qui génére un fichier ecel <br>
 * @author user@talend.com
 * @version 8.0.1.20211109_1610
 * @status 
 */
public class A_GENERER_EXCEL implements TalendJob {

protected static void logIgnoredError(String message, Throwable cause) {
       System.err.println(message);
       if (cause != null) {
               cause.printStackTrace();
       }

}


	public final Object obj = new Object();

	// for transmiting parameters purpose
	private Object valueObject = null;

	public Object getValueObject() {
		return this.valueObject;
	}

	public void setValueObject(Object valueObject) {
		this.valueObject = valueObject;
	}
	
	private final static String defaultCharset = java.nio.charset.Charset.defaultCharset().name();

	
	private final static String utf8Charset = "UTF-8";
	//contains type for every context property
	public class PropertiesWithType extends java.util.Properties {
		private static final long serialVersionUID = 1L;
		private java.util.Map<String,String> propertyTypes = new java.util.HashMap<>();
		
		public PropertiesWithType(java.util.Properties properties){
			super(properties);
		}
		public PropertiesWithType(){
			super();
		}
		
		public void setContextType(String key, String type) {
			propertyTypes.put(key,type);
		}
	
		public String getContextType(String key) {
			return propertyTypes.get(key);
		}
	}
	
	// create and load default properties
	private java.util.Properties defaultProps = new java.util.Properties();
	// create application properties with default
	public class ContextProperties extends PropertiesWithType {

		private static final long serialVersionUID = 1L;

		public ContextProperties(java.util.Properties properties){
			super(properties);
		}
		public ContextProperties(){
			super();
		}

		public void synchronizeContext(){
			
		}
		
		//if the stored or passed value is "<TALEND_NULL>" string, it mean null
		public String getStringValue(String key) {
			String origin_value = this.getProperty(key);
			if(NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY.equals(origin_value)) {
				return null;
			}
			return origin_value;
		}

	}
	protected ContextProperties context = new ContextProperties(); // will be instanciated by MS.
	public ContextProperties getContext() {
		return this.context;
	}
	private final String jobVersion = "0.1";
	private final String jobName = "A_GENERER_EXCEL";
	private final String projectName = "ALIMENTATION_DM1";
	public Integer errorCode = null;
	private String currentComponent = "";
	
		private final java.util.Map<String, Object> globalMap = new java.util.HashMap<String, Object>();
        private final static java.util.Map<String, Object> junitGlobalMap = new java.util.HashMap<String, Object>();
	
		private final java.util.Map<String, Long> start_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Long> end_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Boolean> ok_Hash = new java.util.HashMap<String, Boolean>();
		public  final java.util.List<String[]> globalBuffer = new java.util.ArrayList<String[]>();
	

private RunStat runStat = new RunStat();

	// OSGi DataSource
	private final static String KEY_DB_DATASOURCES = "KEY_DB_DATASOURCES";
	
	private final static String KEY_DB_DATASOURCES_RAW = "KEY_DB_DATASOURCES_RAW";

	public void setDataSources(java.util.Map<String, javax.sql.DataSource> dataSources) {
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		for (java.util.Map.Entry<String, javax.sql.DataSource> dataSourceEntry : dataSources.entrySet()) {
			talendDataSources.put(dataSourceEntry.getKey(), new routines.system.TalendDataSource(dataSourceEntry.getValue()));
		}
		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}
	
	public void setDataSourceReferences(List serviceReferences) throws Exception{
		
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		java.util.Map<String, javax.sql.DataSource> dataSources = new java.util.HashMap<String, javax.sql.DataSource>();
		
		for (java.util.Map.Entry<String, javax.sql.DataSource> entry : BundleUtils.getServices(serviceReferences,  javax.sql.DataSource.class).entrySet()) {
                    dataSources.put(entry.getKey(), entry.getValue());
                    talendDataSources.put(entry.getKey(), new routines.system.TalendDataSource(entry.getValue()));
		}

		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}

	StatCatcherUtils tStatCatcher_1 = new StatCatcherUtils("_w3lusKQjEe6bxKyLjxP8tQ", "0.1");

private final java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
private final java.io.PrintStream errorMessagePS = new java.io.PrintStream(new java.io.BufferedOutputStream(baos));

public String getExceptionStackTrace() {
	if ("failure".equals(this.getStatus())) {
		errorMessagePS.flush();
		return baos.toString();
	}
	return null;
}

private Exception exception;

public Exception getException() {
	if ("failure".equals(this.getStatus())) {
		return this.exception;
	}
	return null;
}

private class TalendException extends Exception {

	private static final long serialVersionUID = 1L;

	private java.util.Map<String, Object> globalMap = null;
	private Exception e = null;
	private String currentComponent = null;
	private String virtualComponentName = null;
	
	public void setVirtualComponentName (String virtualComponentName){
		this.virtualComponentName = virtualComponentName;
	}

	private TalendException(Exception e, String errorComponent, final java.util.Map<String, Object> globalMap) {
		this.currentComponent= errorComponent;
		this.globalMap = globalMap;
		this.e = e;
	}

	public Exception getException() {
		return this.e;
	}

	public String getCurrentComponent() {
		return this.currentComponent;
	}

	
    public String getExceptionCauseMessage(Exception e){
        Throwable cause = e;
        String message = null;
        int i = 10;
        while (null != cause && 0 < i--) {
            message = cause.getMessage();
            if (null == message) {
                cause = cause.getCause();
            } else {
                break;          
            }
        }
        if (null == message) {
            message = e.getClass().getName();
        }   
        return message;
    }

	@Override
	public void printStackTrace() {
		if (!(e instanceof TalendException || e instanceof TDieException)) {
			if(virtualComponentName!=null && currentComponent.indexOf(virtualComponentName+"_")==0){
				globalMap.put(virtualComponentName+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			}
			globalMap.put(currentComponent+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			System.err.println("Exception in component " + currentComponent + " (" + jobName + ")");
		}
		if (!(e instanceof TDieException)) {
			if(e instanceof TalendException){
				e.printStackTrace();
			} else {
				e.printStackTrace();
				e.printStackTrace(errorMessagePS);
				A_GENERER_EXCEL.this.exception = e;
			}
		}
		if (!(e instanceof TalendException)) {
		try {
			for (java.lang.reflect.Method m : this.getClass().getEnclosingClass().getMethods()) {
				if (m.getName().compareTo(currentComponent + "_error") == 0) {
					m.invoke(A_GENERER_EXCEL.this, new Object[] { e , currentComponent, globalMap});
					break;
				}
			}

			if(!(e instanceof TDieException)){
			}
		} catch (Exception e) {
			this.e.printStackTrace();
		}
		}
	}
}

			public void tStatCatcher_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tStatCatcher_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tStatCatcher_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBInput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
							tStatCatcher_1.addMessage("failure",errorComponent, end_Hash.get(errorComponent)-start_Hash.get(errorComponent));
							tStatCatcher_1Process(globalMap);
							
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileOutputExcel_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
							tStatCatcher_1.addMessage("failure",errorComponent, end_Hash.get(errorComponent)-start_Hash.get(errorComponent));
							tStatCatcher_1Process(globalMap);
							
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tStatCatcher_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBInput_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
	






public static class row1Struct implements routines.system.IPersistableRow<row1Struct> {
    final static byte[] commonByteArrayLock_ALIMENTATION_DM1_A_GENERER_EXCEL = new byte[0];
    static byte[] commonByteArray_ALIMENTATION_DM1_A_GENERER_EXCEL = new byte[0];

	
			    public java.util.Date moment;

				public java.util.Date getMoment () {
					return this.moment;
				}
				
			    public String pid;

				public String getPid () {
					return this.pid;
				}
				
			    public String father_pid;

				public String getFather_pid () {
					return this.father_pid;
				}
				
			    public String root_pid;

				public String getRoot_pid () {
					return this.root_pid;
				}
				
			    public Long system_pid;

				public Long getSystem_pid () {
					return this.system_pid;
				}
				
			    public String project;

				public String getProject () {
					return this.project;
				}
				
			    public String job;

				public String getJob () {
					return this.job;
				}
				
			    public String job_repository_id;

				public String getJob_repository_id () {
					return this.job_repository_id;
				}
				
			    public String job_version;

				public String getJob_version () {
					return this.job_version;
				}
				
			    public String context;

				public String getContext () {
					return this.context;
				}
				
			    public String origin;

				public String getOrigin () {
					return this.origin;
				}
				
			    public String message_type;

				public String getMessage_type () {
					return this.message_type;
				}
				
			    public String message;

				public String getMessage () {
					return this.message;
				}
				
			    public Long duration;

				public Long getDuration () {
					return this.duration;
				}
				



	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_DM1_A_GENERER_EXCEL.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_DM1_A_GENERER_EXCEL.length == 0) {
   					commonByteArray_ALIMENTATION_DM1_A_GENERER_EXCEL = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_DM1_A_GENERER_EXCEL = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ALIMENTATION_DM1_A_GENERER_EXCEL, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_DM1_A_GENERER_EXCEL, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_DM1_A_GENERER_EXCEL.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_DM1_A_GENERER_EXCEL.length == 0) {
   					commonByteArray_ALIMENTATION_DM1_A_GENERER_EXCEL = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_DM1_A_GENERER_EXCEL = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ALIMENTATION_DM1_A_GENERER_EXCEL, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_DM1_A_GENERER_EXCEL, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_DM1_A_GENERER_EXCEL) {

        	try {

        		int length = 0;
		
					this.moment = readDate(dis);
					
					this.pid = readString(dis);
					
					this.father_pid = readString(dis);
					
					this.root_pid = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.system_pid = null;
           				} else {
           			    	this.system_pid = dis.readLong();
           				}
					
					this.project = readString(dis);
					
					this.job = readString(dis);
					
					this.job_repository_id = readString(dis);
					
					this.job_version = readString(dis);
					
					this.context = readString(dis);
					
					this.origin = readString(dis);
					
					this.message_type = readString(dis);
					
					this.message = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.duration = null;
           				} else {
           			    	this.duration = dis.readLong();
           				}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_DM1_A_GENERER_EXCEL) {

        	try {

        		int length = 0;
		
					this.moment = readDate(dis);
					
					this.pid = readString(dis);
					
					this.father_pid = readString(dis);
					
					this.root_pid = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.system_pid = null;
           				} else {
           			    	this.system_pid = dis.readLong();
           				}
					
					this.project = readString(dis);
					
					this.job = readString(dis);
					
					this.job_repository_id = readString(dis);
					
					this.job_version = readString(dis);
					
					this.context = readString(dis);
					
					this.origin = readString(dis);
					
					this.message_type = readString(dis);
					
					this.message = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.duration = null;
           				} else {
           			    	this.duration = dis.readLong();
           				}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// java.util.Date
				
						writeDate(this.moment,dos);
					
					// String
				
						writeString(this.pid,dos);
					
					// String
				
						writeString(this.father_pid,dos);
					
					// String
				
						writeString(this.root_pid,dos);
					
					// Long
				
						if(this.system_pid == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.system_pid);
		            	}
					
					// String
				
						writeString(this.project,dos);
					
					// String
				
						writeString(this.job,dos);
					
					// String
				
						writeString(this.job_repository_id,dos);
					
					// String
				
						writeString(this.job_version,dos);
					
					// String
				
						writeString(this.context,dos);
					
					// String
				
						writeString(this.origin,dos);
					
					// String
				
						writeString(this.message_type,dos);
					
					// String
				
						writeString(this.message,dos);
					
					// Long
				
						if(this.duration == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.duration);
		            	}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// java.util.Date
				
						writeDate(this.moment,dos);
					
					// String
				
						writeString(this.pid,dos);
					
					// String
				
						writeString(this.father_pid,dos);
					
					// String
				
						writeString(this.root_pid,dos);
					
					// Long
				
						if(this.system_pid == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.system_pid);
		            	}
					
					// String
				
						writeString(this.project,dos);
					
					// String
				
						writeString(this.job,dos);
					
					// String
				
						writeString(this.job_repository_id,dos);
					
					// String
				
						writeString(this.job_version,dos);
					
					// String
				
						writeString(this.context,dos);
					
					// String
				
						writeString(this.origin,dos);
					
					// String
				
						writeString(this.message_type,dos);
					
					// String
				
						writeString(this.message,dos);
					
					// Long
				
						if(this.duration == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.duration);
		            	}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("moment="+String.valueOf(moment));
		sb.append(",pid="+pid);
		sb.append(",father_pid="+father_pid);
		sb.append(",root_pid="+root_pid);
		sb.append(",system_pid="+String.valueOf(system_pid));
		sb.append(",project="+project);
		sb.append(",job="+job);
		sb.append(",job_repository_id="+job_repository_id);
		sb.append(",job_version="+job_version);
		sb.append(",context="+context);
		sb.append(",origin="+origin);
		sb.append(",message_type="+message_type);
		sb.append(",message="+message);
		sb.append(",duration="+String.valueOf(duration));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row1Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tStatCatcher_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tStatCatcher_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row1Struct row1 = new row1Struct();




	
	/**
	 * [tDBOutput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_1", false);
		start_Hash.put("tDBOutput_1", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_1";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row1");
					}
				
		int tos_count_tDBOutput_1 = 0;
		





String dbschema_tDBOutput_1 = null;
	dbschema_tDBOutput_1 = "dsid_liv_met";
	

String tableName_tDBOutput_1 = null;
if(dbschema_tDBOutput_1 == null || dbschema_tDBOutput_1.trim().length() == 0) {
	tableName_tDBOutput_1 = ("JOB_STATS");
} else {
	tableName_tDBOutput_1 = dbschema_tDBOutput_1 + "\".\"" + ("JOB_STATS");
}


int nb_line_tDBOutput_1 = 0;
int nb_line_update_tDBOutput_1 = 0;
int nb_line_inserted_tDBOutput_1 = 0;
int nb_line_deleted_tDBOutput_1 = 0;
int nb_line_rejected_tDBOutput_1 = 0;

int deletedCount_tDBOutput_1=0;
int updatedCount_tDBOutput_1=0;
int insertedCount_tDBOutput_1=0;
int rowsToCommitCount_tDBOutput_1=0;
int rejectedCount_tDBOutput_1=0;

boolean whetherReject_tDBOutput_1 = false;

java.sql.Connection conn_tDBOutput_1 = null;
String dbUser_tDBOutput_1 = null;

	
    java.lang.Class.forName("org.postgresql.Driver");
    
        String url_tDBOutput_1 = "jdbc:postgresql://"+""+":"+"5432"+"/"+"postgres";
    dbUser_tDBOutput_1 = "dsid_cc2_tos_rw";
 
	final String decryptedPassword_tDBOutput_1 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:8Nki1zXHWr3ubZEe1noi/wpVQ4/Av6I1fgTu5qNpFOs=");

    String dbPwd_tDBOutput_1 = decryptedPassword_tDBOutput_1;

    conn_tDBOutput_1 = java.sql.DriverManager.getConnection(url_tDBOutput_1,dbUser_tDBOutput_1,dbPwd_tDBOutput_1);
	
	resourceMap.put("conn_tDBOutput_1", conn_tDBOutput_1);
        conn_tDBOutput_1.setAutoCommit(false);
        int commitEvery_tDBOutput_1 = 10000;
        int commitCounter_tDBOutput_1 = 0;


   int batchSize_tDBOutput_1 = 10000;
   int batchSizeCounter_tDBOutput_1=0;

int count_tDBOutput_1=0;
	    String insert_tDBOutput_1 = "INSERT INTO \"" + tableName_tDBOutput_1 + "\" (\"moment\",\"pid\",\"father_pid\",\"root_pid\",\"system_pid\",\"project\",\"job\",\"job_repository_id\",\"job_version\",\"context\",\"origin\",\"message_type\",\"message\",\"duration\") VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
	    
	    java.sql.PreparedStatement pstmt_tDBOutput_1 = conn_tDBOutput_1.prepareStatement(insert_tDBOutput_1);
	    resourceMap.put("pstmt_tDBOutput_1", pstmt_tDBOutput_1);
	    

 



/**
 * [tDBOutput_1 begin ] stop
 */



	
	/**
	 * [tStatCatcher_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tStatCatcher_1", false);
		start_Hash.put("tStatCatcher_1", System.currentTimeMillis());
		
	
	currentComponent="tStatCatcher_1";

	
		int tos_count_tStatCatcher_1 = 0;
		

	for (StatCatcherUtils.StatCatcherMessage scm : tStatCatcher_1.getMessages()) {
		row1.pid = pid;
		row1.root_pid = rootPid;
		row1.father_pid = fatherPid;	
    	row1.project = projectName;
    	row1.job = jobName;
    	row1.context = contextStr;
		row1.origin = (scm.getOrigin()==null || scm.getOrigin().length()<1 ? null : scm.getOrigin());
		row1.message = scm.getMessage();
		row1.duration = scm.getDuration();
		row1.moment = scm.getMoment();
		row1.message_type = scm.getMessageType();
		row1.job_version = scm.getJobVersion();
		row1.job_repository_id = scm.getJobId();
		row1.system_pid = scm.getSystemPid();

 



/**
 * [tStatCatcher_1 begin ] stop
 */
	
	/**
	 * [tStatCatcher_1 main ] start
	 */

	

	
	
	currentComponent="tStatCatcher_1";

	

 


	tos_count_tStatCatcher_1++;

/**
 * [tStatCatcher_1 main ] stop
 */
	
	/**
	 * [tStatCatcher_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tStatCatcher_1";

	

 



/**
 * [tStatCatcher_1 process_data_begin ] stop
 */

	
	/**
	 * [tDBOutput_1 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row1"
						
						);
					}
					



        whetherReject_tDBOutput_1 = false;
                    if(row1.moment != null) {
pstmt_tDBOutput_1.setTimestamp(1, new java.sql.Timestamp(row1.moment.getTime()));
} else {
pstmt_tDBOutput_1.setNull(1, java.sql.Types.TIMESTAMP);
}

                    if(row1.pid == null) {
pstmt_tDBOutput_1.setNull(2, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(2, row1.pid);
}

                    if(row1.father_pid == null) {
pstmt_tDBOutput_1.setNull(3, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(3, row1.father_pid);
}

                    if(row1.root_pid == null) {
pstmt_tDBOutput_1.setNull(4, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(4, row1.root_pid);
}

                    if(row1.system_pid == null) {
pstmt_tDBOutput_1.setNull(5, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_1.setLong(5, row1.system_pid);
}

                    if(row1.project == null) {
pstmt_tDBOutput_1.setNull(6, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(6, row1.project);
}

                    if(row1.job == null) {
pstmt_tDBOutput_1.setNull(7, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(7, row1.job);
}

                    if(row1.job_repository_id == null) {
pstmt_tDBOutput_1.setNull(8, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(8, row1.job_repository_id);
}

                    if(row1.job_version == null) {
pstmt_tDBOutput_1.setNull(9, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(9, row1.job_version);
}

                    if(row1.context == null) {
pstmt_tDBOutput_1.setNull(10, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(10, row1.context);
}

                    if(row1.origin == null) {
pstmt_tDBOutput_1.setNull(11, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(11, row1.origin);
}

                    if(row1.message_type == null) {
pstmt_tDBOutput_1.setNull(12, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(12, row1.message_type);
}

                    if(row1.message == null) {
pstmt_tDBOutput_1.setNull(13, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(13, row1.message);
}

                    if(row1.duration == null) {
pstmt_tDBOutput_1.setNull(14, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_1.setLong(14, row1.duration);
}

			
    		pstmt_tDBOutput_1.addBatch();
    		nb_line_tDBOutput_1++;
    		  
    		  
    		  batchSizeCounter_tDBOutput_1++;
    		  
    			if ((batchSize_tDBOutput_1 > 0) && (batchSize_tDBOutput_1 <= batchSizeCounter_tDBOutput_1)) {
                try {
						int countSum_tDBOutput_1 = 0;
						    
						for(int countEach_tDBOutput_1: pstmt_tDBOutput_1.executeBatch()) {
							countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
						}
				    	rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
				    	
				    		insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
				    	
            	    	batchSizeCounter_tDBOutput_1 = 0;
                }catch (java.sql.BatchUpdateException e_tDBOutput_1){
globalMap.put("tDBOutput_1_ERROR_MESSAGE",e_tDBOutput_1.getMessage());
				    	java.sql.SQLException ne_tDBOutput_1 = e_tDBOutput_1.getNextException(),sqle_tDBOutput_1=null;
				    	String errormessage_tDBOutput_1;
						if (ne_tDBOutput_1 != null) {
							// build new exception to provide the original cause
							sqle_tDBOutput_1 = new java.sql.SQLException(e_tDBOutput_1.getMessage() + "\ncaused by: " + ne_tDBOutput_1.getMessage(), ne_tDBOutput_1.getSQLState(), ne_tDBOutput_1.getErrorCode(), ne_tDBOutput_1);
							errormessage_tDBOutput_1 = sqle_tDBOutput_1.getMessage();
						}else{
							errormessage_tDBOutput_1 = e_tDBOutput_1.getMessage();
						}
				    	
				    	int countSum_tDBOutput_1 = 0;
						for(int countEach_tDBOutput_1: e_tDBOutput_1.getUpdateCounts()) {
							countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
						}
						rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
						
				    		insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
				    	
				    	System.err.println(errormessage_tDBOutput_1);
				    	
					}
    			}
    		
    		    commitCounter_tDBOutput_1++;
                if(commitEvery_tDBOutput_1 <= commitCounter_tDBOutput_1) {
                if ((batchSize_tDBOutput_1 > 0) && (batchSizeCounter_tDBOutput_1 > 0)) {
                try {
                		int countSum_tDBOutput_1 = 0;
                		    
						for(int countEach_tDBOutput_1: pstmt_tDBOutput_1.executeBatch()) {
							countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
						}
            	    	rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
            	    	
            	    		insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
            	    	
                batchSizeCounter_tDBOutput_1 = 0;
               }catch (java.sql.BatchUpdateException e_tDBOutput_1){
globalMap.put("tDBOutput_1_ERROR_MESSAGE",e_tDBOutput_1.getMessage());
			    	java.sql.SQLException ne_tDBOutput_1 = e_tDBOutput_1.getNextException(),sqle_tDBOutput_1=null;
			    	String errormessage_tDBOutput_1;
					if (ne_tDBOutput_1 != null) {
						// build new exception to provide the original cause
						sqle_tDBOutput_1 = new java.sql.SQLException(e_tDBOutput_1.getMessage() + "\ncaused by: " + ne_tDBOutput_1.getMessage(), ne_tDBOutput_1.getSQLState(), ne_tDBOutput_1.getErrorCode(), ne_tDBOutput_1);
						errormessage_tDBOutput_1 = sqle_tDBOutput_1.getMessage();
					}else{
						errormessage_tDBOutput_1 = e_tDBOutput_1.getMessage();
					}
			    	
			    	int countSum_tDBOutput_1 = 0;
					for(int countEach_tDBOutput_1: e_tDBOutput_1.getUpdateCounts()) {
						countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
					}
					rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
					
			    		insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
			    	
			    	System.err.println(errormessage_tDBOutput_1);
			    	
				}
            }
                    if(rowsToCommitCount_tDBOutput_1 != 0){
                    	
                    }
                    conn_tDBOutput_1.commit();
                    if(rowsToCommitCount_tDBOutput_1 != 0){
                    	
                    	rowsToCommitCount_tDBOutput_1 = 0;
                    }
                    commitCounter_tDBOutput_1=0;
                }

 


	tos_count_tDBOutput_1++;

/**
 * [tDBOutput_1 main ] stop
 */
	
	/**
	 * [tDBOutput_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";

	

 



/**
 * [tDBOutput_1 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";

	

 



/**
 * [tDBOutput_1 process_data_end ] stop
 */



	
	/**
	 * [tStatCatcher_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tStatCatcher_1";

	

 



/**
 * [tStatCatcher_1 process_data_end ] stop
 */
	
	/**
	 * [tStatCatcher_1 end ] start
	 */

	

	
	
	currentComponent="tStatCatcher_1";

	

	}


 

ok_Hash.put("tStatCatcher_1", true);
end_Hash.put("tStatCatcher_1", System.currentTimeMillis());




/**
 * [tStatCatcher_1 end ] stop
 */

	
	/**
	 * [tDBOutput_1 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";

	



	    try {
				int countSum_tDBOutput_1 = 0;
				if (pstmt_tDBOutput_1 != null && batchSizeCounter_tDBOutput_1 > 0) {
						
					for(int countEach_tDBOutput_1: pstmt_tDBOutput_1.executeBatch()) {
						countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
					}
					rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
						
				}
		    	
		    		insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
		    	
	    }catch (java.sql.BatchUpdateException e_tDBOutput_1){
globalMap.put("tDBOutput_1_ERROR_MESSAGE",e_tDBOutput_1.getMessage());
	    	java.sql.SQLException ne_tDBOutput_1 = e_tDBOutput_1.getNextException(),sqle_tDBOutput_1=null;
	    	String errormessage_tDBOutput_1;
			if (ne_tDBOutput_1 != null) {
				// build new exception to provide the original cause
				sqle_tDBOutput_1 = new java.sql.SQLException(e_tDBOutput_1.getMessage() + "\ncaused by: " + ne_tDBOutput_1.getMessage(), ne_tDBOutput_1.getSQLState(), ne_tDBOutput_1.getErrorCode(), ne_tDBOutput_1);
				errormessage_tDBOutput_1 = sqle_tDBOutput_1.getMessage();
			}else{
				errormessage_tDBOutput_1 = e_tDBOutput_1.getMessage();
			}
	    	
	    	int countSum_tDBOutput_1 = 0;
			for(int countEach_tDBOutput_1: e_tDBOutput_1.getUpdateCounts()) {
				countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
			}
			rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
			
	    		insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
	    	
	    	System.err.println(errormessage_tDBOutput_1);
	    	
		}
	    
        if(pstmt_tDBOutput_1 != null) {
        		
            pstmt_tDBOutput_1.close();
            resourceMap.remove("pstmt_tDBOutput_1");
        }
    resourceMap.put("statementClosed_tDBOutput_1", true);
			if(rowsToCommitCount_tDBOutput_1 != 0){
				
			}
			conn_tDBOutput_1.commit();
			if(rowsToCommitCount_tDBOutput_1 != 0){
				
				rowsToCommitCount_tDBOutput_1 = 0;
			}
			commitCounter_tDBOutput_1 = 0;
		
    	conn_tDBOutput_1 .close();
    	
    	resourceMap.put("finish_tDBOutput_1", true);
    	

	nb_line_deleted_tDBOutput_1=nb_line_deleted_tDBOutput_1+ deletedCount_tDBOutput_1;
	nb_line_update_tDBOutput_1=nb_line_update_tDBOutput_1 + updatedCount_tDBOutput_1;
	nb_line_inserted_tDBOutput_1=nb_line_inserted_tDBOutput_1 + insertedCount_tDBOutput_1;
	nb_line_rejected_tDBOutput_1=nb_line_rejected_tDBOutput_1 + rejectedCount_tDBOutput_1;
	
        globalMap.put("tDBOutput_1_NB_LINE",nb_line_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_UPDATED",nb_line_update_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_DELETED",nb_line_deleted_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_1);
    

	


				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row1");
			  	}
			  	
 

ok_Hash.put("tDBOutput_1", true);
end_Hash.put("tDBOutput_1", System.currentTimeMillis());




/**
 * [tDBOutput_1 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tStatCatcher_1 finally ] start
	 */

	

	
	
	currentComponent="tStatCatcher_1";

	

 



/**
 * [tStatCatcher_1 finally ] stop
 */

	
	/**
	 * [tDBOutput_1 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";

	



    try {
    if (resourceMap.get("statementClosed_tDBOutput_1") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_1 = null;
                if ((pstmtToClose_tDBOutput_1 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_1")) != null) {
                    pstmtToClose_tDBOutput_1.close();
                }
    }
    } finally {
        if(resourceMap.get("finish_tDBOutput_1") == null){
            java.sql.Connection ctn_tDBOutput_1 = null;
            if((ctn_tDBOutput_1 = (java.sql.Connection)resourceMap.get("conn_tDBOutput_1")) != null){
                try {
                    ctn_tDBOutput_1.close();
                } catch (java.sql.SQLException sqlEx_tDBOutput_1) {
                    String errorMessage_tDBOutput_1 = "failed to close the connection in tDBOutput_1 :" + sqlEx_tDBOutput_1.getMessage();
                    System.err.println(errorMessage_tDBOutput_1);
                }
            }
        }
    }
 



/**
 * [tDBOutput_1 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tStatCatcher_1_SUBPROCESS_STATE", 1);
	}
	


public static class row2Struct implements routines.system.IPersistableRow<row2Struct> {
    final static byte[] commonByteArrayLock_ALIMENTATION_DM1_A_GENERER_EXCEL = new byte[0];
    static byte[] commonByteArray_ALIMENTATION_DM1_A_GENERER_EXCEL = new byte[0];

	
			    public BigDecimal ID_COMMANDE;

				public BigDecimal getID_COMMANDE () {
					return this.ID_COMMANDE;
				}
				
			    public BigDecimal NUMERO_COMMANDE;

				public BigDecimal getNUMERO_COMMANDE () {
					return this.NUMERO_COMMANDE;
				}
				
			    public java.util.Date DATE_COMMANDE;

				public java.util.Date getDATE_COMMANDE () {
					return this.DATE_COMMANDE;
				}
				
			    public Float MONTANT_TOTAL;

				public Float getMONTANT_TOTAL () {
					return this.MONTANT_TOTAL;
				}
				
			    public BigDecimal ID_MENU;

				public BigDecimal getID_MENU () {
					return this.ID_MENU;
				}
				
			    public String CODE_MENU;

				public String getCODE_MENU () {
					return this.CODE_MENU;
				}
				
			    public String LIBELLE_MENU;

				public String getLIBELLE_MENU () {
					return this.LIBELLE_MENU;
				}
				
			    public BigDecimal NOMBRE_ARTICLES;

				public BigDecimal getNOMBRE_ARTICLES () {
					return this.NOMBRE_ARTICLES;
				}
				
			    public String TEMPS_THEO_PREPARATION;

				public String getTEMPS_THEO_PREPARATION () {
					return this.TEMPS_THEO_PREPARATION;
				}
				
			    public BigDecimal ID_PREPARATION;

				public BigDecimal getID_PREPARATION () {
					return this.ID_PREPARATION;
				}
				
			    public java.util.Date DATE_DEBUT_PREPARATION;

				public java.util.Date getDATE_DEBUT_PREPARATION () {
					return this.DATE_DEBUT_PREPARATION;
				}
				
			    public java.util.Date DATE_FIN_PREPARATION;

				public java.util.Date getDATE_FIN_PREPARATION () {
					return this.DATE_FIN_PREPARATION;
				}
				
			    public BigDecimal ID_ADRESSE_NORM_CLIENT;

				public BigDecimal getID_ADRESSE_NORM_CLIENT () {
					return this.ID_ADRESSE_NORM_CLIENT;
				}
				
			    public String NUMERO_VOIE;

				public String getNUMERO_VOIE () {
					return this.NUMERO_VOIE;
				}
				
			    public String NOM_VOIE;

				public String getNOM_VOIE () {
					return this.NOM_VOIE;
				}
				
			    public BigDecimal CODE_POSTAL;

				public BigDecimal getCODE_POSTAL () {
					return this.CODE_POSTAL;
				}
				
			    public String NOM_VILLE;

				public String getNOM_VILLE () {
					return this.NOM_VILLE;
				}
				
			    public String LONGITUDE;

				public String getLONGITUDE () {
					return this.LONGITUDE;
				}
				
			    public String LATITUDE;

				public String getLATITUDE () {
					return this.LATITUDE;
				}
				
			    public String ID_ADRESSE_RESTAURANT;

				public String getID_ADRESSE_RESTAURANT () {
					return this.ID_ADRESSE_RESTAURANT;
				}
				
			    public String ADRESSE_RESTAURANT;

				public String getADRESSE_RESTAURANT () {
					return this.ADRESSE_RESTAURANT;
				}
				
			    public String ID_CLIENT;

				public String getID_CLIENT () {
					return this.ID_CLIENT;
				}
				
			    public BigDecimal ID_ADRESSE_CLIENT;

				public BigDecimal getID_ADRESSE_CLIENT () {
					return this.ID_ADRESSE_CLIENT;
				}
				
			    public String ADRESSE_CLIENT;

				public String getADRESSE_CLIENT () {
					return this.ADRESSE_CLIENT;
				}
				
			    public BigDecimal ID_RESTAURANT;

				public BigDecimal getID_RESTAURANT () {
					return this.ID_RESTAURANT;
				}
				
			    public String CODE_RESTAURANT;

				public String getCODE_RESTAURANT () {
					return this.CODE_RESTAURANT;
				}
				
			    public String RAISON_SOCIALE_RESTAURANT;

				public String getRAISON_SOCIALE_RESTAURANT () {
					return this.RAISON_SOCIALE_RESTAURANT;
				}
				
			    public BigDecimal ID_ADRESSE_NORM_RESTAURANT;

				public BigDecimal getID_ADRESSE_NORM_RESTAURANT () {
					return this.ID_ADRESSE_NORM_RESTAURANT;
				}
				
			    public String ID_MOYEN_PAIEMENT;

				public String getID_MOYEN_PAIEMENT () {
					return this.ID_MOYEN_PAIEMENT;
				}
				
			    public String CODE_MOYEN_PAIEMENT;

				public String getCODE_MOYEN_PAIEMENT () {
					return this.CODE_MOYEN_PAIEMENT;
				}
				
			    public String LIVELLE_MOYEN_PAIEMENT;

				public String getLIVELLE_MOYEN_PAIEMENT () {
					return this.LIVELLE_MOYEN_PAIEMENT;
				}
				
			    public String NOM_CLIENT;

				public String getNOM_CLIENT () {
					return this.NOM_CLIENT;
				}
				
			    public String PRENOM_CLIENT;

				public String getPRENOM_CLIENT () {
					return this.PRENOM_CLIENT;
				}
				
			    public String LATITUDE_RESTAU;

				public String getLATITUDE_RESTAU () {
					return this.LATITUDE_RESTAU;
				}
				
			    public BigDecimal LONGITUDE_RESTAU;

				public BigDecimal getLONGITUDE_RESTAU () {
					return this.LONGITUDE_RESTAU;
				}
				
			    public String NOM_VILLE_RESTAU;

				public String getNOM_VILLE_RESTAU () {
					return this.NOM_VILLE_RESTAU;
				}
				
			    public BigDecimal CODE_POSTAL_RESTAU;

				public BigDecimal getCODE_POSTAL_RESTAU () {
					return this.CODE_POSTAL_RESTAU;
				}
				
			    public String NOM_VOIE_RESTAU;

				public String getNOM_VOIE_RESTAU () {
					return this.NOM_VOIE_RESTAU;
				}
				
			    public String NUMERO_VOIE_RESTAU;

				public String getNUMERO_VOIE_RESTAU () {
					return this.NUMERO_VOIE_RESTAU;
				}
				



	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_DM1_A_GENERER_EXCEL.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_DM1_A_GENERER_EXCEL.length == 0) {
   					commonByteArray_ALIMENTATION_DM1_A_GENERER_EXCEL = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_DM1_A_GENERER_EXCEL = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ALIMENTATION_DM1_A_GENERER_EXCEL, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_DM1_A_GENERER_EXCEL, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_DM1_A_GENERER_EXCEL.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_DM1_A_GENERER_EXCEL.length == 0) {
   					commonByteArray_ALIMENTATION_DM1_A_GENERER_EXCEL = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_DM1_A_GENERER_EXCEL = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ALIMENTATION_DM1_A_GENERER_EXCEL, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_DM1_A_GENERER_EXCEL, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_DM1_A_GENERER_EXCEL) {

        	try {

        		int length = 0;
		
						this.ID_COMMANDE = (BigDecimal) dis.readObject();
					
						this.NUMERO_COMMANDE = (BigDecimal) dis.readObject();
					
					this.DATE_COMMANDE = readDate(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.MONTANT_TOTAL = null;
           				} else {
           			    	this.MONTANT_TOTAL = dis.readFloat();
           				}
					
						this.ID_MENU = (BigDecimal) dis.readObject();
					
					this.CODE_MENU = readString(dis);
					
					this.LIBELLE_MENU = readString(dis);
					
						this.NOMBRE_ARTICLES = (BigDecimal) dis.readObject();
					
					this.TEMPS_THEO_PREPARATION = readString(dis);
					
						this.ID_PREPARATION = (BigDecimal) dis.readObject();
					
					this.DATE_DEBUT_PREPARATION = readDate(dis);
					
					this.DATE_FIN_PREPARATION = readDate(dis);
					
						this.ID_ADRESSE_NORM_CLIENT = (BigDecimal) dis.readObject();
					
					this.NUMERO_VOIE = readString(dis);
					
					this.NOM_VOIE = readString(dis);
					
						this.CODE_POSTAL = (BigDecimal) dis.readObject();
					
					this.NOM_VILLE = readString(dis);
					
					this.LONGITUDE = readString(dis);
					
					this.LATITUDE = readString(dis);
					
					this.ID_ADRESSE_RESTAURANT = readString(dis);
					
					this.ADRESSE_RESTAURANT = readString(dis);
					
					this.ID_CLIENT = readString(dis);
					
						this.ID_ADRESSE_CLIENT = (BigDecimal) dis.readObject();
					
					this.ADRESSE_CLIENT = readString(dis);
					
						this.ID_RESTAURANT = (BigDecimal) dis.readObject();
					
					this.CODE_RESTAURANT = readString(dis);
					
					this.RAISON_SOCIALE_RESTAURANT = readString(dis);
					
						this.ID_ADRESSE_NORM_RESTAURANT = (BigDecimal) dis.readObject();
					
					this.ID_MOYEN_PAIEMENT = readString(dis);
					
					this.CODE_MOYEN_PAIEMENT = readString(dis);
					
					this.LIVELLE_MOYEN_PAIEMENT = readString(dis);
					
					this.NOM_CLIENT = readString(dis);
					
					this.PRENOM_CLIENT = readString(dis);
					
					this.LATITUDE_RESTAU = readString(dis);
					
						this.LONGITUDE_RESTAU = (BigDecimal) dis.readObject();
					
					this.NOM_VILLE_RESTAU = readString(dis);
					
						this.CODE_POSTAL_RESTAU = (BigDecimal) dis.readObject();
					
					this.NOM_VOIE_RESTAU = readString(dis);
					
					this.NUMERO_VOIE_RESTAU = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_DM1_A_GENERER_EXCEL) {

        	try {

        		int length = 0;
		
						this.ID_COMMANDE = (BigDecimal) dis.readObject();
					
						this.NUMERO_COMMANDE = (BigDecimal) dis.readObject();
					
					this.DATE_COMMANDE = readDate(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.MONTANT_TOTAL = null;
           				} else {
           			    	this.MONTANT_TOTAL = dis.readFloat();
           				}
					
						this.ID_MENU = (BigDecimal) dis.readObject();
					
					this.CODE_MENU = readString(dis);
					
					this.LIBELLE_MENU = readString(dis);
					
						this.NOMBRE_ARTICLES = (BigDecimal) dis.readObject();
					
					this.TEMPS_THEO_PREPARATION = readString(dis);
					
						this.ID_PREPARATION = (BigDecimal) dis.readObject();
					
					this.DATE_DEBUT_PREPARATION = readDate(dis);
					
					this.DATE_FIN_PREPARATION = readDate(dis);
					
						this.ID_ADRESSE_NORM_CLIENT = (BigDecimal) dis.readObject();
					
					this.NUMERO_VOIE = readString(dis);
					
					this.NOM_VOIE = readString(dis);
					
						this.CODE_POSTAL = (BigDecimal) dis.readObject();
					
					this.NOM_VILLE = readString(dis);
					
					this.LONGITUDE = readString(dis);
					
					this.LATITUDE = readString(dis);
					
					this.ID_ADRESSE_RESTAURANT = readString(dis);
					
					this.ADRESSE_RESTAURANT = readString(dis);
					
					this.ID_CLIENT = readString(dis);
					
						this.ID_ADRESSE_CLIENT = (BigDecimal) dis.readObject();
					
					this.ADRESSE_CLIENT = readString(dis);
					
						this.ID_RESTAURANT = (BigDecimal) dis.readObject();
					
					this.CODE_RESTAURANT = readString(dis);
					
					this.RAISON_SOCIALE_RESTAURANT = readString(dis);
					
						this.ID_ADRESSE_NORM_RESTAURANT = (BigDecimal) dis.readObject();
					
					this.ID_MOYEN_PAIEMENT = readString(dis);
					
					this.CODE_MOYEN_PAIEMENT = readString(dis);
					
					this.LIVELLE_MOYEN_PAIEMENT = readString(dis);
					
					this.NOM_CLIENT = readString(dis);
					
					this.PRENOM_CLIENT = readString(dis);
					
					this.LATITUDE_RESTAU = readString(dis);
					
						this.LONGITUDE_RESTAU = (BigDecimal) dis.readObject();
					
					this.NOM_VILLE_RESTAU = readString(dis);
					
						this.CODE_POSTAL_RESTAU = (BigDecimal) dis.readObject();
					
					this.NOM_VOIE_RESTAU = readString(dis);
					
					this.NUMERO_VOIE_RESTAU = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// BigDecimal
				
       			    	dos.writeObject(this.ID_COMMANDE);
					
					// BigDecimal
				
       			    	dos.writeObject(this.NUMERO_COMMANDE);
					
					// java.util.Date
				
						writeDate(this.DATE_COMMANDE,dos);
					
					// Float
				
						if(this.MONTANT_TOTAL == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.MONTANT_TOTAL);
		            	}
					
					// BigDecimal
				
       			    	dos.writeObject(this.ID_MENU);
					
					// String
				
						writeString(this.CODE_MENU,dos);
					
					// String
				
						writeString(this.LIBELLE_MENU,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.NOMBRE_ARTICLES);
					
					// String
				
						writeString(this.TEMPS_THEO_PREPARATION,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.ID_PREPARATION);
					
					// java.util.Date
				
						writeDate(this.DATE_DEBUT_PREPARATION,dos);
					
					// java.util.Date
				
						writeDate(this.DATE_FIN_PREPARATION,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.ID_ADRESSE_NORM_CLIENT);
					
					// String
				
						writeString(this.NUMERO_VOIE,dos);
					
					// String
				
						writeString(this.NOM_VOIE,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.CODE_POSTAL);
					
					// String
				
						writeString(this.NOM_VILLE,dos);
					
					// String
				
						writeString(this.LONGITUDE,dos);
					
					// String
				
						writeString(this.LATITUDE,dos);
					
					// String
				
						writeString(this.ID_ADRESSE_RESTAURANT,dos);
					
					// String
				
						writeString(this.ADRESSE_RESTAURANT,dos);
					
					// String
				
						writeString(this.ID_CLIENT,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.ID_ADRESSE_CLIENT);
					
					// String
				
						writeString(this.ADRESSE_CLIENT,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.ID_RESTAURANT);
					
					// String
				
						writeString(this.CODE_RESTAURANT,dos);
					
					// String
				
						writeString(this.RAISON_SOCIALE_RESTAURANT,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.ID_ADRESSE_NORM_RESTAURANT);
					
					// String
				
						writeString(this.ID_MOYEN_PAIEMENT,dos);
					
					// String
				
						writeString(this.CODE_MOYEN_PAIEMENT,dos);
					
					// String
				
						writeString(this.LIVELLE_MOYEN_PAIEMENT,dos);
					
					// String
				
						writeString(this.NOM_CLIENT,dos);
					
					// String
				
						writeString(this.PRENOM_CLIENT,dos);
					
					// String
				
						writeString(this.LATITUDE_RESTAU,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.LONGITUDE_RESTAU);
					
					// String
				
						writeString(this.NOM_VILLE_RESTAU,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.CODE_POSTAL_RESTAU);
					
					// String
				
						writeString(this.NOM_VOIE_RESTAU,dos);
					
					// String
				
						writeString(this.NUMERO_VOIE_RESTAU,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// BigDecimal
				
       			    	dos.writeObject(this.ID_COMMANDE);
					
					// BigDecimal
				
       			    	dos.writeObject(this.NUMERO_COMMANDE);
					
					// java.util.Date
				
						writeDate(this.DATE_COMMANDE,dos);
					
					// Float
				
						if(this.MONTANT_TOTAL == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.MONTANT_TOTAL);
		            	}
					
					// BigDecimal
				
       			    	dos.writeObject(this.ID_MENU);
					
					// String
				
						writeString(this.CODE_MENU,dos);
					
					// String
				
						writeString(this.LIBELLE_MENU,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.NOMBRE_ARTICLES);
					
					// String
				
						writeString(this.TEMPS_THEO_PREPARATION,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.ID_PREPARATION);
					
					// java.util.Date
				
						writeDate(this.DATE_DEBUT_PREPARATION,dos);
					
					// java.util.Date
				
						writeDate(this.DATE_FIN_PREPARATION,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.ID_ADRESSE_NORM_CLIENT);
					
					// String
				
						writeString(this.NUMERO_VOIE,dos);
					
					// String
				
						writeString(this.NOM_VOIE,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.CODE_POSTAL);
					
					// String
				
						writeString(this.NOM_VILLE,dos);
					
					// String
				
						writeString(this.LONGITUDE,dos);
					
					// String
				
						writeString(this.LATITUDE,dos);
					
					// String
				
						writeString(this.ID_ADRESSE_RESTAURANT,dos);
					
					// String
				
						writeString(this.ADRESSE_RESTAURANT,dos);
					
					// String
				
						writeString(this.ID_CLIENT,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.ID_ADRESSE_CLIENT);
					
					// String
				
						writeString(this.ADRESSE_CLIENT,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.ID_RESTAURANT);
					
					// String
				
						writeString(this.CODE_RESTAURANT,dos);
					
					// String
				
						writeString(this.RAISON_SOCIALE_RESTAURANT,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.ID_ADRESSE_NORM_RESTAURANT);
					
					// String
				
						writeString(this.ID_MOYEN_PAIEMENT,dos);
					
					// String
				
						writeString(this.CODE_MOYEN_PAIEMENT,dos);
					
					// String
				
						writeString(this.LIVELLE_MOYEN_PAIEMENT,dos);
					
					// String
				
						writeString(this.NOM_CLIENT,dos);
					
					// String
				
						writeString(this.PRENOM_CLIENT,dos);
					
					// String
				
						writeString(this.LATITUDE_RESTAU,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.LONGITUDE_RESTAU);
					
					// String
				
						writeString(this.NOM_VILLE_RESTAU,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.CODE_POSTAL_RESTAU);
					
					// String
				
						writeString(this.NOM_VOIE_RESTAU,dos);
					
					// String
				
						writeString(this.NUMERO_VOIE_RESTAU,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("ID_COMMANDE="+String.valueOf(ID_COMMANDE));
		sb.append(",NUMERO_COMMANDE="+String.valueOf(NUMERO_COMMANDE));
		sb.append(",DATE_COMMANDE="+String.valueOf(DATE_COMMANDE));
		sb.append(",MONTANT_TOTAL="+String.valueOf(MONTANT_TOTAL));
		sb.append(",ID_MENU="+String.valueOf(ID_MENU));
		sb.append(",CODE_MENU="+CODE_MENU);
		sb.append(",LIBELLE_MENU="+LIBELLE_MENU);
		sb.append(",NOMBRE_ARTICLES="+String.valueOf(NOMBRE_ARTICLES));
		sb.append(",TEMPS_THEO_PREPARATION="+TEMPS_THEO_PREPARATION);
		sb.append(",ID_PREPARATION="+String.valueOf(ID_PREPARATION));
		sb.append(",DATE_DEBUT_PREPARATION="+String.valueOf(DATE_DEBUT_PREPARATION));
		sb.append(",DATE_FIN_PREPARATION="+String.valueOf(DATE_FIN_PREPARATION));
		sb.append(",ID_ADRESSE_NORM_CLIENT="+String.valueOf(ID_ADRESSE_NORM_CLIENT));
		sb.append(",NUMERO_VOIE="+NUMERO_VOIE);
		sb.append(",NOM_VOIE="+NOM_VOIE);
		sb.append(",CODE_POSTAL="+String.valueOf(CODE_POSTAL));
		sb.append(",NOM_VILLE="+NOM_VILLE);
		sb.append(",LONGITUDE="+LONGITUDE);
		sb.append(",LATITUDE="+LATITUDE);
		sb.append(",ID_ADRESSE_RESTAURANT="+ID_ADRESSE_RESTAURANT);
		sb.append(",ADRESSE_RESTAURANT="+ADRESSE_RESTAURANT);
		sb.append(",ID_CLIENT="+ID_CLIENT);
		sb.append(",ID_ADRESSE_CLIENT="+String.valueOf(ID_ADRESSE_CLIENT));
		sb.append(",ADRESSE_CLIENT="+ADRESSE_CLIENT);
		sb.append(",ID_RESTAURANT="+String.valueOf(ID_RESTAURANT));
		sb.append(",CODE_RESTAURANT="+CODE_RESTAURANT);
		sb.append(",RAISON_SOCIALE_RESTAURANT="+RAISON_SOCIALE_RESTAURANT);
		sb.append(",ID_ADRESSE_NORM_RESTAURANT="+String.valueOf(ID_ADRESSE_NORM_RESTAURANT));
		sb.append(",ID_MOYEN_PAIEMENT="+ID_MOYEN_PAIEMENT);
		sb.append(",CODE_MOYEN_PAIEMENT="+CODE_MOYEN_PAIEMENT);
		sb.append(",LIVELLE_MOYEN_PAIEMENT="+LIVELLE_MOYEN_PAIEMENT);
		sb.append(",NOM_CLIENT="+NOM_CLIENT);
		sb.append(",PRENOM_CLIENT="+PRENOM_CLIENT);
		sb.append(",LATITUDE_RESTAU="+LATITUDE_RESTAU);
		sb.append(",LONGITUDE_RESTAU="+String.valueOf(LONGITUDE_RESTAU));
		sb.append(",NOM_VILLE_RESTAU="+NOM_VILLE_RESTAU);
		sb.append(",CODE_POSTAL_RESTAU="+String.valueOf(CODE_POSTAL_RESTAU));
		sb.append(",NOM_VOIE_RESTAU="+NOM_VOIE_RESTAU);
		sb.append(",NUMERO_VOIE_RESTAU="+NUMERO_VOIE_RESTAU);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row2Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tDBInput_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBInput_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row2Struct row2 = new row2Struct();




	
	/**
	 * [tFileOutputExcel_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileOutputExcel_1", false);
		start_Hash.put("tFileOutputExcel_1", System.currentTimeMillis());
		
				tStatCatcher_1.addMessage("begin","tFileOutputExcel_1");
				tStatCatcher_1Process(globalMap);
			
	
	currentComponent="tFileOutputExcel_1";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row2");
					}
				
		int tos_count_tFileOutputExcel_1 = 0;
		


		
		int columnIndex_tFileOutputExcel_1 = 0;
		boolean headerIsInserted_tFileOutputExcel_1 = false;
		
		
		int nb_line_tFileOutputExcel_1 = 0;

		String fileName_tFileOutputExcel_1="C:/CC2/Groupe1/3_DATA_FROM_VIEW/CC2_Groupe1_DM1_SRC_DATA.xls";
		java.io.File file_tFileOutputExcel_1 = new java.io.File(fileName_tFileOutputExcel_1);
		boolean isFileGenerated_tFileOutputExcel_1 = true;
//create directory only if not exists
          java.io.File parentFile_tFileOutputExcel_1 = file_tFileOutputExcel_1.getParentFile();
          if (parentFile_tFileOutputExcel_1 != null && !parentFile_tFileOutputExcel_1.exists()) {
        	
             parentFile_tFileOutputExcel_1.mkdirs();
        	
          }

		jxl.write.WritableWorkbook writeableWorkbook_tFileOutputExcel_1 = null;
		jxl.write.WritableSheet writableSheet_tFileOutputExcel_1 = null;

		jxl.WorkbookSettings workbookSettings_tFileOutputExcel_1 = new jxl.WorkbookSettings();
        workbookSettings_tFileOutputExcel_1.setEncoding("ISO-8859-15");
		writeableWorkbook_tFileOutputExcel_1 = new jxl.write.biff.WritableWorkbookImpl(
            		new java.io.BufferedOutputStream(new java.io.FileOutputStream(fileName_tFileOutputExcel_1)),
            		true,
            		workbookSettings_tFileOutputExcel_1);

        writableSheet_tFileOutputExcel_1 = writeableWorkbook_tFileOutputExcel_1.getSheet("Sheet1");
        if(writableSheet_tFileOutputExcel_1 == null){
        	writableSheet_tFileOutputExcel_1 = writeableWorkbook_tFileOutputExcel_1.createSheet("Sheet1", writeableWorkbook_tFileOutputExcel_1.getNumberOfSheets());
		}


        //modif start
        int startRowNum_tFileOutputExcel_1 = writableSheet_tFileOutputExcel_1.getRows();
		//modif end

		int[] fitWidth_tFileOutputExcel_1 = new int[39];
		for(int i_tFileOutputExcel_1=0;i_tFileOutputExcel_1<39;i_tFileOutputExcel_1++){
		    int fitCellViewSize_tFileOutputExcel_1=writableSheet_tFileOutputExcel_1.getColumnView(i_tFileOutputExcel_1).getSize();
			fitWidth_tFileOutputExcel_1[i_tFileOutputExcel_1]=fitCellViewSize_tFileOutputExcel_1/256;
			if(fitCellViewSize_tFileOutputExcel_1%256!=0){
				fitWidth_tFileOutputExcel_1[i_tFileOutputExcel_1]+=1;
			}
		}

						final jxl.write.WritableCellFormat cell_format_DATE_COMMANDE_tFileOutputExcel_1=new jxl.write.WritableCellFormat(new jxl.write.DateFormat("dd-MM-yyyy"));
						final jxl.write.WritableCellFormat cell_format_DATE_DEBUT_PREPARATION_tFileOutputExcel_1=new jxl.write.WritableCellFormat(new jxl.write.DateFormat("dd-MM-yyyy HH:mm"));
						final jxl.write.WritableCellFormat cell_format_DATE_FIN_PREPARATION_tFileOutputExcel_1=new jxl.write.WritableCellFormat(new jxl.write.DateFormat("dd-MM-yyyy HH:mm"));


		if (startRowNum_tFileOutputExcel_1 == 0){
	//modif end
		//modif start
			writableSheet_tFileOutputExcel_1.addCell(new jxl.write.Label(0, nb_line_tFileOutputExcel_1, "ID_COMMANDE"
			));
		//modif end
		fitWidth_tFileOutputExcel_1[0]=fitWidth_tFileOutputExcel_1[0]>11?fitWidth_tFileOutputExcel_1[0]:11;
		//modif start
			writableSheet_tFileOutputExcel_1.addCell(new jxl.write.Label(1, nb_line_tFileOutputExcel_1, "NUMERO_COMMANDE"
			));
		//modif end
		fitWidth_tFileOutputExcel_1[1]=fitWidth_tFileOutputExcel_1[1]>15?fitWidth_tFileOutputExcel_1[1]:15;
		//modif start
			writableSheet_tFileOutputExcel_1.addCell(new jxl.write.Label(2, nb_line_tFileOutputExcel_1, "DATE_COMMANDE"
			));
		//modif end
		fitWidth_tFileOutputExcel_1[2]=fitWidth_tFileOutputExcel_1[2]>13?fitWidth_tFileOutputExcel_1[2]:13;
		//modif start
			writableSheet_tFileOutputExcel_1.addCell(new jxl.write.Label(3, nb_line_tFileOutputExcel_1, "MONTANT_TOTAL"
			));
		//modif end
		fitWidth_tFileOutputExcel_1[3]=fitWidth_tFileOutputExcel_1[3]>13?fitWidth_tFileOutputExcel_1[3]:13;
		//modif start
			writableSheet_tFileOutputExcel_1.addCell(new jxl.write.Label(4, nb_line_tFileOutputExcel_1, "ID_MENU"
			));
		//modif end
		fitWidth_tFileOutputExcel_1[4]=fitWidth_tFileOutputExcel_1[4]>7?fitWidth_tFileOutputExcel_1[4]:7;
		//modif start
			writableSheet_tFileOutputExcel_1.addCell(new jxl.write.Label(5, nb_line_tFileOutputExcel_1, "CODE_MENU"
			));
		//modif end
		fitWidth_tFileOutputExcel_1[5]=fitWidth_tFileOutputExcel_1[5]>9?fitWidth_tFileOutputExcel_1[5]:9;
		//modif start
			writableSheet_tFileOutputExcel_1.addCell(new jxl.write.Label(6, nb_line_tFileOutputExcel_1, "LIBELLE_MENU"
			));
		//modif end
		fitWidth_tFileOutputExcel_1[6]=fitWidth_tFileOutputExcel_1[6]>12?fitWidth_tFileOutputExcel_1[6]:12;
		//modif start
			writableSheet_tFileOutputExcel_1.addCell(new jxl.write.Label(7, nb_line_tFileOutputExcel_1, "NOMBRE_ARTICLES"
			));
		//modif end
		fitWidth_tFileOutputExcel_1[7]=fitWidth_tFileOutputExcel_1[7]>15?fitWidth_tFileOutputExcel_1[7]:15;
		//modif start
			writableSheet_tFileOutputExcel_1.addCell(new jxl.write.Label(8, nb_line_tFileOutputExcel_1, "TEMPS_THEO_PREPARATION"
			));
		//modif end
		fitWidth_tFileOutputExcel_1[8]=fitWidth_tFileOutputExcel_1[8]>22?fitWidth_tFileOutputExcel_1[8]:22;
		//modif start
			writableSheet_tFileOutputExcel_1.addCell(new jxl.write.Label(9, nb_line_tFileOutputExcel_1, "ID_PREPARATION"
			));
		//modif end
		fitWidth_tFileOutputExcel_1[9]=fitWidth_tFileOutputExcel_1[9]>14?fitWidth_tFileOutputExcel_1[9]:14;
		//modif start
			writableSheet_tFileOutputExcel_1.addCell(new jxl.write.Label(10, nb_line_tFileOutputExcel_1, "DATE_DEBUT_PREPARATION"
			));
		//modif end
		fitWidth_tFileOutputExcel_1[10]=fitWidth_tFileOutputExcel_1[10]>22?fitWidth_tFileOutputExcel_1[10]:22;
		//modif start
			writableSheet_tFileOutputExcel_1.addCell(new jxl.write.Label(11, nb_line_tFileOutputExcel_1, "DATE_FIN_PREPARATION"
			));
		//modif end
		fitWidth_tFileOutputExcel_1[11]=fitWidth_tFileOutputExcel_1[11]>20?fitWidth_tFileOutputExcel_1[11]:20;
		//modif start
			writableSheet_tFileOutputExcel_1.addCell(new jxl.write.Label(12, nb_line_tFileOutputExcel_1, "ID_ADRESSE_NORM_CLIENT"
			));
		//modif end
		fitWidth_tFileOutputExcel_1[12]=fitWidth_tFileOutputExcel_1[12]>22?fitWidth_tFileOutputExcel_1[12]:22;
		//modif start
			writableSheet_tFileOutputExcel_1.addCell(new jxl.write.Label(13, nb_line_tFileOutputExcel_1, "NUMERO_VOIE"
			));
		//modif end
		fitWidth_tFileOutputExcel_1[13]=fitWidth_tFileOutputExcel_1[13]>11?fitWidth_tFileOutputExcel_1[13]:11;
		//modif start
			writableSheet_tFileOutputExcel_1.addCell(new jxl.write.Label(14, nb_line_tFileOutputExcel_1, "NOM_VOIE"
			));
		//modif end
		fitWidth_tFileOutputExcel_1[14]=fitWidth_tFileOutputExcel_1[14]>8?fitWidth_tFileOutputExcel_1[14]:8;
		//modif start
			writableSheet_tFileOutputExcel_1.addCell(new jxl.write.Label(15, nb_line_tFileOutputExcel_1, "CODE_POSTAL"
			));
		//modif end
		fitWidth_tFileOutputExcel_1[15]=fitWidth_tFileOutputExcel_1[15]>11?fitWidth_tFileOutputExcel_1[15]:11;
		//modif start
			writableSheet_tFileOutputExcel_1.addCell(new jxl.write.Label(16, nb_line_tFileOutputExcel_1, "NOM_VILLE"
			));
		//modif end
		fitWidth_tFileOutputExcel_1[16]=fitWidth_tFileOutputExcel_1[16]>9?fitWidth_tFileOutputExcel_1[16]:9;
		//modif start
			writableSheet_tFileOutputExcel_1.addCell(new jxl.write.Label(17, nb_line_tFileOutputExcel_1, "LONGITUDE"
			));
		//modif end
		fitWidth_tFileOutputExcel_1[17]=fitWidth_tFileOutputExcel_1[17]>9?fitWidth_tFileOutputExcel_1[17]:9;
		//modif start
			writableSheet_tFileOutputExcel_1.addCell(new jxl.write.Label(18, nb_line_tFileOutputExcel_1, "LATITUDE"
			));
		//modif end
		fitWidth_tFileOutputExcel_1[18]=fitWidth_tFileOutputExcel_1[18]>8?fitWidth_tFileOutputExcel_1[18]:8;
		//modif start
			writableSheet_tFileOutputExcel_1.addCell(new jxl.write.Label(19, nb_line_tFileOutputExcel_1, "ID_ADRESSE_RESTAURANT"
			));
		//modif end
		fitWidth_tFileOutputExcel_1[19]=fitWidth_tFileOutputExcel_1[19]>21?fitWidth_tFileOutputExcel_1[19]:21;
		//modif start
			writableSheet_tFileOutputExcel_1.addCell(new jxl.write.Label(20, nb_line_tFileOutputExcel_1, "ADRESSE_RESTAURANT"
			));
		//modif end
		fitWidth_tFileOutputExcel_1[20]=fitWidth_tFileOutputExcel_1[20]>18?fitWidth_tFileOutputExcel_1[20]:18;
		//modif start
			writableSheet_tFileOutputExcel_1.addCell(new jxl.write.Label(21, nb_line_tFileOutputExcel_1, "ID_CLIENT"
			));
		//modif end
		fitWidth_tFileOutputExcel_1[21]=fitWidth_tFileOutputExcel_1[21]>9?fitWidth_tFileOutputExcel_1[21]:9;
		//modif start
			writableSheet_tFileOutputExcel_1.addCell(new jxl.write.Label(22, nb_line_tFileOutputExcel_1, "ID_ADRESSE_CLIENT"
			));
		//modif end
		fitWidth_tFileOutputExcel_1[22]=fitWidth_tFileOutputExcel_1[22]>17?fitWidth_tFileOutputExcel_1[22]:17;
		//modif start
			writableSheet_tFileOutputExcel_1.addCell(new jxl.write.Label(23, nb_line_tFileOutputExcel_1, "ADRESSE_CLIENT"
			));
		//modif end
		fitWidth_tFileOutputExcel_1[23]=fitWidth_tFileOutputExcel_1[23]>14?fitWidth_tFileOutputExcel_1[23]:14;
		//modif start
			writableSheet_tFileOutputExcel_1.addCell(new jxl.write.Label(24, nb_line_tFileOutputExcel_1, "ID_RESTAURANT"
			));
		//modif end
		fitWidth_tFileOutputExcel_1[24]=fitWidth_tFileOutputExcel_1[24]>13?fitWidth_tFileOutputExcel_1[24]:13;
		//modif start
			writableSheet_tFileOutputExcel_1.addCell(new jxl.write.Label(25, nb_line_tFileOutputExcel_1, "CODE_RESTAURANT"
			));
		//modif end
		fitWidth_tFileOutputExcel_1[25]=fitWidth_tFileOutputExcel_1[25]>15?fitWidth_tFileOutputExcel_1[25]:15;
		//modif start
			writableSheet_tFileOutputExcel_1.addCell(new jxl.write.Label(26, nb_line_tFileOutputExcel_1, "RAISON_SOCIALE_RESTAURANT"
			));
		//modif end
		fitWidth_tFileOutputExcel_1[26]=fitWidth_tFileOutputExcel_1[26]>25?fitWidth_tFileOutputExcel_1[26]:25;
		//modif start
			writableSheet_tFileOutputExcel_1.addCell(new jxl.write.Label(27, nb_line_tFileOutputExcel_1, "ID_ADRESSE_NORM_RESTAURANT"
			));
		//modif end
		fitWidth_tFileOutputExcel_1[27]=fitWidth_tFileOutputExcel_1[27]>26?fitWidth_tFileOutputExcel_1[27]:26;
		//modif start
			writableSheet_tFileOutputExcel_1.addCell(new jxl.write.Label(28, nb_line_tFileOutputExcel_1, "ID_MOYEN_PAIEMENT"
			));
		//modif end
		fitWidth_tFileOutputExcel_1[28]=fitWidth_tFileOutputExcel_1[28]>17?fitWidth_tFileOutputExcel_1[28]:17;
		//modif start
			writableSheet_tFileOutputExcel_1.addCell(new jxl.write.Label(29, nb_line_tFileOutputExcel_1, "CODE_MOYEN_PAIEMENT"
			));
		//modif end
		fitWidth_tFileOutputExcel_1[29]=fitWidth_tFileOutputExcel_1[29]>19?fitWidth_tFileOutputExcel_1[29]:19;
		//modif start
			writableSheet_tFileOutputExcel_1.addCell(new jxl.write.Label(30, nb_line_tFileOutputExcel_1, "LIVELLE_MOYEN_PAIEMENT"
			));
		//modif end
		fitWidth_tFileOutputExcel_1[30]=fitWidth_tFileOutputExcel_1[30]>22?fitWidth_tFileOutputExcel_1[30]:22;
		//modif start
			writableSheet_tFileOutputExcel_1.addCell(new jxl.write.Label(31, nb_line_tFileOutputExcel_1, "NOM_CLIENT"
			));
		//modif end
		fitWidth_tFileOutputExcel_1[31]=fitWidth_tFileOutputExcel_1[31]>10?fitWidth_tFileOutputExcel_1[31]:10;
		//modif start
			writableSheet_tFileOutputExcel_1.addCell(new jxl.write.Label(32, nb_line_tFileOutputExcel_1, "PRENOM_CLIENT"
			));
		//modif end
		fitWidth_tFileOutputExcel_1[32]=fitWidth_tFileOutputExcel_1[32]>13?fitWidth_tFileOutputExcel_1[32]:13;
		//modif start
			writableSheet_tFileOutputExcel_1.addCell(new jxl.write.Label(33, nb_line_tFileOutputExcel_1, "LATITUDE_RESTAU"
			));
		//modif end
		fitWidth_tFileOutputExcel_1[33]=fitWidth_tFileOutputExcel_1[33]>15?fitWidth_tFileOutputExcel_1[33]:15;
		//modif start
			writableSheet_tFileOutputExcel_1.addCell(new jxl.write.Label(34, nb_line_tFileOutputExcel_1, "LONGITUDE_RESTAU"
			));
		//modif end
		fitWidth_tFileOutputExcel_1[34]=fitWidth_tFileOutputExcel_1[34]>16?fitWidth_tFileOutputExcel_1[34]:16;
		//modif start
			writableSheet_tFileOutputExcel_1.addCell(new jxl.write.Label(35, nb_line_tFileOutputExcel_1, "NOM_VILLE_RESTAU"
			));
		//modif end
		fitWidth_tFileOutputExcel_1[35]=fitWidth_tFileOutputExcel_1[35]>16?fitWidth_tFileOutputExcel_1[35]:16;
		//modif start
			writableSheet_tFileOutputExcel_1.addCell(new jxl.write.Label(36, nb_line_tFileOutputExcel_1, "CODE_POSTAL_RESTAU"
			));
		//modif end
		fitWidth_tFileOutputExcel_1[36]=fitWidth_tFileOutputExcel_1[36]>18?fitWidth_tFileOutputExcel_1[36]:18;
		//modif start
			writableSheet_tFileOutputExcel_1.addCell(new jxl.write.Label(37, nb_line_tFileOutputExcel_1, "NOM_VOIE_RESTAU"
			));
		//modif end
		fitWidth_tFileOutputExcel_1[37]=fitWidth_tFileOutputExcel_1[37]>15?fitWidth_tFileOutputExcel_1[37]:15;
		//modif start
			writableSheet_tFileOutputExcel_1.addCell(new jxl.write.Label(38, nb_line_tFileOutputExcel_1, "NUMERO_VOIE_RESTAU"
			));
		//modif end
		fitWidth_tFileOutputExcel_1[38]=fitWidth_tFileOutputExcel_1[38]>18?fitWidth_tFileOutputExcel_1[38]:18;
		nb_line_tFileOutputExcel_1 ++;
		headerIsInserted_tFileOutputExcel_1 = true;
	}


 



/**
 * [tFileOutputExcel_1 begin ] stop
 */



	
	/**
	 * [tDBInput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBInput_1", false);
		start_Hash.put("tDBInput_1", System.currentTimeMillis());
		
				tStatCatcher_1.addMessage("begin","tDBInput_1");
				tStatCatcher_1Process(globalMap);
			
	
	currentComponent="tDBInput_1";

	
		int tos_count_tDBInput_1 = 0;
		
	


	
		    int nb_line_tDBInput_1 = 0;
		    java.sql.Connection conn_tDBInput_1 = null;
				String driverClass_tDBInput_1 = "oracle.jdbc.OracleDriver";
				java.lang.Class.forName(driverClass_tDBInput_1);
				
			String url_tDBInput_1 = null;
				url_tDBInput_1 = "jdbc:oracle:thin:@(description=(address=(protocol=tcp)(host=" + "" + ")(port=" + "1521" + "))(connect_data=(service_name=" + "XEPDB1" + ")))";

				String dbUser_tDBInput_1 = "DSID_LIV_OPE";

				

				 
	final String decryptedPassword_tDBInput_1 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:wUU0IkB4BP6c4zVKF7ggCO33FmDTUOtUlsHn56hls2w=");

				String dbPwd_tDBInput_1 = decryptedPassword_tDBInput_1;

				
					conn_tDBInput_1 = java.sql.DriverManager.getConnection(url_tDBInput_1,dbUser_tDBInput_1,dbPwd_tDBInput_1);
				java.sql.Statement stmtGetTZ_tDBInput_1 = conn_tDBInput_1.createStatement();
				java.sql.ResultSet rsGetTZ_tDBInput_1 = stmtGetTZ_tDBInput_1.executeQuery("select sessiontimezone from dual");
				String sessionTimezone_tDBInput_1 = java.util.TimeZone.getDefault().getID();
				while (rsGetTZ_tDBInput_1.next()) {
					sessionTimezone_tDBInput_1 = rsGetTZ_tDBInput_1.getString(1);
				}
                                if (!(conn_tDBInput_1 instanceof oracle.jdbc.OracleConnection) &&
                                        conn_tDBInput_1.isWrapperFor(oracle.jdbc.OracleConnection.class)) {
                                    if (conn_tDBInput_1.unwrap(oracle.jdbc.OracleConnection.class) != null) {
                                        ((oracle.jdbc.OracleConnection)conn_tDBInput_1.unwrap(oracle.jdbc.OracleConnection.class)).setSessionTimeZone(sessionTimezone_tDBInput_1);
                                    }
                                } else {
                                    ((oracle.jdbc.OracleConnection)conn_tDBInput_1).setSessionTimeZone(sessionTimezone_tDBInput_1);
                                }
		    
			java.sql.Statement stmt_tDBInput_1 = conn_tDBInput_1.createStatement();

		    String dbquery_tDBInput_1 = "SELECT \n  DSID_LIV_OPE.VUE_DM1.ID_COMMANDE, \n  DSID_LIV_OPE.VUE_DM1.NUMERO_COMMANDE, \n  DSID_LIV_OPE.VUE_DM1.DATE_COMMA"
+"NDE, \n  DSID_LIV_OPE.VUE_DM1.MONTANT_TOTAL, \n  DSID_LIV_OPE.VUE_DM1.ID_MENU, \n  DSID_LIV_OPE.VUE_DM1.CODE_MENU, \n  DSID_"
+"LIV_OPE.VUE_DM1.LIBELLE_MENU, \n  DSID_LIV_OPE.VUE_DM1.NOMBRE_ARTICLES, \n  DSID_LIV_OPE.VUE_DM1.TEMPS_THEO_PREPARATION, \n"
+"  DSID_LIV_OPE.VUE_DM1.ID_PREPARATION, \n  DSID_LIV_OPE.VUE_DM1.DATE_DEBUT_PREPARATION, \n  DSID_LIV_OPE.VUE_DM1.DATE_FIN_"
+"PREPARATION, \n  DSID_LIV_OPE.VUE_DM1.ID_ADRESSE_NORM_CLIENT, \n  DSID_LIV_OPE.VUE_DM1.NUMERO_VOIE, \n  DSID_LIV_OPE.VUE_DM"
+"1.NOM_VOIE, \n  DSID_LIV_OPE.VUE_DM1.CODE_POSTAL, \n  DSID_LIV_OPE.VUE_DM1.NOM_VILLE, \n  DSID_LIV_OPE.VUE_DM1.LONGITUDE, \n"
+"  DSID_LIV_OPE.VUE_DM1.LATITUDE, \n  DSID_LIV_OPE.VUE_DM1.ID_ADRESSE_RESTAURANT, \n  DSID_LIV_OPE.VUE_DM1.ADRESSE_RESTAURA"
+"NT, \n  DSID_LIV_OPE.VUE_DM1.ID_CLIENT, \n  DSID_LIV_OPE.VUE_DM1.ID_ADRESSE_CLIENT, \n  DSID_LIV_OPE.VUE_DM1.ADRESSE_CLIENT"
+", \n  DSID_LIV_OPE.VUE_DM1.ID_RESTAURANT, \n  DSID_LIV_OPE.VUE_DM1.CODE_RESTAURANT, \n  DSID_LIV_OPE.VUE_DM1.RAISON_SOCIALE"
+"_RESTAURANT, \n  DSID_LIV_OPE.VUE_DM1.ID_ADRESSE_NORM_RESTAURANT, \n  DSID_LIV_OPE.VUE_DM1.ID_MOYEN_PAIEMENT, \n  DSID_LIV_"
+"OPE.VUE_DM1.CODE_MOYEN_PAIEMENT, \n  DSID_LIV_OPE.VUE_DM1.LIVELLE_MOYEN_PAIEMENT, \n  DSID_LIV_OPE.VUE_DM1.NOM_CLIENT, \n  "
+"DSID_LIV_OPE.VUE_DM1.PRENOM_CLIENT, \n  DSID_LIV_OPE.VUE_DM1.LATITUDE_RESTAU, \n  DSID_LIV_OPE.VUE_DM1.LONGITUDE_RESTAU, \n"
+"  DSID_LIV_OPE.VUE_DM1.NOM_VILLE_RESTAU, \n  DSID_LIV_OPE.VUE_DM1.CODE_POSTAL_RESTAU, \n  DSID_LIV_OPE.VUE_DM1.NOM_VOIE_RE"
+"STAU, \n  DSID_LIV_OPE.VUE_DM1.NUMERO_VOIE_RESTAU\nFROM DSID_LIV_OPE.VUE_DM1";
		    

            	globalMap.put("tDBInput_1_QUERY",dbquery_tDBInput_1);
		    java.sql.ResultSet rs_tDBInput_1 = null;

		    try {
		    	rs_tDBInput_1 = stmt_tDBInput_1.executeQuery(dbquery_tDBInput_1);
		    	java.sql.ResultSetMetaData rsmd_tDBInput_1 = rs_tDBInput_1.getMetaData();
		    	int colQtyInRs_tDBInput_1 = rsmd_tDBInput_1.getColumnCount();

		    String tmpContent_tDBInput_1 = null;
		    
		    
		    while (rs_tDBInput_1.next()) {
		        nb_line_tDBInput_1++;
		        
							if(colQtyInRs_tDBInput_1 < 1) {
								row2.ID_COMMANDE = null;
							} else {
		                          
					if(rs_tDBInput_1.getObject(1) != null) {
						row2.ID_COMMANDE = rs_tDBInput_1.getBigDecimal(1);
					} else {
				
 	                	throw new RuntimeException("Null value in non-Nullable column");
					}
		                    }
							if(colQtyInRs_tDBInput_1 < 2) {
								row2.NUMERO_COMMANDE = null;
							} else {
		                          
					if(rs_tDBInput_1.getObject(2) != null) {
						row2.NUMERO_COMMANDE = rs_tDBInput_1.getBigDecimal(2);
					} else {
				
						row2.NUMERO_COMMANDE = null;
					}
		                    }
							if(colQtyInRs_tDBInput_1 < 3) {
								row2.DATE_COMMANDE = null;
							} else {
										
			row2.DATE_COMMANDE = routines.system.JDBCUtil.getDate(rs_tDBInput_1, 3);
		                    }
							if(colQtyInRs_tDBInput_1 < 4) {
								row2.MONTANT_TOTAL = null;
							} else {
		                          
					if(rs_tDBInput_1.getObject(4) != null) {
						row2.MONTANT_TOTAL = rs_tDBInput_1.getFloat(4);
					} else {
				
						row2.MONTANT_TOTAL = null;
					}
		                    }
							if(colQtyInRs_tDBInput_1 < 5) {
								row2.ID_MENU = null;
							} else {
		                          
					if(rs_tDBInput_1.getObject(5) != null) {
						row2.ID_MENU = rs_tDBInput_1.getBigDecimal(5);
					} else {
				
 	                	throw new RuntimeException("Null value in non-Nullable column");
					}
		                    }
							if(colQtyInRs_tDBInput_1 < 6) {
								row2.CODE_MENU = null;
							} else {
	                         		
        	row2.CODE_MENU = routines.system.JDBCUtil.getString(rs_tDBInput_1, 6, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 7) {
								row2.LIBELLE_MENU = null;
							} else {
	                         		
        	row2.LIBELLE_MENU = routines.system.JDBCUtil.getString(rs_tDBInput_1, 7, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 8) {
								row2.NOMBRE_ARTICLES = null;
							} else {
		                          
					if(rs_tDBInput_1.getObject(8) != null) {
						row2.NOMBRE_ARTICLES = rs_tDBInput_1.getBigDecimal(8);
					} else {
				
						row2.NOMBRE_ARTICLES = null;
					}
		                    }
							if(colQtyInRs_tDBInput_1 < 9) {
								row2.TEMPS_THEO_PREPARATION = null;
							} else {
	                         		
        	row2.TEMPS_THEO_PREPARATION = routines.system.JDBCUtil.getString(rs_tDBInput_1, 9, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 10) {
								row2.ID_PREPARATION = null;
							} else {
		                          
					if(rs_tDBInput_1.getObject(10) != null) {
						row2.ID_PREPARATION = rs_tDBInput_1.getBigDecimal(10);
					} else {
				
 	                	throw new RuntimeException("Null value in non-Nullable column");
					}
		                    }
							if(colQtyInRs_tDBInput_1 < 11) {
								row2.DATE_DEBUT_PREPARATION = null;
							} else {
										
			row2.DATE_DEBUT_PREPARATION = routines.system.JDBCUtil.getDate(rs_tDBInput_1, 11);
		                    }
							if(colQtyInRs_tDBInput_1 < 12) {
								row2.DATE_FIN_PREPARATION = null;
							} else {
										
			row2.DATE_FIN_PREPARATION = routines.system.JDBCUtil.getDate(rs_tDBInput_1, 12);
		                    }
							if(colQtyInRs_tDBInput_1 < 13) {
								row2.ID_ADRESSE_NORM_CLIENT = null;
							} else {
		                          
					if(rs_tDBInput_1.getObject(13) != null) {
						row2.ID_ADRESSE_NORM_CLIENT = rs_tDBInput_1.getBigDecimal(13);
					} else {
				
 	                	throw new RuntimeException("Null value in non-Nullable column");
					}
		                    }
							if(colQtyInRs_tDBInput_1 < 14) {
								row2.NUMERO_VOIE = null;
							} else {
	                         		
        	row2.NUMERO_VOIE = routines.system.JDBCUtil.getString(rs_tDBInput_1, 14, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 15) {
								row2.NOM_VOIE = null;
							} else {
	                         		
        	row2.NOM_VOIE = routines.system.JDBCUtil.getString(rs_tDBInput_1, 15, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 16) {
								row2.CODE_POSTAL = null;
							} else {
		                          
					if(rs_tDBInput_1.getObject(16) != null) {
						row2.CODE_POSTAL = rs_tDBInput_1.getBigDecimal(16);
					} else {
				
 	                	throw new RuntimeException("Null value in non-Nullable column");
					}
		                    }
							if(colQtyInRs_tDBInput_1 < 17) {
								row2.NOM_VILLE = null;
							} else {
	                         		
        	row2.NOM_VILLE = routines.system.JDBCUtil.getString(rs_tDBInput_1, 17, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 18) {
								row2.LONGITUDE = null;
							} else {
	                         		
        	row2.LONGITUDE = routines.system.JDBCUtil.getString(rs_tDBInput_1, 18, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 19) {
								row2.LATITUDE = null;
							} else {
	                         		
        	row2.LATITUDE = routines.system.JDBCUtil.getString(rs_tDBInput_1, 19, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 20) {
								row2.ID_ADRESSE_RESTAURANT = null;
							} else {
	                         		
        	row2.ID_ADRESSE_RESTAURANT = routines.system.JDBCUtil.getString(rs_tDBInput_1, 20, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 21) {
								row2.ADRESSE_RESTAURANT = null;
							} else {
	                         		
        	row2.ADRESSE_RESTAURANT = routines.system.JDBCUtil.getString(rs_tDBInput_1, 21, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 22) {
								row2.ID_CLIENT = null;
							} else {
	                         		
        	row2.ID_CLIENT = routines.system.JDBCUtil.getString(rs_tDBInput_1, 22, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 23) {
								row2.ID_ADRESSE_CLIENT = null;
							} else {
		                          
					if(rs_tDBInput_1.getObject(23) != null) {
						row2.ID_ADRESSE_CLIENT = rs_tDBInput_1.getBigDecimal(23);
					} else {
				
 	                	throw new RuntimeException("Null value in non-Nullable column");
					}
		                    }
							if(colQtyInRs_tDBInput_1 < 24) {
								row2.ADRESSE_CLIENT = null;
							} else {
	                         		
        	row2.ADRESSE_CLIENT = routines.system.JDBCUtil.getString(rs_tDBInput_1, 24, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 25) {
								row2.ID_RESTAURANT = null;
							} else {
		                          
					if(rs_tDBInput_1.getObject(25) != null) {
						row2.ID_RESTAURANT = rs_tDBInput_1.getBigDecimal(25);
					} else {
				
 	                	throw new RuntimeException("Null value in non-Nullable column");
					}
		                    }
							if(colQtyInRs_tDBInput_1 < 26) {
								row2.CODE_RESTAURANT = null;
							} else {
	                         		
        	row2.CODE_RESTAURANT = routines.system.JDBCUtil.getString(rs_tDBInput_1, 26, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 27) {
								row2.RAISON_SOCIALE_RESTAURANT = null;
							} else {
	                         		
        	row2.RAISON_SOCIALE_RESTAURANT = routines.system.JDBCUtil.getString(rs_tDBInput_1, 27, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 28) {
								row2.ID_ADRESSE_NORM_RESTAURANT = null;
							} else {
		                          
					if(rs_tDBInput_1.getObject(28) != null) {
						row2.ID_ADRESSE_NORM_RESTAURANT = rs_tDBInput_1.getBigDecimal(28);
					} else {
				
 	                	throw new RuntimeException("Null value in non-Nullable column");
					}
		                    }
							if(colQtyInRs_tDBInput_1 < 29) {
								row2.ID_MOYEN_PAIEMENT = null;
							} else {
	                         		
        	row2.ID_MOYEN_PAIEMENT = routines.system.JDBCUtil.getString(rs_tDBInput_1, 29, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 30) {
								row2.CODE_MOYEN_PAIEMENT = null;
							} else {
	                         		
        	row2.CODE_MOYEN_PAIEMENT = routines.system.JDBCUtil.getString(rs_tDBInput_1, 30, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 31) {
								row2.LIVELLE_MOYEN_PAIEMENT = null;
							} else {
	                         		
        	row2.LIVELLE_MOYEN_PAIEMENT = routines.system.JDBCUtil.getString(rs_tDBInput_1, 31, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 32) {
								row2.NOM_CLIENT = null;
							} else {
	                         		
        	row2.NOM_CLIENT = routines.system.JDBCUtil.getString(rs_tDBInput_1, 32, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 33) {
								row2.PRENOM_CLIENT = null;
							} else {
	                         		
        	row2.PRENOM_CLIENT = routines.system.JDBCUtil.getString(rs_tDBInput_1, 33, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 34) {
								row2.LATITUDE_RESTAU = null;
							} else {
	                         		
        	row2.LATITUDE_RESTAU = routines.system.JDBCUtil.getString(rs_tDBInput_1, 34, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 35) {
								row2.LONGITUDE_RESTAU = null;
							} else {
		                          
					if(rs_tDBInput_1.getObject(35) != null) {
						row2.LONGITUDE_RESTAU = rs_tDBInput_1.getBigDecimal(35);
					} else {
				
 	                	throw new RuntimeException("Null value in non-Nullable column");
					}
		                    }
							if(colQtyInRs_tDBInput_1 < 36) {
								row2.NOM_VILLE_RESTAU = null;
							} else {
	                         		
        	row2.NOM_VILLE_RESTAU = routines.system.JDBCUtil.getString(rs_tDBInput_1, 36, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 37) {
								row2.CODE_POSTAL_RESTAU = null;
							} else {
		                          
					if(rs_tDBInput_1.getObject(37) != null) {
						row2.CODE_POSTAL_RESTAU = rs_tDBInput_1.getBigDecimal(37);
					} else {
				
 	                	throw new RuntimeException("Null value in non-Nullable column");
					}
		                    }
							if(colQtyInRs_tDBInput_1 < 38) {
								row2.NOM_VOIE_RESTAU = null;
							} else {
	                         		
        	row2.NOM_VOIE_RESTAU = routines.system.JDBCUtil.getString(rs_tDBInput_1, 38, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 39) {
								row2.NUMERO_VOIE_RESTAU = null;
							} else {
	                         		
        	row2.NUMERO_VOIE_RESTAU = routines.system.JDBCUtil.getString(rs_tDBInput_1, 39, false);
		                    }
					




 



/**
 * [tDBInput_1 begin ] stop
 */
	
	/**
	 * [tDBInput_1 main ] start
	 */

	

	
	
	currentComponent="tDBInput_1";

	

 


	tos_count_tDBInput_1++;

/**
 * [tDBInput_1 main ] stop
 */
	
	/**
	 * [tDBInput_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBInput_1";

	

 



/**
 * [tDBInput_1 process_data_begin ] stop
 */

	
	/**
	 * [tFileOutputExcel_1 main ] start
	 */

	

	
	
	currentComponent="tFileOutputExcel_1";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row2"
						
						);
					}
					

								   				
	    				if(row2.ID_COMMANDE != null) {
    				
					
//modif start
					
						columnIndex_tFileOutputExcel_1 = 0;
					

					
						jxl.write.WritableCell cell_0_tFileOutputExcel_1 = new jxl.write.Label(columnIndex_tFileOutputExcel_1, startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,
					
//modif end
							
							FormatterUtils.format_Number(String.valueOf(row2.ID_COMMANDE), ' ', '.')				
							
							);
//modif start					
							//If we keep the cell format from the existing cell in sheet
							
							
//modif ends							
							writableSheet_tFileOutputExcel_1.addCell(cell_0_tFileOutputExcel_1);
							int currentWith_0_tFileOutputExcel_1 = cell_0_tFileOutputExcel_1.getContents().trim().length();
							fitWidth_tFileOutputExcel_1[0]=fitWidth_tFileOutputExcel_1[0]>currentWith_0_tFileOutputExcel_1?fitWidth_tFileOutputExcel_1[0]:currentWith_0_tFileOutputExcel_1+2;
	    				} 
					
								   				
	    				if(row2.NUMERO_COMMANDE != null) {
    				
					
//modif start
					
						columnIndex_tFileOutputExcel_1 = 1;
					

					
						jxl.write.WritableCell cell_1_tFileOutputExcel_1 = new jxl.write.Label(columnIndex_tFileOutputExcel_1, startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,
					
//modif end
							
							FormatterUtils.format_Number(String.valueOf(row2.NUMERO_COMMANDE), ' ', '.')				
							
							);
//modif start					
							//If we keep the cell format from the existing cell in sheet
							
							
//modif ends							
							writableSheet_tFileOutputExcel_1.addCell(cell_1_tFileOutputExcel_1);
							int currentWith_1_tFileOutputExcel_1 = cell_1_tFileOutputExcel_1.getContents().trim().length();
							fitWidth_tFileOutputExcel_1[1]=fitWidth_tFileOutputExcel_1[1]>currentWith_1_tFileOutputExcel_1?fitWidth_tFileOutputExcel_1[1]:currentWith_1_tFileOutputExcel_1+2;
	    				} 
					
								   				
	    				if(row2.DATE_COMMANDE != null) {
    				
					
//modif start
					
						columnIndex_tFileOutputExcel_1 = 2;
					

					
						jxl.write.WritableCell cell_2_tFileOutputExcel_1 = new jxl.write.DateTime(columnIndex_tFileOutputExcel_1, startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,
					
//modif end
								row2.DATE_COMMANDE, cell_format_DATE_COMMANDE_tFileOutputExcel_1
							);
//modif start					
							//If we keep the cell format from the existing cell in sheet
							
							
//modif ends							
							writableSheet_tFileOutputExcel_1.addCell(cell_2_tFileOutputExcel_1);
							int currentWith_2_tFileOutputExcel_1 = cell_2_tFileOutputExcel_1.getContents().trim().length();
							currentWith_2_tFileOutputExcel_1=12;
							fitWidth_tFileOutputExcel_1[2]=fitWidth_tFileOutputExcel_1[2]>currentWith_2_tFileOutputExcel_1?fitWidth_tFileOutputExcel_1[2]:currentWith_2_tFileOutputExcel_1+2;
	    				} 
					
								   				
	    				if(row2.MONTANT_TOTAL != null) {
    				
					
//modif start
					
						columnIndex_tFileOutputExcel_1 = 3;
					

					
						jxl.write.WritableCell cell_3_tFileOutputExcel_1 = new jxl.write.Label(columnIndex_tFileOutputExcel_1, startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,
					
//modif end
							
							FormatterUtils.format_Number(String.valueOf(row2.MONTANT_TOTAL), ' ', '.')				
							
							);
//modif start					
							//If we keep the cell format from the existing cell in sheet
							
							
//modif ends							
							writableSheet_tFileOutputExcel_1.addCell(cell_3_tFileOutputExcel_1);
							int currentWith_3_tFileOutputExcel_1 = cell_3_tFileOutputExcel_1.getContents().trim().length();
							fitWidth_tFileOutputExcel_1[3]=fitWidth_tFileOutputExcel_1[3]>currentWith_3_tFileOutputExcel_1?fitWidth_tFileOutputExcel_1[3]:currentWith_3_tFileOutputExcel_1+2;
	    				} 
					
								   				
	    				if(row2.ID_MENU != null) {
    				
					
//modif start
					
						columnIndex_tFileOutputExcel_1 = 4;
					

					
						jxl.write.WritableCell cell_4_tFileOutputExcel_1 = new jxl.write.Label(columnIndex_tFileOutputExcel_1, startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,
					
//modif end
							
							FormatterUtils.format_Number(String.valueOf(row2.ID_MENU), ' ', '.')				
							
							);
//modif start					
							//If we keep the cell format from the existing cell in sheet
							
							
//modif ends							
							writableSheet_tFileOutputExcel_1.addCell(cell_4_tFileOutputExcel_1);
							int currentWith_4_tFileOutputExcel_1 = cell_4_tFileOutputExcel_1.getContents().trim().length();
							fitWidth_tFileOutputExcel_1[4]=fitWidth_tFileOutputExcel_1[4]>currentWith_4_tFileOutputExcel_1?fitWidth_tFileOutputExcel_1[4]:currentWith_4_tFileOutputExcel_1+2;
	    				} 
					
								   				
	    				if(row2.CODE_MENU != null) {
    				
					
//modif start
					
						columnIndex_tFileOutputExcel_1 = 5;
					

					
						jxl.write.WritableCell cell_5_tFileOutputExcel_1 = new jxl.write.Label(columnIndex_tFileOutputExcel_1, startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,
					
//modif end
								row2.CODE_MENU
							);
//modif start					
							//If we keep the cell format from the existing cell in sheet
							
							
//modif ends							
							writableSheet_tFileOutputExcel_1.addCell(cell_5_tFileOutputExcel_1);
							int currentWith_5_tFileOutputExcel_1 = cell_5_tFileOutputExcel_1.getContents().trim().length();
							fitWidth_tFileOutputExcel_1[5]=fitWidth_tFileOutputExcel_1[5]>currentWith_5_tFileOutputExcel_1?fitWidth_tFileOutputExcel_1[5]:currentWith_5_tFileOutputExcel_1+2;
	    				} 
					
								   				
	    				if(row2.LIBELLE_MENU != null) {
    				
					
//modif start
					
						columnIndex_tFileOutputExcel_1 = 6;
					

					
						jxl.write.WritableCell cell_6_tFileOutputExcel_1 = new jxl.write.Label(columnIndex_tFileOutputExcel_1, startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,
					
//modif end
								row2.LIBELLE_MENU
							);
//modif start					
							//If we keep the cell format from the existing cell in sheet
							
							
//modif ends							
							writableSheet_tFileOutputExcel_1.addCell(cell_6_tFileOutputExcel_1);
							int currentWith_6_tFileOutputExcel_1 = cell_6_tFileOutputExcel_1.getContents().trim().length();
							fitWidth_tFileOutputExcel_1[6]=fitWidth_tFileOutputExcel_1[6]>currentWith_6_tFileOutputExcel_1?fitWidth_tFileOutputExcel_1[6]:currentWith_6_tFileOutputExcel_1+2;
	    				} 
					
								   				
	    				if(row2.NOMBRE_ARTICLES != null) {
    				
					
//modif start
					
						columnIndex_tFileOutputExcel_1 = 7;
					

					
						jxl.write.WritableCell cell_7_tFileOutputExcel_1 = new jxl.write.Label(columnIndex_tFileOutputExcel_1, startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,
					
//modif end
							
							FormatterUtils.format_Number(String.valueOf(row2.NOMBRE_ARTICLES), ' ', '.')				
							
							);
//modif start					
							//If we keep the cell format from the existing cell in sheet
							
							
//modif ends							
							writableSheet_tFileOutputExcel_1.addCell(cell_7_tFileOutputExcel_1);
							int currentWith_7_tFileOutputExcel_1 = cell_7_tFileOutputExcel_1.getContents().trim().length();
							fitWidth_tFileOutputExcel_1[7]=fitWidth_tFileOutputExcel_1[7]>currentWith_7_tFileOutputExcel_1?fitWidth_tFileOutputExcel_1[7]:currentWith_7_tFileOutputExcel_1+2;
	    				} 
					
								   				
	    				if(row2.TEMPS_THEO_PREPARATION != null) {
    				
					
//modif start
					
						columnIndex_tFileOutputExcel_1 = 8;
					

					
						jxl.write.WritableCell cell_8_tFileOutputExcel_1 = new jxl.write.Label(columnIndex_tFileOutputExcel_1, startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,
					
//modif end
								row2.TEMPS_THEO_PREPARATION
							);
//modif start					
							//If we keep the cell format from the existing cell in sheet
							
							
//modif ends							
							writableSheet_tFileOutputExcel_1.addCell(cell_8_tFileOutputExcel_1);
							int currentWith_8_tFileOutputExcel_1 = cell_8_tFileOutputExcel_1.getContents().trim().length();
							fitWidth_tFileOutputExcel_1[8]=fitWidth_tFileOutputExcel_1[8]>currentWith_8_tFileOutputExcel_1?fitWidth_tFileOutputExcel_1[8]:currentWith_8_tFileOutputExcel_1+2;
	    				} 
					
								   				
	    				if(row2.ID_PREPARATION != null) {
    				
					
//modif start
					
						columnIndex_tFileOutputExcel_1 = 9;
					

					
						jxl.write.WritableCell cell_9_tFileOutputExcel_1 = new jxl.write.Label(columnIndex_tFileOutputExcel_1, startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,
					
//modif end
							
							FormatterUtils.format_Number(String.valueOf(row2.ID_PREPARATION), ' ', '.')				
							
							);
//modif start					
							//If we keep the cell format from the existing cell in sheet
							
							
//modif ends							
							writableSheet_tFileOutputExcel_1.addCell(cell_9_tFileOutputExcel_1);
							int currentWith_9_tFileOutputExcel_1 = cell_9_tFileOutputExcel_1.getContents().trim().length();
							fitWidth_tFileOutputExcel_1[9]=fitWidth_tFileOutputExcel_1[9]>currentWith_9_tFileOutputExcel_1?fitWidth_tFileOutputExcel_1[9]:currentWith_9_tFileOutputExcel_1+2;
	    				} 
					
								   				
	    				if(row2.DATE_DEBUT_PREPARATION != null) {
    				
					
//modif start
					
						columnIndex_tFileOutputExcel_1 = 10;
					

					
						jxl.write.WritableCell cell_10_tFileOutputExcel_1 = new jxl.write.DateTime(columnIndex_tFileOutputExcel_1, startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,
					
//modif end
								row2.DATE_DEBUT_PREPARATION, cell_format_DATE_DEBUT_PREPARATION_tFileOutputExcel_1
							);
//modif start					
							//If we keep the cell format from the existing cell in sheet
							
							
//modif ends							
							writableSheet_tFileOutputExcel_1.addCell(cell_10_tFileOutputExcel_1);
							int currentWith_10_tFileOutputExcel_1 = cell_10_tFileOutputExcel_1.getContents().trim().length();
							currentWith_10_tFileOutputExcel_1=18;
							fitWidth_tFileOutputExcel_1[10]=fitWidth_tFileOutputExcel_1[10]>currentWith_10_tFileOutputExcel_1?fitWidth_tFileOutputExcel_1[10]:currentWith_10_tFileOutputExcel_1+2;
	    				} 
					
								   				
	    				if(row2.DATE_FIN_PREPARATION != null) {
    				
					
//modif start
					
						columnIndex_tFileOutputExcel_1 = 11;
					

					
						jxl.write.WritableCell cell_11_tFileOutputExcel_1 = new jxl.write.DateTime(columnIndex_tFileOutputExcel_1, startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,
					
//modif end
								row2.DATE_FIN_PREPARATION, cell_format_DATE_FIN_PREPARATION_tFileOutputExcel_1
							);
//modif start					
							//If we keep the cell format from the existing cell in sheet
							
							
//modif ends							
							writableSheet_tFileOutputExcel_1.addCell(cell_11_tFileOutputExcel_1);
							int currentWith_11_tFileOutputExcel_1 = cell_11_tFileOutputExcel_1.getContents().trim().length();
							currentWith_11_tFileOutputExcel_1=18;
							fitWidth_tFileOutputExcel_1[11]=fitWidth_tFileOutputExcel_1[11]>currentWith_11_tFileOutputExcel_1?fitWidth_tFileOutputExcel_1[11]:currentWith_11_tFileOutputExcel_1+2;
	    				} 
					
								   				
	    				if(row2.ID_ADRESSE_NORM_CLIENT != null) {
    				
					
//modif start
					
						columnIndex_tFileOutputExcel_1 = 12;
					

					
						jxl.write.WritableCell cell_12_tFileOutputExcel_1 = new jxl.write.Label(columnIndex_tFileOutputExcel_1, startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,
					
//modif end
							
							FormatterUtils.format_Number(String.valueOf(row2.ID_ADRESSE_NORM_CLIENT), ' ', '.')				
							
							);
//modif start					
							//If we keep the cell format from the existing cell in sheet
							
							
//modif ends							
							writableSheet_tFileOutputExcel_1.addCell(cell_12_tFileOutputExcel_1);
							int currentWith_12_tFileOutputExcel_1 = cell_12_tFileOutputExcel_1.getContents().trim().length();
							fitWidth_tFileOutputExcel_1[12]=fitWidth_tFileOutputExcel_1[12]>currentWith_12_tFileOutputExcel_1?fitWidth_tFileOutputExcel_1[12]:currentWith_12_tFileOutputExcel_1+2;
	    				} 
					
								   				
	    				if(row2.NUMERO_VOIE != null) {
    				
					
//modif start
					
						columnIndex_tFileOutputExcel_1 = 13;
					

					
						jxl.write.WritableCell cell_13_tFileOutputExcel_1 = new jxl.write.Label(columnIndex_tFileOutputExcel_1, startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,
					
//modif end
								row2.NUMERO_VOIE
							);
//modif start					
							//If we keep the cell format from the existing cell in sheet
							
							
//modif ends							
							writableSheet_tFileOutputExcel_1.addCell(cell_13_tFileOutputExcel_1);
							int currentWith_13_tFileOutputExcel_1 = cell_13_tFileOutputExcel_1.getContents().trim().length();
							fitWidth_tFileOutputExcel_1[13]=fitWidth_tFileOutputExcel_1[13]>currentWith_13_tFileOutputExcel_1?fitWidth_tFileOutputExcel_1[13]:currentWith_13_tFileOutputExcel_1+2;
	    				} 
					
								   				
	    				if(row2.NOM_VOIE != null) {
    				
					
//modif start
					
						columnIndex_tFileOutputExcel_1 = 14;
					

					
						jxl.write.WritableCell cell_14_tFileOutputExcel_1 = new jxl.write.Label(columnIndex_tFileOutputExcel_1, startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,
					
//modif end
								row2.NOM_VOIE
							);
//modif start					
							//If we keep the cell format from the existing cell in sheet
							
							
//modif ends							
							writableSheet_tFileOutputExcel_1.addCell(cell_14_tFileOutputExcel_1);
							int currentWith_14_tFileOutputExcel_1 = cell_14_tFileOutputExcel_1.getContents().trim().length();
							fitWidth_tFileOutputExcel_1[14]=fitWidth_tFileOutputExcel_1[14]>currentWith_14_tFileOutputExcel_1?fitWidth_tFileOutputExcel_1[14]:currentWith_14_tFileOutputExcel_1+2;
	    				} 
					
								   				
	    				if(row2.CODE_POSTAL != null) {
    				
					
//modif start
					
						columnIndex_tFileOutputExcel_1 = 15;
					

					
						jxl.write.WritableCell cell_15_tFileOutputExcel_1 = new jxl.write.Label(columnIndex_tFileOutputExcel_1, startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,
					
//modif end
							
							FormatterUtils.format_Number(String.valueOf(row2.CODE_POSTAL), ' ', '.')				
							
							);
//modif start					
							//If we keep the cell format from the existing cell in sheet
							
							
//modif ends							
							writableSheet_tFileOutputExcel_1.addCell(cell_15_tFileOutputExcel_1);
							int currentWith_15_tFileOutputExcel_1 = cell_15_tFileOutputExcel_1.getContents().trim().length();
							fitWidth_tFileOutputExcel_1[15]=fitWidth_tFileOutputExcel_1[15]>currentWith_15_tFileOutputExcel_1?fitWidth_tFileOutputExcel_1[15]:currentWith_15_tFileOutputExcel_1+2;
	    				} 
					
								   				
	    				if(row2.NOM_VILLE != null) {
    				
					
//modif start
					
						columnIndex_tFileOutputExcel_1 = 16;
					

					
						jxl.write.WritableCell cell_16_tFileOutputExcel_1 = new jxl.write.Label(columnIndex_tFileOutputExcel_1, startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,
					
//modif end
								row2.NOM_VILLE
							);
//modif start					
							//If we keep the cell format from the existing cell in sheet
							
							
//modif ends							
							writableSheet_tFileOutputExcel_1.addCell(cell_16_tFileOutputExcel_1);
							int currentWith_16_tFileOutputExcel_1 = cell_16_tFileOutputExcel_1.getContents().trim().length();
							fitWidth_tFileOutputExcel_1[16]=fitWidth_tFileOutputExcel_1[16]>currentWith_16_tFileOutputExcel_1?fitWidth_tFileOutputExcel_1[16]:currentWith_16_tFileOutputExcel_1+2;
	    				} 
					
								   				
	    				if(row2.LONGITUDE != null) {
    				
					
//modif start
					
						columnIndex_tFileOutputExcel_1 = 17;
					

					
						jxl.write.WritableCell cell_17_tFileOutputExcel_1 = new jxl.write.Label(columnIndex_tFileOutputExcel_1, startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,
					
//modif end
								row2.LONGITUDE
							);
//modif start					
							//If we keep the cell format from the existing cell in sheet
							
							
//modif ends							
							writableSheet_tFileOutputExcel_1.addCell(cell_17_tFileOutputExcel_1);
							int currentWith_17_tFileOutputExcel_1 = cell_17_tFileOutputExcel_1.getContents().trim().length();
							fitWidth_tFileOutputExcel_1[17]=fitWidth_tFileOutputExcel_1[17]>currentWith_17_tFileOutputExcel_1?fitWidth_tFileOutputExcel_1[17]:currentWith_17_tFileOutputExcel_1+2;
	    				} 
					
								   				
	    				if(row2.LATITUDE != null) {
    				
					
//modif start
					
						columnIndex_tFileOutputExcel_1 = 18;
					

					
						jxl.write.WritableCell cell_18_tFileOutputExcel_1 = new jxl.write.Label(columnIndex_tFileOutputExcel_1, startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,
					
//modif end
								row2.LATITUDE
							);
//modif start					
							//If we keep the cell format from the existing cell in sheet
							
							
//modif ends							
							writableSheet_tFileOutputExcel_1.addCell(cell_18_tFileOutputExcel_1);
							int currentWith_18_tFileOutputExcel_1 = cell_18_tFileOutputExcel_1.getContents().trim().length();
							fitWidth_tFileOutputExcel_1[18]=fitWidth_tFileOutputExcel_1[18]>currentWith_18_tFileOutputExcel_1?fitWidth_tFileOutputExcel_1[18]:currentWith_18_tFileOutputExcel_1+2;
	    				} 
					
								   				
	    				if(row2.ID_ADRESSE_RESTAURANT != null) {
    				
					
//modif start
					
						columnIndex_tFileOutputExcel_1 = 19;
					

					
						jxl.write.WritableCell cell_19_tFileOutputExcel_1 = new jxl.write.Label(columnIndex_tFileOutputExcel_1, startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,
					
//modif end
								row2.ID_ADRESSE_RESTAURANT
							);
//modif start					
							//If we keep the cell format from the existing cell in sheet
							
							
//modif ends							
							writableSheet_tFileOutputExcel_1.addCell(cell_19_tFileOutputExcel_1);
							int currentWith_19_tFileOutputExcel_1 = cell_19_tFileOutputExcel_1.getContents().trim().length();
							fitWidth_tFileOutputExcel_1[19]=fitWidth_tFileOutputExcel_1[19]>currentWith_19_tFileOutputExcel_1?fitWidth_tFileOutputExcel_1[19]:currentWith_19_tFileOutputExcel_1+2;
	    				} 
					
								   				
	    				if(row2.ADRESSE_RESTAURANT != null) {
    				
					
//modif start
					
						columnIndex_tFileOutputExcel_1 = 20;
					

					
						jxl.write.WritableCell cell_20_tFileOutputExcel_1 = new jxl.write.Label(columnIndex_tFileOutputExcel_1, startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,
					
//modif end
								row2.ADRESSE_RESTAURANT
							);
//modif start					
							//If we keep the cell format from the existing cell in sheet
							
							
//modif ends							
							writableSheet_tFileOutputExcel_1.addCell(cell_20_tFileOutputExcel_1);
							int currentWith_20_tFileOutputExcel_1 = cell_20_tFileOutputExcel_1.getContents().trim().length();
							fitWidth_tFileOutputExcel_1[20]=fitWidth_tFileOutputExcel_1[20]>currentWith_20_tFileOutputExcel_1?fitWidth_tFileOutputExcel_1[20]:currentWith_20_tFileOutputExcel_1+2;
	    				} 
					
								   				
	    				if(row2.ID_CLIENT != null) {
    				
					
//modif start
					
						columnIndex_tFileOutputExcel_1 = 21;
					

					
						jxl.write.WritableCell cell_21_tFileOutputExcel_1 = new jxl.write.Label(columnIndex_tFileOutputExcel_1, startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,
					
//modif end
								row2.ID_CLIENT
							);
//modif start					
							//If we keep the cell format from the existing cell in sheet
							
							
//modif ends							
							writableSheet_tFileOutputExcel_1.addCell(cell_21_tFileOutputExcel_1);
							int currentWith_21_tFileOutputExcel_1 = cell_21_tFileOutputExcel_1.getContents().trim().length();
							fitWidth_tFileOutputExcel_1[21]=fitWidth_tFileOutputExcel_1[21]>currentWith_21_tFileOutputExcel_1?fitWidth_tFileOutputExcel_1[21]:currentWith_21_tFileOutputExcel_1+2;
	    				} 
					
								   				
	    				if(row2.ID_ADRESSE_CLIENT != null) {
    				
					
//modif start
					
						columnIndex_tFileOutputExcel_1 = 22;
					

					
						jxl.write.WritableCell cell_22_tFileOutputExcel_1 = new jxl.write.Label(columnIndex_tFileOutputExcel_1, startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,
					
//modif end
							
							FormatterUtils.format_Number(String.valueOf(row2.ID_ADRESSE_CLIENT), ' ', '.')				
							
							);
//modif start					
							//If we keep the cell format from the existing cell in sheet
							
							
//modif ends							
							writableSheet_tFileOutputExcel_1.addCell(cell_22_tFileOutputExcel_1);
							int currentWith_22_tFileOutputExcel_1 = cell_22_tFileOutputExcel_1.getContents().trim().length();
							fitWidth_tFileOutputExcel_1[22]=fitWidth_tFileOutputExcel_1[22]>currentWith_22_tFileOutputExcel_1?fitWidth_tFileOutputExcel_1[22]:currentWith_22_tFileOutputExcel_1+2;
	    				} 
					
								   				
	    				if(row2.ADRESSE_CLIENT != null) {
    				
					
//modif start
					
						columnIndex_tFileOutputExcel_1 = 23;
					

					
						jxl.write.WritableCell cell_23_tFileOutputExcel_1 = new jxl.write.Label(columnIndex_tFileOutputExcel_1, startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,
					
//modif end
								row2.ADRESSE_CLIENT
							);
//modif start					
							//If we keep the cell format from the existing cell in sheet
							
							
//modif ends							
							writableSheet_tFileOutputExcel_1.addCell(cell_23_tFileOutputExcel_1);
							int currentWith_23_tFileOutputExcel_1 = cell_23_tFileOutputExcel_1.getContents().trim().length();
							fitWidth_tFileOutputExcel_1[23]=fitWidth_tFileOutputExcel_1[23]>currentWith_23_tFileOutputExcel_1?fitWidth_tFileOutputExcel_1[23]:currentWith_23_tFileOutputExcel_1+2;
	    				} 
					
								   				
	    				if(row2.ID_RESTAURANT != null) {
    				
					
//modif start
					
						columnIndex_tFileOutputExcel_1 = 24;
					

					
						jxl.write.WritableCell cell_24_tFileOutputExcel_1 = new jxl.write.Label(columnIndex_tFileOutputExcel_1, startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,
					
//modif end
							
							FormatterUtils.format_Number(String.valueOf(row2.ID_RESTAURANT), ' ', '.')				
							
							);
//modif start					
							//If we keep the cell format from the existing cell in sheet
							
							
//modif ends							
							writableSheet_tFileOutputExcel_1.addCell(cell_24_tFileOutputExcel_1);
							int currentWith_24_tFileOutputExcel_1 = cell_24_tFileOutputExcel_1.getContents().trim().length();
							fitWidth_tFileOutputExcel_1[24]=fitWidth_tFileOutputExcel_1[24]>currentWith_24_tFileOutputExcel_1?fitWidth_tFileOutputExcel_1[24]:currentWith_24_tFileOutputExcel_1+2;
	    				} 
					
								   				
	    				if(row2.CODE_RESTAURANT != null) {
    				
					
//modif start
					
						columnIndex_tFileOutputExcel_1 = 25;
					

					
						jxl.write.WritableCell cell_25_tFileOutputExcel_1 = new jxl.write.Label(columnIndex_tFileOutputExcel_1, startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,
					
//modif end
								row2.CODE_RESTAURANT
							);
//modif start					
							//If we keep the cell format from the existing cell in sheet
							
							
//modif ends							
							writableSheet_tFileOutputExcel_1.addCell(cell_25_tFileOutputExcel_1);
							int currentWith_25_tFileOutputExcel_1 = cell_25_tFileOutputExcel_1.getContents().trim().length();
							fitWidth_tFileOutputExcel_1[25]=fitWidth_tFileOutputExcel_1[25]>currentWith_25_tFileOutputExcel_1?fitWidth_tFileOutputExcel_1[25]:currentWith_25_tFileOutputExcel_1+2;
	    				} 
					
								   				
	    				if(row2.RAISON_SOCIALE_RESTAURANT != null) {
    				
					
//modif start
					
						columnIndex_tFileOutputExcel_1 = 26;
					

					
						jxl.write.WritableCell cell_26_tFileOutputExcel_1 = new jxl.write.Label(columnIndex_tFileOutputExcel_1, startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,
					
//modif end
								row2.RAISON_SOCIALE_RESTAURANT
							);
//modif start					
							//If we keep the cell format from the existing cell in sheet
							
							
//modif ends							
							writableSheet_tFileOutputExcel_1.addCell(cell_26_tFileOutputExcel_1);
							int currentWith_26_tFileOutputExcel_1 = cell_26_tFileOutputExcel_1.getContents().trim().length();
							fitWidth_tFileOutputExcel_1[26]=fitWidth_tFileOutputExcel_1[26]>currentWith_26_tFileOutputExcel_1?fitWidth_tFileOutputExcel_1[26]:currentWith_26_tFileOutputExcel_1+2;
	    				} 
					
								   				
	    				if(row2.ID_ADRESSE_NORM_RESTAURANT != null) {
    				
					
//modif start
					
						columnIndex_tFileOutputExcel_1 = 27;
					

					
						jxl.write.WritableCell cell_27_tFileOutputExcel_1 = new jxl.write.Label(columnIndex_tFileOutputExcel_1, startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,
					
//modif end
							
							FormatterUtils.format_Number(String.valueOf(row2.ID_ADRESSE_NORM_RESTAURANT), ' ', '.')				
							
							);
//modif start					
							//If we keep the cell format from the existing cell in sheet
							
							
//modif ends							
							writableSheet_tFileOutputExcel_1.addCell(cell_27_tFileOutputExcel_1);
							int currentWith_27_tFileOutputExcel_1 = cell_27_tFileOutputExcel_1.getContents().trim().length();
							fitWidth_tFileOutputExcel_1[27]=fitWidth_tFileOutputExcel_1[27]>currentWith_27_tFileOutputExcel_1?fitWidth_tFileOutputExcel_1[27]:currentWith_27_tFileOutputExcel_1+2;
	    				} 
					
								   				
	    				if(row2.ID_MOYEN_PAIEMENT != null) {
    				
					
//modif start
					
						columnIndex_tFileOutputExcel_1 = 28;
					

					
						jxl.write.WritableCell cell_28_tFileOutputExcel_1 = new jxl.write.Label(columnIndex_tFileOutputExcel_1, startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,
					
//modif end
								row2.ID_MOYEN_PAIEMENT
							);
//modif start					
							//If we keep the cell format from the existing cell in sheet
							
							
//modif ends							
							writableSheet_tFileOutputExcel_1.addCell(cell_28_tFileOutputExcel_1);
							int currentWith_28_tFileOutputExcel_1 = cell_28_tFileOutputExcel_1.getContents().trim().length();
							fitWidth_tFileOutputExcel_1[28]=fitWidth_tFileOutputExcel_1[28]>currentWith_28_tFileOutputExcel_1?fitWidth_tFileOutputExcel_1[28]:currentWith_28_tFileOutputExcel_1+2;
	    				} 
					
								   				
	    				if(row2.CODE_MOYEN_PAIEMENT != null) {
    				
					
//modif start
					
						columnIndex_tFileOutputExcel_1 = 29;
					

					
						jxl.write.WritableCell cell_29_tFileOutputExcel_1 = new jxl.write.Label(columnIndex_tFileOutputExcel_1, startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,
					
//modif end
								row2.CODE_MOYEN_PAIEMENT
							);
//modif start					
							//If we keep the cell format from the existing cell in sheet
							
							
//modif ends							
							writableSheet_tFileOutputExcel_1.addCell(cell_29_tFileOutputExcel_1);
							int currentWith_29_tFileOutputExcel_1 = cell_29_tFileOutputExcel_1.getContents().trim().length();
							fitWidth_tFileOutputExcel_1[29]=fitWidth_tFileOutputExcel_1[29]>currentWith_29_tFileOutputExcel_1?fitWidth_tFileOutputExcel_1[29]:currentWith_29_tFileOutputExcel_1+2;
	    				} 
					
								   				
	    				if(row2.LIVELLE_MOYEN_PAIEMENT != null) {
    				
					
//modif start
					
						columnIndex_tFileOutputExcel_1 = 30;
					

					
						jxl.write.WritableCell cell_30_tFileOutputExcel_1 = new jxl.write.Label(columnIndex_tFileOutputExcel_1, startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,
					
//modif end
								row2.LIVELLE_MOYEN_PAIEMENT
							);
//modif start					
							//If we keep the cell format from the existing cell in sheet
							
							
//modif ends							
							writableSheet_tFileOutputExcel_1.addCell(cell_30_tFileOutputExcel_1);
							int currentWith_30_tFileOutputExcel_1 = cell_30_tFileOutputExcel_1.getContents().trim().length();
							fitWidth_tFileOutputExcel_1[30]=fitWidth_tFileOutputExcel_1[30]>currentWith_30_tFileOutputExcel_1?fitWidth_tFileOutputExcel_1[30]:currentWith_30_tFileOutputExcel_1+2;
	    				} 
					
								   				
	    				if(row2.NOM_CLIENT != null) {
    				
					
//modif start
					
						columnIndex_tFileOutputExcel_1 = 31;
					

					
						jxl.write.WritableCell cell_31_tFileOutputExcel_1 = new jxl.write.Label(columnIndex_tFileOutputExcel_1, startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,
					
//modif end
								row2.NOM_CLIENT
							);
//modif start					
							//If we keep the cell format from the existing cell in sheet
							
							
//modif ends							
							writableSheet_tFileOutputExcel_1.addCell(cell_31_tFileOutputExcel_1);
							int currentWith_31_tFileOutputExcel_1 = cell_31_tFileOutputExcel_1.getContents().trim().length();
							fitWidth_tFileOutputExcel_1[31]=fitWidth_tFileOutputExcel_1[31]>currentWith_31_tFileOutputExcel_1?fitWidth_tFileOutputExcel_1[31]:currentWith_31_tFileOutputExcel_1+2;
	    				} 
					
								   				
	    				if(row2.PRENOM_CLIENT != null) {
    				
					
//modif start
					
						columnIndex_tFileOutputExcel_1 = 32;
					

					
						jxl.write.WritableCell cell_32_tFileOutputExcel_1 = new jxl.write.Label(columnIndex_tFileOutputExcel_1, startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,
					
//modif end
								row2.PRENOM_CLIENT
							);
//modif start					
							//If we keep the cell format from the existing cell in sheet
							
							
//modif ends							
							writableSheet_tFileOutputExcel_1.addCell(cell_32_tFileOutputExcel_1);
							int currentWith_32_tFileOutputExcel_1 = cell_32_tFileOutputExcel_1.getContents().trim().length();
							fitWidth_tFileOutputExcel_1[32]=fitWidth_tFileOutputExcel_1[32]>currentWith_32_tFileOutputExcel_1?fitWidth_tFileOutputExcel_1[32]:currentWith_32_tFileOutputExcel_1+2;
	    				} 
					
								   				
	    				if(row2.LATITUDE_RESTAU != null) {
    				
					
//modif start
					
						columnIndex_tFileOutputExcel_1 = 33;
					

					
						jxl.write.WritableCell cell_33_tFileOutputExcel_1 = new jxl.write.Label(columnIndex_tFileOutputExcel_1, startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,
					
//modif end
								row2.LATITUDE_RESTAU
							);
//modif start					
							//If we keep the cell format from the existing cell in sheet
							
							
//modif ends							
							writableSheet_tFileOutputExcel_1.addCell(cell_33_tFileOutputExcel_1);
							int currentWith_33_tFileOutputExcel_1 = cell_33_tFileOutputExcel_1.getContents().trim().length();
							fitWidth_tFileOutputExcel_1[33]=fitWidth_tFileOutputExcel_1[33]>currentWith_33_tFileOutputExcel_1?fitWidth_tFileOutputExcel_1[33]:currentWith_33_tFileOutputExcel_1+2;
	    				} 
					
								   				
	    				if(row2.LONGITUDE_RESTAU != null) {
    				
					
//modif start
					
						columnIndex_tFileOutputExcel_1 = 34;
					

					
						jxl.write.WritableCell cell_34_tFileOutputExcel_1 = new jxl.write.Label(columnIndex_tFileOutputExcel_1, startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,
					
//modif end
							
							FormatterUtils.format_Number(String.valueOf(row2.LONGITUDE_RESTAU), ' ', '.')				
							
							);
//modif start					
							//If we keep the cell format from the existing cell in sheet
							
							
//modif ends							
							writableSheet_tFileOutputExcel_1.addCell(cell_34_tFileOutputExcel_1);
							int currentWith_34_tFileOutputExcel_1 = cell_34_tFileOutputExcel_1.getContents().trim().length();
							fitWidth_tFileOutputExcel_1[34]=fitWidth_tFileOutputExcel_1[34]>currentWith_34_tFileOutputExcel_1?fitWidth_tFileOutputExcel_1[34]:currentWith_34_tFileOutputExcel_1+2;
	    				} 
					
								   				
	    				if(row2.NOM_VILLE_RESTAU != null) {
    				
					
//modif start
					
						columnIndex_tFileOutputExcel_1 = 35;
					

					
						jxl.write.WritableCell cell_35_tFileOutputExcel_1 = new jxl.write.Label(columnIndex_tFileOutputExcel_1, startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,
					
//modif end
								row2.NOM_VILLE_RESTAU
							);
//modif start					
							//If we keep the cell format from the existing cell in sheet
							
							
//modif ends							
							writableSheet_tFileOutputExcel_1.addCell(cell_35_tFileOutputExcel_1);
							int currentWith_35_tFileOutputExcel_1 = cell_35_tFileOutputExcel_1.getContents().trim().length();
							fitWidth_tFileOutputExcel_1[35]=fitWidth_tFileOutputExcel_1[35]>currentWith_35_tFileOutputExcel_1?fitWidth_tFileOutputExcel_1[35]:currentWith_35_tFileOutputExcel_1+2;
	    				} 
					
								   				
	    				if(row2.CODE_POSTAL_RESTAU != null) {
    				
					
//modif start
					
						columnIndex_tFileOutputExcel_1 = 36;
					

					
						jxl.write.WritableCell cell_36_tFileOutputExcel_1 = new jxl.write.Label(columnIndex_tFileOutputExcel_1, startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,
					
//modif end
							
							FormatterUtils.format_Number(String.valueOf(row2.CODE_POSTAL_RESTAU), ' ', '.')				
							
							);
//modif start					
							//If we keep the cell format from the existing cell in sheet
							
							
//modif ends							
							writableSheet_tFileOutputExcel_1.addCell(cell_36_tFileOutputExcel_1);
							int currentWith_36_tFileOutputExcel_1 = cell_36_tFileOutputExcel_1.getContents().trim().length();
							fitWidth_tFileOutputExcel_1[36]=fitWidth_tFileOutputExcel_1[36]>currentWith_36_tFileOutputExcel_1?fitWidth_tFileOutputExcel_1[36]:currentWith_36_tFileOutputExcel_1+2;
	    				} 
					
								   				
	    				if(row2.NOM_VOIE_RESTAU != null) {
    				
					
//modif start
					
						columnIndex_tFileOutputExcel_1 = 37;
					

					
						jxl.write.WritableCell cell_37_tFileOutputExcel_1 = new jxl.write.Label(columnIndex_tFileOutputExcel_1, startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,
					
//modif end
								row2.NOM_VOIE_RESTAU
							);
//modif start					
							//If we keep the cell format from the existing cell in sheet
							
							
//modif ends							
							writableSheet_tFileOutputExcel_1.addCell(cell_37_tFileOutputExcel_1);
							int currentWith_37_tFileOutputExcel_1 = cell_37_tFileOutputExcel_1.getContents().trim().length();
							fitWidth_tFileOutputExcel_1[37]=fitWidth_tFileOutputExcel_1[37]>currentWith_37_tFileOutputExcel_1?fitWidth_tFileOutputExcel_1[37]:currentWith_37_tFileOutputExcel_1+2;
	    				} 
					
								   				
	    				if(row2.NUMERO_VOIE_RESTAU != null) {
    				
					
//modif start
					
						columnIndex_tFileOutputExcel_1 = 38;
					

					
						jxl.write.WritableCell cell_38_tFileOutputExcel_1 = new jxl.write.Label(columnIndex_tFileOutputExcel_1, startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,
					
//modif end
								row2.NUMERO_VOIE_RESTAU
							);
//modif start					
							//If we keep the cell format from the existing cell in sheet
							
							
//modif ends							
							writableSheet_tFileOutputExcel_1.addCell(cell_38_tFileOutputExcel_1);
							int currentWith_38_tFileOutputExcel_1 = cell_38_tFileOutputExcel_1.getContents().trim().length();
							fitWidth_tFileOutputExcel_1[38]=fitWidth_tFileOutputExcel_1[38]>currentWith_38_tFileOutputExcel_1?fitWidth_tFileOutputExcel_1[38]:currentWith_38_tFileOutputExcel_1+2;
	    				} 
					
    			nb_line_tFileOutputExcel_1++;
				
 


	tos_count_tFileOutputExcel_1++;

/**
 * [tFileOutputExcel_1 main ] stop
 */
	
	/**
	 * [tFileOutputExcel_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFileOutputExcel_1";

	

 



/**
 * [tFileOutputExcel_1 process_data_begin ] stop
 */
	
	/**
	 * [tFileOutputExcel_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tFileOutputExcel_1";

	

 



/**
 * [tFileOutputExcel_1 process_data_end ] stop
 */



	
	/**
	 * [tDBInput_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBInput_1";

	

 



/**
 * [tDBInput_1 process_data_end ] stop
 */
	
	/**
	 * [tDBInput_1 end ] start
	 */

	

	
	
	currentComponent="tDBInput_1";

	

}
}finally{
	if (rs_tDBInput_1 != null) {
		rs_tDBInput_1.close();
	}
	if (stmt_tDBInput_1 != null) {
		stmt_tDBInput_1.close();
	}
	if(conn_tDBInput_1 != null && !conn_tDBInput_1.isClosed()) {
	
			conn_tDBInput_1.close();
			
			if("com.mysql.cj.jdbc.Driver".equals((String)globalMap.get("driverClass_"))
			    && routines.system.BundleUtils.inOSGi()) {
			        Class.forName("com.mysql.cj.jdbc.AbandonedConnectionCleanupThread").
			            getMethod("checkedShutdown").invoke(null, (Object[]) null);
			}
			
	}
	
}

globalMap.put("tDBInput_1_NB_LINE",nb_line_tDBInput_1);
 

ok_Hash.put("tDBInput_1", true);
end_Hash.put("tDBInput_1", System.currentTimeMillis());

tStatCatcher_1.addMessage("end","tDBInput_1", end_Hash.get("tDBInput_1")-start_Hash.get("tDBInput_1"));
tStatCatcher_1Process(globalMap);



/**
 * [tDBInput_1 end ] stop
 */

	
	/**
	 * [tFileOutputExcel_1 end ] start
	 */

	

	
	
	currentComponent="tFileOutputExcel_1";

	

		writeableWorkbook_tFileOutputExcel_1.write();
		writeableWorkbook_tFileOutputExcel_1.close();
		if(headerIsInserted_tFileOutputExcel_1 && nb_line_tFileOutputExcel_1 > 0){
			nb_line_tFileOutputExcel_1 = nb_line_tFileOutputExcel_1 -1;
		}
		globalMap.put("tFileOutputExcel_1_NB_LINE",nb_line_tFileOutputExcel_1);
		
		

				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row2");
			  	}
			  	
 

ok_Hash.put("tFileOutputExcel_1", true);
end_Hash.put("tFileOutputExcel_1", System.currentTimeMillis());

tStatCatcher_1.addMessage("end","tFileOutputExcel_1", end_Hash.get("tFileOutputExcel_1")-start_Hash.get("tFileOutputExcel_1"));
tStatCatcher_1Process(globalMap);



/**
 * [tFileOutputExcel_1 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBInput_1 finally ] start
	 */

	

	
	
	currentComponent="tDBInput_1";

	

 



/**
 * [tDBInput_1 finally ] stop
 */

	
	/**
	 * [tFileOutputExcel_1 finally ] start
	 */

	

	
	
	currentComponent="tFileOutputExcel_1";

	

 



/**
 * [tFileOutputExcel_1 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBInput_1_SUBPROCESS_STATE", 1);
	}
	
    public String resuming_logs_dir_path = null;
    public String resuming_checkpoint_path = null;
    public String parent_part_launcher = null;
    private String resumeEntryMethodName = null;
    private boolean globalResumeTicket = false;

    public boolean watch = false;
    // portStats is null, it means don't execute the statistics
    public Integer portStats = null;
    public int portTraces = 4334;
    public String clientHost;
    public String defaultClientHost = "localhost";
    public String contextStr = "Default";
    public boolean isDefaultContext = true;
    public String pid = "0";
    public String rootPid = null;
    public String fatherPid = null;
    public String fatherNode = null;
    public long startTime = 0;
    public boolean isChildJob = false;
    public String log4jLevel = "";
    
    private boolean enableLogStash;

    private boolean execStat = true;

    private ThreadLocal<java.util.Map<String, String>> threadLocal = new ThreadLocal<java.util.Map<String, String>>() {
        protected java.util.Map<String, String> initialValue() {
            java.util.Map<String,String> threadRunResultMap = new java.util.HashMap<String, String>();
            threadRunResultMap.put("errorCode", null);
            threadRunResultMap.put("status", "");
            return threadRunResultMap;
        };
    };


    protected PropertiesWithType context_param = new PropertiesWithType();
    public java.util.Map<String, Object> parentContextMap = new java.util.HashMap<String, Object>();

    public String status= "";
    

    public static void main(String[] args){
        final A_GENERER_EXCEL A_GENERER_EXCELClass = new A_GENERER_EXCEL();

        int exitCode = A_GENERER_EXCELClass.runJobInTOS(args);

        System.exit(exitCode);
    }


    public String[][] runJob(String[] args) {

        int exitCode = runJobInTOS(args);
        String[][] bufferValue = new String[][] { { Integer.toString(exitCode) } };

        return bufferValue;
    }

    public boolean hastBufferOutputComponent() {
		boolean hastBufferOutput = false;
    	
        return hastBufferOutput;
    }

    public int runJobInTOS(String[] args) {
	   	// reset status
	   	status = "";
	   	
        String lastStr = "";
        for (String arg : args) {
            if (arg.equalsIgnoreCase("--context_param")) {
                lastStr = arg;
            } else if (lastStr.equals("")) {
                evalParam(arg);
            } else {
                evalParam(lastStr + " " + arg);
                lastStr = "";
            }
        }
        enableLogStash = "true".equalsIgnoreCase(System.getProperty("audit.enabled"));

    	
    	

        if(clientHost == null) {
            clientHost = defaultClientHost;
        }

        if(pid == null || "0".equals(pid)) {
            pid = TalendString.getAsciiRandomString(6);
        }

        if (rootPid==null) {
            rootPid = pid;
        }
        if (fatherPid==null) {
            fatherPid = pid;
        }else{
            isChildJob = true;
        }

        if (portStats != null) {
            // portStats = -1; //for testing
            if (portStats < 0 || portStats > 65535) {
                // issue:10869, the portStats is invalid, so this client socket can't open
                System.err.println("The statistics socket port " + portStats + " is invalid.");
                execStat = false;
            }
        } else {
            execStat = false;
        }
        boolean inOSGi = routines.system.BundleUtils.inOSGi();

        if (inOSGi) {
            java.util.Dictionary<String, Object> jobProperties = routines.system.BundleUtils.getJobProperties(jobName);

            if (jobProperties != null && jobProperties.get("context") != null) {
                contextStr = (String)jobProperties.get("context");
            }
        }

        try {
            //call job/subjob with an existing context, like: --context=production. if without this parameter, there will use the default context instead.
            java.io.InputStream inContext = A_GENERER_EXCEL.class.getClassLoader().getResourceAsStream("alimentation_dm1/a_generer_excel_0_1/contexts/" + contextStr + ".properties");
            if (inContext == null) {
                inContext = A_GENERER_EXCEL.class.getClassLoader().getResourceAsStream("config/contexts/" + contextStr + ".properties");
            }
            if (inContext != null) {
                try {
                    //defaultProps is in order to keep the original context value
                    if(context != null && context.isEmpty()) {
	                defaultProps.load(inContext);
	                context = new ContextProperties(defaultProps);
                    }
                } finally {
                    inContext.close();
                }
            } else if (!isDefaultContext) {
                //print info and job continue to run, for case: context_param is not empty.
                System.err.println("Could not find the context " + contextStr);
            }

            if(!context_param.isEmpty()) {
                context.putAll(context_param);
				//set types for params from parentJobs
				for (Object key: context_param.keySet()){
					String context_key = key.toString();
					String context_type = context_param.getContextType(context_key);
					context.setContextType(context_key, context_type);

				}
            }
            class ContextProcessing {
                private void processContext_0() {
                } 
                public void processAllContext() {
                        processContext_0();
                }
            }

            new ContextProcessing().processAllContext();
        } catch (java.io.IOException ie) {
            System.err.println("Could not load context "+contextStr);
            ie.printStackTrace();
        }

        // get context value from parent directly
        if (parentContextMap != null && !parentContextMap.isEmpty()) {
        }

        //Resume: init the resumeUtil
        resumeEntryMethodName = ResumeUtil.getResumeEntryMethodName(resuming_checkpoint_path);
        resumeUtil = new ResumeUtil(resuming_logs_dir_path, isChildJob, rootPid);
        resumeUtil.initCommonInfo(pid, rootPid, fatherPid, projectName, jobName, contextStr, jobVersion);

		List<String> parametersToEncrypt = new java.util.ArrayList<String>();
        //Resume: jobStart
        resumeUtil.addLog("JOB_STARTED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","","","",resumeUtil.convertToJsonText(context,parametersToEncrypt));

if(execStat) {
    try {
        runStat.openSocket(!isChildJob);
        runStat.setAllPID(rootPid, fatherPid, pid, jobName);
        runStat.startThreadStat(clientHost, portStats);
        runStat.updateStatOnJob(RunStat.JOBSTART, fatherNode);
    } catch (java.io.IOException ioException) {
        ioException.printStackTrace();
    }
}



	
	    java.util.concurrent.ConcurrentHashMap<Object, Object> concurrentHashMap = new java.util.concurrent.ConcurrentHashMap<Object, Object>();
	    globalMap.put("concurrentHashMap", concurrentHashMap);
	

    long startUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
    long endUsedMemory = 0;
    long end = 0;

    startTime = System.currentTimeMillis();
        tStatCatcher_1.addMessage("begin");


this.globalResumeTicket = true;//to run tPreJob




        try {
            tStatCatcher_1Process(globalMap);
        } catch (java.lang.Exception e) {
            e.printStackTrace();
        }

this.globalResumeTicket = false;//to run others jobs

try {
errorCode = null;tDBInput_1Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tDBInput_1) {
globalMap.put("tDBInput_1_SUBPROCESS_STATE", -1);

e_tDBInput_1.printStackTrace();

}

this.globalResumeTicket = true;//to run tPostJob




        end = System.currentTimeMillis();

        if (watch) {
            System.out.println((end-startTime)+" milliseconds");
        }

        endUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        if (false) {
            System.out.println((endUsedMemory - startUsedMemory) + " bytes memory increase when running : A_GENERER_EXCEL");
        }
        tStatCatcher_1.addMessage(status==""?"end":status, (end-startTime));
        try {
            tStatCatcher_1Process(globalMap);
        } catch (java.lang.Exception e) {
            e.printStackTrace();
        }



if (execStat) {
    runStat.updateStatOnJob(RunStat.JOBEND, fatherNode);
    runStat.stopThreadStat();
}
    int returnCode = 0;


    if(errorCode == null) {
         returnCode = status != null && status.equals("failure") ? 1 : 0;
    } else {
         returnCode = errorCode.intValue();
    }
    resumeUtil.addLog("JOB_ENDED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","" + returnCode,"","","");

    return returnCode;

  }

    // only for OSGi env
    public void destroy() {


    }














    private java.util.Map<String, Object> getSharedConnections4REST() {
        java.util.Map<String, Object> connections = new java.util.HashMap<String, Object>();






        return connections;
    }

    private void evalParam(String arg) {
        if (arg.startsWith("--resuming_logs_dir_path")) {
            resuming_logs_dir_path = arg.substring(25);
        } else if (arg.startsWith("--resuming_checkpoint_path")) {
            resuming_checkpoint_path = arg.substring(27);
        } else if (arg.startsWith("--parent_part_launcher")) {
            parent_part_launcher = arg.substring(23);
        } else if (arg.startsWith("--watch")) {
            watch = true;
        } else if (arg.startsWith("--stat_port=")) {
            String portStatsStr = arg.substring(12);
            if (portStatsStr != null && !portStatsStr.equals("null")) {
                portStats = Integer.parseInt(portStatsStr);
            }
        } else if (arg.startsWith("--trace_port=")) {
            portTraces = Integer.parseInt(arg.substring(13));
        } else if (arg.startsWith("--client_host=")) {
            clientHost = arg.substring(14);
        } else if (arg.startsWith("--context=")) {
            contextStr = arg.substring(10);
            isDefaultContext = false;
        } else if (arg.startsWith("--father_pid=")) {
            fatherPid = arg.substring(13);
        } else if (arg.startsWith("--root_pid=")) {
            rootPid = arg.substring(11);
        } else if (arg.startsWith("--father_node=")) {
            fatherNode = arg.substring(14);
        } else if (arg.startsWith("--pid=")) {
            pid = arg.substring(6);
        } else if (arg.startsWith("--context_type")) {
            String keyValue = arg.substring(15);
			int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.setContextType(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.setContextType(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }

            }

		} else if (arg.startsWith("--context_param")) {
            String keyValue = arg.substring(16);
            int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.put(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.put(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }
            }
        } else if (arg.startsWith("--log4jLevel=")) {
            log4jLevel = arg.substring(13);
		} else if (arg.startsWith("--audit.enabled") && arg.contains("=")) {//for trunjob call
		    final int equal = arg.indexOf('=');
			final String key = arg.substring("--".length(), equal);
			System.setProperty(key, arg.substring(equal + 1));
		}
    }
    
    private static final String NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY = "<TALEND_NULL>";

    private final String[][] escapeChars = {
        {"\\\\","\\"},{"\\n","\n"},{"\\'","\'"},{"\\r","\r"},
        {"\\f","\f"},{"\\b","\b"},{"\\t","\t"}
        };
    private String replaceEscapeChars (String keyValue) {

		if (keyValue == null || ("").equals(keyValue.trim())) {
			return keyValue;
		}

		StringBuilder result = new StringBuilder();
		int currIndex = 0;
		while (currIndex < keyValue.length()) {
			int index = -1;
			// judege if the left string includes escape chars
			for (String[] strArray : escapeChars) {
				index = keyValue.indexOf(strArray[0],currIndex);
				if (index>=0) {

					result.append(keyValue.substring(currIndex, index + strArray[0].length()).replace(strArray[0], strArray[1]));
					currIndex = index + strArray[0].length();
					break;
				}
			}
			// if the left string doesn't include escape chars, append the left into the result
			if (index < 0) {
				result.append(keyValue.substring(currIndex));
				currIndex = currIndex + keyValue.length();
			}
		}

		return result.toString();
    }

    public Integer getErrorCode() {
        return errorCode;
    }


    public String getStatus() {
        return status;
    }

    ResumeUtil resumeUtil = null;
}
/************************************************************************************************
 *     151653 characters generated by Talend Open Studio for Data Integration 
 *     on the 18 janvier 2024 à 23:35:13 CET
 ************************************************************************************************/