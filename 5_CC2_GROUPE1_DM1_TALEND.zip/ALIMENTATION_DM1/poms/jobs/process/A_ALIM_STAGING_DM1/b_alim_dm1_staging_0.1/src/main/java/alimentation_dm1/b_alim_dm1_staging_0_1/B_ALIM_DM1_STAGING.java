// ============================================================================
//
// Copyright (c) 2006-2015, Talend SA
//
// Ce code source a été automatiquement généré par_Talend Open Studio for Data Integration
// / Soumis à la Licence Apache, Version 2.0 (la "Licence") ;
// votre utilisation de ce fichier doit respecter les termes de la Licence.
// Vous pouvez obtenir une copie de la Licence sur
// http://www.apache.org/licenses/LICENSE-2.0
// 
// Sauf lorsqu'explicitement prévu par la loi en vigueur ou accepté par écrit, le logiciel
// distribué sous la Licence est distribué "TEL QUEL",
// SANS GARANTIE OU CONDITION D'AUCUNE SORTE, expresse ou implicite.
// Consultez la Licence pour connaître la terminologie spécifique régissant les autorisations et
// les limites prévues par la Licence.


package alimentation_dm1.b_alim_dm1_staging_0_1;

import routines.Numeric;
import routines.DataOperation;
import routines.TalendDataGenerator;
import routines.TalendStringUtil;
import routines.TalendString;
import routines.StringHandling;
import routines.Relational;
import routines.TalendDate;
import routines.Mathematical;
import routines.system.*;
import routines.system.api.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.math.BigDecimal;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.util.Comparator;
 





@SuppressWarnings("unused")

/**
 * Job: B_ALIM_DM1_STAGING Purpose: Alimentation dm&_staging<br>
 * Description: Job pour Alimentation dm&_staging <br>
 * @author user@talend.com
 * @version 8.0.1.20211109_1610
 * @status 
 */
public class B_ALIM_DM1_STAGING implements TalendJob {

protected static void logIgnoredError(String message, Throwable cause) {
       System.err.println(message);
       if (cause != null) {
               cause.printStackTrace();
       }

}


	public final Object obj = new Object();

	// for transmiting parameters purpose
	private Object valueObject = null;

	public Object getValueObject() {
		return this.valueObject;
	}

	public void setValueObject(Object valueObject) {
		this.valueObject = valueObject;
	}
	
	private final static String defaultCharset = java.nio.charset.Charset.defaultCharset().name();

	
	private final static String utf8Charset = "UTF-8";
	//contains type for every context property
	public class PropertiesWithType extends java.util.Properties {
		private static final long serialVersionUID = 1L;
		private java.util.Map<String,String> propertyTypes = new java.util.HashMap<>();
		
		public PropertiesWithType(java.util.Properties properties){
			super(properties);
		}
		public PropertiesWithType(){
			super();
		}
		
		public void setContextType(String key, String type) {
			propertyTypes.put(key,type);
		}
	
		public String getContextType(String key) {
			return propertyTypes.get(key);
		}
	}
	
	// create and load default properties
	private java.util.Properties defaultProps = new java.util.Properties();
	// create application properties with default
	public class ContextProperties extends PropertiesWithType {

		private static final long serialVersionUID = 1L;

		public ContextProperties(java.util.Properties properties){
			super(properties);
		}
		public ContextProperties(){
			super();
		}

		public void synchronizeContext(){
			
		}
		
		//if the stored or passed value is "<TALEND_NULL>" string, it mean null
		public String getStringValue(String key) {
			String origin_value = this.getProperty(key);
			if(NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY.equals(origin_value)) {
				return null;
			}
			return origin_value;
		}

	}
	protected ContextProperties context = new ContextProperties(); // will be instanciated by MS.
	public ContextProperties getContext() {
		return this.context;
	}
	private final String jobVersion = "0.1";
	private final String jobName = "B_ALIM_DM1_STAGING";
	private final String projectName = "ALIMENTATION_DM1";
	public Integer errorCode = null;
	private String currentComponent = "";
	
		private final java.util.Map<String, Object> globalMap = new java.util.HashMap<String, Object>();
        private final static java.util.Map<String, Object> junitGlobalMap = new java.util.HashMap<String, Object>();
	
		private final java.util.Map<String, Long> start_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Long> end_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Boolean> ok_Hash = new java.util.HashMap<String, Boolean>();
		public  final java.util.List<String[]> globalBuffer = new java.util.ArrayList<String[]>();
	

private RunStat runStat = new RunStat();

	// OSGi DataSource
	private final static String KEY_DB_DATASOURCES = "KEY_DB_DATASOURCES";
	
	private final static String KEY_DB_DATASOURCES_RAW = "KEY_DB_DATASOURCES_RAW";

	public void setDataSources(java.util.Map<String, javax.sql.DataSource> dataSources) {
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		for (java.util.Map.Entry<String, javax.sql.DataSource> dataSourceEntry : dataSources.entrySet()) {
			talendDataSources.put(dataSourceEntry.getKey(), new routines.system.TalendDataSource(dataSourceEntry.getValue()));
		}
		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}
	
	public void setDataSourceReferences(List serviceReferences) throws Exception{
		
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		java.util.Map<String, javax.sql.DataSource> dataSources = new java.util.HashMap<String, javax.sql.DataSource>();
		
		for (java.util.Map.Entry<String, javax.sql.DataSource> entry : BundleUtils.getServices(serviceReferences,  javax.sql.DataSource.class).entrySet()) {
                    dataSources.put(entry.getKey(), entry.getValue());
                    talendDataSources.put(entry.getKey(), new routines.system.TalendDataSource(entry.getValue()));
		}

		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}

	StatCatcherUtils tStatCatcher_1 = new StatCatcherUtils("_Afjb4KRBEe6Y29G3fOuWUQ", "0.1");

private final java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
private final java.io.PrintStream errorMessagePS = new java.io.PrintStream(new java.io.BufferedOutputStream(baos));

public String getExceptionStackTrace() {
	if ("failure".equals(this.getStatus())) {
		errorMessagePS.flush();
		return baos.toString();
	}
	return null;
}

private Exception exception;

public Exception getException() {
	if ("failure".equals(this.getStatus())) {
		return this.exception;
	}
	return null;
}

private class TalendException extends Exception {

	private static final long serialVersionUID = 1L;

	private java.util.Map<String, Object> globalMap = null;
	private Exception e = null;
	private String currentComponent = null;
	private String virtualComponentName = null;
	
	public void setVirtualComponentName (String virtualComponentName){
		this.virtualComponentName = virtualComponentName;
	}

	private TalendException(Exception e, String errorComponent, final java.util.Map<String, Object> globalMap) {
		this.currentComponent= errorComponent;
		this.globalMap = globalMap;
		this.e = e;
	}

	public Exception getException() {
		return this.e;
	}

	public String getCurrentComponent() {
		return this.currentComponent;
	}

	
    public String getExceptionCauseMessage(Exception e){
        Throwable cause = e;
        String message = null;
        int i = 10;
        while (null != cause && 0 < i--) {
            message = cause.getMessage();
            if (null == message) {
                cause = cause.getCause();
            } else {
                break;          
            }
        }
        if (null == message) {
            message = e.getClass().getName();
        }   
        return message;
    }

	@Override
	public void printStackTrace() {
		if (!(e instanceof TalendException || e instanceof TDieException)) {
			if(virtualComponentName!=null && currentComponent.indexOf(virtualComponentName+"_")==0){
				globalMap.put(virtualComponentName+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			}
			globalMap.put(currentComponent+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			System.err.println("Exception in component " + currentComponent + " (" + jobName + ")");
		}
		if (!(e instanceof TDieException)) {
			if(e instanceof TalendException){
				e.printStackTrace();
			} else {
				e.printStackTrace();
				e.printStackTrace(errorMessagePS);
				B_ALIM_DM1_STAGING.this.exception = e;
			}
		}
		if (!(e instanceof TalendException)) {
		try {
			for (java.lang.reflect.Method m : this.getClass().getEnclosingClass().getMethods()) {
				if (m.getName().compareTo(currentComponent + "_error") == 0) {
					m.invoke(B_ALIM_DM1_STAGING.this, new Object[] { e , currentComponent, globalMap});
					break;
				}
			}

			if(!(e instanceof TDieException)){
			}
		} catch (Exception e) {
			this.e.printStackTrace();
		}
		}
	}
}

			public void tStatCatcher_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tStatCatcher_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tStatCatcher_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileInputExcel_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMap_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
							tStatCatcher_1.addMessage("failure",errorComponent, end_Hash.get(errorComponent)-start_Hash.get(errorComponent));
							tStatCatcher_1Process(globalMap);
							
				status = "failure";
				
					tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
							tStatCatcher_1.addMessage("failure",errorComponent, end_Hash.get(errorComponent)-start_Hash.get(errorComponent));
							tStatCatcher_1Process(globalMap);
							
				status = "failure";
				
					tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileList_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
							tStatCatcher_1.addMessage("failure",errorComponent, end_Hash.get(errorComponent)-start_Hash.get(errorComponent));
							tStatCatcher_1Process(globalMap);
							
				status = "failure";
				
					tFileList_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileArchive_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
							tStatCatcher_1.addMessage("failure",errorComponent, end_Hash.get(errorComponent)-start_Hash.get(errorComponent));
							tStatCatcher_1Process(globalMap);
							
				status = "failure";
				
					tFileList_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tStatCatcher_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFileInputExcel_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFileList_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
	






public static class row1Struct implements routines.system.IPersistableRow<row1Struct> {
    final static byte[] commonByteArrayLock_ALIMENTATION_DM1_B_ALIM_DM1_STAGING = new byte[0];
    static byte[] commonByteArray_ALIMENTATION_DM1_B_ALIM_DM1_STAGING = new byte[0];

	
			    public java.util.Date moment;

				public java.util.Date getMoment () {
					return this.moment;
				}
				
			    public String pid;

				public String getPid () {
					return this.pid;
				}
				
			    public String father_pid;

				public String getFather_pid () {
					return this.father_pid;
				}
				
			    public String root_pid;

				public String getRoot_pid () {
					return this.root_pid;
				}
				
			    public Long system_pid;

				public Long getSystem_pid () {
					return this.system_pid;
				}
				
			    public String project;

				public String getProject () {
					return this.project;
				}
				
			    public String job;

				public String getJob () {
					return this.job;
				}
				
			    public String job_repository_id;

				public String getJob_repository_id () {
					return this.job_repository_id;
				}
				
			    public String job_version;

				public String getJob_version () {
					return this.job_version;
				}
				
			    public String context;

				public String getContext () {
					return this.context;
				}
				
			    public String origin;

				public String getOrigin () {
					return this.origin;
				}
				
			    public String message_type;

				public String getMessage_type () {
					return this.message_type;
				}
				
			    public String message;

				public String getMessage () {
					return this.message;
				}
				
			    public Long duration;

				public Long getDuration () {
					return this.duration;
				}
				



	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_DM1_B_ALIM_DM1_STAGING.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_DM1_B_ALIM_DM1_STAGING.length == 0) {
   					commonByteArray_ALIMENTATION_DM1_B_ALIM_DM1_STAGING = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_DM1_B_ALIM_DM1_STAGING = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ALIMENTATION_DM1_B_ALIM_DM1_STAGING, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_DM1_B_ALIM_DM1_STAGING, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_DM1_B_ALIM_DM1_STAGING.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_DM1_B_ALIM_DM1_STAGING.length == 0) {
   					commonByteArray_ALIMENTATION_DM1_B_ALIM_DM1_STAGING = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_DM1_B_ALIM_DM1_STAGING = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ALIMENTATION_DM1_B_ALIM_DM1_STAGING, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_DM1_B_ALIM_DM1_STAGING, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_DM1_B_ALIM_DM1_STAGING) {

        	try {

        		int length = 0;
		
					this.moment = readDate(dis);
					
					this.pid = readString(dis);
					
					this.father_pid = readString(dis);
					
					this.root_pid = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.system_pid = null;
           				} else {
           			    	this.system_pid = dis.readLong();
           				}
					
					this.project = readString(dis);
					
					this.job = readString(dis);
					
					this.job_repository_id = readString(dis);
					
					this.job_version = readString(dis);
					
					this.context = readString(dis);
					
					this.origin = readString(dis);
					
					this.message_type = readString(dis);
					
					this.message = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.duration = null;
           				} else {
           			    	this.duration = dis.readLong();
           				}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_DM1_B_ALIM_DM1_STAGING) {

        	try {

        		int length = 0;
		
					this.moment = readDate(dis);
					
					this.pid = readString(dis);
					
					this.father_pid = readString(dis);
					
					this.root_pid = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.system_pid = null;
           				} else {
           			    	this.system_pid = dis.readLong();
           				}
					
					this.project = readString(dis);
					
					this.job = readString(dis);
					
					this.job_repository_id = readString(dis);
					
					this.job_version = readString(dis);
					
					this.context = readString(dis);
					
					this.origin = readString(dis);
					
					this.message_type = readString(dis);
					
					this.message = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.duration = null;
           				} else {
           			    	this.duration = dis.readLong();
           				}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// java.util.Date
				
						writeDate(this.moment,dos);
					
					// String
				
						writeString(this.pid,dos);
					
					// String
				
						writeString(this.father_pid,dos);
					
					// String
				
						writeString(this.root_pid,dos);
					
					// Long
				
						if(this.system_pid == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.system_pid);
		            	}
					
					// String
				
						writeString(this.project,dos);
					
					// String
				
						writeString(this.job,dos);
					
					// String
				
						writeString(this.job_repository_id,dos);
					
					// String
				
						writeString(this.job_version,dos);
					
					// String
				
						writeString(this.context,dos);
					
					// String
				
						writeString(this.origin,dos);
					
					// String
				
						writeString(this.message_type,dos);
					
					// String
				
						writeString(this.message,dos);
					
					// Long
				
						if(this.duration == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.duration);
		            	}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// java.util.Date
				
						writeDate(this.moment,dos);
					
					// String
				
						writeString(this.pid,dos);
					
					// String
				
						writeString(this.father_pid,dos);
					
					// String
				
						writeString(this.root_pid,dos);
					
					// Long
				
						if(this.system_pid == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.system_pid);
		            	}
					
					// String
				
						writeString(this.project,dos);
					
					// String
				
						writeString(this.job,dos);
					
					// String
				
						writeString(this.job_repository_id,dos);
					
					// String
				
						writeString(this.job_version,dos);
					
					// String
				
						writeString(this.context,dos);
					
					// String
				
						writeString(this.origin,dos);
					
					// String
				
						writeString(this.message_type,dos);
					
					// String
				
						writeString(this.message,dos);
					
					// Long
				
						if(this.duration == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.duration);
		            	}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("moment="+String.valueOf(moment));
		sb.append(",pid="+pid);
		sb.append(",father_pid="+father_pid);
		sb.append(",root_pid="+root_pid);
		sb.append(",system_pid="+String.valueOf(system_pid));
		sb.append(",project="+project);
		sb.append(",job="+job);
		sb.append(",job_repository_id="+job_repository_id);
		sb.append(",job_version="+job_version);
		sb.append(",context="+context);
		sb.append(",origin="+origin);
		sb.append(",message_type="+message_type);
		sb.append(",message="+message);
		sb.append(",duration="+String.valueOf(duration));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row1Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tStatCatcher_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tStatCatcher_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row1Struct row1 = new row1Struct();




	
	/**
	 * [tDBOutput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_1", false);
		start_Hash.put("tDBOutput_1", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_1";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row1");
					}
				
		int tos_count_tDBOutput_1 = 0;
		





String dbschema_tDBOutput_1 = null;
	dbschema_tDBOutput_1 = "dsid_liv_met";
	

String tableName_tDBOutput_1 = null;
if(dbschema_tDBOutput_1 == null || dbschema_tDBOutput_1.trim().length() == 0) {
	tableName_tDBOutput_1 = ("JOB_STATS");
} else {
	tableName_tDBOutput_1 = dbschema_tDBOutput_1 + "\".\"" + ("JOB_STATS");
}


int nb_line_tDBOutput_1 = 0;
int nb_line_update_tDBOutput_1 = 0;
int nb_line_inserted_tDBOutput_1 = 0;
int nb_line_deleted_tDBOutput_1 = 0;
int nb_line_rejected_tDBOutput_1 = 0;

int deletedCount_tDBOutput_1=0;
int updatedCount_tDBOutput_1=0;
int insertedCount_tDBOutput_1=0;
int rowsToCommitCount_tDBOutput_1=0;
int rejectedCount_tDBOutput_1=0;

boolean whetherReject_tDBOutput_1 = false;

java.sql.Connection conn_tDBOutput_1 = null;
String dbUser_tDBOutput_1 = null;

	
    java.lang.Class.forName("org.postgresql.Driver");
    
        String url_tDBOutput_1 = "jdbc:postgresql://"+""+":"+"5432"+"/"+"postgres";
    dbUser_tDBOutput_1 = "dsid_cc2_tos_rw";
 
	final String decryptedPassword_tDBOutput_1 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:v2V/2UGk5rZnqlSxRK7in4TlTTew8SXZWLJKe9bgCzw=");

    String dbPwd_tDBOutput_1 = decryptedPassword_tDBOutput_1;

    conn_tDBOutput_1 = java.sql.DriverManager.getConnection(url_tDBOutput_1,dbUser_tDBOutput_1,dbPwd_tDBOutput_1);
	
	resourceMap.put("conn_tDBOutput_1", conn_tDBOutput_1);
        conn_tDBOutput_1.setAutoCommit(false);
        int commitEvery_tDBOutput_1 = 10000;
        int commitCounter_tDBOutput_1 = 0;


   int batchSize_tDBOutput_1 = 10000;
   int batchSizeCounter_tDBOutput_1=0;

int count_tDBOutput_1=0;
	    String insert_tDBOutput_1 = "INSERT INTO \"" + tableName_tDBOutput_1 + "\" (\"moment\",\"pid\",\"father_pid\",\"root_pid\",\"system_pid\",\"project\",\"job\",\"job_repository_id\",\"job_version\",\"context\",\"origin\",\"message_type\",\"message\",\"duration\") VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
	    
	    java.sql.PreparedStatement pstmt_tDBOutput_1 = conn_tDBOutput_1.prepareStatement(insert_tDBOutput_1);
	    resourceMap.put("pstmt_tDBOutput_1", pstmt_tDBOutput_1);
	    

 



/**
 * [tDBOutput_1 begin ] stop
 */



	
	/**
	 * [tStatCatcher_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tStatCatcher_1", false);
		start_Hash.put("tStatCatcher_1", System.currentTimeMillis());
		
	
	currentComponent="tStatCatcher_1";

	
		int tos_count_tStatCatcher_1 = 0;
		

	for (StatCatcherUtils.StatCatcherMessage scm : tStatCatcher_1.getMessages()) {
		row1.pid = pid;
		row1.root_pid = rootPid;
		row1.father_pid = fatherPid;	
    	row1.project = projectName;
    	row1.job = jobName;
    	row1.context = contextStr;
		row1.origin = (scm.getOrigin()==null || scm.getOrigin().length()<1 ? null : scm.getOrigin());
		row1.message = scm.getMessage();
		row1.duration = scm.getDuration();
		row1.moment = scm.getMoment();
		row1.message_type = scm.getMessageType();
		row1.job_version = scm.getJobVersion();
		row1.job_repository_id = scm.getJobId();
		row1.system_pid = scm.getSystemPid();

 



/**
 * [tStatCatcher_1 begin ] stop
 */
	
	/**
	 * [tStatCatcher_1 main ] start
	 */

	

	
	
	currentComponent="tStatCatcher_1";

	

 


	tos_count_tStatCatcher_1++;

/**
 * [tStatCatcher_1 main ] stop
 */
	
	/**
	 * [tStatCatcher_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tStatCatcher_1";

	

 



/**
 * [tStatCatcher_1 process_data_begin ] stop
 */

	
	/**
	 * [tDBOutput_1 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row1"
						
						);
					}
					



        whetherReject_tDBOutput_1 = false;
                    if(row1.moment != null) {
pstmt_tDBOutput_1.setTimestamp(1, new java.sql.Timestamp(row1.moment.getTime()));
} else {
pstmt_tDBOutput_1.setNull(1, java.sql.Types.TIMESTAMP);
}

                    if(row1.pid == null) {
pstmt_tDBOutput_1.setNull(2, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(2, row1.pid);
}

                    if(row1.father_pid == null) {
pstmt_tDBOutput_1.setNull(3, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(3, row1.father_pid);
}

                    if(row1.root_pid == null) {
pstmt_tDBOutput_1.setNull(4, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(4, row1.root_pid);
}

                    if(row1.system_pid == null) {
pstmt_tDBOutput_1.setNull(5, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_1.setLong(5, row1.system_pid);
}

                    if(row1.project == null) {
pstmt_tDBOutput_1.setNull(6, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(6, row1.project);
}

                    if(row1.job == null) {
pstmt_tDBOutput_1.setNull(7, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(7, row1.job);
}

                    if(row1.job_repository_id == null) {
pstmt_tDBOutput_1.setNull(8, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(8, row1.job_repository_id);
}

                    if(row1.job_version == null) {
pstmt_tDBOutput_1.setNull(9, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(9, row1.job_version);
}

                    if(row1.context == null) {
pstmt_tDBOutput_1.setNull(10, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(10, row1.context);
}

                    if(row1.origin == null) {
pstmt_tDBOutput_1.setNull(11, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(11, row1.origin);
}

                    if(row1.message_type == null) {
pstmt_tDBOutput_1.setNull(12, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(12, row1.message_type);
}

                    if(row1.message == null) {
pstmt_tDBOutput_1.setNull(13, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(13, row1.message);
}

                    if(row1.duration == null) {
pstmt_tDBOutput_1.setNull(14, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_1.setLong(14, row1.duration);
}

			
    		pstmt_tDBOutput_1.addBatch();
    		nb_line_tDBOutput_1++;
    		  
    		  
    		  batchSizeCounter_tDBOutput_1++;
    		  
    			if ((batchSize_tDBOutput_1 > 0) && (batchSize_tDBOutput_1 <= batchSizeCounter_tDBOutput_1)) {
                try {
						int countSum_tDBOutput_1 = 0;
						    
						for(int countEach_tDBOutput_1: pstmt_tDBOutput_1.executeBatch()) {
							countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
						}
				    	rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
				    	
				    		insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
				    	
            	    	batchSizeCounter_tDBOutput_1 = 0;
                }catch (java.sql.BatchUpdateException e_tDBOutput_1){
globalMap.put("tDBOutput_1_ERROR_MESSAGE",e_tDBOutput_1.getMessage());
				    	java.sql.SQLException ne_tDBOutput_1 = e_tDBOutput_1.getNextException(),sqle_tDBOutput_1=null;
				    	String errormessage_tDBOutput_1;
						if (ne_tDBOutput_1 != null) {
							// build new exception to provide the original cause
							sqle_tDBOutput_1 = new java.sql.SQLException(e_tDBOutput_1.getMessage() + "\ncaused by: " + ne_tDBOutput_1.getMessage(), ne_tDBOutput_1.getSQLState(), ne_tDBOutput_1.getErrorCode(), ne_tDBOutput_1);
							errormessage_tDBOutput_1 = sqle_tDBOutput_1.getMessage();
						}else{
							errormessage_tDBOutput_1 = e_tDBOutput_1.getMessage();
						}
				    	
				    	int countSum_tDBOutput_1 = 0;
						for(int countEach_tDBOutput_1: e_tDBOutput_1.getUpdateCounts()) {
							countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
						}
						rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
						
				    		insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
				    	
				    	System.err.println(errormessage_tDBOutput_1);
				    	
					}
    			}
    		
    		    commitCounter_tDBOutput_1++;
                if(commitEvery_tDBOutput_1 <= commitCounter_tDBOutput_1) {
                if ((batchSize_tDBOutput_1 > 0) && (batchSizeCounter_tDBOutput_1 > 0)) {
                try {
                		int countSum_tDBOutput_1 = 0;
                		    
						for(int countEach_tDBOutput_1: pstmt_tDBOutput_1.executeBatch()) {
							countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
						}
            	    	rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
            	    	
            	    		insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
            	    	
                batchSizeCounter_tDBOutput_1 = 0;
               }catch (java.sql.BatchUpdateException e_tDBOutput_1){
globalMap.put("tDBOutput_1_ERROR_MESSAGE",e_tDBOutput_1.getMessage());
			    	java.sql.SQLException ne_tDBOutput_1 = e_tDBOutput_1.getNextException(),sqle_tDBOutput_1=null;
			    	String errormessage_tDBOutput_1;
					if (ne_tDBOutput_1 != null) {
						// build new exception to provide the original cause
						sqle_tDBOutput_1 = new java.sql.SQLException(e_tDBOutput_1.getMessage() + "\ncaused by: " + ne_tDBOutput_1.getMessage(), ne_tDBOutput_1.getSQLState(), ne_tDBOutput_1.getErrorCode(), ne_tDBOutput_1);
						errormessage_tDBOutput_1 = sqle_tDBOutput_1.getMessage();
					}else{
						errormessage_tDBOutput_1 = e_tDBOutput_1.getMessage();
					}
			    	
			    	int countSum_tDBOutput_1 = 0;
					for(int countEach_tDBOutput_1: e_tDBOutput_1.getUpdateCounts()) {
						countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
					}
					rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
					
			    		insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
			    	
			    	System.err.println(errormessage_tDBOutput_1);
			    	
				}
            }
                    if(rowsToCommitCount_tDBOutput_1 != 0){
                    	
                    }
                    conn_tDBOutput_1.commit();
                    if(rowsToCommitCount_tDBOutput_1 != 0){
                    	
                    	rowsToCommitCount_tDBOutput_1 = 0;
                    }
                    commitCounter_tDBOutput_1=0;
                }

 


	tos_count_tDBOutput_1++;

/**
 * [tDBOutput_1 main ] stop
 */
	
	/**
	 * [tDBOutput_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";

	

 



/**
 * [tDBOutput_1 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";

	

 



/**
 * [tDBOutput_1 process_data_end ] stop
 */



	
	/**
	 * [tStatCatcher_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tStatCatcher_1";

	

 



/**
 * [tStatCatcher_1 process_data_end ] stop
 */
	
	/**
	 * [tStatCatcher_1 end ] start
	 */

	

	
	
	currentComponent="tStatCatcher_1";

	

	}


 

ok_Hash.put("tStatCatcher_1", true);
end_Hash.put("tStatCatcher_1", System.currentTimeMillis());




/**
 * [tStatCatcher_1 end ] stop
 */

	
	/**
	 * [tDBOutput_1 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";

	



	    try {
				int countSum_tDBOutput_1 = 0;
				if (pstmt_tDBOutput_1 != null && batchSizeCounter_tDBOutput_1 > 0) {
						
					for(int countEach_tDBOutput_1: pstmt_tDBOutput_1.executeBatch()) {
						countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
					}
					rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
						
				}
		    	
		    		insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
		    	
	    }catch (java.sql.BatchUpdateException e_tDBOutput_1){
globalMap.put("tDBOutput_1_ERROR_MESSAGE",e_tDBOutput_1.getMessage());
	    	java.sql.SQLException ne_tDBOutput_1 = e_tDBOutput_1.getNextException(),sqle_tDBOutput_1=null;
	    	String errormessage_tDBOutput_1;
			if (ne_tDBOutput_1 != null) {
				// build new exception to provide the original cause
				sqle_tDBOutput_1 = new java.sql.SQLException(e_tDBOutput_1.getMessage() + "\ncaused by: " + ne_tDBOutput_1.getMessage(), ne_tDBOutput_1.getSQLState(), ne_tDBOutput_1.getErrorCode(), ne_tDBOutput_1);
				errormessage_tDBOutput_1 = sqle_tDBOutput_1.getMessage();
			}else{
				errormessage_tDBOutput_1 = e_tDBOutput_1.getMessage();
			}
	    	
	    	int countSum_tDBOutput_1 = 0;
			for(int countEach_tDBOutput_1: e_tDBOutput_1.getUpdateCounts()) {
				countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
			}
			rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
			
	    		insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
	    	
	    	System.err.println(errormessage_tDBOutput_1);
	    	
		}
	    
        if(pstmt_tDBOutput_1 != null) {
        		
            pstmt_tDBOutput_1.close();
            resourceMap.remove("pstmt_tDBOutput_1");
        }
    resourceMap.put("statementClosed_tDBOutput_1", true);
			if(rowsToCommitCount_tDBOutput_1 != 0){
				
			}
			conn_tDBOutput_1.commit();
			if(rowsToCommitCount_tDBOutput_1 != 0){
				
				rowsToCommitCount_tDBOutput_1 = 0;
			}
			commitCounter_tDBOutput_1 = 0;
		
    	conn_tDBOutput_1 .close();
    	
    	resourceMap.put("finish_tDBOutput_1", true);
    	

	nb_line_deleted_tDBOutput_1=nb_line_deleted_tDBOutput_1+ deletedCount_tDBOutput_1;
	nb_line_update_tDBOutput_1=nb_line_update_tDBOutput_1 + updatedCount_tDBOutput_1;
	nb_line_inserted_tDBOutput_1=nb_line_inserted_tDBOutput_1 + insertedCount_tDBOutput_1;
	nb_line_rejected_tDBOutput_1=nb_line_rejected_tDBOutput_1 + rejectedCount_tDBOutput_1;
	
        globalMap.put("tDBOutput_1_NB_LINE",nb_line_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_UPDATED",nb_line_update_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_DELETED",nb_line_deleted_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_1);
    

	


				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row1");
			  	}
			  	
 

ok_Hash.put("tDBOutput_1", true);
end_Hash.put("tDBOutput_1", System.currentTimeMillis());




/**
 * [tDBOutput_1 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tStatCatcher_1 finally ] start
	 */

	

	
	
	currentComponent="tStatCatcher_1";

	

 



/**
 * [tStatCatcher_1 finally ] stop
 */

	
	/**
	 * [tDBOutput_1 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";

	



    try {
    if (resourceMap.get("statementClosed_tDBOutput_1") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_1 = null;
                if ((pstmtToClose_tDBOutput_1 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_1")) != null) {
                    pstmtToClose_tDBOutput_1.close();
                }
    }
    } finally {
        if(resourceMap.get("finish_tDBOutput_1") == null){
            java.sql.Connection ctn_tDBOutput_1 = null;
            if((ctn_tDBOutput_1 = (java.sql.Connection)resourceMap.get("conn_tDBOutput_1")) != null){
                try {
                    ctn_tDBOutput_1.close();
                } catch (java.sql.SQLException sqlEx_tDBOutput_1) {
                    String errorMessage_tDBOutput_1 = "failed to close the connection in tDBOutput_1 :" + sqlEx_tDBOutput_1.getMessage();
                    System.err.println(errorMessage_tDBOutput_1);
                }
            }
        }
    }
 



/**
 * [tDBOutput_1 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tStatCatcher_1_SUBPROCESS_STATE", 1);
	}
	


public static class alimentation_dm1_stagingStruct implements routines.system.IPersistableRow<alimentation_dm1_stagingStruct> {
    final static byte[] commonByteArrayLock_ALIMENTATION_DM1_B_ALIM_DM1_STAGING = new byte[0];
    static byte[] commonByteArray_ALIMENTATION_DM1_B_ALIM_DM1_STAGING = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int id_staging_dm1;

				public int getId_staging_dm1 () {
					return this.id_staging_dm1;
				}
				
			    public Integer id_preparation;

				public Integer getId_preparation () {
					return this.id_preparation;
				}
				
			    public java.util.Date date_debut_preparation;

				public java.util.Date getDate_debut_preparation () {
					return this.date_debut_preparation;
				}
				
			    public java.util.Date date_fin_preparation;

				public java.util.Date getDate_fin_preparation () {
					return this.date_fin_preparation;
				}
				
			    public Integer id_moyen_paiement;

				public Integer getId_moyen_paiement () {
					return this.id_moyen_paiement;
				}
				
			    public String code_moyen_paiement;

				public String getCode_moyen_paiement () {
					return this.code_moyen_paiement;
				}
				
			    public String livelle_moyen_paiement;

				public String getLivelle_moyen_paiement () {
					return this.livelle_moyen_paiement;
				}
				
			    public Integer id_menu;

				public Integer getId_menu () {
					return this.id_menu;
				}
				
			    public String code_menu;

				public String getCode_menu () {
					return this.code_menu;
				}
				
			    public String libelle_menu;

				public String getLibelle_menu () {
					return this.libelle_menu;
				}
				
			    public Integer nombre_articles;

				public Integer getNombre_articles () {
					return this.nombre_articles;
				}
				
			    public String temps_theo_preparation;

				public String getTemps_theo_preparation () {
					return this.temps_theo_preparation;
				}
				
			    public Integer id_commande;

				public Integer getId_commande () {
					return this.id_commande;
				}
				
			    public Integer numero_commande;

				public Integer getNumero_commande () {
					return this.numero_commande;
				}
				
			    public java.util.Date date_commande;

				public java.util.Date getDate_commande () {
					return this.date_commande;
				}
				
			    public Float montant_total;

				public Float getMontant_total () {
					return this.montant_total;
				}
				
			    public Integer id_adresse_norm_restaurant;

				public Integer getId_adresse_norm_restaurant () {
					return this.id_adresse_norm_restaurant;
				}
				
			    public String numero_voie_restau;

				public String getNumero_voie_restau () {
					return this.numero_voie_restau;
				}
				
			    public String nom_voie_restau;

				public String getNom_voie_restau () {
					return this.nom_voie_restau;
				}
				
			    public String code_postal_restau;

				public String getCode_postal_restau () {
					return this.code_postal_restau;
				}
				
			    public String nom_ville_restau;

				public String getNom_ville_restau () {
					return this.nom_ville_restau;
				}
				
			    public String longitude_restau;

				public String getLongitude_restau () {
					return this.longitude_restau;
				}
				
			    public String latitude_restau;

				public String getLatitude_restau () {
					return this.latitude_restau;
				}
				
			    public Integer id_adresse_restaurant;

				public Integer getId_adresse_restaurant () {
					return this.id_adresse_restaurant;
				}
				
			    public String adresse_restaurant;

				public String getAdresse_restaurant () {
					return this.adresse_restaurant;
				}
				
			    public Integer id_restaurant;

				public Integer getId_restaurant () {
					return this.id_restaurant;
				}
				
			    public String code_restaurant;

				public String getCode_restaurant () {
					return this.code_restaurant;
				}
				
			    public String raison_sociale_restaurant;

				public String getRaison_sociale_restaurant () {
					return this.raison_sociale_restaurant;
				}
				
			    public Integer id_adresse_norm_client;

				public Integer getId_adresse_norm_client () {
					return this.id_adresse_norm_client;
				}
				
			    public String numero_voie;

				public String getNumero_voie () {
					return this.numero_voie;
				}
				
			    public String nom_voie;

				public String getNom_voie () {
					return this.nom_voie;
				}
				
			    public String code_postal;

				public String getCode_postal () {
					return this.code_postal;
				}
				
			    public String nom_ville;

				public String getNom_ville () {
					return this.nom_ville;
				}
				
			    public String longitude;

				public String getLongitude () {
					return this.longitude;
				}
				
			    public String latitude;

				public String getLatitude () {
					return this.latitude;
				}
				
			    public Integer id_adresse_client;

				public Integer getId_adresse_client () {
					return this.id_adresse_client;
				}
				
			    public String adresse_client;

				public String getAdresse_client () {
					return this.adresse_client;
				}
				
			    public Integer id_client;

				public Integer getId_client () {
					return this.id_client;
				}
				
			    public String nom_client;

				public String getNom_client () {
					return this.nom_client;
				}
				
			    public String prenom_client;

				public String getPrenom_client () {
					return this.prenom_client;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.id_staging_dm1;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final alimentation_dm1_stagingStruct other = (alimentation_dm1_stagingStruct) obj;
		
						if (this.id_staging_dm1 != other.id_staging_dm1)
							return false;
					

		return true;
    }

	public void copyDataTo(alimentation_dm1_stagingStruct other) {

		other.id_staging_dm1 = this.id_staging_dm1;
	            other.id_preparation = this.id_preparation;
	            other.date_debut_preparation = this.date_debut_preparation;
	            other.date_fin_preparation = this.date_fin_preparation;
	            other.id_moyen_paiement = this.id_moyen_paiement;
	            other.code_moyen_paiement = this.code_moyen_paiement;
	            other.livelle_moyen_paiement = this.livelle_moyen_paiement;
	            other.id_menu = this.id_menu;
	            other.code_menu = this.code_menu;
	            other.libelle_menu = this.libelle_menu;
	            other.nombre_articles = this.nombre_articles;
	            other.temps_theo_preparation = this.temps_theo_preparation;
	            other.id_commande = this.id_commande;
	            other.numero_commande = this.numero_commande;
	            other.date_commande = this.date_commande;
	            other.montant_total = this.montant_total;
	            other.id_adresse_norm_restaurant = this.id_adresse_norm_restaurant;
	            other.numero_voie_restau = this.numero_voie_restau;
	            other.nom_voie_restau = this.nom_voie_restau;
	            other.code_postal_restau = this.code_postal_restau;
	            other.nom_ville_restau = this.nom_ville_restau;
	            other.longitude_restau = this.longitude_restau;
	            other.latitude_restau = this.latitude_restau;
	            other.id_adresse_restaurant = this.id_adresse_restaurant;
	            other.adresse_restaurant = this.adresse_restaurant;
	            other.id_restaurant = this.id_restaurant;
	            other.code_restaurant = this.code_restaurant;
	            other.raison_sociale_restaurant = this.raison_sociale_restaurant;
	            other.id_adresse_norm_client = this.id_adresse_norm_client;
	            other.numero_voie = this.numero_voie;
	            other.nom_voie = this.nom_voie;
	            other.code_postal = this.code_postal;
	            other.nom_ville = this.nom_ville;
	            other.longitude = this.longitude;
	            other.latitude = this.latitude;
	            other.id_adresse_client = this.id_adresse_client;
	            other.adresse_client = this.adresse_client;
	            other.id_client = this.id_client;
	            other.nom_client = this.nom_client;
	            other.prenom_client = this.prenom_client;
	            
	}

	public void copyKeysDataTo(alimentation_dm1_stagingStruct other) {

		other.id_staging_dm1 = this.id_staging_dm1;
	            	
	}



	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_DM1_B_ALIM_DM1_STAGING.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_DM1_B_ALIM_DM1_STAGING.length == 0) {
   					commonByteArray_ALIMENTATION_DM1_B_ALIM_DM1_STAGING = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_DM1_B_ALIM_DM1_STAGING = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ALIMENTATION_DM1_B_ALIM_DM1_STAGING, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_DM1_B_ALIM_DM1_STAGING, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_DM1_B_ALIM_DM1_STAGING.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_DM1_B_ALIM_DM1_STAGING.length == 0) {
   					commonByteArray_ALIMENTATION_DM1_B_ALIM_DM1_STAGING = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_DM1_B_ALIM_DM1_STAGING = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ALIMENTATION_DM1_B_ALIM_DM1_STAGING, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_DM1_B_ALIM_DM1_STAGING, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_DM1_B_ALIM_DM1_STAGING) {

        	try {

        		int length = 0;
		
			        this.id_staging_dm1 = dis.readInt();
					
						this.id_preparation = readInteger(dis);
					
					this.date_debut_preparation = readDate(dis);
					
					this.date_fin_preparation = readDate(dis);
					
						this.id_moyen_paiement = readInteger(dis);
					
					this.code_moyen_paiement = readString(dis);
					
					this.livelle_moyen_paiement = readString(dis);
					
						this.id_menu = readInteger(dis);
					
					this.code_menu = readString(dis);
					
					this.libelle_menu = readString(dis);
					
						this.nombre_articles = readInteger(dis);
					
					this.temps_theo_preparation = readString(dis);
					
						this.id_commande = readInteger(dis);
					
						this.numero_commande = readInteger(dis);
					
					this.date_commande = readDate(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.montant_total = null;
           				} else {
           			    	this.montant_total = dis.readFloat();
           				}
					
						this.id_adresse_norm_restaurant = readInteger(dis);
					
					this.numero_voie_restau = readString(dis);
					
					this.nom_voie_restau = readString(dis);
					
					this.code_postal_restau = readString(dis);
					
					this.nom_ville_restau = readString(dis);
					
					this.longitude_restau = readString(dis);
					
					this.latitude_restau = readString(dis);
					
						this.id_adresse_restaurant = readInteger(dis);
					
					this.adresse_restaurant = readString(dis);
					
						this.id_restaurant = readInteger(dis);
					
					this.code_restaurant = readString(dis);
					
					this.raison_sociale_restaurant = readString(dis);
					
						this.id_adresse_norm_client = readInteger(dis);
					
					this.numero_voie = readString(dis);
					
					this.nom_voie = readString(dis);
					
					this.code_postal = readString(dis);
					
					this.nom_ville = readString(dis);
					
					this.longitude = readString(dis);
					
					this.latitude = readString(dis);
					
						this.id_adresse_client = readInteger(dis);
					
					this.adresse_client = readString(dis);
					
						this.id_client = readInteger(dis);
					
					this.nom_client = readString(dis);
					
					this.prenom_client = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_DM1_B_ALIM_DM1_STAGING) {

        	try {

        		int length = 0;
		
			        this.id_staging_dm1 = dis.readInt();
					
						this.id_preparation = readInteger(dis);
					
					this.date_debut_preparation = readDate(dis);
					
					this.date_fin_preparation = readDate(dis);
					
						this.id_moyen_paiement = readInteger(dis);
					
					this.code_moyen_paiement = readString(dis);
					
					this.livelle_moyen_paiement = readString(dis);
					
						this.id_menu = readInteger(dis);
					
					this.code_menu = readString(dis);
					
					this.libelle_menu = readString(dis);
					
						this.nombre_articles = readInteger(dis);
					
					this.temps_theo_preparation = readString(dis);
					
						this.id_commande = readInteger(dis);
					
						this.numero_commande = readInteger(dis);
					
					this.date_commande = readDate(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.montant_total = null;
           				} else {
           			    	this.montant_total = dis.readFloat();
           				}
					
						this.id_adresse_norm_restaurant = readInteger(dis);
					
					this.numero_voie_restau = readString(dis);
					
					this.nom_voie_restau = readString(dis);
					
					this.code_postal_restau = readString(dis);
					
					this.nom_ville_restau = readString(dis);
					
					this.longitude_restau = readString(dis);
					
					this.latitude_restau = readString(dis);
					
						this.id_adresse_restaurant = readInteger(dis);
					
					this.adresse_restaurant = readString(dis);
					
						this.id_restaurant = readInteger(dis);
					
					this.code_restaurant = readString(dis);
					
					this.raison_sociale_restaurant = readString(dis);
					
						this.id_adresse_norm_client = readInteger(dis);
					
					this.numero_voie = readString(dis);
					
					this.nom_voie = readString(dis);
					
					this.code_postal = readString(dis);
					
					this.nom_ville = readString(dis);
					
					this.longitude = readString(dis);
					
					this.latitude = readString(dis);
					
						this.id_adresse_client = readInteger(dis);
					
					this.adresse_client = readString(dis);
					
						this.id_client = readInteger(dis);
					
					this.nom_client = readString(dis);
					
					this.prenom_client = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id_staging_dm1);
					
					// Integer
				
						writeInteger(this.id_preparation,dos);
					
					// java.util.Date
				
						writeDate(this.date_debut_preparation,dos);
					
					// java.util.Date
				
						writeDate(this.date_fin_preparation,dos);
					
					// Integer
				
						writeInteger(this.id_moyen_paiement,dos);
					
					// String
				
						writeString(this.code_moyen_paiement,dos);
					
					// String
				
						writeString(this.livelle_moyen_paiement,dos);
					
					// Integer
				
						writeInteger(this.id_menu,dos);
					
					// String
				
						writeString(this.code_menu,dos);
					
					// String
				
						writeString(this.libelle_menu,dos);
					
					// Integer
				
						writeInteger(this.nombre_articles,dos);
					
					// String
				
						writeString(this.temps_theo_preparation,dos);
					
					// Integer
				
						writeInteger(this.id_commande,dos);
					
					// Integer
				
						writeInteger(this.numero_commande,dos);
					
					// java.util.Date
				
						writeDate(this.date_commande,dos);
					
					// Float
				
						if(this.montant_total == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.montant_total);
		            	}
					
					// Integer
				
						writeInteger(this.id_adresse_norm_restaurant,dos);
					
					// String
				
						writeString(this.numero_voie_restau,dos);
					
					// String
				
						writeString(this.nom_voie_restau,dos);
					
					// String
				
						writeString(this.code_postal_restau,dos);
					
					// String
				
						writeString(this.nom_ville_restau,dos);
					
					// String
				
						writeString(this.longitude_restau,dos);
					
					// String
				
						writeString(this.latitude_restau,dos);
					
					// Integer
				
						writeInteger(this.id_adresse_restaurant,dos);
					
					// String
				
						writeString(this.adresse_restaurant,dos);
					
					// Integer
				
						writeInteger(this.id_restaurant,dos);
					
					// String
				
						writeString(this.code_restaurant,dos);
					
					// String
				
						writeString(this.raison_sociale_restaurant,dos);
					
					// Integer
				
						writeInteger(this.id_adresse_norm_client,dos);
					
					// String
				
						writeString(this.numero_voie,dos);
					
					// String
				
						writeString(this.nom_voie,dos);
					
					// String
				
						writeString(this.code_postal,dos);
					
					// String
				
						writeString(this.nom_ville,dos);
					
					// String
				
						writeString(this.longitude,dos);
					
					// String
				
						writeString(this.latitude,dos);
					
					// Integer
				
						writeInteger(this.id_adresse_client,dos);
					
					// String
				
						writeString(this.adresse_client,dos);
					
					// Integer
				
						writeInteger(this.id_client,dos);
					
					// String
				
						writeString(this.nom_client,dos);
					
					// String
				
						writeString(this.prenom_client,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id_staging_dm1);
					
					// Integer
				
						writeInteger(this.id_preparation,dos);
					
					// java.util.Date
				
						writeDate(this.date_debut_preparation,dos);
					
					// java.util.Date
				
						writeDate(this.date_fin_preparation,dos);
					
					// Integer
				
						writeInteger(this.id_moyen_paiement,dos);
					
					// String
				
						writeString(this.code_moyen_paiement,dos);
					
					// String
				
						writeString(this.livelle_moyen_paiement,dos);
					
					// Integer
				
						writeInteger(this.id_menu,dos);
					
					// String
				
						writeString(this.code_menu,dos);
					
					// String
				
						writeString(this.libelle_menu,dos);
					
					// Integer
				
						writeInteger(this.nombre_articles,dos);
					
					// String
				
						writeString(this.temps_theo_preparation,dos);
					
					// Integer
				
						writeInteger(this.id_commande,dos);
					
					// Integer
				
						writeInteger(this.numero_commande,dos);
					
					// java.util.Date
				
						writeDate(this.date_commande,dos);
					
					// Float
				
						if(this.montant_total == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.montant_total);
		            	}
					
					// Integer
				
						writeInteger(this.id_adresse_norm_restaurant,dos);
					
					// String
				
						writeString(this.numero_voie_restau,dos);
					
					// String
				
						writeString(this.nom_voie_restau,dos);
					
					// String
				
						writeString(this.code_postal_restau,dos);
					
					// String
				
						writeString(this.nom_ville_restau,dos);
					
					// String
				
						writeString(this.longitude_restau,dos);
					
					// String
				
						writeString(this.latitude_restau,dos);
					
					// Integer
				
						writeInteger(this.id_adresse_restaurant,dos);
					
					// String
				
						writeString(this.adresse_restaurant,dos);
					
					// Integer
				
						writeInteger(this.id_restaurant,dos);
					
					// String
				
						writeString(this.code_restaurant,dos);
					
					// String
				
						writeString(this.raison_sociale_restaurant,dos);
					
					// Integer
				
						writeInteger(this.id_adresse_norm_client,dos);
					
					// String
				
						writeString(this.numero_voie,dos);
					
					// String
				
						writeString(this.nom_voie,dos);
					
					// String
				
						writeString(this.code_postal,dos);
					
					// String
				
						writeString(this.nom_ville,dos);
					
					// String
				
						writeString(this.longitude,dos);
					
					// String
				
						writeString(this.latitude,dos);
					
					// Integer
				
						writeInteger(this.id_adresse_client,dos);
					
					// String
				
						writeString(this.adresse_client,dos);
					
					// Integer
				
						writeInteger(this.id_client,dos);
					
					// String
				
						writeString(this.nom_client,dos);
					
					// String
				
						writeString(this.prenom_client,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id_staging_dm1="+String.valueOf(id_staging_dm1));
		sb.append(",id_preparation="+String.valueOf(id_preparation));
		sb.append(",date_debut_preparation="+String.valueOf(date_debut_preparation));
		sb.append(",date_fin_preparation="+String.valueOf(date_fin_preparation));
		sb.append(",id_moyen_paiement="+String.valueOf(id_moyen_paiement));
		sb.append(",code_moyen_paiement="+code_moyen_paiement);
		sb.append(",livelle_moyen_paiement="+livelle_moyen_paiement);
		sb.append(",id_menu="+String.valueOf(id_menu));
		sb.append(",code_menu="+code_menu);
		sb.append(",libelle_menu="+libelle_menu);
		sb.append(",nombre_articles="+String.valueOf(nombre_articles));
		sb.append(",temps_theo_preparation="+temps_theo_preparation);
		sb.append(",id_commande="+String.valueOf(id_commande));
		sb.append(",numero_commande="+String.valueOf(numero_commande));
		sb.append(",date_commande="+String.valueOf(date_commande));
		sb.append(",montant_total="+String.valueOf(montant_total));
		sb.append(",id_adresse_norm_restaurant="+String.valueOf(id_adresse_norm_restaurant));
		sb.append(",numero_voie_restau="+numero_voie_restau);
		sb.append(",nom_voie_restau="+nom_voie_restau);
		sb.append(",code_postal_restau="+code_postal_restau);
		sb.append(",nom_ville_restau="+nom_ville_restau);
		sb.append(",longitude_restau="+longitude_restau);
		sb.append(",latitude_restau="+latitude_restau);
		sb.append(",id_adresse_restaurant="+String.valueOf(id_adresse_restaurant));
		sb.append(",adresse_restaurant="+adresse_restaurant);
		sb.append(",id_restaurant="+String.valueOf(id_restaurant));
		sb.append(",code_restaurant="+code_restaurant);
		sb.append(",raison_sociale_restaurant="+raison_sociale_restaurant);
		sb.append(",id_adresse_norm_client="+String.valueOf(id_adresse_norm_client));
		sb.append(",numero_voie="+numero_voie);
		sb.append(",nom_voie="+nom_voie);
		sb.append(",code_postal="+code_postal);
		sb.append(",nom_ville="+nom_ville);
		sb.append(",longitude="+longitude);
		sb.append(",latitude="+latitude);
		sb.append(",id_adresse_client="+String.valueOf(id_adresse_client));
		sb.append(",adresse_client="+adresse_client);
		sb.append(",id_client="+String.valueOf(id_client));
		sb.append(",nom_client="+nom_client);
		sb.append(",prenom_client="+prenom_client);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(alimentation_dm1_stagingStruct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.id_staging_dm1, other.id_staging_dm1);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row2Struct implements routines.system.IPersistableRow<row2Struct> {
    final static byte[] commonByteArrayLock_ALIMENTATION_DM1_B_ALIM_DM1_STAGING = new byte[0];
    static byte[] commonByteArray_ALIMENTATION_DM1_B_ALIM_DM1_STAGING = new byte[0];

	
			    public Integer ID_COMMANDE;

				public Integer getID_COMMANDE () {
					return this.ID_COMMANDE;
				}
				
			    public Integer NUMERO_COMMANDE;

				public Integer getNUMERO_COMMANDE () {
					return this.NUMERO_COMMANDE;
				}
				
			    public java.util.Date DATE_COMMANDE;

				public java.util.Date getDATE_COMMANDE () {
					return this.DATE_COMMANDE;
				}
				
			    public Float MONTANT_TOTAL;

				public Float getMONTANT_TOTAL () {
					return this.MONTANT_TOTAL;
				}
				
			    public Integer ID_MENU;

				public Integer getID_MENU () {
					return this.ID_MENU;
				}
				
			    public String CODE_MENU;

				public String getCODE_MENU () {
					return this.CODE_MENU;
				}
				
			    public String LIBELLE_MENU;

				public String getLIBELLE_MENU () {
					return this.LIBELLE_MENU;
				}
				
			    public Integer NOMBRE_ARTICLES;

				public Integer getNOMBRE_ARTICLES () {
					return this.NOMBRE_ARTICLES;
				}
				
			    public String TEMPS_THEO_PREPARATION;

				public String getTEMPS_THEO_PREPARATION () {
					return this.TEMPS_THEO_PREPARATION;
				}
				
			    public Integer ID_PREPARATION;

				public Integer getID_PREPARATION () {
					return this.ID_PREPARATION;
				}
				
			    public java.util.Date DATE_DEBUT_PREPARATION;

				public java.util.Date getDATE_DEBUT_PREPARATION () {
					return this.DATE_DEBUT_PREPARATION;
				}
				
			    public java.util.Date DATE_FIN_PREPARATION;

				public java.util.Date getDATE_FIN_PREPARATION () {
					return this.DATE_FIN_PREPARATION;
				}
				
			    public Integer ID_ADRESSE_NORM_CLIENT;

				public Integer getID_ADRESSE_NORM_CLIENT () {
					return this.ID_ADRESSE_NORM_CLIENT;
				}
				
			    public String NUMERO_VOIE;

				public String getNUMERO_VOIE () {
					return this.NUMERO_VOIE;
				}
				
			    public String NOM_VOIE;

				public String getNOM_VOIE () {
					return this.NOM_VOIE;
				}
				
			    public String CODE_POSTAL;

				public String getCODE_POSTAL () {
					return this.CODE_POSTAL;
				}
				
			    public String NOM_VILLE;

				public String getNOM_VILLE () {
					return this.NOM_VILLE;
				}
				
			    public String LONGITUDE;

				public String getLONGITUDE () {
					return this.LONGITUDE;
				}
				
			    public String LATITUDE;

				public String getLATITUDE () {
					return this.LATITUDE;
				}
				
			    public Integer ID_ADRESSE_RESTAURANT;

				public Integer getID_ADRESSE_RESTAURANT () {
					return this.ID_ADRESSE_RESTAURANT;
				}
				
			    public String ADRESSE_RESTAURANT;

				public String getADRESSE_RESTAURANT () {
					return this.ADRESSE_RESTAURANT;
				}
				
			    public Integer ID_CLIENT;

				public Integer getID_CLIENT () {
					return this.ID_CLIENT;
				}
				
			    public Integer ID_ADRESSE_CLIENT;

				public Integer getID_ADRESSE_CLIENT () {
					return this.ID_ADRESSE_CLIENT;
				}
				
			    public String ADRESSE_CLIENT;

				public String getADRESSE_CLIENT () {
					return this.ADRESSE_CLIENT;
				}
				
			    public Integer ID_RESTAURANT;

				public Integer getID_RESTAURANT () {
					return this.ID_RESTAURANT;
				}
				
			    public String CODE_RESTAURANT;

				public String getCODE_RESTAURANT () {
					return this.CODE_RESTAURANT;
				}
				
			    public String RAISON_SOCIALE_RESTAURANT;

				public String getRAISON_SOCIALE_RESTAURANT () {
					return this.RAISON_SOCIALE_RESTAURANT;
				}
				
			    public Integer ID_ADRESSE_NORM_RESTAURANT;

				public Integer getID_ADRESSE_NORM_RESTAURANT () {
					return this.ID_ADRESSE_NORM_RESTAURANT;
				}
				
			    public Integer ID_MOYEN_PAIEMENT;

				public Integer getID_MOYEN_PAIEMENT () {
					return this.ID_MOYEN_PAIEMENT;
				}
				
			    public String CODE_MOYEN_PAIEMENT;

				public String getCODE_MOYEN_PAIEMENT () {
					return this.CODE_MOYEN_PAIEMENT;
				}
				
			    public String LIVELLE_MOYEN_PAIEMENT;

				public String getLIVELLE_MOYEN_PAIEMENT () {
					return this.LIVELLE_MOYEN_PAIEMENT;
				}
				
			    public String NOM_CLIENT;

				public String getNOM_CLIENT () {
					return this.NOM_CLIENT;
				}
				
			    public String PRENOM_CLIENT;

				public String getPRENOM_CLIENT () {
					return this.PRENOM_CLIENT;
				}
				
			    public String LATITUDE_RESTAU;

				public String getLATITUDE_RESTAU () {
					return this.LATITUDE_RESTAU;
				}
				
			    public String LONGITUDE_RESTAU;

				public String getLONGITUDE_RESTAU () {
					return this.LONGITUDE_RESTAU;
				}
				
			    public String NOM_VILLE_RESTAU;

				public String getNOM_VILLE_RESTAU () {
					return this.NOM_VILLE_RESTAU;
				}
				
			    public String CODE_POSTAL_RESTAU;

				public String getCODE_POSTAL_RESTAU () {
					return this.CODE_POSTAL_RESTAU;
				}
				
			    public String NOM_VOIE_RESTAU;

				public String getNOM_VOIE_RESTAU () {
					return this.NOM_VOIE_RESTAU;
				}
				
			    public String NUMERO_VOIE_RESTAU;

				public String getNUMERO_VOIE_RESTAU () {
					return this.NUMERO_VOIE_RESTAU;
				}
				


	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_DM1_B_ALIM_DM1_STAGING.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_DM1_B_ALIM_DM1_STAGING.length == 0) {
   					commonByteArray_ALIMENTATION_DM1_B_ALIM_DM1_STAGING = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_DM1_B_ALIM_DM1_STAGING = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ALIMENTATION_DM1_B_ALIM_DM1_STAGING, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_DM1_B_ALIM_DM1_STAGING, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_DM1_B_ALIM_DM1_STAGING.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_DM1_B_ALIM_DM1_STAGING.length == 0) {
   					commonByteArray_ALIMENTATION_DM1_B_ALIM_DM1_STAGING = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_DM1_B_ALIM_DM1_STAGING = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ALIMENTATION_DM1_B_ALIM_DM1_STAGING, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_DM1_B_ALIM_DM1_STAGING, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_DM1_B_ALIM_DM1_STAGING) {

        	try {

        		int length = 0;
		
						this.ID_COMMANDE = readInteger(dis);
					
						this.NUMERO_COMMANDE = readInteger(dis);
					
					this.DATE_COMMANDE = readDate(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.MONTANT_TOTAL = null;
           				} else {
           			    	this.MONTANT_TOTAL = dis.readFloat();
           				}
					
						this.ID_MENU = readInteger(dis);
					
					this.CODE_MENU = readString(dis);
					
					this.LIBELLE_MENU = readString(dis);
					
						this.NOMBRE_ARTICLES = readInteger(dis);
					
					this.TEMPS_THEO_PREPARATION = readString(dis);
					
						this.ID_PREPARATION = readInteger(dis);
					
					this.DATE_DEBUT_PREPARATION = readDate(dis);
					
					this.DATE_FIN_PREPARATION = readDate(dis);
					
						this.ID_ADRESSE_NORM_CLIENT = readInteger(dis);
					
					this.NUMERO_VOIE = readString(dis);
					
					this.NOM_VOIE = readString(dis);
					
					this.CODE_POSTAL = readString(dis);
					
					this.NOM_VILLE = readString(dis);
					
					this.LONGITUDE = readString(dis);
					
					this.LATITUDE = readString(dis);
					
						this.ID_ADRESSE_RESTAURANT = readInteger(dis);
					
					this.ADRESSE_RESTAURANT = readString(dis);
					
						this.ID_CLIENT = readInteger(dis);
					
						this.ID_ADRESSE_CLIENT = readInteger(dis);
					
					this.ADRESSE_CLIENT = readString(dis);
					
						this.ID_RESTAURANT = readInteger(dis);
					
					this.CODE_RESTAURANT = readString(dis);
					
					this.RAISON_SOCIALE_RESTAURANT = readString(dis);
					
						this.ID_ADRESSE_NORM_RESTAURANT = readInteger(dis);
					
						this.ID_MOYEN_PAIEMENT = readInteger(dis);
					
					this.CODE_MOYEN_PAIEMENT = readString(dis);
					
					this.LIVELLE_MOYEN_PAIEMENT = readString(dis);
					
					this.NOM_CLIENT = readString(dis);
					
					this.PRENOM_CLIENT = readString(dis);
					
					this.LATITUDE_RESTAU = readString(dis);
					
					this.LONGITUDE_RESTAU = readString(dis);
					
					this.NOM_VILLE_RESTAU = readString(dis);
					
					this.CODE_POSTAL_RESTAU = readString(dis);
					
					this.NOM_VOIE_RESTAU = readString(dis);
					
					this.NUMERO_VOIE_RESTAU = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_DM1_B_ALIM_DM1_STAGING) {

        	try {

        		int length = 0;
		
						this.ID_COMMANDE = readInteger(dis);
					
						this.NUMERO_COMMANDE = readInteger(dis);
					
					this.DATE_COMMANDE = readDate(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.MONTANT_TOTAL = null;
           				} else {
           			    	this.MONTANT_TOTAL = dis.readFloat();
           				}
					
						this.ID_MENU = readInteger(dis);
					
					this.CODE_MENU = readString(dis);
					
					this.LIBELLE_MENU = readString(dis);
					
						this.NOMBRE_ARTICLES = readInteger(dis);
					
					this.TEMPS_THEO_PREPARATION = readString(dis);
					
						this.ID_PREPARATION = readInteger(dis);
					
					this.DATE_DEBUT_PREPARATION = readDate(dis);
					
					this.DATE_FIN_PREPARATION = readDate(dis);
					
						this.ID_ADRESSE_NORM_CLIENT = readInteger(dis);
					
					this.NUMERO_VOIE = readString(dis);
					
					this.NOM_VOIE = readString(dis);
					
					this.CODE_POSTAL = readString(dis);
					
					this.NOM_VILLE = readString(dis);
					
					this.LONGITUDE = readString(dis);
					
					this.LATITUDE = readString(dis);
					
						this.ID_ADRESSE_RESTAURANT = readInteger(dis);
					
					this.ADRESSE_RESTAURANT = readString(dis);
					
						this.ID_CLIENT = readInteger(dis);
					
						this.ID_ADRESSE_CLIENT = readInteger(dis);
					
					this.ADRESSE_CLIENT = readString(dis);
					
						this.ID_RESTAURANT = readInteger(dis);
					
					this.CODE_RESTAURANT = readString(dis);
					
					this.RAISON_SOCIALE_RESTAURANT = readString(dis);
					
						this.ID_ADRESSE_NORM_RESTAURANT = readInteger(dis);
					
						this.ID_MOYEN_PAIEMENT = readInteger(dis);
					
					this.CODE_MOYEN_PAIEMENT = readString(dis);
					
					this.LIVELLE_MOYEN_PAIEMENT = readString(dis);
					
					this.NOM_CLIENT = readString(dis);
					
					this.PRENOM_CLIENT = readString(dis);
					
					this.LATITUDE_RESTAU = readString(dis);
					
					this.LONGITUDE_RESTAU = readString(dis);
					
					this.NOM_VILLE_RESTAU = readString(dis);
					
					this.CODE_POSTAL_RESTAU = readString(dis);
					
					this.NOM_VOIE_RESTAU = readString(dis);
					
					this.NUMERO_VOIE_RESTAU = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Integer
				
						writeInteger(this.ID_COMMANDE,dos);
					
					// Integer
				
						writeInteger(this.NUMERO_COMMANDE,dos);
					
					// java.util.Date
				
						writeDate(this.DATE_COMMANDE,dos);
					
					// Float
				
						if(this.MONTANT_TOTAL == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.MONTANT_TOTAL);
		            	}
					
					// Integer
				
						writeInteger(this.ID_MENU,dos);
					
					// String
				
						writeString(this.CODE_MENU,dos);
					
					// String
				
						writeString(this.LIBELLE_MENU,dos);
					
					// Integer
				
						writeInteger(this.NOMBRE_ARTICLES,dos);
					
					// String
				
						writeString(this.TEMPS_THEO_PREPARATION,dos);
					
					// Integer
				
						writeInteger(this.ID_PREPARATION,dos);
					
					// java.util.Date
				
						writeDate(this.DATE_DEBUT_PREPARATION,dos);
					
					// java.util.Date
				
						writeDate(this.DATE_FIN_PREPARATION,dos);
					
					// Integer
				
						writeInteger(this.ID_ADRESSE_NORM_CLIENT,dos);
					
					// String
				
						writeString(this.NUMERO_VOIE,dos);
					
					// String
				
						writeString(this.NOM_VOIE,dos);
					
					// String
				
						writeString(this.CODE_POSTAL,dos);
					
					// String
				
						writeString(this.NOM_VILLE,dos);
					
					// String
				
						writeString(this.LONGITUDE,dos);
					
					// String
				
						writeString(this.LATITUDE,dos);
					
					// Integer
				
						writeInteger(this.ID_ADRESSE_RESTAURANT,dos);
					
					// String
				
						writeString(this.ADRESSE_RESTAURANT,dos);
					
					// Integer
				
						writeInteger(this.ID_CLIENT,dos);
					
					// Integer
				
						writeInteger(this.ID_ADRESSE_CLIENT,dos);
					
					// String
				
						writeString(this.ADRESSE_CLIENT,dos);
					
					// Integer
				
						writeInteger(this.ID_RESTAURANT,dos);
					
					// String
				
						writeString(this.CODE_RESTAURANT,dos);
					
					// String
				
						writeString(this.RAISON_SOCIALE_RESTAURANT,dos);
					
					// Integer
				
						writeInteger(this.ID_ADRESSE_NORM_RESTAURANT,dos);
					
					// Integer
				
						writeInteger(this.ID_MOYEN_PAIEMENT,dos);
					
					// String
				
						writeString(this.CODE_MOYEN_PAIEMENT,dos);
					
					// String
				
						writeString(this.LIVELLE_MOYEN_PAIEMENT,dos);
					
					// String
				
						writeString(this.NOM_CLIENT,dos);
					
					// String
				
						writeString(this.PRENOM_CLIENT,dos);
					
					// String
				
						writeString(this.LATITUDE_RESTAU,dos);
					
					// String
				
						writeString(this.LONGITUDE_RESTAU,dos);
					
					// String
				
						writeString(this.NOM_VILLE_RESTAU,dos);
					
					// String
				
						writeString(this.CODE_POSTAL_RESTAU,dos);
					
					// String
				
						writeString(this.NOM_VOIE_RESTAU,dos);
					
					// String
				
						writeString(this.NUMERO_VOIE_RESTAU,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// Integer
				
						writeInteger(this.ID_COMMANDE,dos);
					
					// Integer
				
						writeInteger(this.NUMERO_COMMANDE,dos);
					
					// java.util.Date
				
						writeDate(this.DATE_COMMANDE,dos);
					
					// Float
				
						if(this.MONTANT_TOTAL == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.MONTANT_TOTAL);
		            	}
					
					// Integer
				
						writeInteger(this.ID_MENU,dos);
					
					// String
				
						writeString(this.CODE_MENU,dos);
					
					// String
				
						writeString(this.LIBELLE_MENU,dos);
					
					// Integer
				
						writeInteger(this.NOMBRE_ARTICLES,dos);
					
					// String
				
						writeString(this.TEMPS_THEO_PREPARATION,dos);
					
					// Integer
				
						writeInteger(this.ID_PREPARATION,dos);
					
					// java.util.Date
				
						writeDate(this.DATE_DEBUT_PREPARATION,dos);
					
					// java.util.Date
				
						writeDate(this.DATE_FIN_PREPARATION,dos);
					
					// Integer
				
						writeInteger(this.ID_ADRESSE_NORM_CLIENT,dos);
					
					// String
				
						writeString(this.NUMERO_VOIE,dos);
					
					// String
				
						writeString(this.NOM_VOIE,dos);
					
					// String
				
						writeString(this.CODE_POSTAL,dos);
					
					// String
				
						writeString(this.NOM_VILLE,dos);
					
					// String
				
						writeString(this.LONGITUDE,dos);
					
					// String
				
						writeString(this.LATITUDE,dos);
					
					// Integer
				
						writeInteger(this.ID_ADRESSE_RESTAURANT,dos);
					
					// String
				
						writeString(this.ADRESSE_RESTAURANT,dos);
					
					// Integer
				
						writeInteger(this.ID_CLIENT,dos);
					
					// Integer
				
						writeInteger(this.ID_ADRESSE_CLIENT,dos);
					
					// String
				
						writeString(this.ADRESSE_CLIENT,dos);
					
					// Integer
				
						writeInteger(this.ID_RESTAURANT,dos);
					
					// String
				
						writeString(this.CODE_RESTAURANT,dos);
					
					// String
				
						writeString(this.RAISON_SOCIALE_RESTAURANT,dos);
					
					// Integer
				
						writeInteger(this.ID_ADRESSE_NORM_RESTAURANT,dos);
					
					// Integer
				
						writeInteger(this.ID_MOYEN_PAIEMENT,dos);
					
					// String
				
						writeString(this.CODE_MOYEN_PAIEMENT,dos);
					
					// String
				
						writeString(this.LIVELLE_MOYEN_PAIEMENT,dos);
					
					// String
				
						writeString(this.NOM_CLIENT,dos);
					
					// String
				
						writeString(this.PRENOM_CLIENT,dos);
					
					// String
				
						writeString(this.LATITUDE_RESTAU,dos);
					
					// String
				
						writeString(this.LONGITUDE_RESTAU,dos);
					
					// String
				
						writeString(this.NOM_VILLE_RESTAU,dos);
					
					// String
				
						writeString(this.CODE_POSTAL_RESTAU,dos);
					
					// String
				
						writeString(this.NOM_VOIE_RESTAU,dos);
					
					// String
				
						writeString(this.NUMERO_VOIE_RESTAU,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("ID_COMMANDE="+String.valueOf(ID_COMMANDE));
		sb.append(",NUMERO_COMMANDE="+String.valueOf(NUMERO_COMMANDE));
		sb.append(",DATE_COMMANDE="+String.valueOf(DATE_COMMANDE));
		sb.append(",MONTANT_TOTAL="+String.valueOf(MONTANT_TOTAL));
		sb.append(",ID_MENU="+String.valueOf(ID_MENU));
		sb.append(",CODE_MENU="+CODE_MENU);
		sb.append(",LIBELLE_MENU="+LIBELLE_MENU);
		sb.append(",NOMBRE_ARTICLES="+String.valueOf(NOMBRE_ARTICLES));
		sb.append(",TEMPS_THEO_PREPARATION="+TEMPS_THEO_PREPARATION);
		sb.append(",ID_PREPARATION="+String.valueOf(ID_PREPARATION));
		sb.append(",DATE_DEBUT_PREPARATION="+String.valueOf(DATE_DEBUT_PREPARATION));
		sb.append(",DATE_FIN_PREPARATION="+String.valueOf(DATE_FIN_PREPARATION));
		sb.append(",ID_ADRESSE_NORM_CLIENT="+String.valueOf(ID_ADRESSE_NORM_CLIENT));
		sb.append(",NUMERO_VOIE="+NUMERO_VOIE);
		sb.append(",NOM_VOIE="+NOM_VOIE);
		sb.append(",CODE_POSTAL="+CODE_POSTAL);
		sb.append(",NOM_VILLE="+NOM_VILLE);
		sb.append(",LONGITUDE="+LONGITUDE);
		sb.append(",LATITUDE="+LATITUDE);
		sb.append(",ID_ADRESSE_RESTAURANT="+String.valueOf(ID_ADRESSE_RESTAURANT));
		sb.append(",ADRESSE_RESTAURANT="+ADRESSE_RESTAURANT);
		sb.append(",ID_CLIENT="+String.valueOf(ID_CLIENT));
		sb.append(",ID_ADRESSE_CLIENT="+String.valueOf(ID_ADRESSE_CLIENT));
		sb.append(",ADRESSE_CLIENT="+ADRESSE_CLIENT);
		sb.append(",ID_RESTAURANT="+String.valueOf(ID_RESTAURANT));
		sb.append(",CODE_RESTAURANT="+CODE_RESTAURANT);
		sb.append(",RAISON_SOCIALE_RESTAURANT="+RAISON_SOCIALE_RESTAURANT);
		sb.append(",ID_ADRESSE_NORM_RESTAURANT="+String.valueOf(ID_ADRESSE_NORM_RESTAURANT));
		sb.append(",ID_MOYEN_PAIEMENT="+String.valueOf(ID_MOYEN_PAIEMENT));
		sb.append(",CODE_MOYEN_PAIEMENT="+CODE_MOYEN_PAIEMENT);
		sb.append(",LIVELLE_MOYEN_PAIEMENT="+LIVELLE_MOYEN_PAIEMENT);
		sb.append(",NOM_CLIENT="+NOM_CLIENT);
		sb.append(",PRENOM_CLIENT="+PRENOM_CLIENT);
		sb.append(",LATITUDE_RESTAU="+LATITUDE_RESTAU);
		sb.append(",LONGITUDE_RESTAU="+LONGITUDE_RESTAU);
		sb.append(",NOM_VILLE_RESTAU="+NOM_VILLE_RESTAU);
		sb.append(",CODE_POSTAL_RESTAU="+CODE_POSTAL_RESTAU);
		sb.append(",NOM_VOIE_RESTAU="+NOM_VOIE_RESTAU);
		sb.append(",NUMERO_VOIE_RESTAU="+NUMERO_VOIE_RESTAU);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row2Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tFileInputExcel_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFileInputExcel_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row2Struct row2 = new row2Struct();
alimentation_dm1_stagingStruct alimentation_dm1_staging = new alimentation_dm1_stagingStruct();





	
	/**
	 * [tDBOutput_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_2", false);
		start_Hash.put("tDBOutput_2", System.currentTimeMillis());
		
				tStatCatcher_1.addMessage("begin","tDBOutput_2");
				tStatCatcher_1Process(globalMap);
			
	
	currentComponent="tDBOutput_2";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"alimentation_dm1_staging");
					}
				
		int tos_count_tDBOutput_2 = 0;
		





String dbschema_tDBOutput_2 = null;
	dbschema_tDBOutput_2 = "dsid_liv_wrk";
	

String tableName_tDBOutput_2 = null;
if(dbschema_tDBOutput_2 == null || dbschema_tDBOutput_2.trim().length() == 0) {
	tableName_tDBOutput_2 = ("dm1_staging");
} else {
	tableName_tDBOutput_2 = dbschema_tDBOutput_2 + "\".\"" + ("dm1_staging");
}


int nb_line_tDBOutput_2 = 0;
int nb_line_update_tDBOutput_2 = 0;
int nb_line_inserted_tDBOutput_2 = 0;
int nb_line_deleted_tDBOutput_2 = 0;
int nb_line_rejected_tDBOutput_2 = 0;

int deletedCount_tDBOutput_2=0;
int updatedCount_tDBOutput_2=0;
int insertedCount_tDBOutput_2=0;
int rowsToCommitCount_tDBOutput_2=0;
int rejectedCount_tDBOutput_2=0;

boolean whetherReject_tDBOutput_2 = false;

java.sql.Connection conn_tDBOutput_2 = null;
String dbUser_tDBOutput_2 = null;

	
    java.lang.Class.forName("org.postgresql.Driver");
    
        String url_tDBOutput_2 = "jdbc:postgresql://"+""+":"+"5432"+"/"+"postgres";
    dbUser_tDBOutput_2 = "dsid_cc2_tos_rw";
 
	final String decryptedPassword_tDBOutput_2 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:QhdOOCHaHrPOywblQ66jYDnJW2Qk214tmrfcndXWlDw=");

    String dbPwd_tDBOutput_2 = decryptedPassword_tDBOutput_2;

    conn_tDBOutput_2 = java.sql.DriverManager.getConnection(url_tDBOutput_2,dbUser_tDBOutput_2,dbPwd_tDBOutput_2);
	
	resourceMap.put("conn_tDBOutput_2", conn_tDBOutput_2);
        conn_tDBOutput_2.setAutoCommit(false);
        int commitEvery_tDBOutput_2 = 10000;
        int commitCounter_tDBOutput_2 = 0;


   int batchSize_tDBOutput_2 = 10000;
   int batchSizeCounter_tDBOutput_2=0;

int count_tDBOutput_2=0;
            int rsTruncCountNumber_tDBOutput_2 = 0;
            try(java.sql.Statement stmtTruncCount_tDBOutput_2 = conn_tDBOutput_2.createStatement()) {
                try (java.sql.ResultSet rsTruncCount_tDBOutput_2 = stmtTruncCount_tDBOutput_2.executeQuery("SELECT COUNT(1) FROM \"" + tableName_tDBOutput_2 + "\"")) {
                    if(rsTruncCount_tDBOutput_2.next()) {
                        rsTruncCountNumber_tDBOutput_2 = rsTruncCount_tDBOutput_2.getInt(1);
                    }
                }
            }
            try (java.sql.Statement stmtTrunc_tDBOutput_2 = conn_tDBOutput_2.createStatement()) {
                stmtTrunc_tDBOutput_2.executeUpdate("TRUNCATE TABLE \"" + tableName_tDBOutput_2 + "\"");
                deletedCount_tDBOutput_2 += rsTruncCountNumber_tDBOutput_2;
            }
	    String insert_tDBOutput_2 = "INSERT INTO \"" + tableName_tDBOutput_2 + "\" (\"" + "id_staging_dm1" + "\",\"id_preparation\",\"date_debut_preparation\",\"date_fin_preparation\",\"id_moyen_paiement\",\"code_moyen_paiement\",\"livelle_moyen_paiement\",\"id_menu\",\"code_menu\",\"libelle_menu\",\"nombre_articles\",\"temps_theo_preparation\",\"id_commande\",\"numero_commande\",\"date_commande\",\"montant_total\",\"id_adresse_norm_restaurant\",\"numero_voie_restau\",\"nom_voie_restau\",\"code_postal_restau\",\"nom_ville_restau\",\"longitude_restau\",\"latitude_restau\",\"id_adresse_restaurant\",\"adresse_restaurant\",\"id_restaurant\",\"code_restaurant\",\"raison_sociale_restaurant\",\"id_adresse_norm_client\",\"numero_voie\",\"nom_voie\",\"code_postal\",\"nom_ville\",\"longitude\",\"latitude\",\"id_adresse_client\",\"adresse_client\",\"id_client\",\"nom_client\",\"prenom_client\") VALUES (" + "nextval('dsid_liv_wrk.seq_id_staging_dm1')" + ",?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
	    
	    java.sql.PreparedStatement pstmt_tDBOutput_2 = conn_tDBOutput_2.prepareStatement(insert_tDBOutput_2);
	    resourceMap.put("pstmt_tDBOutput_2", pstmt_tDBOutput_2);
	    

 



/**
 * [tDBOutput_2 begin ] stop
 */



	
	/**
	 * [tMap_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tMap_1", false);
		start_Hash.put("tMap_1", System.currentTimeMillis());
		
				tStatCatcher_1.addMessage("begin","tMap_1");
				tStatCatcher_1Process(globalMap);
			
	
	currentComponent="tMap_1";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row2");
					}
				
		int tos_count_tMap_1 = 0;
		




// ###############################
// # Lookup's keys initialization
// ###############################        

// ###############################
// # Vars initialization
class  Var__tMap_1__Struct  {
}
Var__tMap_1__Struct Var__tMap_1 = new Var__tMap_1__Struct();
// ###############################

// ###############################
// # Outputs initialization
alimentation_dm1_stagingStruct alimentation_dm1_staging_tmp = new alimentation_dm1_stagingStruct();
// ###############################

        
        



        









 



/**
 * [tMap_1 begin ] stop
 */



	
	/**
	 * [tFileInputExcel_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileInputExcel_1", false);
		start_Hash.put("tFileInputExcel_1", System.currentTimeMillis());
		
	
	currentComponent="tFileInputExcel_1";

	
		int tos_count_tFileInputExcel_1 = 0;
		



			class RegexUtil_tFileInputExcel_1 {

		    	public java.util.List<jxl.Sheet> getSheets(jxl.Workbook workbook, String oneSheetName, boolean useRegex) {

			        java.util.List<jxl.Sheet> list = new java.util.ArrayList<jxl.Sheet>();

			        if(useRegex){//this part process the regex issue

				        jxl.Sheet[] sheets = workbook.getSheets();
				        java.util.regex.Pattern pattern = java.util.regex.Pattern.compile(oneSheetName);
				        for (int i = 0; i < sheets.length; i++) {
				            String sheetName = sheets[i].getName();
				            java.util.regex.Matcher matcher = pattern.matcher(sheetName);
				            if (matcher.matches()) {
				            	jxl.Sheet sheet = workbook.getSheet(sheetName);
				            	if(sheet != null){
				                	list.add(sheet);
				                }
				            }
				        }

			        }else{
			        	jxl.Sheet sheet = workbook.getSheet(oneSheetName);
		            	if(sheet != null){
		                	list.add(sheet);
		                }

			        }

			        return list;
			    }

			    public java.util.List<jxl.Sheet> getSheets(jxl.Workbook workbook, int index, boolean useRegex) {
			    	java.util.List<jxl.Sheet> list =  new java.util.ArrayList<jxl.Sheet>();
			    	jxl.Sheet sheet = workbook.getSheet(index);
	            	if(sheet != null){
	                	list.add(sheet);
	                }
			    	return list;
			    }

			}


		RegexUtil_tFileInputExcel_1 regexUtil_tFileInputExcel_1 = new RegexUtil_tFileInputExcel_1();
		final jxl.WorkbookSettings workbookSettings_tFileInputExcel_1 = new jxl.WorkbookSettings();
		workbookSettings_tFileInputExcel_1.setDrawingsDisabled(true);
        workbookSettings_tFileInputExcel_1.setEncoding("UTF-8");

        Object source_tFileInputExcel_1 ="C:/CC2/Groupe1/3_DATA_FROM_VIEW/CC2_Groupe1_DM1_SRC_DATA.xls";
        final jxl.Workbook workbook_tFileInputExcel_1;

        java.io.InputStream toClose_tFileInputExcel_1 = null;
        java.io.BufferedInputStream buffIStreamtFileInputExcel_1 = null;
        try {
            if(source_tFileInputExcel_1 instanceof java.io.InputStream){
        		toClose_tFileInputExcel_1 = (java.io.InputStream)source_tFileInputExcel_1;
        		buffIStreamtFileInputExcel_1 = new java.io.BufferedInputStream(toClose_tFileInputExcel_1);
        		workbook_tFileInputExcel_1 = jxl.Workbook.getWorkbook(buffIStreamtFileInputExcel_1, workbookSettings_tFileInputExcel_1);
            }else if(source_tFileInputExcel_1 instanceof String){
        		toClose_tFileInputExcel_1 = new java.io.FileInputStream(source_tFileInputExcel_1.toString());
        		buffIStreamtFileInputExcel_1 = new java.io.BufferedInputStream(toClose_tFileInputExcel_1);
        		workbook_tFileInputExcel_1 = jxl.Workbook.getWorkbook(buffIStreamtFileInputExcel_1, workbookSettings_tFileInputExcel_1);
            }else{
            	workbook_tFileInputExcel_1 = null;
            	throw new java.lang.Exception("The data source should be specified as Inputstream or File Path!");
            }
        } finally {
			try{
			   if(buffIStreamtFileInputExcel_1 != null){
			   	  buffIStreamtFileInputExcel_1.close();
			   }
			}catch(Exception e){
globalMap.put("tFileInputExcel_1_ERROR_MESSAGE",e.getMessage());
			}
        }
        try {
		java.util.List<jxl.Sheet> sheetList_tFileInputExcel_1 = java.util.Arrays.<jxl.Sheet> asList(workbook_tFileInputExcel_1.getSheets());
        if(sheetList_tFileInputExcel_1.size() <= 0){
        	throw new RuntimeException("Special sheets not exist!");
        }

        java.util.List<jxl.Sheet> sheet_FilterNullList_tFileInputExcel_1 = new java.util.ArrayList<jxl.Sheet>();
        for(jxl.Sheet sheet_FilterNull_tFileInputExcel_1 : sheetList_tFileInputExcel_1){
        	if(sheet_FilterNull_tFileInputExcel_1.getRows()>0){
        		sheet_FilterNullList_tFileInputExcel_1.add(sheet_FilterNull_tFileInputExcel_1);
        	}
        }
		sheetList_tFileInputExcel_1 = sheet_FilterNullList_tFileInputExcel_1;
	if(sheetList_tFileInputExcel_1.size()>0){
        int nb_line_tFileInputExcel_1 = 0;

        int begin_line_tFileInputExcel_1 = 1;

        int footer_input_tFileInputExcel_1 = 0;

        int end_line_tFileInputExcel_1=0;
        for(jxl.Sheet sheet_tFileInputExcel_1:sheetList_tFileInputExcel_1){
        	end_line_tFileInputExcel_1+=sheet_tFileInputExcel_1.getRows();
        }
        end_line_tFileInputExcel_1 -= footer_input_tFileInputExcel_1;
        int limit_tFileInputExcel_1 = -1;
        int start_column_tFileInputExcel_1 = 1-1;
        int end_column_tFileInputExcel_1 = sheetList_tFileInputExcel_1.get(0).getColumns();
        jxl.Cell[] row_tFileInputExcel_1 = null;
        jxl.Sheet sheet_tFileInputExcel_1 = sheetList_tFileInputExcel_1.get(0);
        int rowCount_tFileInputExcel_1 = 0;
        int sheetIndex_tFileInputExcel_1 = 0;
        int currentRows_tFileInputExcel_1 = sheetList_tFileInputExcel_1.get(0).getRows();

        //for the number format
        java.text.DecimalFormat df_tFileInputExcel_1 = new java.text.DecimalFormat("#.####################################");
		char separatorChar_tFileInputExcel_1 = df_tFileInputExcel_1.getDecimalFormatSymbols().getDecimalSeparator();
		
		
		
        for(int i_tFileInputExcel_1 = begin_line_tFileInputExcel_1; i_tFileInputExcel_1 < end_line_tFileInputExcel_1; i_tFileInputExcel_1++){

        	int emptyColumnCount_tFileInputExcel_1 = 0;

        	if (limit_tFileInputExcel_1 != -1 && nb_line_tFileInputExcel_1 >= limit_tFileInputExcel_1) {
        		break;
        	}

            while (i_tFileInputExcel_1 >= rowCount_tFileInputExcel_1 + currentRows_tFileInputExcel_1) {
                rowCount_tFileInputExcel_1 += currentRows_tFileInputExcel_1;
                sheet_tFileInputExcel_1 = sheetList_tFileInputExcel_1.get(++sheetIndex_tFileInputExcel_1);
                currentRows_tFileInputExcel_1 = sheet_tFileInputExcel_1.getRows();
            }
            if (rowCount_tFileInputExcel_1 <= i_tFileInputExcel_1) {
                row_tFileInputExcel_1 = sheet_tFileInputExcel_1.getRow(i_tFileInputExcel_1 - rowCount_tFileInputExcel_1);
            }
        	globalMap.put("tFileInputExcel_1_CURRENT_SHEET",sheet_tFileInputExcel_1.getName());
    		row2 = null;
					int tempRowLength_tFileInputExcel_1 = 39;
				
				int columnIndex_tFileInputExcel_1 = 0;
			
//
//end%>
			
			String[] temp_row_tFileInputExcel_1 = new String[tempRowLength_tFileInputExcel_1];
			int actual_end_column_tFileInputExcel_1 = end_column_tFileInputExcel_1 >	row_tFileInputExcel_1.length ? row_tFileInputExcel_1.length : end_column_tFileInputExcel_1;

				java.util.TimeZone zone_tFileInputExcel_1 = java.util.TimeZone.getTimeZone("GMT");
                java.text.SimpleDateFormat sdf_tFileInputExcel_1 = new java.text.SimpleDateFormat("dd-MM-yyyy");
                sdf_tFileInputExcel_1.setTimeZone(zone_tFileInputExcel_1);
                

			for(int i=0;i<tempRowLength_tFileInputExcel_1;i++){

				if(i + start_column_tFileInputExcel_1 < actual_end_column_tFileInputExcel_1){

				  jxl.Cell cell_tFileInputExcel_1 = row_tFileInputExcel_1[i + start_column_tFileInputExcel_1];
                        temp_row_tFileInputExcel_1[i] = cell_tFileInputExcel_1.getContents();

				}else{
					temp_row_tFileInputExcel_1[i]="";
				}
			}

			boolean whetherReject_tFileInputExcel_1 = false;
			row2 = new row2Struct();
			int curColNum_tFileInputExcel_1 = -1;
			String curColName_tFileInputExcel_1 = "";
			try {
							columnIndex_tFileInputExcel_1 = 0;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "ID_COMMANDE";
			row2.ID_COMMANDE = ParserUtils.parseTo_Integer(temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1]);
			}else {
				row2.ID_COMMANDE = null;
				emptyColumnCount_tFileInputExcel_1++;
		}
							columnIndex_tFileInputExcel_1 = 1;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "NUMERO_COMMANDE";
			row2.NUMERO_COMMANDE = ParserUtils.parseTo_Integer(temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1]);
			}else {
				row2.NUMERO_COMMANDE = null;
				emptyColumnCount_tFileInputExcel_1++;
		}
							columnIndex_tFileInputExcel_1 = 2;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "DATE_COMMANDE";
			if(2<actual_end_column_tFileInputExcel_1){
				try{
					java.util.Date dateGMT_tFileInputExcel_1 = ((jxl.DateCell)row_tFileInputExcel_1[columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1]).getDate();
					row2.DATE_COMMANDE = new java.util.Date(dateGMT_tFileInputExcel_1.getTime() - java.util.TimeZone.getDefault().getOffset(dateGMT_tFileInputExcel_1.getTime()));
				}catch(java.lang.Exception e){
globalMap.put("tFileInputExcel_1_ERROR_MESSAGE",e.getMessage());
					
					throw new RuntimeException("The cell format is not Date in ( Row. "+(nb_line_tFileInputExcel_1+1)+ " and ColumnNum. " + curColNum_tFileInputExcel_1 + " )");
				}
			}
			}else {
				row2.DATE_COMMANDE = null;
				emptyColumnCount_tFileInputExcel_1++;
		}
							columnIndex_tFileInputExcel_1 = 3;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "MONTANT_TOTAL";
			row2.MONTANT_TOTAL = ParserUtils.parseTo_Float(temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1]);
			}else {
				row2.MONTANT_TOTAL = null;
				emptyColumnCount_tFileInputExcel_1++;
		}
							columnIndex_tFileInputExcel_1 = 4;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "ID_MENU";
			row2.ID_MENU = ParserUtils.parseTo_Integer(temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1]);
			}else {
				row2.ID_MENU = null;
				emptyColumnCount_tFileInputExcel_1++;
		}
							columnIndex_tFileInputExcel_1 = 5;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "CODE_MENU";
			row2.CODE_MENU = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
			}else {
				row2.CODE_MENU = null;
				emptyColumnCount_tFileInputExcel_1++;
		}
							columnIndex_tFileInputExcel_1 = 6;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "LIBELLE_MENU";
			row2.LIBELLE_MENU = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
			}else {
				row2.LIBELLE_MENU = null;
				emptyColumnCount_tFileInputExcel_1++;
		}
							columnIndex_tFileInputExcel_1 = 7;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "NOMBRE_ARTICLES";
			row2.NOMBRE_ARTICLES = ParserUtils.parseTo_Integer(temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1]);
			}else {
				row2.NOMBRE_ARTICLES = null;
				emptyColumnCount_tFileInputExcel_1++;
		}
							columnIndex_tFileInputExcel_1 = 8;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "TEMPS_THEO_PREPARATION";
			row2.TEMPS_THEO_PREPARATION = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
			}else {
				row2.TEMPS_THEO_PREPARATION = null;
				emptyColumnCount_tFileInputExcel_1++;
		}
							columnIndex_tFileInputExcel_1 = 9;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "ID_PREPARATION";
			row2.ID_PREPARATION = ParserUtils.parseTo_Integer(temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1]);
			}else {
				row2.ID_PREPARATION = null;
				emptyColumnCount_tFileInputExcel_1++;
		}
							columnIndex_tFileInputExcel_1 = 10;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "DATE_DEBUT_PREPARATION";
			if(10<actual_end_column_tFileInputExcel_1){
				try{
					java.util.Date dateGMT_tFileInputExcel_1 = ((jxl.DateCell)row_tFileInputExcel_1[columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1]).getDate();
					row2.DATE_DEBUT_PREPARATION = new java.util.Date(dateGMT_tFileInputExcel_1.getTime() - java.util.TimeZone.getDefault().getOffset(dateGMT_tFileInputExcel_1.getTime()));
				}catch(java.lang.Exception e){
globalMap.put("tFileInputExcel_1_ERROR_MESSAGE",e.getMessage());
					
					throw new RuntimeException("The cell format is not Date in ( Row. "+(nb_line_tFileInputExcel_1+1)+ " and ColumnNum. " + curColNum_tFileInputExcel_1 + " )");
				}
			}
			}else {
				row2.DATE_DEBUT_PREPARATION = null;
				emptyColumnCount_tFileInputExcel_1++;
		}
							columnIndex_tFileInputExcel_1 = 11;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "DATE_FIN_PREPARATION";
			if(11<actual_end_column_tFileInputExcel_1){
				try{
					java.util.Date dateGMT_tFileInputExcel_1 = ((jxl.DateCell)row_tFileInputExcel_1[columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1]).getDate();
					row2.DATE_FIN_PREPARATION = new java.util.Date(dateGMT_tFileInputExcel_1.getTime() - java.util.TimeZone.getDefault().getOffset(dateGMT_tFileInputExcel_1.getTime()));
				}catch(java.lang.Exception e){
globalMap.put("tFileInputExcel_1_ERROR_MESSAGE",e.getMessage());
					
					throw new RuntimeException("The cell format is not Date in ( Row. "+(nb_line_tFileInputExcel_1+1)+ " and ColumnNum. " + curColNum_tFileInputExcel_1 + " )");
				}
			}
			}else {
				row2.DATE_FIN_PREPARATION = null;
				emptyColumnCount_tFileInputExcel_1++;
		}
							columnIndex_tFileInputExcel_1 = 12;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "ID_ADRESSE_NORM_CLIENT";
			row2.ID_ADRESSE_NORM_CLIENT = ParserUtils.parseTo_Integer(temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1]);
			}else {
				row2.ID_ADRESSE_NORM_CLIENT = null;
				emptyColumnCount_tFileInputExcel_1++;
		}
							columnIndex_tFileInputExcel_1 = 13;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "NUMERO_VOIE";
			row2.NUMERO_VOIE = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
			}else {
				row2.NUMERO_VOIE = null;
				emptyColumnCount_tFileInputExcel_1++;
		}
							columnIndex_tFileInputExcel_1 = 14;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "NOM_VOIE";
			row2.NOM_VOIE = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
			}else {
				row2.NOM_VOIE = null;
				emptyColumnCount_tFileInputExcel_1++;
		}
							columnIndex_tFileInputExcel_1 = 15;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "CODE_POSTAL";
			row2.CODE_POSTAL = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
			}else {
				row2.CODE_POSTAL = null;
				emptyColumnCount_tFileInputExcel_1++;
		}
							columnIndex_tFileInputExcel_1 = 16;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "NOM_VILLE";
			row2.NOM_VILLE = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
			}else {
				row2.NOM_VILLE = null;
				emptyColumnCount_tFileInputExcel_1++;
		}
							columnIndex_tFileInputExcel_1 = 17;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "LONGITUDE";
			row2.LONGITUDE = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
			}else {
				row2.LONGITUDE = null;
				emptyColumnCount_tFileInputExcel_1++;
		}
							columnIndex_tFileInputExcel_1 = 18;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "LATITUDE";
			row2.LATITUDE = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
			}else {
				row2.LATITUDE = null;
				emptyColumnCount_tFileInputExcel_1++;
		}
							columnIndex_tFileInputExcel_1 = 19;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "ID_ADRESSE_RESTAURANT";
			row2.ID_ADRESSE_RESTAURANT = ParserUtils.parseTo_Integer(temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1]);
			}else {
				row2.ID_ADRESSE_RESTAURANT = null;
				emptyColumnCount_tFileInputExcel_1++;
		}
							columnIndex_tFileInputExcel_1 = 20;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "ADRESSE_RESTAURANT";
			row2.ADRESSE_RESTAURANT = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
			}else {
				row2.ADRESSE_RESTAURANT = null;
				emptyColumnCount_tFileInputExcel_1++;
		}
							columnIndex_tFileInputExcel_1 = 21;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "ID_CLIENT";
			row2.ID_CLIENT = ParserUtils.parseTo_Integer(temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1]);
			}else {
				row2.ID_CLIENT = null;
				emptyColumnCount_tFileInputExcel_1++;
		}
							columnIndex_tFileInputExcel_1 = 22;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "ID_ADRESSE_CLIENT";
			row2.ID_ADRESSE_CLIENT = ParserUtils.parseTo_Integer(temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1]);
			}else {
				row2.ID_ADRESSE_CLIENT = null;
				emptyColumnCount_tFileInputExcel_1++;
		}
							columnIndex_tFileInputExcel_1 = 23;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "ADRESSE_CLIENT";
			row2.ADRESSE_CLIENT = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
			}else {
				row2.ADRESSE_CLIENT = null;
				emptyColumnCount_tFileInputExcel_1++;
		}
							columnIndex_tFileInputExcel_1 = 24;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "ID_RESTAURANT";
			row2.ID_RESTAURANT = ParserUtils.parseTo_Integer(temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1]);
			}else {
				row2.ID_RESTAURANT = null;
				emptyColumnCount_tFileInputExcel_1++;
		}
							columnIndex_tFileInputExcel_1 = 25;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "CODE_RESTAURANT";
			row2.CODE_RESTAURANT = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
			}else {
				row2.CODE_RESTAURANT = null;
				emptyColumnCount_tFileInputExcel_1++;
		}
							columnIndex_tFileInputExcel_1 = 26;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "RAISON_SOCIALE_RESTAURANT";
			row2.RAISON_SOCIALE_RESTAURANT = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
			}else {
				row2.RAISON_SOCIALE_RESTAURANT = null;
				emptyColumnCount_tFileInputExcel_1++;
		}
							columnIndex_tFileInputExcel_1 = 27;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "ID_ADRESSE_NORM_RESTAURANT";
			row2.ID_ADRESSE_NORM_RESTAURANT = ParserUtils.parseTo_Integer(temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1]);
			}else {
				row2.ID_ADRESSE_NORM_RESTAURANT = null;
				emptyColumnCount_tFileInputExcel_1++;
		}
							columnIndex_tFileInputExcel_1 = 28;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "ID_MOYEN_PAIEMENT";
			row2.ID_MOYEN_PAIEMENT = ParserUtils.parseTo_Integer(temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1]);
			}else {
				row2.ID_MOYEN_PAIEMENT = null;
				emptyColumnCount_tFileInputExcel_1++;
		}
							columnIndex_tFileInputExcel_1 = 29;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "CODE_MOYEN_PAIEMENT";
			row2.CODE_MOYEN_PAIEMENT = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
			}else {
				row2.CODE_MOYEN_PAIEMENT = null;
				emptyColumnCount_tFileInputExcel_1++;
		}
							columnIndex_tFileInputExcel_1 = 30;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "LIVELLE_MOYEN_PAIEMENT";
			row2.LIVELLE_MOYEN_PAIEMENT = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
			}else {
				row2.LIVELLE_MOYEN_PAIEMENT = null;
				emptyColumnCount_tFileInputExcel_1++;
		}
							columnIndex_tFileInputExcel_1 = 31;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "NOM_CLIENT";
			row2.NOM_CLIENT = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
			}else {
				row2.NOM_CLIENT = null;
				emptyColumnCount_tFileInputExcel_1++;
		}
							columnIndex_tFileInputExcel_1 = 32;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "PRENOM_CLIENT";
			row2.PRENOM_CLIENT = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
			}else {
				row2.PRENOM_CLIENT = null;
				emptyColumnCount_tFileInputExcel_1++;
		}
							columnIndex_tFileInputExcel_1 = 33;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "LATITUDE_RESTAU";
			row2.LATITUDE_RESTAU = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
			}else {
				row2.LATITUDE_RESTAU = null;
				emptyColumnCount_tFileInputExcel_1++;
		}
							columnIndex_tFileInputExcel_1 = 34;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "LONGITUDE_RESTAU";
			row2.LONGITUDE_RESTAU = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
			}else {
				row2.LONGITUDE_RESTAU = null;
				emptyColumnCount_tFileInputExcel_1++;
		}
							columnIndex_tFileInputExcel_1 = 35;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "NOM_VILLE_RESTAU";
			row2.NOM_VILLE_RESTAU = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
			}else {
				row2.NOM_VILLE_RESTAU = null;
				emptyColumnCount_tFileInputExcel_1++;
		}
							columnIndex_tFileInputExcel_1 = 36;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "CODE_POSTAL_RESTAU";
			row2.CODE_POSTAL_RESTAU = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
			}else {
				row2.CODE_POSTAL_RESTAU = null;
				emptyColumnCount_tFileInputExcel_1++;
		}
							columnIndex_tFileInputExcel_1 = 37;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "NOM_VOIE_RESTAU";
			row2.NOM_VOIE_RESTAU = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
			}else {
				row2.NOM_VOIE_RESTAU = null;
				emptyColumnCount_tFileInputExcel_1++;
		}
							columnIndex_tFileInputExcel_1 = 38;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "NUMERO_VOIE_RESTAU";
			row2.NUMERO_VOIE_RESTAU = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
			}else {
				row2.NUMERO_VOIE_RESTAU = null;
				emptyColumnCount_tFileInputExcel_1++;
		}

			nb_line_tFileInputExcel_1++;
			
    } catch (java.lang.Exception e) {
globalMap.put("tFileInputExcel_1_ERROR_MESSAGE",e.getMessage());
        whetherReject_tFileInputExcel_1 = true;
                System.err.println(e.getMessage());
                row2 = null;
    }

					
		



 



/**
 * [tFileInputExcel_1 begin ] stop
 */
	
	/**
	 * [tFileInputExcel_1 main ] start
	 */

	

	
	
	currentComponent="tFileInputExcel_1";

	

 


	tos_count_tFileInputExcel_1++;

/**
 * [tFileInputExcel_1 main ] stop
 */
	
	/**
	 * [tFileInputExcel_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFileInputExcel_1";

	

 



/**
 * [tFileInputExcel_1 process_data_begin ] stop
 */
// Start of branch "row2"
if(row2 != null) { 



	
	/**
	 * [tMap_1 main ] start
	 */

	

	
	
	currentComponent="tMap_1";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row2"
						
						);
					}
					

		
		
		boolean hasCasePrimitiveKeyWithNull_tMap_1 = false;
		

        // ###############################
        // # Input tables (lookups)
		  boolean rejectedInnerJoin_tMap_1 = false;
		  boolean mainRowRejected_tMap_1 = false;
            				    								  
		// ###############################
        { // start of Var scope
        
	        // ###############################
        	// # Vars tables
        
Var__tMap_1__Struct Var = Var__tMap_1;// ###############################
        // ###############################
        // # Output tables

alimentation_dm1_staging = null;


// # Output table : 'alimentation_dm1_staging'
alimentation_dm1_staging_tmp.id_staging_dm1 = 0;
alimentation_dm1_staging_tmp.id_preparation = row2.ID_PREPARATION;
alimentation_dm1_staging_tmp.date_debut_preparation = row2.DATE_DEBUT_PREPARATION;
alimentation_dm1_staging_tmp.date_fin_preparation = row2.DATE_FIN_PREPARATION;
alimentation_dm1_staging_tmp.id_moyen_paiement = row2.ID_MOYEN_PAIEMENT;
alimentation_dm1_staging_tmp.code_moyen_paiement = row2.CODE_MOYEN_PAIEMENT;
alimentation_dm1_staging_tmp.livelle_moyen_paiement = row2.LIVELLE_MOYEN_PAIEMENT;
alimentation_dm1_staging_tmp.id_menu = row2.ID_MENU;
alimentation_dm1_staging_tmp.code_menu = row2.CODE_MENU;
alimentation_dm1_staging_tmp.libelle_menu = row2.LIBELLE_MENU;
alimentation_dm1_staging_tmp.nombre_articles = row2.NOMBRE_ARTICLES;
alimentation_dm1_staging_tmp.temps_theo_preparation = row2.TEMPS_THEO_PREPARATION;
alimentation_dm1_staging_tmp.id_commande = row2.ID_COMMANDE;
alimentation_dm1_staging_tmp.numero_commande = row2.NUMERO_COMMANDE;
alimentation_dm1_staging_tmp.date_commande = row2.DATE_COMMANDE;
alimentation_dm1_staging_tmp.montant_total = row2.MONTANT_TOTAL ;
alimentation_dm1_staging_tmp.id_adresse_norm_restaurant = row2.ID_ADRESSE_NORM_RESTAURANT;
alimentation_dm1_staging_tmp.numero_voie_restau = row2.NUMERO_VOIE_RESTAU;
alimentation_dm1_staging_tmp.nom_voie_restau = row2.NOM_VOIE_RESTAU;
alimentation_dm1_staging_tmp.code_postal_restau = StringHandling.EREPLACE(row2.CODE_POSTAL_RESTAU," ","") ;
alimentation_dm1_staging_tmp.nom_ville_restau = row2.NOM_VILLE_RESTAU;
alimentation_dm1_staging_tmp.longitude_restau = row2.LONGITUDE_RESTAU;
alimentation_dm1_staging_tmp.latitude_restau = row2.LATITUDE_RESTAU;
alimentation_dm1_staging_tmp.id_adresse_restaurant = row2.ID_ADRESSE_RESTAURANT;
alimentation_dm1_staging_tmp.adresse_restaurant = row2.ADRESSE_RESTAURANT;
alimentation_dm1_staging_tmp.id_restaurant = row2.ID_RESTAURANT;
alimentation_dm1_staging_tmp.code_restaurant = row2.CODE_RESTAURANT;
alimentation_dm1_staging_tmp.raison_sociale_restaurant = row2.RAISON_SOCIALE_RESTAURANT;
alimentation_dm1_staging_tmp.id_adresse_norm_client = row2.ID_ADRESSE_NORM_CLIENT;
alimentation_dm1_staging_tmp.numero_voie = row2.NUMERO_VOIE;
alimentation_dm1_staging_tmp.nom_voie = row2.NOM_VOIE;
alimentation_dm1_staging_tmp.code_postal = StringHandling.EREPLACE(row2.CODE_POSTAL," ","") ;
alimentation_dm1_staging_tmp.nom_ville = row2.NOM_VILLE;
alimentation_dm1_staging_tmp.longitude = row2.LONGITUDE;
alimentation_dm1_staging_tmp.latitude = row2.LATITUDE;
alimentation_dm1_staging_tmp.id_adresse_client = row2.ID_ADRESSE_CLIENT;
alimentation_dm1_staging_tmp.adresse_client = row2.ADRESSE_CLIENT;
alimentation_dm1_staging_tmp.id_client = row2.ID_CLIENT;
alimentation_dm1_staging_tmp.nom_client = row2.NOM_CLIENT;
alimentation_dm1_staging_tmp.prenom_client = row2.PRENOM_CLIENT;
alimentation_dm1_staging = alimentation_dm1_staging_tmp;
// ###############################

} // end of Var scope

rejectedInnerJoin_tMap_1 = false;










 


	tos_count_tMap_1++;

/**
 * [tMap_1 main ] stop
 */
	
	/**
	 * [tMap_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tMap_1";

	

 



/**
 * [tMap_1 process_data_begin ] stop
 */
// Start of branch "alimentation_dm1_staging"
if(alimentation_dm1_staging != null) { 



	
	/**
	 * [tDBOutput_2 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"alimentation_dm1_staging"
						
						);
					}
					



        whetherReject_tDBOutput_2 = false;
                    if(alimentation_dm1_staging.id_preparation == null) {
pstmt_tDBOutput_2.setNull(1, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_2.setInt(1, alimentation_dm1_staging.id_preparation);
}

                    if(alimentation_dm1_staging.date_debut_preparation != null) {
pstmt_tDBOutput_2.setTimestamp(2, new java.sql.Timestamp(alimentation_dm1_staging.date_debut_preparation.getTime()));
} else {
pstmt_tDBOutput_2.setNull(2, java.sql.Types.TIMESTAMP);
}

                    if(alimentation_dm1_staging.date_fin_preparation != null) {
pstmt_tDBOutput_2.setTimestamp(3, new java.sql.Timestamp(alimentation_dm1_staging.date_fin_preparation.getTime()));
} else {
pstmt_tDBOutput_2.setNull(3, java.sql.Types.TIMESTAMP);
}

                    if(alimentation_dm1_staging.id_moyen_paiement == null) {
pstmt_tDBOutput_2.setNull(4, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_2.setInt(4, alimentation_dm1_staging.id_moyen_paiement);
}

                    if(alimentation_dm1_staging.code_moyen_paiement == null) {
pstmt_tDBOutput_2.setNull(5, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(5, alimentation_dm1_staging.code_moyen_paiement);
}

                    if(alimentation_dm1_staging.livelle_moyen_paiement == null) {
pstmt_tDBOutput_2.setNull(6, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(6, alimentation_dm1_staging.livelle_moyen_paiement);
}

                    if(alimentation_dm1_staging.id_menu == null) {
pstmt_tDBOutput_2.setNull(7, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_2.setInt(7, alimentation_dm1_staging.id_menu);
}

                    if(alimentation_dm1_staging.code_menu == null) {
pstmt_tDBOutput_2.setNull(8, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(8, alimentation_dm1_staging.code_menu);
}

                    if(alimentation_dm1_staging.libelle_menu == null) {
pstmt_tDBOutput_2.setNull(9, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(9, alimentation_dm1_staging.libelle_menu);
}

                    if(alimentation_dm1_staging.nombre_articles == null) {
pstmt_tDBOutput_2.setNull(10, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_2.setInt(10, alimentation_dm1_staging.nombre_articles);
}

                    if(alimentation_dm1_staging.temps_theo_preparation == null) {
pstmt_tDBOutput_2.setNull(11, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(11, alimentation_dm1_staging.temps_theo_preparation);
}

                    if(alimentation_dm1_staging.id_commande == null) {
pstmt_tDBOutput_2.setNull(12, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_2.setInt(12, alimentation_dm1_staging.id_commande);
}

                    if(alimentation_dm1_staging.numero_commande == null) {
pstmt_tDBOutput_2.setNull(13, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_2.setInt(13, alimentation_dm1_staging.numero_commande);
}

                    if(alimentation_dm1_staging.date_commande != null) {
pstmt_tDBOutput_2.setTimestamp(14, new java.sql.Timestamp(alimentation_dm1_staging.date_commande.getTime()));
} else {
pstmt_tDBOutput_2.setNull(14, java.sql.Types.TIMESTAMP);
}

                    if(alimentation_dm1_staging.montant_total == null) {
pstmt_tDBOutput_2.setNull(15, java.sql.Types.FLOAT);
} else {pstmt_tDBOutput_2.setFloat(15, alimentation_dm1_staging.montant_total);
}

                    if(alimentation_dm1_staging.id_adresse_norm_restaurant == null) {
pstmt_tDBOutput_2.setNull(16, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_2.setInt(16, alimentation_dm1_staging.id_adresse_norm_restaurant);
}

                    if(alimentation_dm1_staging.numero_voie_restau == null) {
pstmt_tDBOutput_2.setNull(17, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(17, alimentation_dm1_staging.numero_voie_restau);
}

                    if(alimentation_dm1_staging.nom_voie_restau == null) {
pstmt_tDBOutput_2.setNull(18, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(18, alimentation_dm1_staging.nom_voie_restau);
}

                    if(alimentation_dm1_staging.code_postal_restau == null) {
pstmt_tDBOutput_2.setNull(19, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(19, alimentation_dm1_staging.code_postal_restau);
}

                    if(alimentation_dm1_staging.nom_ville_restau == null) {
pstmt_tDBOutput_2.setNull(20, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(20, alimentation_dm1_staging.nom_ville_restau);
}

                    if(alimentation_dm1_staging.longitude_restau == null) {
pstmt_tDBOutput_2.setNull(21, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(21, alimentation_dm1_staging.longitude_restau);
}

                    if(alimentation_dm1_staging.latitude_restau == null) {
pstmt_tDBOutput_2.setNull(22, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(22, alimentation_dm1_staging.latitude_restau);
}

                    if(alimentation_dm1_staging.id_adresse_restaurant == null) {
pstmt_tDBOutput_2.setNull(23, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_2.setInt(23, alimentation_dm1_staging.id_adresse_restaurant);
}

                    if(alimentation_dm1_staging.adresse_restaurant == null) {
pstmt_tDBOutput_2.setNull(24, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(24, alimentation_dm1_staging.adresse_restaurant);
}

                    if(alimentation_dm1_staging.id_restaurant == null) {
pstmt_tDBOutput_2.setNull(25, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_2.setInt(25, alimentation_dm1_staging.id_restaurant);
}

                    if(alimentation_dm1_staging.code_restaurant == null) {
pstmt_tDBOutput_2.setNull(26, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(26, alimentation_dm1_staging.code_restaurant);
}

                    if(alimentation_dm1_staging.raison_sociale_restaurant == null) {
pstmt_tDBOutput_2.setNull(27, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(27, alimentation_dm1_staging.raison_sociale_restaurant);
}

                    if(alimentation_dm1_staging.id_adresse_norm_client == null) {
pstmt_tDBOutput_2.setNull(28, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_2.setInt(28, alimentation_dm1_staging.id_adresse_norm_client);
}

                    if(alimentation_dm1_staging.numero_voie == null) {
pstmt_tDBOutput_2.setNull(29, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(29, alimentation_dm1_staging.numero_voie);
}

                    if(alimentation_dm1_staging.nom_voie == null) {
pstmt_tDBOutput_2.setNull(30, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(30, alimentation_dm1_staging.nom_voie);
}

                    if(alimentation_dm1_staging.code_postal == null) {
pstmt_tDBOutput_2.setNull(31, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(31, alimentation_dm1_staging.code_postal);
}

                    if(alimentation_dm1_staging.nom_ville == null) {
pstmt_tDBOutput_2.setNull(32, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(32, alimentation_dm1_staging.nom_ville);
}

                    if(alimentation_dm1_staging.longitude == null) {
pstmt_tDBOutput_2.setNull(33, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(33, alimentation_dm1_staging.longitude);
}

                    if(alimentation_dm1_staging.latitude == null) {
pstmt_tDBOutput_2.setNull(34, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(34, alimentation_dm1_staging.latitude);
}

                    if(alimentation_dm1_staging.id_adresse_client == null) {
pstmt_tDBOutput_2.setNull(35, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_2.setInt(35, alimentation_dm1_staging.id_adresse_client);
}

                    if(alimentation_dm1_staging.adresse_client == null) {
pstmt_tDBOutput_2.setNull(36, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(36, alimentation_dm1_staging.adresse_client);
}

                    if(alimentation_dm1_staging.id_client == null) {
pstmt_tDBOutput_2.setNull(37, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_2.setInt(37, alimentation_dm1_staging.id_client);
}

                    if(alimentation_dm1_staging.nom_client == null) {
pstmt_tDBOutput_2.setNull(38, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(38, alimentation_dm1_staging.nom_client);
}

                    if(alimentation_dm1_staging.prenom_client == null) {
pstmt_tDBOutput_2.setNull(39, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(39, alimentation_dm1_staging.prenom_client);
}

			
    		pstmt_tDBOutput_2.addBatch();
    		nb_line_tDBOutput_2++;
    		  
    		  
    		  batchSizeCounter_tDBOutput_2++;
    		  
    			if ((batchSize_tDBOutput_2 > 0) && (batchSize_tDBOutput_2 <= batchSizeCounter_tDBOutput_2)) {
                try {
						int countSum_tDBOutput_2 = 0;
						    
						for(int countEach_tDBOutput_2: pstmt_tDBOutput_2.executeBatch()) {
							countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
						}
				    	rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;
				    	
				    		insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
				    	
            	    	batchSizeCounter_tDBOutput_2 = 0;
                }catch (java.sql.BatchUpdateException e_tDBOutput_2){
globalMap.put("tDBOutput_2_ERROR_MESSAGE",e_tDBOutput_2.getMessage());
				    	java.sql.SQLException ne_tDBOutput_2 = e_tDBOutput_2.getNextException(),sqle_tDBOutput_2=null;
				    	String errormessage_tDBOutput_2;
						if (ne_tDBOutput_2 != null) {
							// build new exception to provide the original cause
							sqle_tDBOutput_2 = new java.sql.SQLException(e_tDBOutput_2.getMessage() + "\ncaused by: " + ne_tDBOutput_2.getMessage(), ne_tDBOutput_2.getSQLState(), ne_tDBOutput_2.getErrorCode(), ne_tDBOutput_2);
							errormessage_tDBOutput_2 = sqle_tDBOutput_2.getMessage();
						}else{
							errormessage_tDBOutput_2 = e_tDBOutput_2.getMessage();
						}
				    	
				    	int countSum_tDBOutput_2 = 0;
						for(int countEach_tDBOutput_2: e_tDBOutput_2.getUpdateCounts()) {
							countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
						}
						rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;
						
				    		insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
				    	
				    	System.err.println(errormessage_tDBOutput_2);
				    	
					}
    			}
    		
    		    commitCounter_tDBOutput_2++;
                if(commitEvery_tDBOutput_2 <= commitCounter_tDBOutput_2) {
                if ((batchSize_tDBOutput_2 > 0) && (batchSizeCounter_tDBOutput_2 > 0)) {
                try {
                		int countSum_tDBOutput_2 = 0;
                		    
						for(int countEach_tDBOutput_2: pstmt_tDBOutput_2.executeBatch()) {
							countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
						}
            	    	rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;
            	    	
            	    		insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
            	    	
                batchSizeCounter_tDBOutput_2 = 0;
               }catch (java.sql.BatchUpdateException e_tDBOutput_2){
globalMap.put("tDBOutput_2_ERROR_MESSAGE",e_tDBOutput_2.getMessage());
			    	java.sql.SQLException ne_tDBOutput_2 = e_tDBOutput_2.getNextException(),sqle_tDBOutput_2=null;
			    	String errormessage_tDBOutput_2;
					if (ne_tDBOutput_2 != null) {
						// build new exception to provide the original cause
						sqle_tDBOutput_2 = new java.sql.SQLException(e_tDBOutput_2.getMessage() + "\ncaused by: " + ne_tDBOutput_2.getMessage(), ne_tDBOutput_2.getSQLState(), ne_tDBOutput_2.getErrorCode(), ne_tDBOutput_2);
						errormessage_tDBOutput_2 = sqle_tDBOutput_2.getMessage();
					}else{
						errormessage_tDBOutput_2 = e_tDBOutput_2.getMessage();
					}
			    	
			    	int countSum_tDBOutput_2 = 0;
					for(int countEach_tDBOutput_2: e_tDBOutput_2.getUpdateCounts()) {
						countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
					}
					rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;
					
			    		insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
			    	
			    	System.err.println(errormessage_tDBOutput_2);
			    	
				}
            }
                    if(rowsToCommitCount_tDBOutput_2 != 0){
                    	
                    }
                    conn_tDBOutput_2.commit();
                    if(rowsToCommitCount_tDBOutput_2 != 0){
                    	
                    	rowsToCommitCount_tDBOutput_2 = 0;
                    }
                    commitCounter_tDBOutput_2=0;
                }

 


	tos_count_tDBOutput_2++;

/**
 * [tDBOutput_2 main ] stop
 */
	
	/**
	 * [tDBOutput_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";

	

 



/**
 * [tDBOutput_2 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";

	

 



/**
 * [tDBOutput_2 process_data_end ] stop
 */

} // End of branch "alimentation_dm1_staging"




	
	/**
	 * [tMap_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tMap_1";

	

 



/**
 * [tMap_1 process_data_end ] stop
 */

} // End of branch "row2"




	
	/**
	 * [tFileInputExcel_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tFileInputExcel_1";

	

 



/**
 * [tFileInputExcel_1 process_data_end ] stop
 */
	
	/**
	 * [tFileInputExcel_1 end ] start
	 */

	

	
	
	currentComponent="tFileInputExcel_1";

	

			}
			
			
			
			globalMap.put("tFileInputExcel_1_NB_LINE",nb_line_tFileInputExcel_1);
			
				}
			
		} finally { 
				
					if(!(source_tFileInputExcel_1 instanceof java.io.InputStream)){
						workbook_tFileInputExcel_1.close();
					}
				
		}	
		

 

ok_Hash.put("tFileInputExcel_1", true);
end_Hash.put("tFileInputExcel_1", System.currentTimeMillis());




/**
 * [tFileInputExcel_1 end ] stop
 */

	
	/**
	 * [tMap_1 end ] start
	 */

	

	
	
	currentComponent="tMap_1";

	


// ###############################
// # Lookup hashes releasing
// ###############################      





				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row2");
			  	}
			  	
 

ok_Hash.put("tMap_1", true);
end_Hash.put("tMap_1", System.currentTimeMillis());

tStatCatcher_1.addMessage("end","tMap_1", end_Hash.get("tMap_1")-start_Hash.get("tMap_1"));
tStatCatcher_1Process(globalMap);



/**
 * [tMap_1 end ] stop
 */

	
	/**
	 * [tDBOutput_2 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";

	



	    try {
				int countSum_tDBOutput_2 = 0;
				if (pstmt_tDBOutput_2 != null && batchSizeCounter_tDBOutput_2 > 0) {
						
					for(int countEach_tDBOutput_2: pstmt_tDBOutput_2.executeBatch()) {
						countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
					}
					rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;
						
				}
		    	
		    		insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
		    	
	    }catch (java.sql.BatchUpdateException e_tDBOutput_2){
globalMap.put("tDBOutput_2_ERROR_MESSAGE",e_tDBOutput_2.getMessage());
	    	java.sql.SQLException ne_tDBOutput_2 = e_tDBOutput_2.getNextException(),sqle_tDBOutput_2=null;
	    	String errormessage_tDBOutput_2;
			if (ne_tDBOutput_2 != null) {
				// build new exception to provide the original cause
				sqle_tDBOutput_2 = new java.sql.SQLException(e_tDBOutput_2.getMessage() + "\ncaused by: " + ne_tDBOutput_2.getMessage(), ne_tDBOutput_2.getSQLState(), ne_tDBOutput_2.getErrorCode(), ne_tDBOutput_2);
				errormessage_tDBOutput_2 = sqle_tDBOutput_2.getMessage();
			}else{
				errormessage_tDBOutput_2 = e_tDBOutput_2.getMessage();
			}
	    	
	    	int countSum_tDBOutput_2 = 0;
			for(int countEach_tDBOutput_2: e_tDBOutput_2.getUpdateCounts()) {
				countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
			}
			rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;
			
	    		insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
	    	
	    	System.err.println(errormessage_tDBOutput_2);
	    	
		}
	    
        if(pstmt_tDBOutput_2 != null) {
        		
            pstmt_tDBOutput_2.close();
            resourceMap.remove("pstmt_tDBOutput_2");
        }
    resourceMap.put("statementClosed_tDBOutput_2", true);
			if(rowsToCommitCount_tDBOutput_2 != 0){
				
			}
			conn_tDBOutput_2.commit();
			if(rowsToCommitCount_tDBOutput_2 != 0){
				
				rowsToCommitCount_tDBOutput_2 = 0;
			}
			commitCounter_tDBOutput_2 = 0;
		
    	conn_tDBOutput_2 .close();
    	
    	resourceMap.put("finish_tDBOutput_2", true);
    	

	nb_line_deleted_tDBOutput_2=nb_line_deleted_tDBOutput_2+ deletedCount_tDBOutput_2;
	nb_line_update_tDBOutput_2=nb_line_update_tDBOutput_2 + updatedCount_tDBOutput_2;
	nb_line_inserted_tDBOutput_2=nb_line_inserted_tDBOutput_2 + insertedCount_tDBOutput_2;
	nb_line_rejected_tDBOutput_2=nb_line_rejected_tDBOutput_2 + rejectedCount_tDBOutput_2;
	
        globalMap.put("tDBOutput_2_NB_LINE",nb_line_tDBOutput_2);
        globalMap.put("tDBOutput_2_NB_LINE_UPDATED",nb_line_update_tDBOutput_2);
        globalMap.put("tDBOutput_2_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_2);
        globalMap.put("tDBOutput_2_NB_LINE_DELETED",nb_line_deleted_tDBOutput_2);
        globalMap.put("tDBOutput_2_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_2);
    

	


				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"alimentation_dm1_staging");
			  	}
			  	
 

ok_Hash.put("tDBOutput_2", true);
end_Hash.put("tDBOutput_2", System.currentTimeMillis());

tStatCatcher_1.addMessage("end","tDBOutput_2", end_Hash.get("tDBOutput_2")-start_Hash.get("tDBOutput_2"));
tStatCatcher_1Process(globalMap);



/**
 * [tDBOutput_2 end ] stop
 */






				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tFileInputExcel_1:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk1", 0, "ok");
								} 
							
							tFileList_1Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFileInputExcel_1 finally ] start
	 */

	

	
	
	currentComponent="tFileInputExcel_1";

	

 



/**
 * [tFileInputExcel_1 finally ] stop
 */

	
	/**
	 * [tMap_1 finally ] start
	 */

	

	
	
	currentComponent="tMap_1";

	

 



/**
 * [tMap_1 finally ] stop
 */

	
	/**
	 * [tDBOutput_2 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";

	



    try {
    if (resourceMap.get("statementClosed_tDBOutput_2") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_2 = null;
                if ((pstmtToClose_tDBOutput_2 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_2")) != null) {
                    pstmtToClose_tDBOutput_2.close();
                }
    }
    } finally {
        if(resourceMap.get("finish_tDBOutput_2") == null){
            java.sql.Connection ctn_tDBOutput_2 = null;
            if((ctn_tDBOutput_2 = (java.sql.Connection)resourceMap.get("conn_tDBOutput_2")) != null){
                try {
                    ctn_tDBOutput_2.close();
                } catch (java.sql.SQLException sqlEx_tDBOutput_2) {
                    String errorMessage_tDBOutput_2 = "failed to close the connection in tDBOutput_2 :" + sqlEx_tDBOutput_2.getMessage();
                    System.err.println(errorMessage_tDBOutput_2);
                }
            }
        }
    }
 



/**
 * [tDBOutput_2 finally ] stop
 */






				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFileInputExcel_1_SUBPROCESS_STATE", 1);
	}
	

public void tFileList_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFileList_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tFileList_1 begin ] start
	 */

				
			int NB_ITERATE_tFileArchive_1 = 0; //for statistics
			

	
		
		ok_Hash.put("tFileList_1", false);
		start_Hash.put("tFileList_1", System.currentTimeMillis());
		
				tStatCatcher_1.addMessage("begin","tFileList_1");
				tStatCatcher_1Process(globalMap);
			
	
	currentComponent="tFileList_1";

	
		int tos_count_tFileList_1 = 0;
		
	
 
     
    
  String directory_tFileList_1 = "C:/CC2/Groupe1/5_DATA_IN";
  final java.util.List<String> maskList_tFileList_1 = new java.util.ArrayList<String>();
  final java.util.List<java.util.regex.Pattern> patternList_tFileList_1 = new java.util.ArrayList<java.util.regex.Pattern>();
      maskList_tFileList_1.add("*");  
  for (final String filemask_tFileList_1 : maskList_tFileList_1) {
	String filemask_compile_tFileList_1 = filemask_tFileList_1;
	
		filemask_compile_tFileList_1 = org.apache.oro.text.GlobCompiler.globToPerl5(filemask_tFileList_1.toCharArray(), org.apache.oro.text.GlobCompiler.DEFAULT_MASK);
	
		java.util.regex.Pattern fileNamePattern_tFileList_1 = java.util.regex.Pattern.compile(filemask_compile_tFileList_1);
	patternList_tFileList_1.add(fileNamePattern_tFileList_1);
  }
  int NB_FILEtFileList_1 = 0;

  final boolean case_sensitive_tFileList_1 = true;
	
	
	
    final java.util.List<java.io.File> list_tFileList_1 = new java.util.ArrayList<java.io.File>();
    final java.util.Set<String> filePath_tFileList_1 = new java.util.HashSet<String>();
	java.io.File file_tFileList_1 = new java.io.File(directory_tFileList_1);
     
		file_tFileList_1.listFiles(new java.io.FilenameFilter() {
			public boolean accept(java.io.File dir, String name) {
				java.io.File file = new java.io.File(dir, name);
                if (!file.isDirectory()) {
                	
    	String fileName_tFileList_1 = file.getName();
		for (final java.util.regex.Pattern fileNamePattern_tFileList_1 : patternList_tFileList_1) {
          	if (fileNamePattern_tFileList_1.matcher(fileName_tFileList_1).matches()){
					if(!filePath_tFileList_1.contains(file.getAbsolutePath())) {
			          list_tFileList_1.add(file);
			          filePath_tFileList_1.add(file.getAbsolutePath());
			        }
			}
		}
                }
              return true;
            }
          }
      ); 
      java.util.Collections.sort(list_tFileList_1);
    
    for (int i_tFileList_1 = 0; i_tFileList_1 < list_tFileList_1.size(); i_tFileList_1++){
      java.io.File files_tFileList_1 = list_tFileList_1.get(i_tFileList_1);
      String fileName_tFileList_1 = files_tFileList_1.getName();
      
      String currentFileName_tFileList_1 = files_tFileList_1.getName(); 
      String currentFilePath_tFileList_1 = files_tFileList_1.getAbsolutePath();
      String currentFileDirectory_tFileList_1 = files_tFileList_1.getParent();
      String currentFileExtension_tFileList_1 = null;
      
      if (files_tFileList_1.getName().contains(".") && files_tFileList_1.isFile()){
        currentFileExtension_tFileList_1 = files_tFileList_1.getName().substring(files_tFileList_1.getName().lastIndexOf(".") + 1);
      } else{
        currentFileExtension_tFileList_1 = "";
      }
      
      NB_FILEtFileList_1 ++;
      globalMap.put("tFileList_1_CURRENT_FILE", currentFileName_tFileList_1);
      globalMap.put("tFileList_1_CURRENT_FILEPATH", currentFilePath_tFileList_1);
      globalMap.put("tFileList_1_CURRENT_FILEDIRECTORY", currentFileDirectory_tFileList_1);
      globalMap.put("tFileList_1_CURRENT_FILEEXTENSION", currentFileExtension_tFileList_1);
      globalMap.put("tFileList_1_NB_FILE", NB_FILEtFileList_1);
      
 



/**
 * [tFileList_1 begin ] stop
 */
	
	/**
	 * [tFileList_1 main ] start
	 */

	

	
	
	currentComponent="tFileList_1";

	

 


	tos_count_tFileList_1++;

/**
 * [tFileList_1 main ] stop
 */
	
	/**
	 * [tFileList_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFileList_1";

	

 



/**
 * [tFileList_1 process_data_begin ] stop
 */
	NB_ITERATE_tFileArchive_1++;
	
	
				if(execStat){
					runStat.updateStatOnConnection("iterate1", 1, "exec" + NB_ITERATE_tFileArchive_1);
					//Thread.sleep(1000);
				}				
			

	
	/**
	 * [tFileArchive_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileArchive_1", false);
		start_Hash.put("tFileArchive_1", System.currentTimeMillis());
		
				tStatCatcher_1.addMessage("begin","tFileArchive_1");
				tStatCatcher_1Process(globalMap);
			
	
	currentComponent="tFileArchive_1";

	
		int tos_count_tFileArchive_1 = 0;
		

 



/**
 * [tFileArchive_1 begin ] stop
 */
	
	/**
	 * [tFileArchive_1 main ] start
	 */

	

	
	
	currentComponent="tFileArchive_1";

	

	

		String sourceFile_tFileArchive_1 = "C:/CC2/Groupe1/5_DATA_IN";
	

    if (java.nio.file.Files.notExists(java.nio.file.Paths.get(sourceFile_tFileArchive_1), java.nio.file.LinkOption.NOFOLLOW_LINKS)){
        throw new java.io.FileNotFoundException(sourceFile_tFileArchive_1 + " (The system cannot find the path specified)");
    }

    String zipFile_tFileArchive_1 = "C:/CC2/Groupe1/6_DATA_IN_ZIP/" + ((String)globalMap.get("tFileList_1_CURRENT_FILE")) + ".zip";
    
    com.talend.compress.zip.Zip zip_tFileArchive_1 = new com.talend.compress.zip.Zip(sourceFile_tFileArchive_1, zipFile_tFileArchive_1);
    zip_tFileArchive_1.setOverwriteExistTargetZip(true);
	zip_tFileArchive_1.setMakeTargetDir(false);
	zip_tFileArchive_1.setCompressLevel(4);
	zip_tFileArchive_1.setArchiveFormat("zip");
	zip_tFileArchive_1.setAllFiles(false);
	
	  
    	//build filename pattern filter
	    String[] patterns_tFileArchive_1 = new String[1];
    	
	        patterns_tFileArchive_1[0] = ((String)globalMap.get("tFileList_1_CURRENT_FILE"));
  		StringBuilder sbf_tFileArchive_1 = new StringBuilder(); 
        sbf_tFileArchive_1.append("(");
        for (int i_tFileArchive_1 = 0 ; i_tFileArchive_1 < patterns_tFileArchive_1.length ; i_tFileArchive_1++) {
            sbf_tFileArchive_1.append(patterns_tFileArchive_1[i_tFileArchive_1].replaceAll("\\.", "\\\\.").replaceAll("\\*", ".*"));
            if(i_tFileArchive_1 != patterns_tFileArchive_1.length-1) sbf_tFileArchive_1.append("|");
        }        
        sbf_tFileArchive_1.append(")");
        final String maskStr_tFileArchive_1 = new String(sbf_tFileArchive_1.toString());
        
        //apply the filter
       	zip_tFileArchive_1.setNamePatternFilter(maskStr_tFileArchive_1);
	
	   zip_tFileArchive_1.setContainSubDir(true);
	   zip_tFileArchive_1.setEncoding("ISO-8859-15");
	   zip_tFileArchive_1.setZip64Mode("ASNEEDED");
	   zip_tFileArchive_1.setEncrypted(false);
		        
	   
	    
	    
	final String decryptedPassword_tFileArchive_1 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:EGr4To8s37/PQVuz7NSRuZXjr7KpSKbLgtMNcw==");
	    
	   zip_tFileArchive_1.setPassword(decryptedPassword_tFileArchive_1);
	   
	      zip_tFileArchive_1.setUseZip4jEncryption(true);
	      zip_tFileArchive_1.setEncryptionMethod(net.lingala.zip4j.util.Zip4jConstants.ENC_METHOD_STANDARD);
	      
  
  
   globalMap.put("tFileArchive_1_ARCHIVE_FILEPATH",zipFile_tFileArchive_1);
   
   globalMap.put("tFileArchive_1_ARCHIVE_FILENAME", new java.io.File(zipFile_tFileArchive_1).getName());

   zip_tFileArchive_1.doZip();


 


	tos_count_tFileArchive_1++;

/**
 * [tFileArchive_1 main ] stop
 */
	
	/**
	 * [tFileArchive_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFileArchive_1";

	

 



/**
 * [tFileArchive_1 process_data_begin ] stop
 */
	
	/**
	 * [tFileArchive_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tFileArchive_1";

	

 



/**
 * [tFileArchive_1 process_data_end ] stop
 */
	
	/**
	 * [tFileArchive_1 end ] start
	 */

	

	
	
	currentComponent="tFileArchive_1";

	

 

ok_Hash.put("tFileArchive_1", true);
end_Hash.put("tFileArchive_1", System.currentTimeMillis());

tStatCatcher_1.addMessage("end","tFileArchive_1", end_Hash.get("tFileArchive_1")-start_Hash.get("tFileArchive_1"));
tStatCatcher_1Process(globalMap);



/**
 * [tFileArchive_1 end ] stop
 */
						if(execStat){
							runStat.updateStatOnConnection("iterate1", 2, "exec" + NB_ITERATE_tFileArchive_1);
						}				
					




	
	/**
	 * [tFileList_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tFileList_1";

	

 



/**
 * [tFileList_1 process_data_end ] stop
 */
	
	/**
	 * [tFileList_1 end ] start
	 */

	

	
	
	currentComponent="tFileList_1";

	

  
    }
  globalMap.put("tFileList_1_NB_FILE", NB_FILEtFileList_1);
  

  
 

 

ok_Hash.put("tFileList_1", true);
end_Hash.put("tFileList_1", System.currentTimeMillis());

tStatCatcher_1.addMessage("end","tFileList_1", end_Hash.get("tFileList_1")-start_Hash.get("tFileList_1"));
tStatCatcher_1Process(globalMap);



/**
 * [tFileList_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFileList_1 finally ] start
	 */

	

	
	
	currentComponent="tFileList_1";

	

 



/**
 * [tFileList_1 finally ] stop
 */

	
	/**
	 * [tFileArchive_1 finally ] start
	 */

	

	
	
	currentComponent="tFileArchive_1";

	

 



/**
 * [tFileArchive_1 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFileList_1_SUBPROCESS_STATE", 1);
	}
	
    public String resuming_logs_dir_path = null;
    public String resuming_checkpoint_path = null;
    public String parent_part_launcher = null;
    private String resumeEntryMethodName = null;
    private boolean globalResumeTicket = false;

    public boolean watch = false;
    // portStats is null, it means don't execute the statistics
    public Integer portStats = null;
    public int portTraces = 4334;
    public String clientHost;
    public String defaultClientHost = "localhost";
    public String contextStr = "Default";
    public boolean isDefaultContext = true;
    public String pid = "0";
    public String rootPid = null;
    public String fatherPid = null;
    public String fatherNode = null;
    public long startTime = 0;
    public boolean isChildJob = false;
    public String log4jLevel = "";
    
    private boolean enableLogStash;

    private boolean execStat = true;

    private ThreadLocal<java.util.Map<String, String>> threadLocal = new ThreadLocal<java.util.Map<String, String>>() {
        protected java.util.Map<String, String> initialValue() {
            java.util.Map<String,String> threadRunResultMap = new java.util.HashMap<String, String>();
            threadRunResultMap.put("errorCode", null);
            threadRunResultMap.put("status", "");
            return threadRunResultMap;
        };
    };


    protected PropertiesWithType context_param = new PropertiesWithType();
    public java.util.Map<String, Object> parentContextMap = new java.util.HashMap<String, Object>();

    public String status= "";
    

    public static void main(String[] args){
        final B_ALIM_DM1_STAGING B_ALIM_DM1_STAGINGClass = new B_ALIM_DM1_STAGING();

        int exitCode = B_ALIM_DM1_STAGINGClass.runJobInTOS(args);

        System.exit(exitCode);
    }


    public String[][] runJob(String[] args) {

        int exitCode = runJobInTOS(args);
        String[][] bufferValue = new String[][] { { Integer.toString(exitCode) } };

        return bufferValue;
    }

    public boolean hastBufferOutputComponent() {
		boolean hastBufferOutput = false;
    	
        return hastBufferOutput;
    }

    public int runJobInTOS(String[] args) {
	   	// reset status
	   	status = "";
	   	
        String lastStr = "";
        for (String arg : args) {
            if (arg.equalsIgnoreCase("--context_param")) {
                lastStr = arg;
            } else if (lastStr.equals("")) {
                evalParam(arg);
            } else {
                evalParam(lastStr + " " + arg);
                lastStr = "";
            }
        }
        enableLogStash = "true".equalsIgnoreCase(System.getProperty("audit.enabled"));

    	
    	

        if(clientHost == null) {
            clientHost = defaultClientHost;
        }

        if(pid == null || "0".equals(pid)) {
            pid = TalendString.getAsciiRandomString(6);
        }

        if (rootPid==null) {
            rootPid = pid;
        }
        if (fatherPid==null) {
            fatherPid = pid;
        }else{
            isChildJob = true;
        }

        if (portStats != null) {
            // portStats = -1; //for testing
            if (portStats < 0 || portStats > 65535) {
                // issue:10869, the portStats is invalid, so this client socket can't open
                System.err.println("The statistics socket port " + portStats + " is invalid.");
                execStat = false;
            }
        } else {
            execStat = false;
        }
        boolean inOSGi = routines.system.BundleUtils.inOSGi();

        if (inOSGi) {
            java.util.Dictionary<String, Object> jobProperties = routines.system.BundleUtils.getJobProperties(jobName);

            if (jobProperties != null && jobProperties.get("context") != null) {
                contextStr = (String)jobProperties.get("context");
            }
        }

        try {
            //call job/subjob with an existing context, like: --context=production. if without this parameter, there will use the default context instead.
            java.io.InputStream inContext = B_ALIM_DM1_STAGING.class.getClassLoader().getResourceAsStream("alimentation_dm1/b_alim_dm1_staging_0_1/contexts/" + contextStr + ".properties");
            if (inContext == null) {
                inContext = B_ALIM_DM1_STAGING.class.getClassLoader().getResourceAsStream("config/contexts/" + contextStr + ".properties");
            }
            if (inContext != null) {
                try {
                    //defaultProps is in order to keep the original context value
                    if(context != null && context.isEmpty()) {
	                defaultProps.load(inContext);
	                context = new ContextProperties(defaultProps);
                    }
                } finally {
                    inContext.close();
                }
            } else if (!isDefaultContext) {
                //print info and job continue to run, for case: context_param is not empty.
                System.err.println("Could not find the context " + contextStr);
            }

            if(!context_param.isEmpty()) {
                context.putAll(context_param);
				//set types for params from parentJobs
				for (Object key: context_param.keySet()){
					String context_key = key.toString();
					String context_type = context_param.getContextType(context_key);
					context.setContextType(context_key, context_type);

				}
            }
            class ContextProcessing {
                private void processContext_0() {
                } 
                public void processAllContext() {
                        processContext_0();
                }
            }

            new ContextProcessing().processAllContext();
        } catch (java.io.IOException ie) {
            System.err.println("Could not load context "+contextStr);
            ie.printStackTrace();
        }

        // get context value from parent directly
        if (parentContextMap != null && !parentContextMap.isEmpty()) {
        }

        //Resume: init the resumeUtil
        resumeEntryMethodName = ResumeUtil.getResumeEntryMethodName(resuming_checkpoint_path);
        resumeUtil = new ResumeUtil(resuming_logs_dir_path, isChildJob, rootPid);
        resumeUtil.initCommonInfo(pid, rootPid, fatherPid, projectName, jobName, contextStr, jobVersion);

		List<String> parametersToEncrypt = new java.util.ArrayList<String>();
        //Resume: jobStart
        resumeUtil.addLog("JOB_STARTED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","","","",resumeUtil.convertToJsonText(context,parametersToEncrypt));

if(execStat) {
    try {
        runStat.openSocket(!isChildJob);
        runStat.setAllPID(rootPid, fatherPid, pid, jobName);
        runStat.startThreadStat(clientHost, portStats);
        runStat.updateStatOnJob(RunStat.JOBSTART, fatherNode);
    } catch (java.io.IOException ioException) {
        ioException.printStackTrace();
    }
}



	
	    java.util.concurrent.ConcurrentHashMap<Object, Object> concurrentHashMap = new java.util.concurrent.ConcurrentHashMap<Object, Object>();
	    globalMap.put("concurrentHashMap", concurrentHashMap);
	

    long startUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
    long endUsedMemory = 0;
    long end = 0;

    startTime = System.currentTimeMillis();
        tStatCatcher_1.addMessage("begin");


this.globalResumeTicket = true;//to run tPreJob




        try {
            tStatCatcher_1Process(globalMap);
        } catch (java.lang.Exception e) {
            e.printStackTrace();
        }

this.globalResumeTicket = false;//to run others jobs

try {
errorCode = null;tFileInputExcel_1Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tFileInputExcel_1) {
globalMap.put("tFileInputExcel_1_SUBPROCESS_STATE", -1);

e_tFileInputExcel_1.printStackTrace();

}

this.globalResumeTicket = true;//to run tPostJob




        end = System.currentTimeMillis();

        if (watch) {
            System.out.println((end-startTime)+" milliseconds");
        }

        endUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        if (false) {
            System.out.println((endUsedMemory - startUsedMemory) + " bytes memory increase when running : B_ALIM_DM1_STAGING");
        }
        tStatCatcher_1.addMessage(status==""?"end":status, (end-startTime));
        try {
            tStatCatcher_1Process(globalMap);
        } catch (java.lang.Exception e) {
            e.printStackTrace();
        }



if (execStat) {
    runStat.updateStatOnJob(RunStat.JOBEND, fatherNode);
    runStat.stopThreadStat();
}
    int returnCode = 0;


    if(errorCode == null) {
         returnCode = status != null && status.equals("failure") ? 1 : 0;
    } else {
         returnCode = errorCode.intValue();
    }
    resumeUtil.addLog("JOB_ENDED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","" + returnCode,"","","");

    return returnCode;

  }

    // only for OSGi env
    public void destroy() {


    }














    private java.util.Map<String, Object> getSharedConnections4REST() {
        java.util.Map<String, Object> connections = new java.util.HashMap<String, Object>();






        return connections;
    }

    private void evalParam(String arg) {
        if (arg.startsWith("--resuming_logs_dir_path")) {
            resuming_logs_dir_path = arg.substring(25);
        } else if (arg.startsWith("--resuming_checkpoint_path")) {
            resuming_checkpoint_path = arg.substring(27);
        } else if (arg.startsWith("--parent_part_launcher")) {
            parent_part_launcher = arg.substring(23);
        } else if (arg.startsWith("--watch")) {
            watch = true;
        } else if (arg.startsWith("--stat_port=")) {
            String portStatsStr = arg.substring(12);
            if (portStatsStr != null && !portStatsStr.equals("null")) {
                portStats = Integer.parseInt(portStatsStr);
            }
        } else if (arg.startsWith("--trace_port=")) {
            portTraces = Integer.parseInt(arg.substring(13));
        } else if (arg.startsWith("--client_host=")) {
            clientHost = arg.substring(14);
        } else if (arg.startsWith("--context=")) {
            contextStr = arg.substring(10);
            isDefaultContext = false;
        } else if (arg.startsWith("--father_pid=")) {
            fatherPid = arg.substring(13);
        } else if (arg.startsWith("--root_pid=")) {
            rootPid = arg.substring(11);
        } else if (arg.startsWith("--father_node=")) {
            fatherNode = arg.substring(14);
        } else if (arg.startsWith("--pid=")) {
            pid = arg.substring(6);
        } else if (arg.startsWith("--context_type")) {
            String keyValue = arg.substring(15);
			int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.setContextType(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.setContextType(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }

            }

		} else if (arg.startsWith("--context_param")) {
            String keyValue = arg.substring(16);
            int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.put(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.put(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }
            }
        } else if (arg.startsWith("--log4jLevel=")) {
            log4jLevel = arg.substring(13);
		} else if (arg.startsWith("--audit.enabled") && arg.contains("=")) {//for trunjob call
		    final int equal = arg.indexOf('=');
			final String key = arg.substring("--".length(), equal);
			System.setProperty(key, arg.substring(equal + 1));
		}
    }
    
    private static final String NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY = "<TALEND_NULL>";

    private final String[][] escapeChars = {
        {"\\\\","\\"},{"\\n","\n"},{"\\'","\'"},{"\\r","\r"},
        {"\\f","\f"},{"\\b","\b"},{"\\t","\t"}
        };
    private String replaceEscapeChars (String keyValue) {

		if (keyValue == null || ("").equals(keyValue.trim())) {
			return keyValue;
		}

		StringBuilder result = new StringBuilder();
		int currIndex = 0;
		while (currIndex < keyValue.length()) {
			int index = -1;
			// judege if the left string includes escape chars
			for (String[] strArray : escapeChars) {
				index = keyValue.indexOf(strArray[0],currIndex);
				if (index>=0) {

					result.append(keyValue.substring(currIndex, index + strArray[0].length()).replace(strArray[0], strArray[1]));
					currIndex = index + strArray[0].length();
					break;
				}
			}
			// if the left string doesn't include escape chars, append the left into the result
			if (index < 0) {
				result.append(keyValue.substring(currIndex));
				currIndex = currIndex + keyValue.length();
			}
		}

		return result.toString();
    }

    public Integer getErrorCode() {
        return errorCode;
    }


    public String getStatus() {
        return status;
    }

    ResumeUtil resumeUtil = null;
}
/************************************************************************************************
 *     184061 characters generated by Talend Open Studio for Data Integration 
 *     on the 9 janvier 2024 à 20:33:11 CET
 ************************************************************************************************/