// ============================================================================
//
// Copyright (c) 2006-2015, Talend SA
//
// Ce code source a été automatiquement généré par_Talend Open Studio for Data Integration
// / Soumis à la Licence Apache, Version 2.0 (la "Licence") ;
// votre utilisation de ce fichier doit respecter les termes de la Licence.
// Vous pouvez obtenir une copie de la Licence sur
// http://www.apache.org/licenses/LICENSE-2.0
// 
// Sauf lorsqu'explicitement prévu par la loi en vigueur ou accepté par écrit, le logiciel
// distribué sous la Licence est distribué "TEL QUEL",
// SANS GARANTIE OU CONDITION D'AUCUNE SORTE, expresse ou implicite.
// Consultez la Licence pour connaître la terminologie spécifique régissant les autorisations et
// les limites prévues par la Licence.


package alimentation_dm1.f_alim_fait_0_1;

import routines.Numeric;
import routines.DataOperation;
import routines.TalendDataGenerator;
import routines.TalendStringUtil;
import routines.TalendString;
import routines.StringHandling;
import routines.Relational;
import routines.TalendDate;
import routines.Mathematical;
import routines.system.*;
import routines.system.api.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.math.BigDecimal;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.util.Comparator;
 





@SuppressWarnings("unused")

/**
 * Job: F_ALIM_FAIT Purpose: Job qui alimente la table de fait<br>
 * Description: Job qui alimente la table de fait <br>
 * @author user@talend.com
 * @version 8.0.1.20211109_1610
 * @status 
 */
public class F_ALIM_FAIT implements TalendJob {

protected static void logIgnoredError(String message, Throwable cause) {
       System.err.println(message);
       if (cause != null) {
               cause.printStackTrace();
       }

}


	public final Object obj = new Object();

	// for transmiting parameters purpose
	private Object valueObject = null;

	public Object getValueObject() {
		return this.valueObject;
	}

	public void setValueObject(Object valueObject) {
		this.valueObject = valueObject;
	}
	
	private final static String defaultCharset = java.nio.charset.Charset.defaultCharset().name();

	
	private final static String utf8Charset = "UTF-8";
	//contains type for every context property
	public class PropertiesWithType extends java.util.Properties {
		private static final long serialVersionUID = 1L;
		private java.util.Map<String,String> propertyTypes = new java.util.HashMap<>();
		
		public PropertiesWithType(java.util.Properties properties){
			super(properties);
		}
		public PropertiesWithType(){
			super();
		}
		
		public void setContextType(String key, String type) {
			propertyTypes.put(key,type);
		}
	
		public String getContextType(String key) {
			return propertyTypes.get(key);
		}
	}
	
	// create and load default properties
	private java.util.Properties defaultProps = new java.util.Properties();
	// create application properties with default
	public class ContextProperties extends PropertiesWithType {

		private static final long serialVersionUID = 1L;

		public ContextProperties(java.util.Properties properties){
			super(properties);
		}
		public ContextProperties(){
			super();
		}

		public void synchronizeContext(){
			
		}
		
		//if the stored or passed value is "<TALEND_NULL>" string, it mean null
		public String getStringValue(String key) {
			String origin_value = this.getProperty(key);
			if(NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY.equals(origin_value)) {
				return null;
			}
			return origin_value;
		}

	}
	protected ContextProperties context = new ContextProperties(); // will be instanciated by MS.
	public ContextProperties getContext() {
		return this.context;
	}
	private final String jobVersion = "0.1";
	private final String jobName = "F_ALIM_FAIT";
	private final String projectName = "ALIMENTATION_DM1";
	public Integer errorCode = null;
	private String currentComponent = "";
	
		private final java.util.Map<String, Object> globalMap = new java.util.HashMap<String, Object>();
        private final static java.util.Map<String, Object> junitGlobalMap = new java.util.HashMap<String, Object>();
	
		private final java.util.Map<String, Long> start_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Long> end_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Boolean> ok_Hash = new java.util.HashMap<String, Boolean>();
		public  final java.util.List<String[]> globalBuffer = new java.util.ArrayList<String[]>();
	

private RunStat runStat = new RunStat();

	// OSGi DataSource
	private final static String KEY_DB_DATASOURCES = "KEY_DB_DATASOURCES";
	
	private final static String KEY_DB_DATASOURCES_RAW = "KEY_DB_DATASOURCES_RAW";

	public void setDataSources(java.util.Map<String, javax.sql.DataSource> dataSources) {
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		for (java.util.Map.Entry<String, javax.sql.DataSource> dataSourceEntry : dataSources.entrySet()) {
			talendDataSources.put(dataSourceEntry.getKey(), new routines.system.TalendDataSource(dataSourceEntry.getValue()));
		}
		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}
	
	public void setDataSourceReferences(List serviceReferences) throws Exception{
		
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		java.util.Map<String, javax.sql.DataSource> dataSources = new java.util.HashMap<String, javax.sql.DataSource>();
		
		for (java.util.Map.Entry<String, javax.sql.DataSource> entry : BundleUtils.getServices(serviceReferences,  javax.sql.DataSource.class).entrySet()) {
                    dataSources.put(entry.getKey(), entry.getValue());
                    talendDataSources.put(entry.getKey(), new routines.system.TalendDataSource(entry.getValue()));
		}

		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}

	StatCatcherUtils tStatCatcher_1 = new StatCatcherUtils("_46NSgKTtEe6HdLQjDeTAqA", "0.1");

private final java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
private final java.io.PrintStream errorMessagePS = new java.io.PrintStream(new java.io.BufferedOutputStream(baos));

public String getExceptionStackTrace() {
	if ("failure".equals(this.getStatus())) {
		errorMessagePS.flush();
		return baos.toString();
	}
	return null;
}

private Exception exception;

public Exception getException() {
	if ("failure".equals(this.getStatus())) {
		return this.exception;
	}
	return null;
}

private class TalendException extends Exception {

	private static final long serialVersionUID = 1L;

	private java.util.Map<String, Object> globalMap = null;
	private Exception e = null;
	private String currentComponent = null;
	private String virtualComponentName = null;
	
	public void setVirtualComponentName (String virtualComponentName){
		this.virtualComponentName = virtualComponentName;
	}

	private TalendException(Exception e, String errorComponent, final java.util.Map<String, Object> globalMap) {
		this.currentComponent= errorComponent;
		this.globalMap = globalMap;
		this.e = e;
	}

	public Exception getException() {
		return this.e;
	}

	public String getCurrentComponent() {
		return this.currentComponent;
	}

	
    public String getExceptionCauseMessage(Exception e){
        Throwable cause = e;
        String message = null;
        int i = 10;
        while (null != cause && 0 < i--) {
            message = cause.getMessage();
            if (null == message) {
                cause = cause.getCause();
            } else {
                break;          
            }
        }
        if (null == message) {
            message = e.getClass().getName();
        }   
        return message;
    }

	@Override
	public void printStackTrace() {
		if (!(e instanceof TalendException || e instanceof TDieException)) {
			if(virtualComponentName!=null && currentComponent.indexOf(virtualComponentName+"_")==0){
				globalMap.put(virtualComponentName+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			}
			globalMap.put(currentComponent+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			System.err.println("Exception in component " + currentComponent + " (" + jobName + ")");
		}
		if (!(e instanceof TDieException)) {
			if(e instanceof TalendException){
				e.printStackTrace();
			} else {
				e.printStackTrace();
				e.printStackTrace(errorMessagePS);
				F_ALIM_FAIT.this.exception = e;
			}
		}
		if (!(e instanceof TalendException)) {
		try {
			for (java.lang.reflect.Method m : this.getClass().getEnclosingClass().getMethods()) {
				if (m.getName().compareTo(currentComponent + "_error") == 0) {
					m.invoke(F_ALIM_FAIT.this, new Object[] { e , currentComponent, globalMap});
					break;
				}
			}

			if(!(e instanceof TDieException)){
			}
		} catch (Exception e) {
			this.e.printStackTrace();
		}
		}
	}
}

			public void tStatCatcher_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tStatCatcher_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tStatCatcher_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBInput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
							tStatCatcher_1.addMessage("failure",errorComponent, end_Hash.get(errorComponent)-start_Hash.get(errorComponent));
							tStatCatcher_1Process(globalMap);
							
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMap_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
							tStatCatcher_1.addMessage("failure",errorComponent, end_Hash.get(errorComponent)-start_Hash.get(errorComponent));
							tStatCatcher_1Process(globalMap);
							
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
							tStatCatcher_1.addMessage("failure",errorComponent, end_Hash.get(errorComponent)-start_Hash.get(errorComponent));
							tStatCatcher_1Process(globalMap);
							
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBInput_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
							tStatCatcher_1.addMessage("failure",errorComponent, end_Hash.get(errorComponent)-start_Hash.get(errorComponent));
							tStatCatcher_1Process(globalMap);
							
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBInput_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
							tStatCatcher_1.addMessage("failure",errorComponent, end_Hash.get(errorComponent)-start_Hash.get(errorComponent));
							tStatCatcher_1Process(globalMap);
							
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBInput_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
							tStatCatcher_1.addMessage("failure",errorComponent, end_Hash.get(errorComponent)-start_Hash.get(errorComponent));
							tStatCatcher_1Process(globalMap);
							
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBInput_5_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
							tStatCatcher_1.addMessage("failure",errorComponent, end_Hash.get(errorComponent)-start_Hash.get(errorComponent));
							tStatCatcher_1Process(globalMap);
							
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBInput_6_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
							tStatCatcher_1.addMessage("failure",errorComponent, end_Hash.get(errorComponent)-start_Hash.get(errorComponent));
							tStatCatcher_1Process(globalMap);
							
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBInput_7_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
							tStatCatcher_1.addMessage("failure",errorComponent, end_Hash.get(errorComponent)-start_Hash.get(errorComponent));
							tStatCatcher_1Process(globalMap);
							
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBInput_8_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBInput_9_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
							tStatCatcher_1.addMessage("failure",errorComponent, end_Hash.get(errorComponent)-start_Hash.get(errorComponent));
							tStatCatcher_1Process(globalMap);
							
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBInput_10_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
							tStatCatcher_1.addMessage("failure",errorComponent, end_Hash.get(errorComponent)-start_Hash.get(errorComponent));
							tStatCatcher_1Process(globalMap);
							
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tAdvancedHash_row3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tAdvancedHash_row4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tAdvancedHash_row5_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tAdvancedHash_row6_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tAdvancedHash_row7_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tAdvancedHash_row8_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tAdvancedHash_row9_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tAdvancedHash_row10_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tAdvancedHash_row11_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tStatCatcher_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBInput_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
	






public static class row1Struct implements routines.system.IPersistableRow<row1Struct> {
    final static byte[] commonByteArrayLock_ALIMENTATION_DM1_F_ALIM_FAIT = new byte[0];
    static byte[] commonByteArray_ALIMENTATION_DM1_F_ALIM_FAIT = new byte[0];

	
			    public java.util.Date moment;

				public java.util.Date getMoment () {
					return this.moment;
				}
				
			    public String pid;

				public String getPid () {
					return this.pid;
				}
				
			    public String father_pid;

				public String getFather_pid () {
					return this.father_pid;
				}
				
			    public String root_pid;

				public String getRoot_pid () {
					return this.root_pid;
				}
				
			    public Long system_pid;

				public Long getSystem_pid () {
					return this.system_pid;
				}
				
			    public String project;

				public String getProject () {
					return this.project;
				}
				
			    public String job;

				public String getJob () {
					return this.job;
				}
				
			    public String job_repository_id;

				public String getJob_repository_id () {
					return this.job_repository_id;
				}
				
			    public String job_version;

				public String getJob_version () {
					return this.job_version;
				}
				
			    public String context;

				public String getContext () {
					return this.context;
				}
				
			    public String origin;

				public String getOrigin () {
					return this.origin;
				}
				
			    public String message_type;

				public String getMessage_type () {
					return this.message_type;
				}
				
			    public String message;

				public String getMessage () {
					return this.message;
				}
				
			    public Long duration;

				public Long getDuration () {
					return this.duration;
				}
				



	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_DM1_F_ALIM_FAIT.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_DM1_F_ALIM_FAIT.length == 0) {
   					commonByteArray_ALIMENTATION_DM1_F_ALIM_FAIT = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_DM1_F_ALIM_FAIT = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ALIMENTATION_DM1_F_ALIM_FAIT, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_DM1_F_ALIM_FAIT, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_DM1_F_ALIM_FAIT.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_DM1_F_ALIM_FAIT.length == 0) {
   					commonByteArray_ALIMENTATION_DM1_F_ALIM_FAIT = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_DM1_F_ALIM_FAIT = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ALIMENTATION_DM1_F_ALIM_FAIT, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_DM1_F_ALIM_FAIT, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_DM1_F_ALIM_FAIT) {

        	try {

        		int length = 0;
		
					this.moment = readDate(dis);
					
					this.pid = readString(dis);
					
					this.father_pid = readString(dis);
					
					this.root_pid = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.system_pid = null;
           				} else {
           			    	this.system_pid = dis.readLong();
           				}
					
					this.project = readString(dis);
					
					this.job = readString(dis);
					
					this.job_repository_id = readString(dis);
					
					this.job_version = readString(dis);
					
					this.context = readString(dis);
					
					this.origin = readString(dis);
					
					this.message_type = readString(dis);
					
					this.message = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.duration = null;
           				} else {
           			    	this.duration = dis.readLong();
           				}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_DM1_F_ALIM_FAIT) {

        	try {

        		int length = 0;
		
					this.moment = readDate(dis);
					
					this.pid = readString(dis);
					
					this.father_pid = readString(dis);
					
					this.root_pid = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.system_pid = null;
           				} else {
           			    	this.system_pid = dis.readLong();
           				}
					
					this.project = readString(dis);
					
					this.job = readString(dis);
					
					this.job_repository_id = readString(dis);
					
					this.job_version = readString(dis);
					
					this.context = readString(dis);
					
					this.origin = readString(dis);
					
					this.message_type = readString(dis);
					
					this.message = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.duration = null;
           				} else {
           			    	this.duration = dis.readLong();
           				}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// java.util.Date
				
						writeDate(this.moment,dos);
					
					// String
				
						writeString(this.pid,dos);
					
					// String
				
						writeString(this.father_pid,dos);
					
					// String
				
						writeString(this.root_pid,dos);
					
					// Long
				
						if(this.system_pid == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.system_pid);
		            	}
					
					// String
				
						writeString(this.project,dos);
					
					// String
				
						writeString(this.job,dos);
					
					// String
				
						writeString(this.job_repository_id,dos);
					
					// String
				
						writeString(this.job_version,dos);
					
					// String
				
						writeString(this.context,dos);
					
					// String
				
						writeString(this.origin,dos);
					
					// String
				
						writeString(this.message_type,dos);
					
					// String
				
						writeString(this.message,dos);
					
					// Long
				
						if(this.duration == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.duration);
		            	}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// java.util.Date
				
						writeDate(this.moment,dos);
					
					// String
				
						writeString(this.pid,dos);
					
					// String
				
						writeString(this.father_pid,dos);
					
					// String
				
						writeString(this.root_pid,dos);
					
					// Long
				
						if(this.system_pid == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.system_pid);
		            	}
					
					// String
				
						writeString(this.project,dos);
					
					// String
				
						writeString(this.job,dos);
					
					// String
				
						writeString(this.job_repository_id,dos);
					
					// String
				
						writeString(this.job_version,dos);
					
					// String
				
						writeString(this.context,dos);
					
					// String
				
						writeString(this.origin,dos);
					
					// String
				
						writeString(this.message_type,dos);
					
					// String
				
						writeString(this.message,dos);
					
					// Long
				
						if(this.duration == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.duration);
		            	}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("moment="+String.valueOf(moment));
		sb.append(",pid="+pid);
		sb.append(",father_pid="+father_pid);
		sb.append(",root_pid="+root_pid);
		sb.append(",system_pid="+String.valueOf(system_pid));
		sb.append(",project="+project);
		sb.append(",job="+job);
		sb.append(",job_repository_id="+job_repository_id);
		sb.append(",job_version="+job_version);
		sb.append(",context="+context);
		sb.append(",origin="+origin);
		sb.append(",message_type="+message_type);
		sb.append(",message="+message);
		sb.append(",duration="+String.valueOf(duration));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row1Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tStatCatcher_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tStatCatcher_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row1Struct row1 = new row1Struct();




	
	/**
	 * [tDBOutput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_1", false);
		start_Hash.put("tDBOutput_1", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_1";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row1");
					}
				
		int tos_count_tDBOutput_1 = 0;
		





String dbschema_tDBOutput_1 = null;
	dbschema_tDBOutput_1 = "dsid_liv_met";
	

String tableName_tDBOutput_1 = null;
if(dbschema_tDBOutput_1 == null || dbschema_tDBOutput_1.trim().length() == 0) {
	tableName_tDBOutput_1 = ("JOB_STATS");
} else {
	tableName_tDBOutput_1 = dbschema_tDBOutput_1 + "\".\"" + ("JOB_STATS");
}


int nb_line_tDBOutput_1 = 0;
int nb_line_update_tDBOutput_1 = 0;
int nb_line_inserted_tDBOutput_1 = 0;
int nb_line_deleted_tDBOutput_1 = 0;
int nb_line_rejected_tDBOutput_1 = 0;

int deletedCount_tDBOutput_1=0;
int updatedCount_tDBOutput_1=0;
int insertedCount_tDBOutput_1=0;
int rowsToCommitCount_tDBOutput_1=0;
int rejectedCount_tDBOutput_1=0;

boolean whetherReject_tDBOutput_1 = false;

java.sql.Connection conn_tDBOutput_1 = null;
String dbUser_tDBOutput_1 = null;

	
    java.lang.Class.forName("org.postgresql.Driver");
    
        String url_tDBOutput_1 = "jdbc:postgresql://"+""+":"+"5432"+"/"+"postgres";
    dbUser_tDBOutput_1 = "dsid_cc2_tos_rw";
 
	final String decryptedPassword_tDBOutput_1 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:rKTn3nuFCK5VomoEu6s9/sbsCbrN28NQlwn8KELOoXI=");

    String dbPwd_tDBOutput_1 = decryptedPassword_tDBOutput_1;

    conn_tDBOutput_1 = java.sql.DriverManager.getConnection(url_tDBOutput_1,dbUser_tDBOutput_1,dbPwd_tDBOutput_1);
	
	resourceMap.put("conn_tDBOutput_1", conn_tDBOutput_1);
        conn_tDBOutput_1.setAutoCommit(false);
        int commitEvery_tDBOutput_1 = 10000;
        int commitCounter_tDBOutput_1 = 0;


   int batchSize_tDBOutput_1 = 10000;
   int batchSizeCounter_tDBOutput_1=0;

int count_tDBOutput_1=0;
	    String insert_tDBOutput_1 = "INSERT INTO \"" + tableName_tDBOutput_1 + "\" (\"moment\",\"pid\",\"father_pid\",\"root_pid\",\"system_pid\",\"project\",\"job\",\"job_repository_id\",\"job_version\",\"context\",\"origin\",\"message_type\",\"message\",\"duration\") VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
	    
	    java.sql.PreparedStatement pstmt_tDBOutput_1 = conn_tDBOutput_1.prepareStatement(insert_tDBOutput_1);
	    resourceMap.put("pstmt_tDBOutput_1", pstmt_tDBOutput_1);
	    

 



/**
 * [tDBOutput_1 begin ] stop
 */



	
	/**
	 * [tStatCatcher_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tStatCatcher_1", false);
		start_Hash.put("tStatCatcher_1", System.currentTimeMillis());
		
	
	currentComponent="tStatCatcher_1";

	
		int tos_count_tStatCatcher_1 = 0;
		

	for (StatCatcherUtils.StatCatcherMessage scm : tStatCatcher_1.getMessages()) {
		row1.pid = pid;
		row1.root_pid = rootPid;
		row1.father_pid = fatherPid;	
    	row1.project = projectName;
    	row1.job = jobName;
    	row1.context = contextStr;
		row1.origin = (scm.getOrigin()==null || scm.getOrigin().length()<1 ? null : scm.getOrigin());
		row1.message = scm.getMessage();
		row1.duration = scm.getDuration();
		row1.moment = scm.getMoment();
		row1.message_type = scm.getMessageType();
		row1.job_version = scm.getJobVersion();
		row1.job_repository_id = scm.getJobId();
		row1.system_pid = scm.getSystemPid();

 



/**
 * [tStatCatcher_1 begin ] stop
 */
	
	/**
	 * [tStatCatcher_1 main ] start
	 */

	

	
	
	currentComponent="tStatCatcher_1";

	

 


	tos_count_tStatCatcher_1++;

/**
 * [tStatCatcher_1 main ] stop
 */
	
	/**
	 * [tStatCatcher_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tStatCatcher_1";

	

 



/**
 * [tStatCatcher_1 process_data_begin ] stop
 */

	
	/**
	 * [tDBOutput_1 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row1"
						
						);
					}
					



        whetherReject_tDBOutput_1 = false;
                    if(row1.moment != null) {
pstmt_tDBOutput_1.setTimestamp(1, new java.sql.Timestamp(row1.moment.getTime()));
} else {
pstmt_tDBOutput_1.setNull(1, java.sql.Types.TIMESTAMP);
}

                    if(row1.pid == null) {
pstmt_tDBOutput_1.setNull(2, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(2, row1.pid);
}

                    if(row1.father_pid == null) {
pstmt_tDBOutput_1.setNull(3, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(3, row1.father_pid);
}

                    if(row1.root_pid == null) {
pstmt_tDBOutput_1.setNull(4, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(4, row1.root_pid);
}

                    if(row1.system_pid == null) {
pstmt_tDBOutput_1.setNull(5, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_1.setLong(5, row1.system_pid);
}

                    if(row1.project == null) {
pstmt_tDBOutput_1.setNull(6, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(6, row1.project);
}

                    if(row1.job == null) {
pstmt_tDBOutput_1.setNull(7, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(7, row1.job);
}

                    if(row1.job_repository_id == null) {
pstmt_tDBOutput_1.setNull(8, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(8, row1.job_repository_id);
}

                    if(row1.job_version == null) {
pstmt_tDBOutput_1.setNull(9, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(9, row1.job_version);
}

                    if(row1.context == null) {
pstmt_tDBOutput_1.setNull(10, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(10, row1.context);
}

                    if(row1.origin == null) {
pstmt_tDBOutput_1.setNull(11, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(11, row1.origin);
}

                    if(row1.message_type == null) {
pstmt_tDBOutput_1.setNull(12, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(12, row1.message_type);
}

                    if(row1.message == null) {
pstmt_tDBOutput_1.setNull(13, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(13, row1.message);
}

                    if(row1.duration == null) {
pstmt_tDBOutput_1.setNull(14, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_1.setLong(14, row1.duration);
}

			
    		pstmt_tDBOutput_1.addBatch();
    		nb_line_tDBOutput_1++;
    		  
    		  
    		  batchSizeCounter_tDBOutput_1++;
    		  
    			if ((batchSize_tDBOutput_1 > 0) && (batchSize_tDBOutput_1 <= batchSizeCounter_tDBOutput_1)) {
                try {
						int countSum_tDBOutput_1 = 0;
						    
						for(int countEach_tDBOutput_1: pstmt_tDBOutput_1.executeBatch()) {
							countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
						}
				    	rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
				    	
				    		insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
				    	
            	    	batchSizeCounter_tDBOutput_1 = 0;
                }catch (java.sql.BatchUpdateException e_tDBOutput_1){
globalMap.put("tDBOutput_1_ERROR_MESSAGE",e_tDBOutput_1.getMessage());
				    	java.sql.SQLException ne_tDBOutput_1 = e_tDBOutput_1.getNextException(),sqle_tDBOutput_1=null;
				    	String errormessage_tDBOutput_1;
						if (ne_tDBOutput_1 != null) {
							// build new exception to provide the original cause
							sqle_tDBOutput_1 = new java.sql.SQLException(e_tDBOutput_1.getMessage() + "\ncaused by: " + ne_tDBOutput_1.getMessage(), ne_tDBOutput_1.getSQLState(), ne_tDBOutput_1.getErrorCode(), ne_tDBOutput_1);
							errormessage_tDBOutput_1 = sqle_tDBOutput_1.getMessage();
						}else{
							errormessage_tDBOutput_1 = e_tDBOutput_1.getMessage();
						}
				    	
				    	int countSum_tDBOutput_1 = 0;
						for(int countEach_tDBOutput_1: e_tDBOutput_1.getUpdateCounts()) {
							countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
						}
						rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
						
				    		insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
				    	
				    	System.err.println(errormessage_tDBOutput_1);
				    	
					}
    			}
    		
    		    commitCounter_tDBOutput_1++;
                if(commitEvery_tDBOutput_1 <= commitCounter_tDBOutput_1) {
                if ((batchSize_tDBOutput_1 > 0) && (batchSizeCounter_tDBOutput_1 > 0)) {
                try {
                		int countSum_tDBOutput_1 = 0;
                		    
						for(int countEach_tDBOutput_1: pstmt_tDBOutput_1.executeBatch()) {
							countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
						}
            	    	rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
            	    	
            	    		insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
            	    	
                batchSizeCounter_tDBOutput_1 = 0;
               }catch (java.sql.BatchUpdateException e_tDBOutput_1){
globalMap.put("tDBOutput_1_ERROR_MESSAGE",e_tDBOutput_1.getMessage());
			    	java.sql.SQLException ne_tDBOutput_1 = e_tDBOutput_1.getNextException(),sqle_tDBOutput_1=null;
			    	String errormessage_tDBOutput_1;
					if (ne_tDBOutput_1 != null) {
						// build new exception to provide the original cause
						sqle_tDBOutput_1 = new java.sql.SQLException(e_tDBOutput_1.getMessage() + "\ncaused by: " + ne_tDBOutput_1.getMessage(), ne_tDBOutput_1.getSQLState(), ne_tDBOutput_1.getErrorCode(), ne_tDBOutput_1);
						errormessage_tDBOutput_1 = sqle_tDBOutput_1.getMessage();
					}else{
						errormessage_tDBOutput_1 = e_tDBOutput_1.getMessage();
					}
			    	
			    	int countSum_tDBOutput_1 = 0;
					for(int countEach_tDBOutput_1: e_tDBOutput_1.getUpdateCounts()) {
						countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
					}
					rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
					
			    		insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
			    	
			    	System.err.println(errormessage_tDBOutput_1);
			    	
				}
            }
                    if(rowsToCommitCount_tDBOutput_1 != 0){
                    	
                    }
                    conn_tDBOutput_1.commit();
                    if(rowsToCommitCount_tDBOutput_1 != 0){
                    	
                    	rowsToCommitCount_tDBOutput_1 = 0;
                    }
                    commitCounter_tDBOutput_1=0;
                }

 


	tos_count_tDBOutput_1++;

/**
 * [tDBOutput_1 main ] stop
 */
	
	/**
	 * [tDBOutput_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";

	

 



/**
 * [tDBOutput_1 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";

	

 



/**
 * [tDBOutput_1 process_data_end ] stop
 */



	
	/**
	 * [tStatCatcher_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tStatCatcher_1";

	

 



/**
 * [tStatCatcher_1 process_data_end ] stop
 */
	
	/**
	 * [tStatCatcher_1 end ] start
	 */

	

	
	
	currentComponent="tStatCatcher_1";

	

	}


 

ok_Hash.put("tStatCatcher_1", true);
end_Hash.put("tStatCatcher_1", System.currentTimeMillis());




/**
 * [tStatCatcher_1 end ] stop
 */

	
	/**
	 * [tDBOutput_1 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";

	



	    try {
				int countSum_tDBOutput_1 = 0;
				if (pstmt_tDBOutput_1 != null && batchSizeCounter_tDBOutput_1 > 0) {
						
					for(int countEach_tDBOutput_1: pstmt_tDBOutput_1.executeBatch()) {
						countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
					}
					rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
						
				}
		    	
		    		insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
		    	
	    }catch (java.sql.BatchUpdateException e_tDBOutput_1){
globalMap.put("tDBOutput_1_ERROR_MESSAGE",e_tDBOutput_1.getMessage());
	    	java.sql.SQLException ne_tDBOutput_1 = e_tDBOutput_1.getNextException(),sqle_tDBOutput_1=null;
	    	String errormessage_tDBOutput_1;
			if (ne_tDBOutput_1 != null) {
				// build new exception to provide the original cause
				sqle_tDBOutput_1 = new java.sql.SQLException(e_tDBOutput_1.getMessage() + "\ncaused by: " + ne_tDBOutput_1.getMessage(), ne_tDBOutput_1.getSQLState(), ne_tDBOutput_1.getErrorCode(), ne_tDBOutput_1);
				errormessage_tDBOutput_1 = sqle_tDBOutput_1.getMessage();
			}else{
				errormessage_tDBOutput_1 = e_tDBOutput_1.getMessage();
			}
	    	
	    	int countSum_tDBOutput_1 = 0;
			for(int countEach_tDBOutput_1: e_tDBOutput_1.getUpdateCounts()) {
				countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
			}
			rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
			
	    		insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
	    	
	    	System.err.println(errormessage_tDBOutput_1);
	    	
		}
	    
        if(pstmt_tDBOutput_1 != null) {
        		
            pstmt_tDBOutput_1.close();
            resourceMap.remove("pstmt_tDBOutput_1");
        }
    resourceMap.put("statementClosed_tDBOutput_1", true);
			if(rowsToCommitCount_tDBOutput_1 != 0){
				
			}
			conn_tDBOutput_1.commit();
			if(rowsToCommitCount_tDBOutput_1 != 0){
				
				rowsToCommitCount_tDBOutput_1 = 0;
			}
			commitCounter_tDBOutput_1 = 0;
		
    	conn_tDBOutput_1 .close();
    	
    	resourceMap.put("finish_tDBOutput_1", true);
    	

	nb_line_deleted_tDBOutput_1=nb_line_deleted_tDBOutput_1+ deletedCount_tDBOutput_1;
	nb_line_update_tDBOutput_1=nb_line_update_tDBOutput_1 + updatedCount_tDBOutput_1;
	nb_line_inserted_tDBOutput_1=nb_line_inserted_tDBOutput_1 + insertedCount_tDBOutput_1;
	nb_line_rejected_tDBOutput_1=nb_line_rejected_tDBOutput_1 + rejectedCount_tDBOutput_1;
	
        globalMap.put("tDBOutput_1_NB_LINE",nb_line_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_UPDATED",nb_line_update_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_DELETED",nb_line_deleted_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_1);
    

	


				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row1");
			  	}
			  	
 

ok_Hash.put("tDBOutput_1", true);
end_Hash.put("tDBOutput_1", System.currentTimeMillis());




/**
 * [tDBOutput_1 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tStatCatcher_1 finally ] start
	 */

	

	
	
	currentComponent="tStatCatcher_1";

	

 



/**
 * [tStatCatcher_1 finally ] stop
 */

	
	/**
	 * [tDBOutput_1 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";

	



    try {
    if (resourceMap.get("statementClosed_tDBOutput_1") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_1 = null;
                if ((pstmtToClose_tDBOutput_1 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_1")) != null) {
                    pstmtToClose_tDBOutput_1.close();
                }
    }
    } finally {
        if(resourceMap.get("finish_tDBOutput_1") == null){
            java.sql.Connection ctn_tDBOutput_1 = null;
            if((ctn_tDBOutput_1 = (java.sql.Connection)resourceMap.get("conn_tDBOutput_1")) != null){
                try {
                    ctn_tDBOutput_1.close();
                } catch (java.sql.SQLException sqlEx_tDBOutput_1) {
                    String errorMessage_tDBOutput_1 = "failed to close the connection in tDBOutput_1 :" + sqlEx_tDBOutput_1.getMessage();
                    System.err.println(errorMessage_tDBOutput_1);
                }
            }
        }
    }
 



/**
 * [tDBOutput_1 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tStatCatcher_1_SUBPROCESS_STATE", 1);
	}
	


public static class alim_faitStruct implements routines.system.IPersistableRow<alim_faitStruct> {
    final static byte[] commonByteArrayLock_ALIMENTATION_DM1_F_ALIM_FAIT = new byte[0];
    static byte[] commonByteArray_ALIMENTATION_DM1_F_ALIM_FAIT = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int id_commande;

				public int getId_commande () {
					return this.id_commande;
				}
				
			    public int id_date_commande;

				public int getId_date_commande () {
					return this.id_date_commande;
				}
				
			    public int id_preparation;

				public int getId_preparation () {
					return this.id_preparation;
				}
				
			    public int id_client;

				public int getId_client () {
					return this.id_client;
				}
				
			    public int id_adresse_norm_client;

				public int getId_adresse_norm_client () {
					return this.id_adresse_norm_client;
				}
				
			    public int id_restaurant;

				public int getId_restaurant () {
					return this.id_restaurant;
				}
				
			    public int id_adresse_norm_restaurant;

				public int getId_adresse_norm_restaurant () {
					return this.id_adresse_norm_restaurant;
				}
				
			    public int id_moyen_paiement;

				public int getId_moyen_paiement () {
					return this.id_moyen_paiement;
				}
				
			    public int id_menu;

				public int getId_menu () {
					return this.id_menu;
				}
				
			    public int id_date_fin_preparation;

				public int getId_date_fin_preparation () {
					return this.id_date_fin_preparation;
				}
				
			    public Float montant_total;

				public Float getMontant_total () {
					return this.montant_total;
				}
				
			    public BigDecimal temps_theo_preparation;

				public BigDecimal getTemps_theo_preparation () {
					return this.temps_theo_preparation;
				}
				
			    public BigDecimal temps_reel_preparation;

				public BigDecimal getTemps_reel_preparation () {
					return this.temps_reel_preparation;
				}
				
			    public Integer numero_commande;

				public Integer getNumero_commande () {
					return this.numero_commande;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.id_commande;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final alim_faitStruct other = (alim_faitStruct) obj;
		
						if (this.id_commande != other.id_commande)
							return false;
					

		return true;
    }

	public void copyDataTo(alim_faitStruct other) {

		other.id_commande = this.id_commande;
	            other.id_date_commande = this.id_date_commande;
	            other.id_preparation = this.id_preparation;
	            other.id_client = this.id_client;
	            other.id_adresse_norm_client = this.id_adresse_norm_client;
	            other.id_restaurant = this.id_restaurant;
	            other.id_adresse_norm_restaurant = this.id_adresse_norm_restaurant;
	            other.id_moyen_paiement = this.id_moyen_paiement;
	            other.id_menu = this.id_menu;
	            other.id_date_fin_preparation = this.id_date_fin_preparation;
	            other.montant_total = this.montant_total;
	            other.temps_theo_preparation = this.temps_theo_preparation;
	            other.temps_reel_preparation = this.temps_reel_preparation;
	            other.numero_commande = this.numero_commande;
	            
	}

	public void copyKeysDataTo(alim_faitStruct other) {

		other.id_commande = this.id_commande;
	            	
	}



	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_DM1_F_ALIM_FAIT) {

        	try {

        		int length = 0;
		
			        this.id_commande = dis.readInt();
					
			        this.id_date_commande = dis.readInt();
					
			        this.id_preparation = dis.readInt();
					
			        this.id_client = dis.readInt();
					
			        this.id_adresse_norm_client = dis.readInt();
					
			        this.id_restaurant = dis.readInt();
					
			        this.id_adresse_norm_restaurant = dis.readInt();
					
			        this.id_moyen_paiement = dis.readInt();
					
			        this.id_menu = dis.readInt();
					
			        this.id_date_fin_preparation = dis.readInt();
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.montant_total = null;
           				} else {
           			    	this.montant_total = dis.readFloat();
           				}
					
						this.temps_theo_preparation = (BigDecimal) dis.readObject();
					
						this.temps_reel_preparation = (BigDecimal) dis.readObject();
					
						this.numero_commande = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_DM1_F_ALIM_FAIT) {

        	try {

        		int length = 0;
		
			        this.id_commande = dis.readInt();
					
			        this.id_date_commande = dis.readInt();
					
			        this.id_preparation = dis.readInt();
					
			        this.id_client = dis.readInt();
					
			        this.id_adresse_norm_client = dis.readInt();
					
			        this.id_restaurant = dis.readInt();
					
			        this.id_adresse_norm_restaurant = dis.readInt();
					
			        this.id_moyen_paiement = dis.readInt();
					
			        this.id_menu = dis.readInt();
					
			        this.id_date_fin_preparation = dis.readInt();
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.montant_total = null;
           				} else {
           			    	this.montant_total = dis.readFloat();
           				}
					
						this.temps_theo_preparation = (BigDecimal) dis.readObject();
					
						this.temps_reel_preparation = (BigDecimal) dis.readObject();
					
						this.numero_commande = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id_commande);
					
					// int
				
		            	dos.writeInt(this.id_date_commande);
					
					// int
				
		            	dos.writeInt(this.id_preparation);
					
					// int
				
		            	dos.writeInt(this.id_client);
					
					// int
				
		            	dos.writeInt(this.id_adresse_norm_client);
					
					// int
				
		            	dos.writeInt(this.id_restaurant);
					
					// int
				
		            	dos.writeInt(this.id_adresse_norm_restaurant);
					
					// int
				
		            	dos.writeInt(this.id_moyen_paiement);
					
					// int
				
		            	dos.writeInt(this.id_menu);
					
					// int
				
		            	dos.writeInt(this.id_date_fin_preparation);
					
					// Float
				
						if(this.montant_total == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.montant_total);
		            	}
					
					// BigDecimal
				
       			    	dos.writeObject(this.temps_theo_preparation);
					
					// BigDecimal
				
       			    	dos.writeObject(this.temps_reel_preparation);
					
					// Integer
				
						writeInteger(this.numero_commande,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id_commande);
					
					// int
				
		            	dos.writeInt(this.id_date_commande);
					
					// int
				
		            	dos.writeInt(this.id_preparation);
					
					// int
				
		            	dos.writeInt(this.id_client);
					
					// int
				
		            	dos.writeInt(this.id_adresse_norm_client);
					
					// int
				
		            	dos.writeInt(this.id_restaurant);
					
					// int
				
		            	dos.writeInt(this.id_adresse_norm_restaurant);
					
					// int
				
		            	dos.writeInt(this.id_moyen_paiement);
					
					// int
				
		            	dos.writeInt(this.id_menu);
					
					// int
				
		            	dos.writeInt(this.id_date_fin_preparation);
					
					// Float
				
						if(this.montant_total == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.montant_total);
		            	}
					
					// BigDecimal
				
       			    	dos.writeObject(this.temps_theo_preparation);
					
					// BigDecimal
				
       			    	dos.writeObject(this.temps_reel_preparation);
					
					// Integer
				
						writeInteger(this.numero_commande,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id_commande="+String.valueOf(id_commande));
		sb.append(",id_date_commande="+String.valueOf(id_date_commande));
		sb.append(",id_preparation="+String.valueOf(id_preparation));
		sb.append(",id_client="+String.valueOf(id_client));
		sb.append(",id_adresse_norm_client="+String.valueOf(id_adresse_norm_client));
		sb.append(",id_restaurant="+String.valueOf(id_restaurant));
		sb.append(",id_adresse_norm_restaurant="+String.valueOf(id_adresse_norm_restaurant));
		sb.append(",id_moyen_paiement="+String.valueOf(id_moyen_paiement));
		sb.append(",id_menu="+String.valueOf(id_menu));
		sb.append(",id_date_fin_preparation="+String.valueOf(id_date_fin_preparation));
		sb.append(",montant_total="+String.valueOf(montant_total));
		sb.append(",temps_theo_preparation="+String.valueOf(temps_theo_preparation));
		sb.append(",temps_reel_preparation="+String.valueOf(temps_reel_preparation));
		sb.append(",numero_commande="+String.valueOf(numero_commande));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(alim_faitStruct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.id_commande, other.id_commande);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row2Struct implements routines.system.IPersistableRow<row2Struct> {
    final static byte[] commonByteArrayLock_ALIMENTATION_DM1_F_ALIM_FAIT = new byte[0];
    static byte[] commonByteArray_ALIMENTATION_DM1_F_ALIM_FAIT = new byte[0];

	
			    public int id_ods_dm1;

				public int getId_ods_dm1 () {
					return this.id_ods_dm1;
				}
				
			    public Integer id_preparation;

				public Integer getId_preparation () {
					return this.id_preparation;
				}
				
			    public java.util.Date date_debut_preparation;

				public java.util.Date getDate_debut_preparation () {
					return this.date_debut_preparation;
				}
				
			    public java.util.Date date_fin_preparation;

				public java.util.Date getDate_fin_preparation () {
					return this.date_fin_preparation;
				}
				
			    public BigDecimal temps_reel_preparation;

				public BigDecimal getTemps_reel_preparation () {
					return this.temps_reel_preparation;
				}
				
			    public Integer id_moyen_paiement;

				public Integer getId_moyen_paiement () {
					return this.id_moyen_paiement;
				}
				
			    public String code_moyen_paiement;

				public String getCode_moyen_paiement () {
					return this.code_moyen_paiement;
				}
				
			    public String livelle_moyen_paiement;

				public String getLivelle_moyen_paiement () {
					return this.livelle_moyen_paiement;
				}
				
			    public Integer id_menu;

				public Integer getId_menu () {
					return this.id_menu;
				}
				
			    public String code_menu;

				public String getCode_menu () {
					return this.code_menu;
				}
				
			    public String libelle_menu;

				public String getLibelle_menu () {
					return this.libelle_menu;
				}
				
			    public Integer nombre_articles;

				public Integer getNombre_articles () {
					return this.nombre_articles;
				}
				
			    public BigDecimal temps_theo_preparation;

				public BigDecimal getTemps_theo_preparation () {
					return this.temps_theo_preparation;
				}
				
			    public Integer id_commande;

				public Integer getId_commande () {
					return this.id_commande;
				}
				
			    public Integer numero_commande;

				public Integer getNumero_commande () {
					return this.numero_commande;
				}
				
			    public java.util.Date date_commande;

				public java.util.Date getDate_commande () {
					return this.date_commande;
				}
				
			    public Float montant_total;

				public Float getMontant_total () {
					return this.montant_total;
				}
				
			    public Integer id_adresse_norm_restaurant;

				public Integer getId_adresse_norm_restaurant () {
					return this.id_adresse_norm_restaurant;
				}
				
			    public String numero_voie_restau;

				public String getNumero_voie_restau () {
					return this.numero_voie_restau;
				}
				
			    public String nom_voie_restau;

				public String getNom_voie_restau () {
					return this.nom_voie_restau;
				}
				
			    public String code_postal_restau;

				public String getCode_postal_restau () {
					return this.code_postal_restau;
				}
				
			    public String nom_ville_restau;

				public String getNom_ville_restau () {
					return this.nom_ville_restau;
				}
				
			    public String longitude_restau;

				public String getLongitude_restau () {
					return this.longitude_restau;
				}
				
			    public String latitude_restau;

				public String getLatitude_restau () {
					return this.latitude_restau;
				}
				
			    public Integer id_adresse_restaurant;

				public Integer getId_adresse_restaurant () {
					return this.id_adresse_restaurant;
				}
				
			    public String adresse_restaurant;

				public String getAdresse_restaurant () {
					return this.adresse_restaurant;
				}
				
			    public Integer id_restaurant;

				public Integer getId_restaurant () {
					return this.id_restaurant;
				}
				
			    public String code_restaurant;

				public String getCode_restaurant () {
					return this.code_restaurant;
				}
				
			    public String raison_sociale_restaurant;

				public String getRaison_sociale_restaurant () {
					return this.raison_sociale_restaurant;
				}
				
			    public Integer id_adresse_norm_client;

				public Integer getId_adresse_norm_client () {
					return this.id_adresse_norm_client;
				}
				
			    public String numero_voie;

				public String getNumero_voie () {
					return this.numero_voie;
				}
				
			    public String nom_voie;

				public String getNom_voie () {
					return this.nom_voie;
				}
				
			    public String code_postal;

				public String getCode_postal () {
					return this.code_postal;
				}
				
			    public String nom_ville;

				public String getNom_ville () {
					return this.nom_ville;
				}
				
			    public String longitude;

				public String getLongitude () {
					return this.longitude;
				}
				
			    public String latitude;

				public String getLatitude () {
					return this.latitude;
				}
				
			    public Integer id_adresse_client;

				public Integer getId_adresse_client () {
					return this.id_adresse_client;
				}
				
			    public String adresse_client;

				public String getAdresse_client () {
					return this.adresse_client;
				}
				
			    public Integer id_client;

				public Integer getId_client () {
					return this.id_client;
				}
				
			    public String nom_client;

				public String getNom_client () {
					return this.nom_client;
				}
				
			    public String prenom_client;

				public String getPrenom_client () {
					return this.prenom_client;
				}
				


	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_DM1_F_ALIM_FAIT.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_DM1_F_ALIM_FAIT.length == 0) {
   					commonByteArray_ALIMENTATION_DM1_F_ALIM_FAIT = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_DM1_F_ALIM_FAIT = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ALIMENTATION_DM1_F_ALIM_FAIT, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_DM1_F_ALIM_FAIT, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_DM1_F_ALIM_FAIT.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_DM1_F_ALIM_FAIT.length == 0) {
   					commonByteArray_ALIMENTATION_DM1_F_ALIM_FAIT = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_DM1_F_ALIM_FAIT = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ALIMENTATION_DM1_F_ALIM_FAIT, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_DM1_F_ALIM_FAIT, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_DM1_F_ALIM_FAIT) {

        	try {

        		int length = 0;
		
			        this.id_ods_dm1 = dis.readInt();
					
						this.id_preparation = readInteger(dis);
					
					this.date_debut_preparation = readDate(dis);
					
					this.date_fin_preparation = readDate(dis);
					
						this.temps_reel_preparation = (BigDecimal) dis.readObject();
					
						this.id_moyen_paiement = readInteger(dis);
					
					this.code_moyen_paiement = readString(dis);
					
					this.livelle_moyen_paiement = readString(dis);
					
						this.id_menu = readInteger(dis);
					
					this.code_menu = readString(dis);
					
					this.libelle_menu = readString(dis);
					
						this.nombre_articles = readInteger(dis);
					
						this.temps_theo_preparation = (BigDecimal) dis.readObject();
					
						this.id_commande = readInteger(dis);
					
						this.numero_commande = readInteger(dis);
					
					this.date_commande = readDate(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.montant_total = null;
           				} else {
           			    	this.montant_total = dis.readFloat();
           				}
					
						this.id_adresse_norm_restaurant = readInteger(dis);
					
					this.numero_voie_restau = readString(dis);
					
					this.nom_voie_restau = readString(dis);
					
					this.code_postal_restau = readString(dis);
					
					this.nom_ville_restau = readString(dis);
					
					this.longitude_restau = readString(dis);
					
					this.latitude_restau = readString(dis);
					
						this.id_adresse_restaurant = readInteger(dis);
					
					this.adresse_restaurant = readString(dis);
					
						this.id_restaurant = readInteger(dis);
					
					this.code_restaurant = readString(dis);
					
					this.raison_sociale_restaurant = readString(dis);
					
						this.id_adresse_norm_client = readInteger(dis);
					
					this.numero_voie = readString(dis);
					
					this.nom_voie = readString(dis);
					
					this.code_postal = readString(dis);
					
					this.nom_ville = readString(dis);
					
					this.longitude = readString(dis);
					
					this.latitude = readString(dis);
					
						this.id_adresse_client = readInteger(dis);
					
					this.adresse_client = readString(dis);
					
						this.id_client = readInteger(dis);
					
					this.nom_client = readString(dis);
					
					this.prenom_client = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_DM1_F_ALIM_FAIT) {

        	try {

        		int length = 0;
		
			        this.id_ods_dm1 = dis.readInt();
					
						this.id_preparation = readInteger(dis);
					
					this.date_debut_preparation = readDate(dis);
					
					this.date_fin_preparation = readDate(dis);
					
						this.temps_reel_preparation = (BigDecimal) dis.readObject();
					
						this.id_moyen_paiement = readInteger(dis);
					
					this.code_moyen_paiement = readString(dis);
					
					this.livelle_moyen_paiement = readString(dis);
					
						this.id_menu = readInteger(dis);
					
					this.code_menu = readString(dis);
					
					this.libelle_menu = readString(dis);
					
						this.nombre_articles = readInteger(dis);
					
						this.temps_theo_preparation = (BigDecimal) dis.readObject();
					
						this.id_commande = readInteger(dis);
					
						this.numero_commande = readInteger(dis);
					
					this.date_commande = readDate(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.montant_total = null;
           				} else {
           			    	this.montant_total = dis.readFloat();
           				}
					
						this.id_adresse_norm_restaurant = readInteger(dis);
					
					this.numero_voie_restau = readString(dis);
					
					this.nom_voie_restau = readString(dis);
					
					this.code_postal_restau = readString(dis);
					
					this.nom_ville_restau = readString(dis);
					
					this.longitude_restau = readString(dis);
					
					this.latitude_restau = readString(dis);
					
						this.id_adresse_restaurant = readInteger(dis);
					
					this.adresse_restaurant = readString(dis);
					
						this.id_restaurant = readInteger(dis);
					
					this.code_restaurant = readString(dis);
					
					this.raison_sociale_restaurant = readString(dis);
					
						this.id_adresse_norm_client = readInteger(dis);
					
					this.numero_voie = readString(dis);
					
					this.nom_voie = readString(dis);
					
					this.code_postal = readString(dis);
					
					this.nom_ville = readString(dis);
					
					this.longitude = readString(dis);
					
					this.latitude = readString(dis);
					
						this.id_adresse_client = readInteger(dis);
					
					this.adresse_client = readString(dis);
					
						this.id_client = readInteger(dis);
					
					this.nom_client = readString(dis);
					
					this.prenom_client = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id_ods_dm1);
					
					// Integer
				
						writeInteger(this.id_preparation,dos);
					
					// java.util.Date
				
						writeDate(this.date_debut_preparation,dos);
					
					// java.util.Date
				
						writeDate(this.date_fin_preparation,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.temps_reel_preparation);
					
					// Integer
				
						writeInteger(this.id_moyen_paiement,dos);
					
					// String
				
						writeString(this.code_moyen_paiement,dos);
					
					// String
				
						writeString(this.livelle_moyen_paiement,dos);
					
					// Integer
				
						writeInteger(this.id_menu,dos);
					
					// String
				
						writeString(this.code_menu,dos);
					
					// String
				
						writeString(this.libelle_menu,dos);
					
					// Integer
				
						writeInteger(this.nombre_articles,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.temps_theo_preparation);
					
					// Integer
				
						writeInteger(this.id_commande,dos);
					
					// Integer
				
						writeInteger(this.numero_commande,dos);
					
					// java.util.Date
				
						writeDate(this.date_commande,dos);
					
					// Float
				
						if(this.montant_total == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.montant_total);
		            	}
					
					// Integer
				
						writeInteger(this.id_adresse_norm_restaurant,dos);
					
					// String
				
						writeString(this.numero_voie_restau,dos);
					
					// String
				
						writeString(this.nom_voie_restau,dos);
					
					// String
				
						writeString(this.code_postal_restau,dos);
					
					// String
				
						writeString(this.nom_ville_restau,dos);
					
					// String
				
						writeString(this.longitude_restau,dos);
					
					// String
				
						writeString(this.latitude_restau,dos);
					
					// Integer
				
						writeInteger(this.id_adresse_restaurant,dos);
					
					// String
				
						writeString(this.adresse_restaurant,dos);
					
					// Integer
				
						writeInteger(this.id_restaurant,dos);
					
					// String
				
						writeString(this.code_restaurant,dos);
					
					// String
				
						writeString(this.raison_sociale_restaurant,dos);
					
					// Integer
				
						writeInteger(this.id_adresse_norm_client,dos);
					
					// String
				
						writeString(this.numero_voie,dos);
					
					// String
				
						writeString(this.nom_voie,dos);
					
					// String
				
						writeString(this.code_postal,dos);
					
					// String
				
						writeString(this.nom_ville,dos);
					
					// String
				
						writeString(this.longitude,dos);
					
					// String
				
						writeString(this.latitude,dos);
					
					// Integer
				
						writeInteger(this.id_adresse_client,dos);
					
					// String
				
						writeString(this.adresse_client,dos);
					
					// Integer
				
						writeInteger(this.id_client,dos);
					
					// String
				
						writeString(this.nom_client,dos);
					
					// String
				
						writeString(this.prenom_client,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id_ods_dm1);
					
					// Integer
				
						writeInteger(this.id_preparation,dos);
					
					// java.util.Date
				
						writeDate(this.date_debut_preparation,dos);
					
					// java.util.Date
				
						writeDate(this.date_fin_preparation,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.temps_reel_preparation);
					
					// Integer
				
						writeInteger(this.id_moyen_paiement,dos);
					
					// String
				
						writeString(this.code_moyen_paiement,dos);
					
					// String
				
						writeString(this.livelle_moyen_paiement,dos);
					
					// Integer
				
						writeInteger(this.id_menu,dos);
					
					// String
				
						writeString(this.code_menu,dos);
					
					// String
				
						writeString(this.libelle_menu,dos);
					
					// Integer
				
						writeInteger(this.nombre_articles,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.temps_theo_preparation);
					
					// Integer
				
						writeInteger(this.id_commande,dos);
					
					// Integer
				
						writeInteger(this.numero_commande,dos);
					
					// java.util.Date
				
						writeDate(this.date_commande,dos);
					
					// Float
				
						if(this.montant_total == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.montant_total);
		            	}
					
					// Integer
				
						writeInteger(this.id_adresse_norm_restaurant,dos);
					
					// String
				
						writeString(this.numero_voie_restau,dos);
					
					// String
				
						writeString(this.nom_voie_restau,dos);
					
					// String
				
						writeString(this.code_postal_restau,dos);
					
					// String
				
						writeString(this.nom_ville_restau,dos);
					
					// String
				
						writeString(this.longitude_restau,dos);
					
					// String
				
						writeString(this.latitude_restau,dos);
					
					// Integer
				
						writeInteger(this.id_adresse_restaurant,dos);
					
					// String
				
						writeString(this.adresse_restaurant,dos);
					
					// Integer
				
						writeInteger(this.id_restaurant,dos);
					
					// String
				
						writeString(this.code_restaurant,dos);
					
					// String
				
						writeString(this.raison_sociale_restaurant,dos);
					
					// Integer
				
						writeInteger(this.id_adresse_norm_client,dos);
					
					// String
				
						writeString(this.numero_voie,dos);
					
					// String
				
						writeString(this.nom_voie,dos);
					
					// String
				
						writeString(this.code_postal,dos);
					
					// String
				
						writeString(this.nom_ville,dos);
					
					// String
				
						writeString(this.longitude,dos);
					
					// String
				
						writeString(this.latitude,dos);
					
					// Integer
				
						writeInteger(this.id_adresse_client,dos);
					
					// String
				
						writeString(this.adresse_client,dos);
					
					// Integer
				
						writeInteger(this.id_client,dos);
					
					// String
				
						writeString(this.nom_client,dos);
					
					// String
				
						writeString(this.prenom_client,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id_ods_dm1="+String.valueOf(id_ods_dm1));
		sb.append(",id_preparation="+String.valueOf(id_preparation));
		sb.append(",date_debut_preparation="+String.valueOf(date_debut_preparation));
		sb.append(",date_fin_preparation="+String.valueOf(date_fin_preparation));
		sb.append(",temps_reel_preparation="+String.valueOf(temps_reel_preparation));
		sb.append(",id_moyen_paiement="+String.valueOf(id_moyen_paiement));
		sb.append(",code_moyen_paiement="+code_moyen_paiement);
		sb.append(",livelle_moyen_paiement="+livelle_moyen_paiement);
		sb.append(",id_menu="+String.valueOf(id_menu));
		sb.append(",code_menu="+code_menu);
		sb.append(",libelle_menu="+libelle_menu);
		sb.append(",nombre_articles="+String.valueOf(nombre_articles));
		sb.append(",temps_theo_preparation="+String.valueOf(temps_theo_preparation));
		sb.append(",id_commande="+String.valueOf(id_commande));
		sb.append(",numero_commande="+String.valueOf(numero_commande));
		sb.append(",date_commande="+String.valueOf(date_commande));
		sb.append(",montant_total="+String.valueOf(montant_total));
		sb.append(",id_adresse_norm_restaurant="+String.valueOf(id_adresse_norm_restaurant));
		sb.append(",numero_voie_restau="+numero_voie_restau);
		sb.append(",nom_voie_restau="+nom_voie_restau);
		sb.append(",code_postal_restau="+code_postal_restau);
		sb.append(",nom_ville_restau="+nom_ville_restau);
		sb.append(",longitude_restau="+longitude_restau);
		sb.append(",latitude_restau="+latitude_restau);
		sb.append(",id_adresse_restaurant="+String.valueOf(id_adresse_restaurant));
		sb.append(",adresse_restaurant="+adresse_restaurant);
		sb.append(",id_restaurant="+String.valueOf(id_restaurant));
		sb.append(",code_restaurant="+code_restaurant);
		sb.append(",raison_sociale_restaurant="+raison_sociale_restaurant);
		sb.append(",id_adresse_norm_client="+String.valueOf(id_adresse_norm_client));
		sb.append(",numero_voie="+numero_voie);
		sb.append(",nom_voie="+nom_voie);
		sb.append(",code_postal="+code_postal);
		sb.append(",nom_ville="+nom_ville);
		sb.append(",longitude="+longitude);
		sb.append(",latitude="+latitude);
		sb.append(",id_adresse_client="+String.valueOf(id_adresse_client));
		sb.append(",adresse_client="+adresse_client);
		sb.append(",id_client="+String.valueOf(id_client));
		sb.append(",nom_client="+nom_client);
		sb.append(",prenom_client="+prenom_client);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row2Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class after_tDBInput_1Struct implements routines.system.IPersistableRow<after_tDBInput_1Struct> {
    final static byte[] commonByteArrayLock_ALIMENTATION_DM1_F_ALIM_FAIT = new byte[0];
    static byte[] commonByteArray_ALIMENTATION_DM1_F_ALIM_FAIT = new byte[0];

	
			    public int id_ods_dm1;

				public int getId_ods_dm1 () {
					return this.id_ods_dm1;
				}
				
			    public Integer id_preparation;

				public Integer getId_preparation () {
					return this.id_preparation;
				}
				
			    public java.util.Date date_debut_preparation;

				public java.util.Date getDate_debut_preparation () {
					return this.date_debut_preparation;
				}
				
			    public java.util.Date date_fin_preparation;

				public java.util.Date getDate_fin_preparation () {
					return this.date_fin_preparation;
				}
				
			    public BigDecimal temps_reel_preparation;

				public BigDecimal getTemps_reel_preparation () {
					return this.temps_reel_preparation;
				}
				
			    public Integer id_moyen_paiement;

				public Integer getId_moyen_paiement () {
					return this.id_moyen_paiement;
				}
				
			    public String code_moyen_paiement;

				public String getCode_moyen_paiement () {
					return this.code_moyen_paiement;
				}
				
			    public String livelle_moyen_paiement;

				public String getLivelle_moyen_paiement () {
					return this.livelle_moyen_paiement;
				}
				
			    public Integer id_menu;

				public Integer getId_menu () {
					return this.id_menu;
				}
				
			    public String code_menu;

				public String getCode_menu () {
					return this.code_menu;
				}
				
			    public String libelle_menu;

				public String getLibelle_menu () {
					return this.libelle_menu;
				}
				
			    public Integer nombre_articles;

				public Integer getNombre_articles () {
					return this.nombre_articles;
				}
				
			    public BigDecimal temps_theo_preparation;

				public BigDecimal getTemps_theo_preparation () {
					return this.temps_theo_preparation;
				}
				
			    public Integer id_commande;

				public Integer getId_commande () {
					return this.id_commande;
				}
				
			    public Integer numero_commande;

				public Integer getNumero_commande () {
					return this.numero_commande;
				}
				
			    public java.util.Date date_commande;

				public java.util.Date getDate_commande () {
					return this.date_commande;
				}
				
			    public Float montant_total;

				public Float getMontant_total () {
					return this.montant_total;
				}
				
			    public Integer id_adresse_norm_restaurant;

				public Integer getId_adresse_norm_restaurant () {
					return this.id_adresse_norm_restaurant;
				}
				
			    public String numero_voie_restau;

				public String getNumero_voie_restau () {
					return this.numero_voie_restau;
				}
				
			    public String nom_voie_restau;

				public String getNom_voie_restau () {
					return this.nom_voie_restau;
				}
				
			    public String code_postal_restau;

				public String getCode_postal_restau () {
					return this.code_postal_restau;
				}
				
			    public String nom_ville_restau;

				public String getNom_ville_restau () {
					return this.nom_ville_restau;
				}
				
			    public String longitude_restau;

				public String getLongitude_restau () {
					return this.longitude_restau;
				}
				
			    public String latitude_restau;

				public String getLatitude_restau () {
					return this.latitude_restau;
				}
				
			    public Integer id_adresse_restaurant;

				public Integer getId_adresse_restaurant () {
					return this.id_adresse_restaurant;
				}
				
			    public String adresse_restaurant;

				public String getAdresse_restaurant () {
					return this.adresse_restaurant;
				}
				
			    public Integer id_restaurant;

				public Integer getId_restaurant () {
					return this.id_restaurant;
				}
				
			    public String code_restaurant;

				public String getCode_restaurant () {
					return this.code_restaurant;
				}
				
			    public String raison_sociale_restaurant;

				public String getRaison_sociale_restaurant () {
					return this.raison_sociale_restaurant;
				}
				
			    public Integer id_adresse_norm_client;

				public Integer getId_adresse_norm_client () {
					return this.id_adresse_norm_client;
				}
				
			    public String numero_voie;

				public String getNumero_voie () {
					return this.numero_voie;
				}
				
			    public String nom_voie;

				public String getNom_voie () {
					return this.nom_voie;
				}
				
			    public String code_postal;

				public String getCode_postal () {
					return this.code_postal;
				}
				
			    public String nom_ville;

				public String getNom_ville () {
					return this.nom_ville;
				}
				
			    public String longitude;

				public String getLongitude () {
					return this.longitude;
				}
				
			    public String latitude;

				public String getLatitude () {
					return this.latitude;
				}
				
			    public Integer id_adresse_client;

				public Integer getId_adresse_client () {
					return this.id_adresse_client;
				}
				
			    public String adresse_client;

				public String getAdresse_client () {
					return this.adresse_client;
				}
				
			    public Integer id_client;

				public Integer getId_client () {
					return this.id_client;
				}
				
			    public String nom_client;

				public String getNom_client () {
					return this.nom_client;
				}
				
			    public String prenom_client;

				public String getPrenom_client () {
					return this.prenom_client;
				}
				


	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_DM1_F_ALIM_FAIT.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_DM1_F_ALIM_FAIT.length == 0) {
   					commonByteArray_ALIMENTATION_DM1_F_ALIM_FAIT = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_DM1_F_ALIM_FAIT = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ALIMENTATION_DM1_F_ALIM_FAIT, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_DM1_F_ALIM_FAIT, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_DM1_F_ALIM_FAIT.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_DM1_F_ALIM_FAIT.length == 0) {
   					commonByteArray_ALIMENTATION_DM1_F_ALIM_FAIT = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_DM1_F_ALIM_FAIT = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ALIMENTATION_DM1_F_ALIM_FAIT, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_DM1_F_ALIM_FAIT, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_DM1_F_ALIM_FAIT) {

        	try {

        		int length = 0;
		
			        this.id_ods_dm1 = dis.readInt();
					
						this.id_preparation = readInteger(dis);
					
					this.date_debut_preparation = readDate(dis);
					
					this.date_fin_preparation = readDate(dis);
					
						this.temps_reel_preparation = (BigDecimal) dis.readObject();
					
						this.id_moyen_paiement = readInteger(dis);
					
					this.code_moyen_paiement = readString(dis);
					
					this.livelle_moyen_paiement = readString(dis);
					
						this.id_menu = readInteger(dis);
					
					this.code_menu = readString(dis);
					
					this.libelle_menu = readString(dis);
					
						this.nombre_articles = readInteger(dis);
					
						this.temps_theo_preparation = (BigDecimal) dis.readObject();
					
						this.id_commande = readInteger(dis);
					
						this.numero_commande = readInteger(dis);
					
					this.date_commande = readDate(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.montant_total = null;
           				} else {
           			    	this.montant_total = dis.readFloat();
           				}
					
						this.id_adresse_norm_restaurant = readInteger(dis);
					
					this.numero_voie_restau = readString(dis);
					
					this.nom_voie_restau = readString(dis);
					
					this.code_postal_restau = readString(dis);
					
					this.nom_ville_restau = readString(dis);
					
					this.longitude_restau = readString(dis);
					
					this.latitude_restau = readString(dis);
					
						this.id_adresse_restaurant = readInteger(dis);
					
					this.adresse_restaurant = readString(dis);
					
						this.id_restaurant = readInteger(dis);
					
					this.code_restaurant = readString(dis);
					
					this.raison_sociale_restaurant = readString(dis);
					
						this.id_adresse_norm_client = readInteger(dis);
					
					this.numero_voie = readString(dis);
					
					this.nom_voie = readString(dis);
					
					this.code_postal = readString(dis);
					
					this.nom_ville = readString(dis);
					
					this.longitude = readString(dis);
					
					this.latitude = readString(dis);
					
						this.id_adresse_client = readInteger(dis);
					
					this.adresse_client = readString(dis);
					
						this.id_client = readInteger(dis);
					
					this.nom_client = readString(dis);
					
					this.prenom_client = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_DM1_F_ALIM_FAIT) {

        	try {

        		int length = 0;
		
			        this.id_ods_dm1 = dis.readInt();
					
						this.id_preparation = readInteger(dis);
					
					this.date_debut_preparation = readDate(dis);
					
					this.date_fin_preparation = readDate(dis);
					
						this.temps_reel_preparation = (BigDecimal) dis.readObject();
					
						this.id_moyen_paiement = readInteger(dis);
					
					this.code_moyen_paiement = readString(dis);
					
					this.livelle_moyen_paiement = readString(dis);
					
						this.id_menu = readInteger(dis);
					
					this.code_menu = readString(dis);
					
					this.libelle_menu = readString(dis);
					
						this.nombre_articles = readInteger(dis);
					
						this.temps_theo_preparation = (BigDecimal) dis.readObject();
					
						this.id_commande = readInteger(dis);
					
						this.numero_commande = readInteger(dis);
					
					this.date_commande = readDate(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.montant_total = null;
           				} else {
           			    	this.montant_total = dis.readFloat();
           				}
					
						this.id_adresse_norm_restaurant = readInteger(dis);
					
					this.numero_voie_restau = readString(dis);
					
					this.nom_voie_restau = readString(dis);
					
					this.code_postal_restau = readString(dis);
					
					this.nom_ville_restau = readString(dis);
					
					this.longitude_restau = readString(dis);
					
					this.latitude_restau = readString(dis);
					
						this.id_adresse_restaurant = readInteger(dis);
					
					this.adresse_restaurant = readString(dis);
					
						this.id_restaurant = readInteger(dis);
					
					this.code_restaurant = readString(dis);
					
					this.raison_sociale_restaurant = readString(dis);
					
						this.id_adresse_norm_client = readInteger(dis);
					
					this.numero_voie = readString(dis);
					
					this.nom_voie = readString(dis);
					
					this.code_postal = readString(dis);
					
					this.nom_ville = readString(dis);
					
					this.longitude = readString(dis);
					
					this.latitude = readString(dis);
					
						this.id_adresse_client = readInteger(dis);
					
					this.adresse_client = readString(dis);
					
						this.id_client = readInteger(dis);
					
					this.nom_client = readString(dis);
					
					this.prenom_client = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id_ods_dm1);
					
					// Integer
				
						writeInteger(this.id_preparation,dos);
					
					// java.util.Date
				
						writeDate(this.date_debut_preparation,dos);
					
					// java.util.Date
				
						writeDate(this.date_fin_preparation,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.temps_reel_preparation);
					
					// Integer
				
						writeInteger(this.id_moyen_paiement,dos);
					
					// String
				
						writeString(this.code_moyen_paiement,dos);
					
					// String
				
						writeString(this.livelle_moyen_paiement,dos);
					
					// Integer
				
						writeInteger(this.id_menu,dos);
					
					// String
				
						writeString(this.code_menu,dos);
					
					// String
				
						writeString(this.libelle_menu,dos);
					
					// Integer
				
						writeInteger(this.nombre_articles,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.temps_theo_preparation);
					
					// Integer
				
						writeInteger(this.id_commande,dos);
					
					// Integer
				
						writeInteger(this.numero_commande,dos);
					
					// java.util.Date
				
						writeDate(this.date_commande,dos);
					
					// Float
				
						if(this.montant_total == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.montant_total);
		            	}
					
					// Integer
				
						writeInteger(this.id_adresse_norm_restaurant,dos);
					
					// String
				
						writeString(this.numero_voie_restau,dos);
					
					// String
				
						writeString(this.nom_voie_restau,dos);
					
					// String
				
						writeString(this.code_postal_restau,dos);
					
					// String
				
						writeString(this.nom_ville_restau,dos);
					
					// String
				
						writeString(this.longitude_restau,dos);
					
					// String
				
						writeString(this.latitude_restau,dos);
					
					// Integer
				
						writeInteger(this.id_adresse_restaurant,dos);
					
					// String
				
						writeString(this.adresse_restaurant,dos);
					
					// Integer
				
						writeInteger(this.id_restaurant,dos);
					
					// String
				
						writeString(this.code_restaurant,dos);
					
					// String
				
						writeString(this.raison_sociale_restaurant,dos);
					
					// Integer
				
						writeInteger(this.id_adresse_norm_client,dos);
					
					// String
				
						writeString(this.numero_voie,dos);
					
					// String
				
						writeString(this.nom_voie,dos);
					
					// String
				
						writeString(this.code_postal,dos);
					
					// String
				
						writeString(this.nom_ville,dos);
					
					// String
				
						writeString(this.longitude,dos);
					
					// String
				
						writeString(this.latitude,dos);
					
					// Integer
				
						writeInteger(this.id_adresse_client,dos);
					
					// String
				
						writeString(this.adresse_client,dos);
					
					// Integer
				
						writeInteger(this.id_client,dos);
					
					// String
				
						writeString(this.nom_client,dos);
					
					// String
				
						writeString(this.prenom_client,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id_ods_dm1);
					
					// Integer
				
						writeInteger(this.id_preparation,dos);
					
					// java.util.Date
				
						writeDate(this.date_debut_preparation,dos);
					
					// java.util.Date
				
						writeDate(this.date_fin_preparation,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.temps_reel_preparation);
					
					// Integer
				
						writeInteger(this.id_moyen_paiement,dos);
					
					// String
				
						writeString(this.code_moyen_paiement,dos);
					
					// String
				
						writeString(this.livelle_moyen_paiement,dos);
					
					// Integer
				
						writeInteger(this.id_menu,dos);
					
					// String
				
						writeString(this.code_menu,dos);
					
					// String
				
						writeString(this.libelle_menu,dos);
					
					// Integer
				
						writeInteger(this.nombre_articles,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.temps_theo_preparation);
					
					// Integer
				
						writeInteger(this.id_commande,dos);
					
					// Integer
				
						writeInteger(this.numero_commande,dos);
					
					// java.util.Date
				
						writeDate(this.date_commande,dos);
					
					// Float
				
						if(this.montant_total == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.montant_total);
		            	}
					
					// Integer
				
						writeInteger(this.id_adresse_norm_restaurant,dos);
					
					// String
				
						writeString(this.numero_voie_restau,dos);
					
					// String
				
						writeString(this.nom_voie_restau,dos);
					
					// String
				
						writeString(this.code_postal_restau,dos);
					
					// String
				
						writeString(this.nom_ville_restau,dos);
					
					// String
				
						writeString(this.longitude_restau,dos);
					
					// String
				
						writeString(this.latitude_restau,dos);
					
					// Integer
				
						writeInteger(this.id_adresse_restaurant,dos);
					
					// String
				
						writeString(this.adresse_restaurant,dos);
					
					// Integer
				
						writeInteger(this.id_restaurant,dos);
					
					// String
				
						writeString(this.code_restaurant,dos);
					
					// String
				
						writeString(this.raison_sociale_restaurant,dos);
					
					// Integer
				
						writeInteger(this.id_adresse_norm_client,dos);
					
					// String
				
						writeString(this.numero_voie,dos);
					
					// String
				
						writeString(this.nom_voie,dos);
					
					// String
				
						writeString(this.code_postal,dos);
					
					// String
				
						writeString(this.nom_ville,dos);
					
					// String
				
						writeString(this.longitude,dos);
					
					// String
				
						writeString(this.latitude,dos);
					
					// Integer
				
						writeInteger(this.id_adresse_client,dos);
					
					// String
				
						writeString(this.adresse_client,dos);
					
					// Integer
				
						writeInteger(this.id_client,dos);
					
					// String
				
						writeString(this.nom_client,dos);
					
					// String
				
						writeString(this.prenom_client,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id_ods_dm1="+String.valueOf(id_ods_dm1));
		sb.append(",id_preparation="+String.valueOf(id_preparation));
		sb.append(",date_debut_preparation="+String.valueOf(date_debut_preparation));
		sb.append(",date_fin_preparation="+String.valueOf(date_fin_preparation));
		sb.append(",temps_reel_preparation="+String.valueOf(temps_reel_preparation));
		sb.append(",id_moyen_paiement="+String.valueOf(id_moyen_paiement));
		sb.append(",code_moyen_paiement="+code_moyen_paiement);
		sb.append(",livelle_moyen_paiement="+livelle_moyen_paiement);
		sb.append(",id_menu="+String.valueOf(id_menu));
		sb.append(",code_menu="+code_menu);
		sb.append(",libelle_menu="+libelle_menu);
		sb.append(",nombre_articles="+String.valueOf(nombre_articles));
		sb.append(",temps_theo_preparation="+String.valueOf(temps_theo_preparation));
		sb.append(",id_commande="+String.valueOf(id_commande));
		sb.append(",numero_commande="+String.valueOf(numero_commande));
		sb.append(",date_commande="+String.valueOf(date_commande));
		sb.append(",montant_total="+String.valueOf(montant_total));
		sb.append(",id_adresse_norm_restaurant="+String.valueOf(id_adresse_norm_restaurant));
		sb.append(",numero_voie_restau="+numero_voie_restau);
		sb.append(",nom_voie_restau="+nom_voie_restau);
		sb.append(",code_postal_restau="+code_postal_restau);
		sb.append(",nom_ville_restau="+nom_ville_restau);
		sb.append(",longitude_restau="+longitude_restau);
		sb.append(",latitude_restau="+latitude_restau);
		sb.append(",id_adresse_restaurant="+String.valueOf(id_adresse_restaurant));
		sb.append(",adresse_restaurant="+adresse_restaurant);
		sb.append(",id_restaurant="+String.valueOf(id_restaurant));
		sb.append(",code_restaurant="+code_restaurant);
		sb.append(",raison_sociale_restaurant="+raison_sociale_restaurant);
		sb.append(",id_adresse_norm_client="+String.valueOf(id_adresse_norm_client));
		sb.append(",numero_voie="+numero_voie);
		sb.append(",nom_voie="+nom_voie);
		sb.append(",code_postal="+code_postal);
		sb.append(",nom_ville="+nom_ville);
		sb.append(",longitude="+longitude);
		sb.append(",latitude="+latitude);
		sb.append(",id_adresse_client="+String.valueOf(id_adresse_client));
		sb.append(",adresse_client="+adresse_client);
		sb.append(",id_client="+String.valueOf(id_client));
		sb.append(",nom_client="+nom_client);
		sb.append(",prenom_client="+prenom_client);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(after_tDBInput_1Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tDBInput_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBInput_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;


		tDBInput_2Process(globalMap);
		tDBInput_3Process(globalMap);
		tDBInput_4Process(globalMap);
		tDBInput_5Process(globalMap);
		tDBInput_6Process(globalMap);
		tDBInput_7Process(globalMap);
		tDBInput_8Process(globalMap);
		tDBInput_9Process(globalMap);
		tDBInput_10Process(globalMap);

		row2Struct row2 = new row2Struct();
alim_faitStruct alim_fait = new alim_faitStruct();





	
	/**
	 * [tDBOutput_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_2", false);
		start_Hash.put("tDBOutput_2", System.currentTimeMillis());
		
				tStatCatcher_1.addMessage("begin","tDBOutput_2");
				tStatCatcher_1Process(globalMap);
			
	
	currentComponent="tDBOutput_2";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"alim_fait");
					}
				
		int tos_count_tDBOutput_2 = 0;
		





String dbschema_tDBOutput_2 = null;
	dbschema_tDBOutput_2 = "dsid_liv_dm1";
	

String tableName_tDBOutput_2 = null;
if(dbschema_tDBOutput_2 == null || dbschema_tDBOutput_2.trim().length() == 0) {
	tableName_tDBOutput_2 = ("fait_commande_f");
} else {
	tableName_tDBOutput_2 = dbschema_tDBOutput_2 + "\".\"" + ("fait_commande_f");
}


int nb_line_tDBOutput_2 = 0;
int nb_line_update_tDBOutput_2 = 0;
int nb_line_inserted_tDBOutput_2 = 0;
int nb_line_deleted_tDBOutput_2 = 0;
int nb_line_rejected_tDBOutput_2 = 0;

int deletedCount_tDBOutput_2=0;
int updatedCount_tDBOutput_2=0;
int insertedCount_tDBOutput_2=0;
int rowsToCommitCount_tDBOutput_2=0;
int rejectedCount_tDBOutput_2=0;

boolean whetherReject_tDBOutput_2 = false;

java.sql.Connection conn_tDBOutput_2 = null;
String dbUser_tDBOutput_2 = null;

	
    java.lang.Class.forName("org.postgresql.Driver");
    
        String url_tDBOutput_2 = "jdbc:postgresql://"+""+":"+"5432"+"/"+"postgres";
    dbUser_tDBOutput_2 = "dsid_cc2_tos_rw";
 
	final String decryptedPassword_tDBOutput_2 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:HJ5ubRMEOzFsPy0wgNgWMTHSlILozHfcdlgZrS5ZM3g=");

    String dbPwd_tDBOutput_2 = decryptedPassword_tDBOutput_2;

    conn_tDBOutput_2 = java.sql.DriverManager.getConnection(url_tDBOutput_2,dbUser_tDBOutput_2,dbPwd_tDBOutput_2);
	
	resourceMap.put("conn_tDBOutput_2", conn_tDBOutput_2);
        conn_tDBOutput_2.setAutoCommit(false);
        int commitEvery_tDBOutput_2 = 10000;
        int commitCounter_tDBOutput_2 = 0;


   int batchSize_tDBOutput_2 = 10000;
   int batchSizeCounter_tDBOutput_2=0;

int count_tDBOutput_2=0;
            try (java.sql.Statement stmtClear_tDBOutput_2 = conn_tDBOutput_2.createStatement()) {
                stmtClear_tDBOutput_2.executeUpdate("DELETE FROM \"" + tableName_tDBOutput_2 + "\"");
            }
	    String insert_tDBOutput_2 = "INSERT INTO \"" + tableName_tDBOutput_2 + "\" (\"" + "id_commande" + "\",\"id_date_commande\",\"id_preparation\",\"id_client\",\"id_adresse_norm_client\",\"id_restaurant\",\"id_adresse_norm_restaurant\",\"id_moyen_paiement\",\"id_menu\",\"id_date_fin_preparation\",\"montant_total\",\"temps_theo_preparation\",\"temps_reel_preparation\",\"numero_commande\") VALUES (" + "nextval('dsid_liv_dm1.seq_id_commande')" + ",?,?,?,?,?,?,?,?,?,?,?,?,?)";
	    
	    java.sql.PreparedStatement pstmt_tDBOutput_2 = conn_tDBOutput_2.prepareStatement(insert_tDBOutput_2);
	    resourceMap.put("pstmt_tDBOutput_2", pstmt_tDBOutput_2);
	    

 



/**
 * [tDBOutput_2 begin ] stop
 */



	
	/**
	 * [tMap_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tMap_1", false);
		start_Hash.put("tMap_1", System.currentTimeMillis());
		
				tStatCatcher_1.addMessage("begin","tMap_1");
				tStatCatcher_1Process(globalMap);
			
	
	currentComponent="tMap_1";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row2");
					}
				
		int tos_count_tMap_1 = 0;
		




// ###############################
// # Lookup's keys initialization
	
		org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row3Struct> tHash_Lookup_row3 = (org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row3Struct>) 
				((org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row3Struct>) 
					globalMap.get( "tHash_Lookup_row3" ))
					;					
					
	

row3Struct row3HashKey = new row3Struct();
row3Struct row3Default = new row3Struct();
	
		org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row4Struct> tHash_Lookup_row4 = (org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row4Struct>) 
				((org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row4Struct>) 
					globalMap.get( "tHash_Lookup_row4" ))
					;					
					
	

row4Struct row4HashKey = new row4Struct();
row4Struct row4Default = new row4Struct();
	
		org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row5Struct> tHash_Lookup_row5 = (org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row5Struct>) 
				((org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row5Struct>) 
					globalMap.get( "tHash_Lookup_row5" ))
					;					
					
	

row5Struct row5HashKey = new row5Struct();
row5Struct row5Default = new row5Struct();
	
		org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row6Struct> tHash_Lookup_row6 = (org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row6Struct>) 
				((org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row6Struct>) 
					globalMap.get( "tHash_Lookup_row6" ))
					;					
					
	

row6Struct row6HashKey = new row6Struct();
row6Struct row6Default = new row6Struct();
	
		org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row7Struct> tHash_Lookup_row7 = (org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row7Struct>) 
				((org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row7Struct>) 
					globalMap.get( "tHash_Lookup_row7" ))
					;					
					
	

row7Struct row7HashKey = new row7Struct();
row7Struct row7Default = new row7Struct();
	
		org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row8Struct> tHash_Lookup_row8 = (org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row8Struct>) 
				((org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row8Struct>) 
					globalMap.get( "tHash_Lookup_row8" ))
					;					
					
	

row8Struct row8HashKey = new row8Struct();
row8Struct row8Default = new row8Struct();
	
		org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row9Struct> tHash_Lookup_row9 = (org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row9Struct>) 
				((org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row9Struct>) 
					globalMap.get( "tHash_Lookup_row9" ))
					;					
					
	

row9Struct row9HashKey = new row9Struct();
row9Struct row9Default = new row9Struct();
	
		org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row10Struct> tHash_Lookup_row10 = (org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row10Struct>) 
				((org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row10Struct>) 
					globalMap.get( "tHash_Lookup_row10" ))
					;					
					
	

row10Struct row10HashKey = new row10Struct();
row10Struct row10Default = new row10Struct();
	
		org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row11Struct> tHash_Lookup_row11 = (org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row11Struct>) 
				((org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row11Struct>) 
					globalMap.get( "tHash_Lookup_row11" ))
					;					
					
	

row11Struct row11HashKey = new row11Struct();
row11Struct row11Default = new row11Struct();
// ###############################        

// ###############################
// # Vars initialization
class  Var__tMap_1__Struct  {
}
Var__tMap_1__Struct Var__tMap_1 = new Var__tMap_1__Struct();
// ###############################

// ###############################
// # Outputs initialization
alim_faitStruct alim_fait_tmp = new alim_faitStruct();
// ###############################

        
        



        









 



/**
 * [tMap_1 begin ] stop
 */



	
	/**
	 * [tDBInput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBInput_1", false);
		start_Hash.put("tDBInput_1", System.currentTimeMillis());
		
				tStatCatcher_1.addMessage("begin","tDBInput_1");
				tStatCatcher_1Process(globalMap);
			
	
	currentComponent="tDBInput_1";

	
		int tos_count_tDBInput_1 = 0;
		
	
    
	
		    int nb_line_tDBInput_1 = 0;
		    java.sql.Connection conn_tDBInput_1 = null;
				String driverClass_tDBInput_1 = "org.postgresql.Driver";
			    java.lang.Class jdbcclazz_tDBInput_1 = java.lang.Class.forName(driverClass_tDBInput_1);
				String dbUser_tDBInput_1 = "dsid_cc2_tos_rw";
				
				 
	final String decryptedPassword_tDBInput_1 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:8oTSPRQMTAPjAkqhFf4xqojHQzFgZdZrcoD8G60ir2c=");
				
				String dbPwd_tDBInput_1 = decryptedPassword_tDBInput_1;
				
				String url_tDBInput_1 = "jdbc:postgresql://" + "" + ":" + "5432" + "/" + "postgres";
				
				conn_tDBInput_1 = java.sql.DriverManager.getConnection(url_tDBInput_1,dbUser_tDBInput_1,dbPwd_tDBInput_1);
		        
				conn_tDBInput_1.setAutoCommit(false);
			
		    
			java.sql.Statement stmt_tDBInput_1 = conn_tDBInput_1.createStatement();

		    String dbquery_tDBInput_1 = "SELECT \n  \"dsid_liv_wrk\".\"dm1_ods\".\"id_ods_dm1\", \n  \"dsid_liv_wrk\".\"dm1_ods\".\"id_preparation\", \n  \"dsid_li"
+"v_wrk\".\"dm1_ods\".\"date_debut_preparation\", \n  \"dsid_liv_wrk\".\"dm1_ods\".\"date_fin_preparation\", \n  \"dsid_liv_"
+"wrk\".\"dm1_ods\".\"temps_reel_preparation\", \n  \"dsid_liv_wrk\".\"dm1_ods\".\"id_moyen_paiement\", \n  \"dsid_liv_wrk\""
+".\"dm1_ods\".\"code_moyen_paiement\", \n  \"dsid_liv_wrk\".\"dm1_ods\".\"livelle_moyen_paiement\", \n  \"dsid_liv_wrk\".\""
+"dm1_ods\".\"id_menu\", \n  \"dsid_liv_wrk\".\"dm1_ods\".\"code_menu\", \n  \"dsid_liv_wrk\".\"dm1_ods\".\"libelle_menu\", "
+"\n  \"dsid_liv_wrk\".\"dm1_ods\".\"nombre_articles\", \n  \"dsid_liv_wrk\".\"dm1_ods\".\"temps_theo_preparation\", \n  \"ds"
+"id_liv_wrk\".\"dm1_ods\".\"id_commande\", \n  \"dsid_liv_wrk\".\"dm1_ods\".\"numero_commande\", \n  \"dsid_liv_wrk\".\"dm1"
+"_ods\".\"date_commande\", \n  \"dsid_liv_wrk\".\"dm1_ods\".\"montant_total\", \n  \"dsid_liv_wrk\".\"dm1_ods\".\"id_adress"
+"e_norm_restaurant\", \n  \"dsid_liv_wrk\".\"dm1_ods\".\"numero_voie_restau\", \n  \"dsid_liv_wrk\".\"dm1_ods\".\"nom_voie_"
+"restau\", \n  \"dsid_liv_wrk\".\"dm1_ods\".\"code_postal_restau\", \n  \"dsid_liv_wrk\".\"dm1_ods\".\"nom_ville_restau\", "
+"\n  \"dsid_liv_wrk\".\"dm1_ods\".\"longitude_restau\", \n  \"dsid_liv_wrk\".\"dm1_ods\".\"latitude_restau\", \n  \"dsid_liv"
+"_wrk\".\"dm1_ods\".\"id_adresse_restaurant\", \n  \"dsid_liv_wrk\".\"dm1_ods\".\"adresse_restaurant\", \n  \"dsid_liv_wrk"
+"\".\"dm1_ods\".\"id_restaurant\", \n  \"dsid_liv_wrk\".\"dm1_ods\".\"code_restaurant\", \n  \"dsid_liv_wrk\".\"dm1_ods\"."
+"\"raison_sociale_restaurant\", \n  \"dsid_liv_wrk\".\"dm1_ods\".\"id_adresse_norm_client\", \n  \"dsid_liv_wrk\".\"dm1_ods"
+"\".\"numero_voie\", \n  \"dsid_liv_wrk\".\"dm1_ods\".\"nom_voie\", \n  \"dsid_liv_wrk\".\"dm1_ods\".\"code_postal\", \n  \""
+"dsid_liv_wrk\".\"dm1_ods\".\"nom_ville\", \n  \"dsid_liv_wrk\".\"dm1_ods\".\"longitude\", \n  \"dsid_liv_wrk\".\"dm1_ods\""
+".\"latitude\", \n  \"dsid_liv_wrk\".\"dm1_ods\".\"id_adresse_client\", \n  \"dsid_liv_wrk\".\"dm1_ods\".\"adresse_client\""
+", \n  \"dsid_liv_wrk\".\"dm1_ods\".\"id_client\", \n  \"dsid_liv_wrk\".\"dm1_ods\".\"nom_client\", \n  \"dsid_liv_wrk\".\"d"
+"m1_ods\".\"prenom_client\"\nFROM \"dsid_liv_wrk\".\"dm1_ods\"";
		    

            	globalMap.put("tDBInput_1_QUERY",dbquery_tDBInput_1);
		    java.sql.ResultSet rs_tDBInput_1 = null;

		    try {
		    	rs_tDBInput_1 = stmt_tDBInput_1.executeQuery(dbquery_tDBInput_1);
		    	java.sql.ResultSetMetaData rsmd_tDBInput_1 = rs_tDBInput_1.getMetaData();
		    	int colQtyInRs_tDBInput_1 = rsmd_tDBInput_1.getColumnCount();

		    String tmpContent_tDBInput_1 = null;
		    
		    
		    while (rs_tDBInput_1.next()) {
		        nb_line_tDBInput_1++;
		        
							if(colQtyInRs_tDBInput_1 < 1) {
								row2.id_ods_dm1 = 0;
							} else {
		                          
            row2.id_ods_dm1 = rs_tDBInput_1.getInt(1);
            if(rs_tDBInput_1.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 2) {
								row2.id_preparation = null;
							} else {
		                          
            row2.id_preparation = rs_tDBInput_1.getInt(2);
            if(rs_tDBInput_1.wasNull()){
                    row2.id_preparation = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 3) {
								row2.date_debut_preparation = null;
							} else {
										
			row2.date_debut_preparation = routines.system.JDBCUtil.getDate(rs_tDBInput_1, 3);
		                    }
							if(colQtyInRs_tDBInput_1 < 4) {
								row2.date_fin_preparation = null;
							} else {
										
			row2.date_fin_preparation = routines.system.JDBCUtil.getDate(rs_tDBInput_1, 4);
		                    }
							if(colQtyInRs_tDBInput_1 < 5) {
								row2.temps_reel_preparation = null;
							} else {
		                          
            row2.temps_reel_preparation = rs_tDBInput_1.getBigDecimal(5);
            if(rs_tDBInput_1.wasNull()){
                    row2.temps_reel_preparation = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 6) {
								row2.id_moyen_paiement = null;
							} else {
		                          
            row2.id_moyen_paiement = rs_tDBInput_1.getInt(6);
            if(rs_tDBInput_1.wasNull()){
                    row2.id_moyen_paiement = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 7) {
								row2.code_moyen_paiement = null;
							} else {
	                         		
        	row2.code_moyen_paiement = routines.system.JDBCUtil.getString(rs_tDBInput_1, 7, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 8) {
								row2.livelle_moyen_paiement = null;
							} else {
	                         		
        	row2.livelle_moyen_paiement = routines.system.JDBCUtil.getString(rs_tDBInput_1, 8, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 9) {
								row2.id_menu = null;
							} else {
		                          
            row2.id_menu = rs_tDBInput_1.getInt(9);
            if(rs_tDBInput_1.wasNull()){
                    row2.id_menu = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 10) {
								row2.code_menu = null;
							} else {
	                         		
        	row2.code_menu = routines.system.JDBCUtil.getString(rs_tDBInput_1, 10, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 11) {
								row2.libelle_menu = null;
							} else {
	                         		
        	row2.libelle_menu = routines.system.JDBCUtil.getString(rs_tDBInput_1, 11, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 12) {
								row2.nombre_articles = null;
							} else {
		                          
            row2.nombre_articles = rs_tDBInput_1.getInt(12);
            if(rs_tDBInput_1.wasNull()){
                    row2.nombre_articles = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 13) {
								row2.temps_theo_preparation = null;
							} else {
		                          
            row2.temps_theo_preparation = rs_tDBInput_1.getBigDecimal(13);
            if(rs_tDBInput_1.wasNull()){
                    row2.temps_theo_preparation = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 14) {
								row2.id_commande = null;
							} else {
		                          
            row2.id_commande = rs_tDBInput_1.getInt(14);
            if(rs_tDBInput_1.wasNull()){
                    row2.id_commande = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 15) {
								row2.numero_commande = null;
							} else {
		                          
            row2.numero_commande = rs_tDBInput_1.getInt(15);
            if(rs_tDBInput_1.wasNull()){
                    row2.numero_commande = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 16) {
								row2.date_commande = null;
							} else {
										
			row2.date_commande = routines.system.JDBCUtil.getDate(rs_tDBInput_1, 16);
		                    }
							if(colQtyInRs_tDBInput_1 < 17) {
								row2.montant_total = null;
							} else {
		                          
            row2.montant_total = rs_tDBInput_1.getFloat(17);
            if(rs_tDBInput_1.wasNull()){
                    row2.montant_total = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 18) {
								row2.id_adresse_norm_restaurant = null;
							} else {
		                          
            row2.id_adresse_norm_restaurant = rs_tDBInput_1.getInt(18);
            if(rs_tDBInput_1.wasNull()){
                    row2.id_adresse_norm_restaurant = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 19) {
								row2.numero_voie_restau = null;
							} else {
	                         		
        	row2.numero_voie_restau = routines.system.JDBCUtil.getString(rs_tDBInput_1, 19, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 20) {
								row2.nom_voie_restau = null;
							} else {
	                         		
        	row2.nom_voie_restau = routines.system.JDBCUtil.getString(rs_tDBInput_1, 20, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 21) {
								row2.code_postal_restau = null;
							} else {
	                         		
        	row2.code_postal_restau = routines.system.JDBCUtil.getString(rs_tDBInput_1, 21, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 22) {
								row2.nom_ville_restau = null;
							} else {
	                         		
        	row2.nom_ville_restau = routines.system.JDBCUtil.getString(rs_tDBInput_1, 22, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 23) {
								row2.longitude_restau = null;
							} else {
	                         		
        	row2.longitude_restau = routines.system.JDBCUtil.getString(rs_tDBInput_1, 23, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 24) {
								row2.latitude_restau = null;
							} else {
	                         		
        	row2.latitude_restau = routines.system.JDBCUtil.getString(rs_tDBInput_1, 24, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 25) {
								row2.id_adresse_restaurant = null;
							} else {
		                          
            row2.id_adresse_restaurant = rs_tDBInput_1.getInt(25);
            if(rs_tDBInput_1.wasNull()){
                    row2.id_adresse_restaurant = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 26) {
								row2.adresse_restaurant = null;
							} else {
	                         		
        	row2.adresse_restaurant = routines.system.JDBCUtil.getString(rs_tDBInput_1, 26, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 27) {
								row2.id_restaurant = null;
							} else {
		                          
            row2.id_restaurant = rs_tDBInput_1.getInt(27);
            if(rs_tDBInput_1.wasNull()){
                    row2.id_restaurant = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 28) {
								row2.code_restaurant = null;
							} else {
	                         		
        	row2.code_restaurant = routines.system.JDBCUtil.getString(rs_tDBInput_1, 28, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 29) {
								row2.raison_sociale_restaurant = null;
							} else {
	                         		
        	row2.raison_sociale_restaurant = routines.system.JDBCUtil.getString(rs_tDBInput_1, 29, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 30) {
								row2.id_adresse_norm_client = null;
							} else {
		                          
            row2.id_adresse_norm_client = rs_tDBInput_1.getInt(30);
            if(rs_tDBInput_1.wasNull()){
                    row2.id_adresse_norm_client = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 31) {
								row2.numero_voie = null;
							} else {
	                         		
        	row2.numero_voie = routines.system.JDBCUtil.getString(rs_tDBInput_1, 31, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 32) {
								row2.nom_voie = null;
							} else {
	                         		
        	row2.nom_voie = routines.system.JDBCUtil.getString(rs_tDBInput_1, 32, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 33) {
								row2.code_postal = null;
							} else {
	                         		
        	row2.code_postal = routines.system.JDBCUtil.getString(rs_tDBInput_1, 33, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 34) {
								row2.nom_ville = null;
							} else {
	                         		
        	row2.nom_ville = routines.system.JDBCUtil.getString(rs_tDBInput_1, 34, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 35) {
								row2.longitude = null;
							} else {
	                         		
        	row2.longitude = routines.system.JDBCUtil.getString(rs_tDBInput_1, 35, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 36) {
								row2.latitude = null;
							} else {
	                         		
        	row2.latitude = routines.system.JDBCUtil.getString(rs_tDBInput_1, 36, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 37) {
								row2.id_adresse_client = null;
							} else {
		                          
            row2.id_adresse_client = rs_tDBInput_1.getInt(37);
            if(rs_tDBInput_1.wasNull()){
                    row2.id_adresse_client = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 38) {
								row2.adresse_client = null;
							} else {
	                         		
        	row2.adresse_client = routines.system.JDBCUtil.getString(rs_tDBInput_1, 38, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 39) {
								row2.id_client = null;
							} else {
		                          
            row2.id_client = rs_tDBInput_1.getInt(39);
            if(rs_tDBInput_1.wasNull()){
                    row2.id_client = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 40) {
								row2.nom_client = null;
							} else {
	                         		
        	row2.nom_client = routines.system.JDBCUtil.getString(rs_tDBInput_1, 40, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 41) {
								row2.prenom_client = null;
							} else {
	                         		
        	row2.prenom_client = routines.system.JDBCUtil.getString(rs_tDBInput_1, 41, false);
		                    }
					


 



/**
 * [tDBInput_1 begin ] stop
 */
	
	/**
	 * [tDBInput_1 main ] start
	 */

	

	
	
	currentComponent="tDBInput_1";

	

 


	tos_count_tDBInput_1++;

/**
 * [tDBInput_1 main ] stop
 */
	
	/**
	 * [tDBInput_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBInput_1";

	

 



/**
 * [tDBInput_1 process_data_begin ] stop
 */

	
	/**
	 * [tMap_1 main ] start
	 */

	

	
	
	currentComponent="tMap_1";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row2"
						
						);
					}
					

		
		
		boolean hasCasePrimitiveKeyWithNull_tMap_1 = false;
		

        // ###############################
        // # Input tables (lookups)
		  boolean rejectedInnerJoin_tMap_1 = false;
		  boolean mainRowRejected_tMap_1 = false;
            				    								  
		

				///////////////////////////////////////////////
				// Starting Lookup Table "row3" 
				///////////////////////////////////////////////


				
				
                            
 					    boolean forceLooprow3 = false;
       		  	    	
       		  	    	
 							row3Struct row3ObjectFromLookup = null;
                          
		           		  	if(!rejectedInnerJoin_tMap_1) { // G_TM_M_020

								
								hasCasePrimitiveKeyWithNull_tMap_1 = false;
								
                        		    		    row3HashKey.id_adresse_norm_client_src = row2.id_adresse_norm_client ;
                        		    		

								
		                        	row3HashKey.hashCodeDirty = true;
                        		
	  					
	  							
			  					
			  					
	  					
		  							tHash_Lookup_row3.lookup( row3HashKey );

	  							

	  							

 								
		  				
	  								
						
									
  									  		
 								



							} // G_TM_M_020
			           		  	  
							
				           		if(tHash_Lookup_row3 != null && tHash_Lookup_row3.getCount(row3HashKey) > 1) { // G 071
			  							
			  						
									 		
									//System.out.println("WARNING: UNIQUE MATCH is configured for the lookup 'row3' and it contains more one result from keys :  row3.id_adresse_norm_client_src = '" + row3HashKey.id_adresse_norm_client_src + "'");
								} // G 071
							

							row3Struct row3 = null;
                    		  	 
							   
                    		  	 
	       		  	    	row3Struct fromLookup_row3 = null;
							row3 = row3Default;
										 
							
								 
							
							
								if (tHash_Lookup_row3 !=null && tHash_Lookup_row3.hasNext()) { // G 099
								
							
								
								fromLookup_row3 = tHash_Lookup_row3.next();

							
							
								} // G 099
							
							

							if(fromLookup_row3 != null) {
								row3 = fromLookup_row3;
							}
							
							
							
			  							
								
	                    		  	
		                    
	            	
	           	
	            	
	            	
	            

				///////////////////////////////////////////////
				// Starting Lookup Table "row4" 
				///////////////////////////////////////////////


				
				
                            
 					    boolean forceLooprow4 = false;
       		  	    	
       		  	    	
 							row4Struct row4ObjectFromLookup = null;
                          
		           		  	if(!rejectedInnerJoin_tMap_1) { // G_TM_M_020

								
								hasCasePrimitiveKeyWithNull_tMap_1 = false;
								
                        		    		    row4HashKey.id_adresse_norm_restau_src = row2.id_adresse_norm_restaurant ;
                        		    		

								
		                        	row4HashKey.hashCodeDirty = true;
                        		
	  					
	  							
			  					
			  					
	  					
		  							tHash_Lookup_row4.lookup( row4HashKey );

	  							

	  							

 								
		  				
	  								
						
									
  									  		
 								



							} // G_TM_M_020
			           		  	  
							
				           		if(tHash_Lookup_row4 != null && tHash_Lookup_row4.getCount(row4HashKey) > 1) { // G 071
			  							
			  						
									 		
									//System.out.println("WARNING: UNIQUE MATCH is configured for the lookup 'row4' and it contains more one result from keys :  row4.id_adresse_norm_restau_src = '" + row4HashKey.id_adresse_norm_restau_src + "'");
								} // G 071
							

							row4Struct row4 = null;
                    		  	 
							   
                    		  	 
	       		  	    	row4Struct fromLookup_row4 = null;
							row4 = row4Default;
										 
							
								 
							
							
								if (tHash_Lookup_row4 !=null && tHash_Lookup_row4.hasNext()) { // G 099
								
							
								
								fromLookup_row4 = tHash_Lookup_row4.next();

							
							
								} // G 099
							
							

							if(fromLookup_row4 != null) {
								row4 = fromLookup_row4;
							}
							
							
							
			  							
								
	                    		  	
		                    
	            	
	           	
	            	
	            	
	            

				///////////////////////////////////////////////
				// Starting Lookup Table "row5" 
				///////////////////////////////////////////////


				
				
                            
 					    boolean forceLooprow5 = false;
       		  	    	
       		  	    	
 							row5Struct row5ObjectFromLookup = null;
                          
		           		  	if(!rejectedInnerJoin_tMap_1) { // G_TM_M_020

								
								hasCasePrimitiveKeyWithNull_tMap_1 = false;
								
                        		    		    row5HashKey.id_client_src = row2.id_client ;
                        		    		

								
		                        	row5HashKey.hashCodeDirty = true;
                        		
	  					
	  							
			  					
			  					
	  					
		  							tHash_Lookup_row5.lookup( row5HashKey );

	  							

	  							

 								
		  				
	  								
						
									
  									  		
 								



							} // G_TM_M_020
			           		  	  
							
				           		if(tHash_Lookup_row5 != null && tHash_Lookup_row5.getCount(row5HashKey) > 1) { // G 071
			  							
			  						
									 		
									//System.out.println("WARNING: UNIQUE MATCH is configured for the lookup 'row5' and it contains more one result from keys :  row5.id_client_src = '" + row5HashKey.id_client_src + "'");
								} // G 071
							

							row5Struct row5 = null;
                    		  	 
							   
                    		  	 
	       		  	    	row5Struct fromLookup_row5 = null;
							row5 = row5Default;
										 
							
								 
							
							
								if (tHash_Lookup_row5 !=null && tHash_Lookup_row5.hasNext()) { // G 099
								
							
								
								fromLookup_row5 = tHash_Lookup_row5.next();

							
							
								} // G 099
							
							

							if(fromLookup_row5 != null) {
								row5 = fromLookup_row5;
							}
							
							
							
			  							
								
	                    		  	
		                    
	            	
	           	
	            	
	            	
	            

				///////////////////////////////////////////////
				// Starting Lookup Table "row6" 
				///////////////////////////////////////////////


				
				
                            
 					    boolean forceLooprow6 = false;
       		  	    	
       		  	    	
 							row6Struct row6ObjectFromLookup = null;
                          
		           		  	if(!rejectedInnerJoin_tMap_1) { // G_TM_M_020

								
								hasCasePrimitiveKeyWithNull_tMap_1 = false;
								
                        		    		    row6HashKey.date_commande = row2.date_commande  == null ? null : new java.util.Date(row2.date_commande .getTime());
                        		    		

								
		                        	row6HashKey.hashCodeDirty = true;
                        		
	  					
	  							
			  					
			  					
	  					
		  							tHash_Lookup_row6.lookup( row6HashKey );

	  							

	  							

 								
		  				
	  								
						
									
  									  		
 								



							} // G_TM_M_020
			           		  	  
							
				           		if(tHash_Lookup_row6 != null && tHash_Lookup_row6.getCount(row6HashKey) > 1) { // G 071
			  							
			  						
									 		
									//System.out.println("WARNING: UNIQUE MATCH is configured for the lookup 'row6' and it contains more one result from keys :  row6.date_commande = '" + row6HashKey.date_commande + "'");
								} // G 071
							

							row6Struct row6 = null;
                    		  	 
							   
                    		  	 
	       		  	    	row6Struct fromLookup_row6 = null;
							row6 = row6Default;
										 
							
								 
							
							
								if (tHash_Lookup_row6 !=null && tHash_Lookup_row6.hasNext()) { // G 099
								
							
								
								fromLookup_row6 = tHash_Lookup_row6.next();

							
							
								} // G 099
							
							

							if(fromLookup_row6 != null) {
								row6 = fromLookup_row6;
							}
							
							
							
			  							
								
	                    		  	
		                    
	            	
	           	
	            	
	            	
	            

				///////////////////////////////////////////////
				// Starting Lookup Table "row7" 
				///////////////////////////////////////////////


				
				
                            
 					    boolean forceLooprow7 = false;
       		  	    	
       		  	    	
 							row7Struct row7ObjectFromLookup = null;
                          
		           		  	if(!rejectedInnerJoin_tMap_1) { // G_TM_M_020

								
								hasCasePrimitiveKeyWithNull_tMap_1 = false;
								
                        		    		    row7HashKey.id_moyen_paiement_src = row2.id_moyen_paiement ;
                        		    		

								
		                        	row7HashKey.hashCodeDirty = true;
                        		
	  					
	  							
			  					
			  					
	  					
		  							tHash_Lookup_row7.lookup( row7HashKey );

	  							

	  							

 								
		  				
	  								
						
									
  									  		
 								



							} // G_TM_M_020
			           		  	  
							
				           		if(tHash_Lookup_row7 != null && tHash_Lookup_row7.getCount(row7HashKey) > 1) { // G 071
			  							
			  						
									 		
									//System.out.println("WARNING: UNIQUE MATCH is configured for the lookup 'row7' and it contains more one result from keys :  row7.id_moyen_paiement_src = '" + row7HashKey.id_moyen_paiement_src + "'");
								} // G 071
							

							row7Struct row7 = null;
                    		  	 
							   
                    		  	 
	       		  	    	row7Struct fromLookup_row7 = null;
							row7 = row7Default;
										 
							
								 
							
							
								if (tHash_Lookup_row7 !=null && tHash_Lookup_row7.hasNext()) { // G 099
								
							
								
								fromLookup_row7 = tHash_Lookup_row7.next();

							
							
								} // G 099
							
							

							if(fromLookup_row7 != null) {
								row7 = fromLookup_row7;
							}
							
							
							
			  							
								
	                    		  	
		                    
	            	
	           	
	            	
	            	
	            

				///////////////////////////////////////////////
				// Starting Lookup Table "row8" 
				///////////////////////////////////////////////


				
				
                            
 					    boolean forceLooprow8 = false;
       		  	    	
       		  	    	
 							row8Struct row8ObjectFromLookup = null;
                          
		           		  	if(!rejectedInnerJoin_tMap_1) { // G_TM_M_020

								
								hasCasePrimitiveKeyWithNull_tMap_1 = false;
								
                        		    		    row8HashKey.id_preparation_src = row2.id_preparation ;
                        		    		

								
		                        	row8HashKey.hashCodeDirty = true;
                        		
	  					
	  							
			  					
			  					
	  					
		  							tHash_Lookup_row8.lookup( row8HashKey );

	  							

	  							

 								
		  				
	  								
						
									
  									  		
 								



							} // G_TM_M_020
			           		  	  
							
				           		if(tHash_Lookup_row8 != null && tHash_Lookup_row8.getCount(row8HashKey) > 1) { // G 071
			  							
			  						
									 		
									//System.out.println("WARNING: UNIQUE MATCH is configured for the lookup 'row8' and it contains more one result from keys :  row8.id_preparation_src = '" + row8HashKey.id_preparation_src + "'");
								} // G 071
							

							row8Struct row8 = null;
                    		  	 
							   
                    		  	 
	       		  	    	row8Struct fromLookup_row8 = null;
							row8 = row8Default;
										 
							
								 
							
							
								if (tHash_Lookup_row8 !=null && tHash_Lookup_row8.hasNext()) { // G 099
								
							
								
								fromLookup_row8 = tHash_Lookup_row8.next();

							
							
								} // G 099
							
							

							if(fromLookup_row8 != null) {
								row8 = fromLookup_row8;
							}
							
							
							
			  							
								
	                    		  	
		                    
	            	
	           	
	            	
	            	
	            

				///////////////////////////////////////////////
				// Starting Lookup Table "row9" 
				///////////////////////////////////////////////


				
				
                            
 					    boolean forceLooprow9 = false;
       		  	    	
       		  	    	
 							row9Struct row9ObjectFromLookup = null;
                          
		           		  	if(!rejectedInnerJoin_tMap_1) { // G_TM_M_020

								
								hasCasePrimitiveKeyWithNull_tMap_1 = false;
								
                        		    		    row9HashKey.id_restaurant_src = row2.id_restaurant ;
                        		    		

								
		                        	row9HashKey.hashCodeDirty = true;
                        		
	  					
	  							
			  					
			  					
	  					
		  							tHash_Lookup_row9.lookup( row9HashKey );

	  							

	  							

 								
		  				
	  								
						
									
  									  		
 								



							} // G_TM_M_020
			           		  	  
							
				           		if(tHash_Lookup_row9 != null && tHash_Lookup_row9.getCount(row9HashKey) > 1) { // G 071
			  							
			  						
									 		
									//System.out.println("WARNING: UNIQUE MATCH is configured for the lookup 'row9' and it contains more one result from keys :  row9.id_restaurant_src = '" + row9HashKey.id_restaurant_src + "'");
								} // G 071
							

							row9Struct row9 = null;
                    		  	 
							   
                    		  	 
	       		  	    	row9Struct fromLookup_row9 = null;
							row9 = row9Default;
										 
							
								 
							
							
								if (tHash_Lookup_row9 !=null && tHash_Lookup_row9.hasNext()) { // G 099
								
							
								
								fromLookup_row9 = tHash_Lookup_row9.next();

							
							
								} // G 099
							
							

							if(fromLookup_row9 != null) {
								row9 = fromLookup_row9;
							}
							
							
							
			  							
								
	                    		  	
		                    
	            	
	           	
	            	
	            	
	            

				///////////////////////////////////////////////
				// Starting Lookup Table "row10" 
				///////////////////////////////////////////////


				
				
                            
 					    boolean forceLooprow10 = false;
       		  	    	
       		  	    	
 							row10Struct row10ObjectFromLookup = null;
                          
		           		  	if(!rejectedInnerJoin_tMap_1) { // G_TM_M_020

								
								hasCasePrimitiveKeyWithNull_tMap_1 = false;
								
                        		    		    row10HashKey.id_menu_src = row2.id_menu;
                        		    		

								
		                        	row10HashKey.hashCodeDirty = true;
                        		
	  					
	  							
			  					
			  					
	  					
		  							tHash_Lookup_row10.lookup( row10HashKey );

	  							

	  							

 								
		  				
	  								
						
									
  									  		
 								



							} // G_TM_M_020
			           		  	  
							
				           		if(tHash_Lookup_row10 != null && tHash_Lookup_row10.getCount(row10HashKey) > 1) { // G 071
			  							
			  						
									 		
									//System.out.println("WARNING: UNIQUE MATCH is configured for the lookup 'row10' and it contains more one result from keys :  row10.id_menu_src = '" + row10HashKey.id_menu_src + "'");
								} // G 071
							

							row10Struct row10 = null;
                    		  	 
							   
                    		  	 
	       		  	    	row10Struct fromLookup_row10 = null;
							row10 = row10Default;
										 
							
								 
							
							
								if (tHash_Lookup_row10 !=null && tHash_Lookup_row10.hasNext()) { // G 099
								
							
								
								fromLookup_row10 = tHash_Lookup_row10.next();

							
							
								} // G 099
							
							

							if(fromLookup_row10 != null) {
								row10 = fromLookup_row10;
							}
							
							
							
			  							
								
	                    		  	
		                    
	            	
	           	
	            	
	            	
	            

				///////////////////////////////////////////////
				// Starting Lookup Table "row11" 
				///////////////////////////////////////////////


				
				
                            
 					    boolean forceLooprow11 = false;
       		  	    	
       		  	    	
 							row11Struct row11ObjectFromLookup = null;
                          
		           		  	if(!rejectedInnerJoin_tMap_1) { // G_TM_M_020

								
								hasCasePrimitiveKeyWithNull_tMap_1 = false;
								
                        		    		    row11HashKey.date_fin_preparation = row2.date_fin_preparation  == null ? null : new java.util.Date(row2.date_fin_preparation .getTime());
                        		    		

								
		                        	row11HashKey.hashCodeDirty = true;
                        		
	  					
	  							
			  					
			  					
	  					
		  							tHash_Lookup_row11.lookup( row11HashKey );

	  							

	  							

 								
		  				
	  								
						
									
  									  		
 								



							} // G_TM_M_020
			           		  	  
							
				           		if(tHash_Lookup_row11 != null && tHash_Lookup_row11.getCount(row11HashKey) > 1) { // G 071
			  							
			  						
									 		
									//System.out.println("WARNING: UNIQUE MATCH is configured for the lookup 'row11' and it contains more one result from keys :  row11.date_fin_preparation = '" + row11HashKey.date_fin_preparation + "'");
								} // G 071
							

							row11Struct row11 = null;
                    		  	 
							   
                    		  	 
	       		  	    	row11Struct fromLookup_row11 = null;
							row11 = row11Default;
										 
							
								 
							
							
								if (tHash_Lookup_row11 !=null && tHash_Lookup_row11.hasNext()) { // G 099
								
							
								
								fromLookup_row11 = tHash_Lookup_row11.next();

							
							
								} // G 099
							
							

							if(fromLookup_row11 != null) {
								row11 = fromLookup_row11;
							}
							
							
							
			  							
								
	                    		  	
		                    
	            	
	            	
	            // ###############################
        { // start of Var scope
        
	        // ###############################
        	// # Vars tables
        
Var__tMap_1__Struct Var = Var__tMap_1;// ###############################
        // ###############################
        // # Output tables

alim_fait = null;


// # Output table : 'alim_fait'
alim_fait_tmp.id_commande = 0;
alim_fait_tmp.id_date_commande = row6.id_date_commande ;
alim_fait_tmp.id_preparation = row8.id_preparation ;
alim_fait_tmp.id_client = row5.id_client ;
alim_fait_tmp.id_adresse_norm_client = row3.id_adresse_norm_client ;
alim_fait_tmp.id_restaurant = row9.id_restaurant ;
alim_fait_tmp.id_adresse_norm_restaurant = row4.id_adresse_norm_restaurant ;
alim_fait_tmp.id_moyen_paiement = row7.id_moyen_paiement ;
alim_fait_tmp.id_menu = row10.id_menu ;
alim_fait_tmp.id_date_fin_preparation = row11.id_date_fin_preparation ;
alim_fait_tmp.montant_total = row2.montant_total ;
alim_fait_tmp.temps_theo_preparation = row2.temps_theo_preparation ;
alim_fait_tmp.temps_reel_preparation = row2.temps_reel_preparation ;
alim_fait_tmp.numero_commande = row2.numero_commande ;
alim_fait = alim_fait_tmp;
// ###############################

} // end of Var scope

rejectedInnerJoin_tMap_1 = false;










 


	tos_count_tMap_1++;

/**
 * [tMap_1 main ] stop
 */
	
	/**
	 * [tMap_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tMap_1";

	

 



/**
 * [tMap_1 process_data_begin ] stop
 */
// Start of branch "alim_fait"
if(alim_fait != null) { 



	
	/**
	 * [tDBOutput_2 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"alim_fait"
						
						);
					}
					



        whetherReject_tDBOutput_2 = false;
                    pstmt_tDBOutput_2.setInt(1, alim_fait.id_date_commande);

                    pstmt_tDBOutput_2.setInt(2, alim_fait.id_preparation);

                    pstmt_tDBOutput_2.setInt(3, alim_fait.id_client);

                    pstmt_tDBOutput_2.setInt(4, alim_fait.id_adresse_norm_client);

                    pstmt_tDBOutput_2.setInt(5, alim_fait.id_restaurant);

                    pstmt_tDBOutput_2.setInt(6, alim_fait.id_adresse_norm_restaurant);

                    pstmt_tDBOutput_2.setInt(7, alim_fait.id_moyen_paiement);

                    pstmt_tDBOutput_2.setInt(8, alim_fait.id_menu);

                    pstmt_tDBOutput_2.setInt(9, alim_fait.id_date_fin_preparation);

                    if(alim_fait.montant_total == null) {
pstmt_tDBOutput_2.setNull(10, java.sql.Types.FLOAT);
} else {pstmt_tDBOutput_2.setFloat(10, alim_fait.montant_total);
}

                    pstmt_tDBOutput_2.setBigDecimal(11, alim_fait.temps_theo_preparation);

                    pstmt_tDBOutput_2.setBigDecimal(12, alim_fait.temps_reel_preparation);

                    if(alim_fait.numero_commande == null) {
pstmt_tDBOutput_2.setNull(13, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_2.setInt(13, alim_fait.numero_commande);
}

			
    		pstmt_tDBOutput_2.addBatch();
    		nb_line_tDBOutput_2++;
    		  
    		  
    		  batchSizeCounter_tDBOutput_2++;
    		  
    			if ((batchSize_tDBOutput_2 > 0) && (batchSize_tDBOutput_2 <= batchSizeCounter_tDBOutput_2)) {
                try {
						int countSum_tDBOutput_2 = 0;
						    
						for(int countEach_tDBOutput_2: pstmt_tDBOutput_2.executeBatch()) {
							countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
						}
				    	rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;
				    	
				    		insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
				    	
            	    	batchSizeCounter_tDBOutput_2 = 0;
                }catch (java.sql.BatchUpdateException e_tDBOutput_2){
globalMap.put("tDBOutput_2_ERROR_MESSAGE",e_tDBOutput_2.getMessage());
				    	java.sql.SQLException ne_tDBOutput_2 = e_tDBOutput_2.getNextException(),sqle_tDBOutput_2=null;
				    	String errormessage_tDBOutput_2;
						if (ne_tDBOutput_2 != null) {
							// build new exception to provide the original cause
							sqle_tDBOutput_2 = new java.sql.SQLException(e_tDBOutput_2.getMessage() + "\ncaused by: " + ne_tDBOutput_2.getMessage(), ne_tDBOutput_2.getSQLState(), ne_tDBOutput_2.getErrorCode(), ne_tDBOutput_2);
							errormessage_tDBOutput_2 = sqle_tDBOutput_2.getMessage();
						}else{
							errormessage_tDBOutput_2 = e_tDBOutput_2.getMessage();
						}
				    	
				    	int countSum_tDBOutput_2 = 0;
						for(int countEach_tDBOutput_2: e_tDBOutput_2.getUpdateCounts()) {
							countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
						}
						rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;
						
				    		insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
				    	
				    	System.err.println(errormessage_tDBOutput_2);
				    	
					}
    			}
    		
    		    commitCounter_tDBOutput_2++;
                if(commitEvery_tDBOutput_2 <= commitCounter_tDBOutput_2) {
                if ((batchSize_tDBOutput_2 > 0) && (batchSizeCounter_tDBOutput_2 > 0)) {
                try {
                		int countSum_tDBOutput_2 = 0;
                		    
						for(int countEach_tDBOutput_2: pstmt_tDBOutput_2.executeBatch()) {
							countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
						}
            	    	rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;
            	    	
            	    		insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
            	    	
                batchSizeCounter_tDBOutput_2 = 0;
               }catch (java.sql.BatchUpdateException e_tDBOutput_2){
globalMap.put("tDBOutput_2_ERROR_MESSAGE",e_tDBOutput_2.getMessage());
			    	java.sql.SQLException ne_tDBOutput_2 = e_tDBOutput_2.getNextException(),sqle_tDBOutput_2=null;
			    	String errormessage_tDBOutput_2;
					if (ne_tDBOutput_2 != null) {
						// build new exception to provide the original cause
						sqle_tDBOutput_2 = new java.sql.SQLException(e_tDBOutput_2.getMessage() + "\ncaused by: " + ne_tDBOutput_2.getMessage(), ne_tDBOutput_2.getSQLState(), ne_tDBOutput_2.getErrorCode(), ne_tDBOutput_2);
						errormessage_tDBOutput_2 = sqle_tDBOutput_2.getMessage();
					}else{
						errormessage_tDBOutput_2 = e_tDBOutput_2.getMessage();
					}
			    	
			    	int countSum_tDBOutput_2 = 0;
					for(int countEach_tDBOutput_2: e_tDBOutput_2.getUpdateCounts()) {
						countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
					}
					rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;
					
			    		insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
			    	
			    	System.err.println(errormessage_tDBOutput_2);
			    	
				}
            }
                    if(rowsToCommitCount_tDBOutput_2 != 0){
                    	
                    }
                    conn_tDBOutput_2.commit();
                    if(rowsToCommitCount_tDBOutput_2 != 0){
                    	
                    	rowsToCommitCount_tDBOutput_2 = 0;
                    }
                    commitCounter_tDBOutput_2=0;
                }

 


	tos_count_tDBOutput_2++;

/**
 * [tDBOutput_2 main ] stop
 */
	
	/**
	 * [tDBOutput_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";

	

 



/**
 * [tDBOutput_2 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";

	

 



/**
 * [tDBOutput_2 process_data_end ] stop
 */

} // End of branch "alim_fait"




	
	/**
	 * [tMap_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tMap_1";

	

 



/**
 * [tMap_1 process_data_end ] stop
 */



	
	/**
	 * [tDBInput_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBInput_1";

	

 



/**
 * [tDBInput_1 process_data_end ] stop
 */
	
	/**
	 * [tDBInput_1 end ] start
	 */

	

	
	
	currentComponent="tDBInput_1";

	

	}
}finally{
	if (rs_tDBInput_1 != null) {
		rs_tDBInput_1.close();
	}
	if (stmt_tDBInput_1 != null) {
		stmt_tDBInput_1.close();
	}
	if(conn_tDBInput_1 != null && !conn_tDBInput_1.isClosed()) {
		
			conn_tDBInput_1.commit();
			
		
			conn_tDBInput_1.close();
			
			if("com.mysql.cj.jdbc.Driver".equals((String)globalMap.get("driverClass_"))
			    && routines.system.BundleUtils.inOSGi()) {
			        Class.forName("com.mysql.cj.jdbc.AbandonedConnectionCleanupThread").
			            getMethod("checkedShutdown").invoke(null, (Object[]) null);
			}
			
	}
	
}
globalMap.put("tDBInput_1_NB_LINE",nb_line_tDBInput_1);
 

ok_Hash.put("tDBInput_1", true);
end_Hash.put("tDBInput_1", System.currentTimeMillis());

tStatCatcher_1.addMessage("end","tDBInput_1", end_Hash.get("tDBInput_1")-start_Hash.get("tDBInput_1"));
tStatCatcher_1Process(globalMap);



/**
 * [tDBInput_1 end ] stop
 */

	
	/**
	 * [tMap_1 end ] start
	 */

	

	
	
	currentComponent="tMap_1";

	


// ###############################
// # Lookup hashes releasing
					if(tHash_Lookup_row3 != null) {
						tHash_Lookup_row3.endGet();
					}
					globalMap.remove( "tHash_Lookup_row3" );

					
					
				
					if(tHash_Lookup_row4 != null) {
						tHash_Lookup_row4.endGet();
					}
					globalMap.remove( "tHash_Lookup_row4" );

					
					
				
					if(tHash_Lookup_row5 != null) {
						tHash_Lookup_row5.endGet();
					}
					globalMap.remove( "tHash_Lookup_row5" );

					
					
				
					if(tHash_Lookup_row6 != null) {
						tHash_Lookup_row6.endGet();
					}
					globalMap.remove( "tHash_Lookup_row6" );

					
					
				
					if(tHash_Lookup_row7 != null) {
						tHash_Lookup_row7.endGet();
					}
					globalMap.remove( "tHash_Lookup_row7" );

					
					
				
					if(tHash_Lookup_row8 != null) {
						tHash_Lookup_row8.endGet();
					}
					globalMap.remove( "tHash_Lookup_row8" );

					
					
				
					if(tHash_Lookup_row9 != null) {
						tHash_Lookup_row9.endGet();
					}
					globalMap.remove( "tHash_Lookup_row9" );

					
					
				
					if(tHash_Lookup_row10 != null) {
						tHash_Lookup_row10.endGet();
					}
					globalMap.remove( "tHash_Lookup_row10" );

					
					
				
					if(tHash_Lookup_row11 != null) {
						tHash_Lookup_row11.endGet();
					}
					globalMap.remove( "tHash_Lookup_row11" );

					
					
				
// ###############################      





				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row2");
			  	}
			  	
 

ok_Hash.put("tMap_1", true);
end_Hash.put("tMap_1", System.currentTimeMillis());

tStatCatcher_1.addMessage("end","tMap_1", end_Hash.get("tMap_1")-start_Hash.get("tMap_1"));
tStatCatcher_1Process(globalMap);



/**
 * [tMap_1 end ] stop
 */

	
	/**
	 * [tDBOutput_2 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";

	



	    try {
				int countSum_tDBOutput_2 = 0;
				if (pstmt_tDBOutput_2 != null && batchSizeCounter_tDBOutput_2 > 0) {
						
					for(int countEach_tDBOutput_2: pstmt_tDBOutput_2.executeBatch()) {
						countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
					}
					rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;
						
				}
		    	
		    		insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
		    	
	    }catch (java.sql.BatchUpdateException e_tDBOutput_2){
globalMap.put("tDBOutput_2_ERROR_MESSAGE",e_tDBOutput_2.getMessage());
	    	java.sql.SQLException ne_tDBOutput_2 = e_tDBOutput_2.getNextException(),sqle_tDBOutput_2=null;
	    	String errormessage_tDBOutput_2;
			if (ne_tDBOutput_2 != null) {
				// build new exception to provide the original cause
				sqle_tDBOutput_2 = new java.sql.SQLException(e_tDBOutput_2.getMessage() + "\ncaused by: " + ne_tDBOutput_2.getMessage(), ne_tDBOutput_2.getSQLState(), ne_tDBOutput_2.getErrorCode(), ne_tDBOutput_2);
				errormessage_tDBOutput_2 = sqle_tDBOutput_2.getMessage();
			}else{
				errormessage_tDBOutput_2 = e_tDBOutput_2.getMessage();
			}
	    	
	    	int countSum_tDBOutput_2 = 0;
			for(int countEach_tDBOutput_2: e_tDBOutput_2.getUpdateCounts()) {
				countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
			}
			rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;
			
	    		insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
	    	
	    	System.err.println(errormessage_tDBOutput_2);
	    	
		}
	    
        if(pstmt_tDBOutput_2 != null) {
        		
            pstmt_tDBOutput_2.close();
            resourceMap.remove("pstmt_tDBOutput_2");
        }
    resourceMap.put("statementClosed_tDBOutput_2", true);
			if(rowsToCommitCount_tDBOutput_2 != 0){
				
			}
			conn_tDBOutput_2.commit();
			if(rowsToCommitCount_tDBOutput_2 != 0){
				
				rowsToCommitCount_tDBOutput_2 = 0;
			}
			commitCounter_tDBOutput_2 = 0;
		
    	conn_tDBOutput_2 .close();
    	
    	resourceMap.put("finish_tDBOutput_2", true);
    	

	nb_line_deleted_tDBOutput_2=nb_line_deleted_tDBOutput_2+ deletedCount_tDBOutput_2;
	nb_line_update_tDBOutput_2=nb_line_update_tDBOutput_2 + updatedCount_tDBOutput_2;
	nb_line_inserted_tDBOutput_2=nb_line_inserted_tDBOutput_2 + insertedCount_tDBOutput_2;
	nb_line_rejected_tDBOutput_2=nb_line_rejected_tDBOutput_2 + rejectedCount_tDBOutput_2;
	
        globalMap.put("tDBOutput_2_NB_LINE",nb_line_tDBOutput_2);
        globalMap.put("tDBOutput_2_NB_LINE_UPDATED",nb_line_update_tDBOutput_2);
        globalMap.put("tDBOutput_2_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_2);
        globalMap.put("tDBOutput_2_NB_LINE_DELETED",nb_line_deleted_tDBOutput_2);
        globalMap.put("tDBOutput_2_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_2);
    

	


				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"alim_fait");
			  	}
			  	
 

ok_Hash.put("tDBOutput_2", true);
end_Hash.put("tDBOutput_2", System.currentTimeMillis());

tStatCatcher_1.addMessage("end","tDBOutput_2", end_Hash.get("tDBOutput_2")-start_Hash.get("tDBOutput_2"));
tStatCatcher_1Process(globalMap);



/**
 * [tDBOutput_2 end ] stop
 */






				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
					     			//free memory for "tMap_1"
					     			globalMap.remove("tHash_Lookup_row3"); 
				     			
					     			//free memory for "tMap_1"
					     			globalMap.remove("tHash_Lookup_row4"); 
				     			
					     			//free memory for "tMap_1"
					     			globalMap.remove("tHash_Lookup_row5"); 
				     			
					     			//free memory for "tMap_1"
					     			globalMap.remove("tHash_Lookup_row6"); 
				     			
					     			//free memory for "tMap_1"
					     			globalMap.remove("tHash_Lookup_row7"); 
				     			
					     			//free memory for "tMap_1"
					     			globalMap.remove("tHash_Lookup_row8"); 
				     			
					     			//free memory for "tMap_1"
					     			globalMap.remove("tHash_Lookup_row9"); 
				     			
					     			//free memory for "tMap_1"
					     			globalMap.remove("tHash_Lookup_row10"); 
				     			
					     			//free memory for "tMap_1"
					     			globalMap.remove("tHash_Lookup_row11"); 
				     			
				try{
					
	
	/**
	 * [tDBInput_1 finally ] start
	 */

	

	
	
	currentComponent="tDBInput_1";

	

 



/**
 * [tDBInput_1 finally ] stop
 */

	
	/**
	 * [tMap_1 finally ] start
	 */

	

	
	
	currentComponent="tMap_1";

	

 



/**
 * [tMap_1 finally ] stop
 */

	
	/**
	 * [tDBOutput_2 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";

	



    try {
    if (resourceMap.get("statementClosed_tDBOutput_2") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_2 = null;
                if ((pstmtToClose_tDBOutput_2 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_2")) != null) {
                    pstmtToClose_tDBOutput_2.close();
                }
    }
    } finally {
        if(resourceMap.get("finish_tDBOutput_2") == null){
            java.sql.Connection ctn_tDBOutput_2 = null;
            if((ctn_tDBOutput_2 = (java.sql.Connection)resourceMap.get("conn_tDBOutput_2")) != null){
                try {
                    ctn_tDBOutput_2.close();
                } catch (java.sql.SQLException sqlEx_tDBOutput_2) {
                    String errorMessage_tDBOutput_2 = "failed to close the connection in tDBOutput_2 :" + sqlEx_tDBOutput_2.getMessage();
                    System.err.println(errorMessage_tDBOutput_2);
                }
            }
        }
    }
 



/**
 * [tDBOutput_2 finally ] stop
 */






				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBInput_1_SUBPROCESS_STATE", 1);
	}
	


public static class row3Struct implements routines.system.IPersistableComparableLookupRow<row3Struct> {
    final static byte[] commonByteArrayLock_ALIMENTATION_DM1_F_ALIM_FAIT = new byte[0];
    static byte[] commonByteArray_ALIMENTATION_DM1_F_ALIM_FAIT = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int id_adresse_norm_client;

				public int getId_adresse_norm_client () {
					return this.id_adresse_norm_client;
				}
				
			    public Integer id_adresse_norm_client_src;

				public Integer getId_adresse_norm_client_src () {
					return this.id_adresse_norm_client_src;
				}
				
			    public String numero_voie;

				public String getNumero_voie () {
					return this.numero_voie;
				}
				
			    public String nom_voie;

				public String getNom_voie () {
					return this.nom_voie;
				}
				
			    public String code_postal;

				public String getCode_postal () {
					return this.code_postal;
				}
				
			    public String nom_ville;

				public String getNom_ville () {
					return this.nom_ville;
				}
				
			    public String longitude;

				public String getLongitude () {
					return this.longitude;
				}
				
			    public String latitude;

				public String getLatitude () {
					return this.latitude;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
						result = prime * result + ((this.id_adresse_norm_client_src == null) ? 0 : this.id_adresse_norm_client_src.hashCode());
					
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row3Struct other = (row3Struct) obj;
		
						if (this.id_adresse_norm_client_src == null) {
							if (other.id_adresse_norm_client_src != null)
								return false;
						
						} else if (!this.id_adresse_norm_client_src.equals(other.id_adresse_norm_client_src))
						
							return false;
					

		return true;
    }

	public void copyDataTo(row3Struct other) {

		other.id_adresse_norm_client = this.id_adresse_norm_client;
	            other.id_adresse_norm_client_src = this.id_adresse_norm_client_src;
	            other.numero_voie = this.numero_voie;
	            other.nom_voie = this.nom_voie;
	            other.code_postal = this.code_postal;
	            other.nom_ville = this.nom_ville;
	            other.longitude = this.longitude;
	            other.latitude = this.latitude;
	            
	}

	public void copyKeysDataTo(row3Struct other) {

		other.id_adresse_norm_client_src = this.id_adresse_norm_client_src;
	            	
	}



	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}
	
	private String readString(DataInputStream dis, ObjectInputStream ois) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			byte[] byteArray = new byte[length];
			dis.read(byteArray);
			strReturn = new String(byteArray, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(DataInputStream dis, org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			byte[] byteArray = new byte[length];
			unmarshaller.read(byteArray);
			strReturn = new String(byteArray, utf8Charset);
		}
		return strReturn;
	}
	
	private void writeString(String str, DataOutputStream dos, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
	}

	private void writeString(String str, DataOutputStream dos, ObjectOutputStream oos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
	}

    public void readKeysData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_DM1_F_ALIM_FAIT) {

        	try {

        		int length = 0;
		
						this.id_adresse_norm_client_src = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readKeysData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_DM1_F_ALIM_FAIT) {

        	try {

        		int length = 0;
		
						this.id_adresse_norm_client_src = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeKeysData(ObjectOutputStream dos) {
        try {

		
					// Integer
				
						writeInteger(this.id_adresse_norm_client_src,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeKeysData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// Integer
				
						writeInteger(this.id_adresse_norm_client_src,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }



    /**
     * Fill Values data by reading ObjectInputStream.
     */
    public void readValuesData(DataInputStream dis, ObjectInputStream ois) {
        try {

			int length = 0;
		
			            this.id_adresse_norm_client = dis.readInt();
					
						this.numero_voie = readString(dis,ois);
					
						this.nom_voie = readString(dis,ois);
					
						this.code_postal = readString(dis,ois);
					
						this.nom_ville = readString(dis,ois);
					
						this.longitude = readString(dis,ois);
					
						this.latitude = readString(dis,ois);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

    }
    
    public void readValuesData(DataInputStream dis, org.jboss.marshalling.Unmarshaller objectIn) {
        try {
			int length = 0;
		
			            this.id_adresse_norm_client = objectIn.readInt();
					
						this.numero_voie = readString(dis,objectIn);
					
						this.nom_voie = readString(dis,objectIn);
					
						this.code_postal = readString(dis,objectIn);
					
						this.nom_ville = readString(dis,objectIn);
					
						this.longitude = readString(dis,objectIn);
					
						this.latitude = readString(dis,objectIn);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

    }

    /**
     * Return a byte array which represents Values data.
     */
    public void writeValuesData(DataOutputStream dos, ObjectOutputStream oos) {
        try {

		
		            	dos.writeInt(this.id_adresse_norm_client);
					
						writeString(this.numero_voie, dos, oos);
					
						writeString(this.nom_voie, dos, oos);
					
						writeString(this.code_postal, dos, oos);
					
						writeString(this.nom_ville, dos, oos);
					
						writeString(this.longitude, dos, oos);
					
						writeString(this.latitude, dos, oos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        	}

    }
    
    public void writeValuesData(DataOutputStream dos, org.jboss.marshalling.Marshaller objectOut){
                try {

		
					objectOut.writeInt(this.id_adresse_norm_client);
					
						writeString(this.numero_voie, dos, objectOut);
					
						writeString(this.nom_voie, dos, objectOut);
					
						writeString(this.code_postal, dos, objectOut);
					
						writeString(this.nom_ville, dos, objectOut);
					
						writeString(this.longitude, dos, objectOut);
					
						writeString(this.latitude, dos, objectOut);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        	}
    }


    
    public boolean supportMarshaller(){
        return true;
    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id_adresse_norm_client="+String.valueOf(id_adresse_norm_client));
		sb.append(",id_adresse_norm_client_src="+String.valueOf(id_adresse_norm_client_src));
		sb.append(",numero_voie="+numero_voie);
		sb.append(",nom_voie="+nom_voie);
		sb.append(",code_postal="+code_postal);
		sb.append(",nom_ville="+nom_ville);
		sb.append(",longitude="+longitude);
		sb.append(",latitude="+latitude);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row3Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.id_adresse_norm_client_src, other.id_adresse_norm_client_src);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tDBInput_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBInput_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row3Struct row3 = new row3Struct();




	
	/**
	 * [tAdvancedHash_row3 begin ] start
	 */

	

	
		
		ok_Hash.put("tAdvancedHash_row3", false);
		start_Hash.put("tAdvancedHash_row3", System.currentTimeMillis());
		
	
	currentComponent="tAdvancedHash_row3";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row3");
					}
				
		int tos_count_tAdvancedHash_row3 = 0;
		

			   		// connection name:row3
			   		// source node:tDBInput_2 - inputs:(after_tDBInput_1) outputs:(row3,row3) | target node:tAdvancedHash_row3 - inputs:(row3) outputs:()
			   		// linked node: tMap_1 - inputs:(row2,row3,row4,row5,row6,row7,row8,row9,row10,row11) outputs:(alim_fait)
			   
			   		org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE matchingModeEnum_row3 = 
			   			org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE.UNIQUE_MATCH;
			   			
			   
	   			org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row3Struct> tHash_Lookup_row3 =org.talend.designer.components.lookup.memory.AdvancedMemoryLookup.
	   						<row3Struct>getLookup(matchingModeEnum_row3);
	   						   
		   	   	   globalMap.put("tHash_Lookup_row3", tHash_Lookup_row3);
		   	   	   
				
           

 



/**
 * [tAdvancedHash_row3 begin ] stop
 */



	
	/**
	 * [tDBInput_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBInput_2", false);
		start_Hash.put("tDBInput_2", System.currentTimeMillis());
		
				tStatCatcher_1.addMessage("begin","tDBInput_2");
				tStatCatcher_1Process(globalMap);
			
	
	currentComponent="tDBInput_2";

	
		int tos_count_tDBInput_2 = 0;
		
	
    
	
		    int nb_line_tDBInput_2 = 0;
		    java.sql.Connection conn_tDBInput_2 = null;
				String driverClass_tDBInput_2 = "org.postgresql.Driver";
			    java.lang.Class jdbcclazz_tDBInput_2 = java.lang.Class.forName(driverClass_tDBInput_2);
				String dbUser_tDBInput_2 = "dsid_cc2_tos_rw";
				
				 
	final String decryptedPassword_tDBInput_2 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:DVUbL7DebpWltUDPmqVxkucdRH/KXcOcejeJ31xOl4s=");
				
				String dbPwd_tDBInput_2 = decryptedPassword_tDBInput_2;
				
				String url_tDBInput_2 = "jdbc:postgresql://" + "" + ":" + "5432" + "/" + "postgres";
				
				conn_tDBInput_2 = java.sql.DriverManager.getConnection(url_tDBInput_2,dbUser_tDBInput_2,dbPwd_tDBInput_2);
		        
				conn_tDBInput_2.setAutoCommit(false);
			
		    
			java.sql.Statement stmt_tDBInput_2 = conn_tDBInput_2.createStatement();

		    String dbquery_tDBInput_2 = "SELECT \n  \"dsid_liv_dm1\".\"dim_adresse_norm_client_d\".\"id_adresse_norm_client\", \n  \"dsid_liv_dm1\".\"dim_adresse_"
+"norm_client_d\".\"id_adresse_norm_client_src\", \n  \"dsid_liv_dm1\".\"dim_adresse_norm_client_d\".\"numero_voie\", \n  \""
+"dsid_liv_dm1\".\"dim_adresse_norm_client_d\".\"nom_voie\", \n  \"dsid_liv_dm1\".\"dim_adresse_norm_client_d\".\"code_post"
+"al\", \n  \"dsid_liv_dm1\".\"dim_adresse_norm_client_d\".\"nom_ville\", \n  \"dsid_liv_dm1\".\"dim_adresse_norm_client_d\""
+".\"longitude\", \n  \"dsid_liv_dm1\".\"dim_adresse_norm_client_d\".\"latitude\"\nFROM \"dsid_liv_dm1\".\"dim_adresse_norm_"
+"client_d\"";
		    

            	globalMap.put("tDBInput_2_QUERY",dbquery_tDBInput_2);
		    java.sql.ResultSet rs_tDBInput_2 = null;

		    try {
		    	rs_tDBInput_2 = stmt_tDBInput_2.executeQuery(dbquery_tDBInput_2);
		    	java.sql.ResultSetMetaData rsmd_tDBInput_2 = rs_tDBInput_2.getMetaData();
		    	int colQtyInRs_tDBInput_2 = rsmd_tDBInput_2.getColumnCount();

		    String tmpContent_tDBInput_2 = null;
		    
		    
		    while (rs_tDBInput_2.next()) {
		        nb_line_tDBInput_2++;
		        
							if(colQtyInRs_tDBInput_2 < 1) {
								row3.id_adresse_norm_client = 0;
							} else {
		                          
            row3.id_adresse_norm_client = rs_tDBInput_2.getInt(1);
            if(rs_tDBInput_2.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 2) {
								row3.id_adresse_norm_client_src = null;
							} else {
		                          
            row3.id_adresse_norm_client_src = rs_tDBInput_2.getInt(2);
            if(rs_tDBInput_2.wasNull()){
                    row3.id_adresse_norm_client_src = null;
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 3) {
								row3.numero_voie = null;
							} else {
	                         		
        	row3.numero_voie = routines.system.JDBCUtil.getString(rs_tDBInput_2, 3, false);
		                    }
							if(colQtyInRs_tDBInput_2 < 4) {
								row3.nom_voie = null;
							} else {
	                         		
        	row3.nom_voie = routines.system.JDBCUtil.getString(rs_tDBInput_2, 4, false);
		                    }
							if(colQtyInRs_tDBInput_2 < 5) {
								row3.code_postal = null;
							} else {
	                         		
        	row3.code_postal = routines.system.JDBCUtil.getString(rs_tDBInput_2, 5, false);
		                    }
							if(colQtyInRs_tDBInput_2 < 6) {
								row3.nom_ville = null;
							} else {
	                         		
        	row3.nom_ville = routines.system.JDBCUtil.getString(rs_tDBInput_2, 6, false);
		                    }
							if(colQtyInRs_tDBInput_2 < 7) {
								row3.longitude = null;
							} else {
	                         		
        	row3.longitude = routines.system.JDBCUtil.getString(rs_tDBInput_2, 7, false);
		                    }
							if(colQtyInRs_tDBInput_2 < 8) {
								row3.latitude = null;
							} else {
	                         		
        	row3.latitude = routines.system.JDBCUtil.getString(rs_tDBInput_2, 8, false);
		                    }
					


 



/**
 * [tDBInput_2 begin ] stop
 */
	
	/**
	 * [tDBInput_2 main ] start
	 */

	

	
	
	currentComponent="tDBInput_2";

	

 


	tos_count_tDBInput_2++;

/**
 * [tDBInput_2 main ] stop
 */
	
	/**
	 * [tDBInput_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBInput_2";

	

 



/**
 * [tDBInput_2 process_data_begin ] stop
 */

	
	/**
	 * [tAdvancedHash_row3 main ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row3";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row3"
						
						);
					}
					


			   
			   

					row3Struct row3_HashRow = new row3Struct();
		   	   	   
				
				row3_HashRow.id_adresse_norm_client = row3.id_adresse_norm_client;
				
				row3_HashRow.id_adresse_norm_client_src = row3.id_adresse_norm_client_src;
				
				row3_HashRow.numero_voie = row3.numero_voie;
				
				row3_HashRow.nom_voie = row3.nom_voie;
				
				row3_HashRow.code_postal = row3.code_postal;
				
				row3_HashRow.nom_ville = row3.nom_ville;
				
				row3_HashRow.longitude = row3.longitude;
				
				row3_HashRow.latitude = row3.latitude;
				
			tHash_Lookup_row3.put(row3_HashRow);
			
            




 


	tos_count_tAdvancedHash_row3++;

/**
 * [tAdvancedHash_row3 main ] stop
 */
	
	/**
	 * [tAdvancedHash_row3 process_data_begin ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row3";

	

 



/**
 * [tAdvancedHash_row3 process_data_begin ] stop
 */
	
	/**
	 * [tAdvancedHash_row3 process_data_end ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row3";

	

 



/**
 * [tAdvancedHash_row3 process_data_end ] stop
 */



	
	/**
	 * [tDBInput_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBInput_2";

	

 



/**
 * [tDBInput_2 process_data_end ] stop
 */
	
	/**
	 * [tDBInput_2 end ] start
	 */

	

	
	
	currentComponent="tDBInput_2";

	

	}
}finally{
	if (rs_tDBInput_2 != null) {
		rs_tDBInput_2.close();
	}
	if (stmt_tDBInput_2 != null) {
		stmt_tDBInput_2.close();
	}
	if(conn_tDBInput_2 != null && !conn_tDBInput_2.isClosed()) {
		
			conn_tDBInput_2.commit();
			
		
			conn_tDBInput_2.close();
			
			if("com.mysql.cj.jdbc.Driver".equals((String)globalMap.get("driverClass_"))
			    && routines.system.BundleUtils.inOSGi()) {
			        Class.forName("com.mysql.cj.jdbc.AbandonedConnectionCleanupThread").
			            getMethod("checkedShutdown").invoke(null, (Object[]) null);
			}
			
	}
	
}
globalMap.put("tDBInput_2_NB_LINE",nb_line_tDBInput_2);
 

ok_Hash.put("tDBInput_2", true);
end_Hash.put("tDBInput_2", System.currentTimeMillis());

tStatCatcher_1.addMessage("end","tDBInput_2", end_Hash.get("tDBInput_2")-start_Hash.get("tDBInput_2"));
tStatCatcher_1Process(globalMap);



/**
 * [tDBInput_2 end ] stop
 */

	
	/**
	 * [tAdvancedHash_row3 end ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row3";

	

tHash_Lookup_row3.endPut();

				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row3");
			  	}
			  	
 

ok_Hash.put("tAdvancedHash_row3", true);
end_Hash.put("tAdvancedHash_row3", System.currentTimeMillis());




/**
 * [tAdvancedHash_row3 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBInput_2 finally ] start
	 */

	

	
	
	currentComponent="tDBInput_2";

	

 



/**
 * [tDBInput_2 finally ] stop
 */

	
	/**
	 * [tAdvancedHash_row3 finally ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row3";

	

 



/**
 * [tAdvancedHash_row3 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBInput_2_SUBPROCESS_STATE", 1);
	}
	


public static class row4Struct implements routines.system.IPersistableComparableLookupRow<row4Struct> {
    final static byte[] commonByteArrayLock_ALIMENTATION_DM1_F_ALIM_FAIT = new byte[0];
    static byte[] commonByteArray_ALIMENTATION_DM1_F_ALIM_FAIT = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int id_adresse_norm_restaurant;

				public int getId_adresse_norm_restaurant () {
					return this.id_adresse_norm_restaurant;
				}
				
			    public Integer id_adresse_norm_restau_src;

				public Integer getId_adresse_norm_restau_src () {
					return this.id_adresse_norm_restau_src;
				}
				
			    public String numero_voie;

				public String getNumero_voie () {
					return this.numero_voie;
				}
				
			    public String nom_voie;

				public String getNom_voie () {
					return this.nom_voie;
				}
				
			    public String code_postal;

				public String getCode_postal () {
					return this.code_postal;
				}
				
			    public String nom_ville;

				public String getNom_ville () {
					return this.nom_ville;
				}
				
			    public String longitude;

				public String getLongitude () {
					return this.longitude;
				}
				
			    public String latitude;

				public String getLatitude () {
					return this.latitude;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
						result = prime * result + ((this.id_adresse_norm_restau_src == null) ? 0 : this.id_adresse_norm_restau_src.hashCode());
					
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row4Struct other = (row4Struct) obj;
		
						if (this.id_adresse_norm_restau_src == null) {
							if (other.id_adresse_norm_restau_src != null)
								return false;
						
						} else if (!this.id_adresse_norm_restau_src.equals(other.id_adresse_norm_restau_src))
						
							return false;
					

		return true;
    }

	public void copyDataTo(row4Struct other) {

		other.id_adresse_norm_restaurant = this.id_adresse_norm_restaurant;
	            other.id_adresse_norm_restau_src = this.id_adresse_norm_restau_src;
	            other.numero_voie = this.numero_voie;
	            other.nom_voie = this.nom_voie;
	            other.code_postal = this.code_postal;
	            other.nom_ville = this.nom_ville;
	            other.longitude = this.longitude;
	            other.latitude = this.latitude;
	            
	}

	public void copyKeysDataTo(row4Struct other) {

		other.id_adresse_norm_restau_src = this.id_adresse_norm_restau_src;
	            	
	}



	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}
	
	private String readString(DataInputStream dis, ObjectInputStream ois) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			byte[] byteArray = new byte[length];
			dis.read(byteArray);
			strReturn = new String(byteArray, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(DataInputStream dis, org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			byte[] byteArray = new byte[length];
			unmarshaller.read(byteArray);
			strReturn = new String(byteArray, utf8Charset);
		}
		return strReturn;
	}
	
	private void writeString(String str, DataOutputStream dos, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
	}

	private void writeString(String str, DataOutputStream dos, ObjectOutputStream oos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
	}

    public void readKeysData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_DM1_F_ALIM_FAIT) {

        	try {

        		int length = 0;
		
						this.id_adresse_norm_restau_src = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readKeysData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_DM1_F_ALIM_FAIT) {

        	try {

        		int length = 0;
		
						this.id_adresse_norm_restau_src = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeKeysData(ObjectOutputStream dos) {
        try {

		
					// Integer
				
						writeInteger(this.id_adresse_norm_restau_src,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeKeysData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// Integer
				
						writeInteger(this.id_adresse_norm_restau_src,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }



    /**
     * Fill Values data by reading ObjectInputStream.
     */
    public void readValuesData(DataInputStream dis, ObjectInputStream ois) {
        try {

			int length = 0;
		
			            this.id_adresse_norm_restaurant = dis.readInt();
					
						this.numero_voie = readString(dis,ois);
					
						this.nom_voie = readString(dis,ois);
					
						this.code_postal = readString(dis,ois);
					
						this.nom_ville = readString(dis,ois);
					
						this.longitude = readString(dis,ois);
					
						this.latitude = readString(dis,ois);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

    }
    
    public void readValuesData(DataInputStream dis, org.jboss.marshalling.Unmarshaller objectIn) {
        try {
			int length = 0;
		
			            this.id_adresse_norm_restaurant = objectIn.readInt();
					
						this.numero_voie = readString(dis,objectIn);
					
						this.nom_voie = readString(dis,objectIn);
					
						this.code_postal = readString(dis,objectIn);
					
						this.nom_ville = readString(dis,objectIn);
					
						this.longitude = readString(dis,objectIn);
					
						this.latitude = readString(dis,objectIn);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

    }

    /**
     * Return a byte array which represents Values data.
     */
    public void writeValuesData(DataOutputStream dos, ObjectOutputStream oos) {
        try {

		
		            	dos.writeInt(this.id_adresse_norm_restaurant);
					
						writeString(this.numero_voie, dos, oos);
					
						writeString(this.nom_voie, dos, oos);
					
						writeString(this.code_postal, dos, oos);
					
						writeString(this.nom_ville, dos, oos);
					
						writeString(this.longitude, dos, oos);
					
						writeString(this.latitude, dos, oos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        	}

    }
    
    public void writeValuesData(DataOutputStream dos, org.jboss.marshalling.Marshaller objectOut){
                try {

		
					objectOut.writeInt(this.id_adresse_norm_restaurant);
					
						writeString(this.numero_voie, dos, objectOut);
					
						writeString(this.nom_voie, dos, objectOut);
					
						writeString(this.code_postal, dos, objectOut);
					
						writeString(this.nom_ville, dos, objectOut);
					
						writeString(this.longitude, dos, objectOut);
					
						writeString(this.latitude, dos, objectOut);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        	}
    }


    
    public boolean supportMarshaller(){
        return true;
    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id_adresse_norm_restaurant="+String.valueOf(id_adresse_norm_restaurant));
		sb.append(",id_adresse_norm_restau_src="+String.valueOf(id_adresse_norm_restau_src));
		sb.append(",numero_voie="+numero_voie);
		sb.append(",nom_voie="+nom_voie);
		sb.append(",code_postal="+code_postal);
		sb.append(",nom_ville="+nom_ville);
		sb.append(",longitude="+longitude);
		sb.append(",latitude="+latitude);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row4Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.id_adresse_norm_restau_src, other.id_adresse_norm_restau_src);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tDBInput_3Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBInput_3_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row4Struct row4 = new row4Struct();




	
	/**
	 * [tAdvancedHash_row4 begin ] start
	 */

	

	
		
		ok_Hash.put("tAdvancedHash_row4", false);
		start_Hash.put("tAdvancedHash_row4", System.currentTimeMillis());
		
	
	currentComponent="tAdvancedHash_row4";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row4");
					}
				
		int tos_count_tAdvancedHash_row4 = 0;
		

			   		// connection name:row4
			   		// source node:tDBInput_3 - inputs:(after_tDBInput_1) outputs:(row4,row4) | target node:tAdvancedHash_row4 - inputs:(row4) outputs:()
			   		// linked node: tMap_1 - inputs:(row2,row3,row4,row5,row6,row7,row8,row9,row10,row11) outputs:(alim_fait)
			   
			   		org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE matchingModeEnum_row4 = 
			   			org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE.UNIQUE_MATCH;
			   			
			   
	   			org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row4Struct> tHash_Lookup_row4 =org.talend.designer.components.lookup.memory.AdvancedMemoryLookup.
	   						<row4Struct>getLookup(matchingModeEnum_row4);
	   						   
		   	   	   globalMap.put("tHash_Lookup_row4", tHash_Lookup_row4);
		   	   	   
				
           

 



/**
 * [tAdvancedHash_row4 begin ] stop
 */



	
	/**
	 * [tDBInput_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBInput_3", false);
		start_Hash.put("tDBInput_3", System.currentTimeMillis());
		
				tStatCatcher_1.addMessage("begin","tDBInput_3");
				tStatCatcher_1Process(globalMap);
			
	
	currentComponent="tDBInput_3";

	
		int tos_count_tDBInput_3 = 0;
		
	
    
	
		    int nb_line_tDBInput_3 = 0;
		    java.sql.Connection conn_tDBInput_3 = null;
				String driverClass_tDBInput_3 = "org.postgresql.Driver";
			    java.lang.Class jdbcclazz_tDBInput_3 = java.lang.Class.forName(driverClass_tDBInput_3);
				String dbUser_tDBInput_3 = "dsid_cc2_tos_rw";
				
				 
	final String decryptedPassword_tDBInput_3 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:rm76MOnZ80xDbrC+9ueJcba8w0GmyzhZsHP/ybS9vC4=");
				
				String dbPwd_tDBInput_3 = decryptedPassword_tDBInput_3;
				
				String url_tDBInput_3 = "jdbc:postgresql://" + "" + ":" + "5432" + "/" + "postgres";
				
				conn_tDBInput_3 = java.sql.DriverManager.getConnection(url_tDBInput_3,dbUser_tDBInput_3,dbPwd_tDBInput_3);
		        
				conn_tDBInput_3.setAutoCommit(false);
			
		    
			java.sql.Statement stmt_tDBInput_3 = conn_tDBInput_3.createStatement();

		    String dbquery_tDBInput_3 = "SELECT \n  \"dsid_liv_dm1\".\"dim_adresse_norm_restaurant_d\".\"id_adresse_norm_restaurant\", \n  \"dsid_liv_dm1\".\"dim_"
+"adresse_norm_restaurant_d\".\"id_adresse_norm_restau_src\", \n  \"dsid_liv_dm1\".\"dim_adresse_norm_restaurant_d\".\"nume"
+"ro_voie\", \n  \"dsid_liv_dm1\".\"dim_adresse_norm_restaurant_d\".\"nom_voie\", \n  \"dsid_liv_dm1\".\"dim_adresse_norm_re"
+"staurant_d\".\"code_postal\", \n  \"dsid_liv_dm1\".\"dim_adresse_norm_restaurant_d\".\"nom_ville\", \n  \"dsid_liv_dm1\"."
+"\"dim_adresse_norm_restaurant_d\".\"longitude\", \n  \"dsid_liv_dm1\".\"dim_adresse_norm_restaurant_d\".\"latitude\"\nFROM"
+" \"dsid_liv_dm1\".\"dim_adresse_norm_restaurant_d\"";
		    

            	globalMap.put("tDBInput_3_QUERY",dbquery_tDBInput_3);
		    java.sql.ResultSet rs_tDBInput_3 = null;

		    try {
		    	rs_tDBInput_3 = stmt_tDBInput_3.executeQuery(dbquery_tDBInput_3);
		    	java.sql.ResultSetMetaData rsmd_tDBInput_3 = rs_tDBInput_3.getMetaData();
		    	int colQtyInRs_tDBInput_3 = rsmd_tDBInput_3.getColumnCount();

		    String tmpContent_tDBInput_3 = null;
		    
		    
		    while (rs_tDBInput_3.next()) {
		        nb_line_tDBInput_3++;
		        
							if(colQtyInRs_tDBInput_3 < 1) {
								row4.id_adresse_norm_restaurant = 0;
							} else {
		                          
            row4.id_adresse_norm_restaurant = rs_tDBInput_3.getInt(1);
            if(rs_tDBInput_3.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_3 < 2) {
								row4.id_adresse_norm_restau_src = null;
							} else {
		                          
            row4.id_adresse_norm_restau_src = rs_tDBInput_3.getInt(2);
            if(rs_tDBInput_3.wasNull()){
                    row4.id_adresse_norm_restau_src = null;
            }
		                    }
							if(colQtyInRs_tDBInput_3 < 3) {
								row4.numero_voie = null;
							} else {
	                         		
        	row4.numero_voie = routines.system.JDBCUtil.getString(rs_tDBInput_3, 3, false);
		                    }
							if(colQtyInRs_tDBInput_3 < 4) {
								row4.nom_voie = null;
							} else {
	                         		
        	row4.nom_voie = routines.system.JDBCUtil.getString(rs_tDBInput_3, 4, false);
		                    }
							if(colQtyInRs_tDBInput_3 < 5) {
								row4.code_postal = null;
							} else {
	                         		
        	row4.code_postal = routines.system.JDBCUtil.getString(rs_tDBInput_3, 5, false);
		                    }
							if(colQtyInRs_tDBInput_3 < 6) {
								row4.nom_ville = null;
							} else {
	                         		
        	row4.nom_ville = routines.system.JDBCUtil.getString(rs_tDBInput_3, 6, false);
		                    }
							if(colQtyInRs_tDBInput_3 < 7) {
								row4.longitude = null;
							} else {
	                         		
        	row4.longitude = routines.system.JDBCUtil.getString(rs_tDBInput_3, 7, false);
		                    }
							if(colQtyInRs_tDBInput_3 < 8) {
								row4.latitude = null;
							} else {
	                         		
        	row4.latitude = routines.system.JDBCUtil.getString(rs_tDBInput_3, 8, false);
		                    }
					


 



/**
 * [tDBInput_3 begin ] stop
 */
	
	/**
	 * [tDBInput_3 main ] start
	 */

	

	
	
	currentComponent="tDBInput_3";

	

 


	tos_count_tDBInput_3++;

/**
 * [tDBInput_3 main ] stop
 */
	
	/**
	 * [tDBInput_3 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBInput_3";

	

 



/**
 * [tDBInput_3 process_data_begin ] stop
 */

	
	/**
	 * [tAdvancedHash_row4 main ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row4";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row4"
						
						);
					}
					


			   
			   

					row4Struct row4_HashRow = new row4Struct();
		   	   	   
				
				row4_HashRow.id_adresse_norm_restaurant = row4.id_adresse_norm_restaurant;
				
				row4_HashRow.id_adresse_norm_restau_src = row4.id_adresse_norm_restau_src;
				
				row4_HashRow.numero_voie = row4.numero_voie;
				
				row4_HashRow.nom_voie = row4.nom_voie;
				
				row4_HashRow.code_postal = row4.code_postal;
				
				row4_HashRow.nom_ville = row4.nom_ville;
				
				row4_HashRow.longitude = row4.longitude;
				
				row4_HashRow.latitude = row4.latitude;
				
			tHash_Lookup_row4.put(row4_HashRow);
			
            




 


	tos_count_tAdvancedHash_row4++;

/**
 * [tAdvancedHash_row4 main ] stop
 */
	
	/**
	 * [tAdvancedHash_row4 process_data_begin ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row4";

	

 



/**
 * [tAdvancedHash_row4 process_data_begin ] stop
 */
	
	/**
	 * [tAdvancedHash_row4 process_data_end ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row4";

	

 



/**
 * [tAdvancedHash_row4 process_data_end ] stop
 */



	
	/**
	 * [tDBInput_3 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBInput_3";

	

 



/**
 * [tDBInput_3 process_data_end ] stop
 */
	
	/**
	 * [tDBInput_3 end ] start
	 */

	

	
	
	currentComponent="tDBInput_3";

	

	}
}finally{
	if (rs_tDBInput_3 != null) {
		rs_tDBInput_3.close();
	}
	if (stmt_tDBInput_3 != null) {
		stmt_tDBInput_3.close();
	}
	if(conn_tDBInput_3 != null && !conn_tDBInput_3.isClosed()) {
		
			conn_tDBInput_3.commit();
			
		
			conn_tDBInput_3.close();
			
			if("com.mysql.cj.jdbc.Driver".equals((String)globalMap.get("driverClass_"))
			    && routines.system.BundleUtils.inOSGi()) {
			        Class.forName("com.mysql.cj.jdbc.AbandonedConnectionCleanupThread").
			            getMethod("checkedShutdown").invoke(null, (Object[]) null);
			}
			
	}
	
}
globalMap.put("tDBInput_3_NB_LINE",nb_line_tDBInput_3);
 

ok_Hash.put("tDBInput_3", true);
end_Hash.put("tDBInput_3", System.currentTimeMillis());

tStatCatcher_1.addMessage("end","tDBInput_3", end_Hash.get("tDBInput_3")-start_Hash.get("tDBInput_3"));
tStatCatcher_1Process(globalMap);



/**
 * [tDBInput_3 end ] stop
 */

	
	/**
	 * [tAdvancedHash_row4 end ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row4";

	

tHash_Lookup_row4.endPut();

				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row4");
			  	}
			  	
 

ok_Hash.put("tAdvancedHash_row4", true);
end_Hash.put("tAdvancedHash_row4", System.currentTimeMillis());




/**
 * [tAdvancedHash_row4 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBInput_3 finally ] start
	 */

	

	
	
	currentComponent="tDBInput_3";

	

 



/**
 * [tDBInput_3 finally ] stop
 */

	
	/**
	 * [tAdvancedHash_row4 finally ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row4";

	

 



/**
 * [tAdvancedHash_row4 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBInput_3_SUBPROCESS_STATE", 1);
	}
	


public static class row5Struct implements routines.system.IPersistableComparableLookupRow<row5Struct> {
    final static byte[] commonByteArrayLock_ALIMENTATION_DM1_F_ALIM_FAIT = new byte[0];
    static byte[] commonByteArray_ALIMENTATION_DM1_F_ALIM_FAIT = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int id_client;

				public int getId_client () {
					return this.id_client;
				}
				
			    public Integer id_client_src;

				public Integer getId_client_src () {
					return this.id_client_src;
				}
				
			    public String nom_client;

				public String getNom_client () {
					return this.nom_client;
				}
				
			    public String prenom_client;

				public String getPrenom_client () {
					return this.prenom_client;
				}
				
			    public String nom_precedent;

				public String getNom_precedent () {
					return this.nom_precedent;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
						result = prime * result + ((this.id_client_src == null) ? 0 : this.id_client_src.hashCode());
					
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row5Struct other = (row5Struct) obj;
		
						if (this.id_client_src == null) {
							if (other.id_client_src != null)
								return false;
						
						} else if (!this.id_client_src.equals(other.id_client_src))
						
							return false;
					

		return true;
    }

	public void copyDataTo(row5Struct other) {

		other.id_client = this.id_client;
	            other.id_client_src = this.id_client_src;
	            other.nom_client = this.nom_client;
	            other.prenom_client = this.prenom_client;
	            other.nom_precedent = this.nom_precedent;
	            
	}

	public void copyKeysDataTo(row5Struct other) {

		other.id_client_src = this.id_client_src;
	            	
	}



	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}
	
	private String readString(DataInputStream dis, ObjectInputStream ois) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			byte[] byteArray = new byte[length];
			dis.read(byteArray);
			strReturn = new String(byteArray, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(DataInputStream dis, org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			byte[] byteArray = new byte[length];
			unmarshaller.read(byteArray);
			strReturn = new String(byteArray, utf8Charset);
		}
		return strReturn;
	}
	
	private void writeString(String str, DataOutputStream dos, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
	}

	private void writeString(String str, DataOutputStream dos, ObjectOutputStream oos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
	}

    public void readKeysData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_DM1_F_ALIM_FAIT) {

        	try {

        		int length = 0;
		
						this.id_client_src = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readKeysData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_DM1_F_ALIM_FAIT) {

        	try {

        		int length = 0;
		
						this.id_client_src = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeKeysData(ObjectOutputStream dos) {
        try {

		
					// Integer
				
						writeInteger(this.id_client_src,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeKeysData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// Integer
				
						writeInteger(this.id_client_src,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }



    /**
     * Fill Values data by reading ObjectInputStream.
     */
    public void readValuesData(DataInputStream dis, ObjectInputStream ois) {
        try {

			int length = 0;
		
			            this.id_client = dis.readInt();
					
						this.nom_client = readString(dis,ois);
					
						this.prenom_client = readString(dis,ois);
					
						this.nom_precedent = readString(dis,ois);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

    }
    
    public void readValuesData(DataInputStream dis, org.jboss.marshalling.Unmarshaller objectIn) {
        try {
			int length = 0;
		
			            this.id_client = objectIn.readInt();
					
						this.nom_client = readString(dis,objectIn);
					
						this.prenom_client = readString(dis,objectIn);
					
						this.nom_precedent = readString(dis,objectIn);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

    }

    /**
     * Return a byte array which represents Values data.
     */
    public void writeValuesData(DataOutputStream dos, ObjectOutputStream oos) {
        try {

		
		            	dos.writeInt(this.id_client);
					
						writeString(this.nom_client, dos, oos);
					
						writeString(this.prenom_client, dos, oos);
					
						writeString(this.nom_precedent, dos, oos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        	}

    }
    
    public void writeValuesData(DataOutputStream dos, org.jboss.marshalling.Marshaller objectOut){
                try {

		
					objectOut.writeInt(this.id_client);
					
						writeString(this.nom_client, dos, objectOut);
					
						writeString(this.prenom_client, dos, objectOut);
					
						writeString(this.nom_precedent, dos, objectOut);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        	}
    }


    
    public boolean supportMarshaller(){
        return true;
    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id_client="+String.valueOf(id_client));
		sb.append(",id_client_src="+String.valueOf(id_client_src));
		sb.append(",nom_client="+nom_client);
		sb.append(",prenom_client="+prenom_client);
		sb.append(",nom_precedent="+nom_precedent);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row5Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.id_client_src, other.id_client_src);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tDBInput_4Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBInput_4_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row5Struct row5 = new row5Struct();




	
	/**
	 * [tAdvancedHash_row5 begin ] start
	 */

	

	
		
		ok_Hash.put("tAdvancedHash_row5", false);
		start_Hash.put("tAdvancedHash_row5", System.currentTimeMillis());
		
	
	currentComponent="tAdvancedHash_row5";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row5");
					}
				
		int tos_count_tAdvancedHash_row5 = 0;
		

			   		// connection name:row5
			   		// source node:tDBInput_4 - inputs:(after_tDBInput_1) outputs:(row5,row5) | target node:tAdvancedHash_row5 - inputs:(row5) outputs:()
			   		// linked node: tMap_1 - inputs:(row2,row3,row4,row5,row6,row7,row8,row9,row10,row11) outputs:(alim_fait)
			   
			   		org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE matchingModeEnum_row5 = 
			   			org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE.UNIQUE_MATCH;
			   			
			   
	   			org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row5Struct> tHash_Lookup_row5 =org.talend.designer.components.lookup.memory.AdvancedMemoryLookup.
	   						<row5Struct>getLookup(matchingModeEnum_row5);
	   						   
		   	   	   globalMap.put("tHash_Lookup_row5", tHash_Lookup_row5);
		   	   	   
				
           

 



/**
 * [tAdvancedHash_row5 begin ] stop
 */



	
	/**
	 * [tDBInput_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBInput_4", false);
		start_Hash.put("tDBInput_4", System.currentTimeMillis());
		
				tStatCatcher_1.addMessage("begin","tDBInput_4");
				tStatCatcher_1Process(globalMap);
			
	
	currentComponent="tDBInput_4";

	
		int tos_count_tDBInput_4 = 0;
		
	
    
	
		    int nb_line_tDBInput_4 = 0;
		    java.sql.Connection conn_tDBInput_4 = null;
				String driverClass_tDBInput_4 = "org.postgresql.Driver";
			    java.lang.Class jdbcclazz_tDBInput_4 = java.lang.Class.forName(driverClass_tDBInput_4);
				String dbUser_tDBInput_4 = "dsid_cc2_tos_rw";
				
				 
	final String decryptedPassword_tDBInput_4 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:4lP80VV8FpiD5puSmPZeCJ8MvvXPpPFoaJHzymMfphs=");
				
				String dbPwd_tDBInput_4 = decryptedPassword_tDBInput_4;
				
				String url_tDBInput_4 = "jdbc:postgresql://" + "" + ":" + "5432" + "/" + "postgres";
				
				conn_tDBInput_4 = java.sql.DriverManager.getConnection(url_tDBInput_4,dbUser_tDBInput_4,dbPwd_tDBInput_4);
		        
				conn_tDBInput_4.setAutoCommit(false);
			
		    
			java.sql.Statement stmt_tDBInput_4 = conn_tDBInput_4.createStatement();

		    String dbquery_tDBInput_4 = "SELECT \n  \"dsid_liv_dm1\".\"dim_client_d\".\"id_client\", \n  \"dsid_liv_dm1\".\"dim_client_d\".\"id_client_src\", \n  "
+"\"dsid_liv_dm1\".\"dim_client_d\".\"nom_client\", \n  \"dsid_liv_dm1\".\"dim_client_d\".\"prenom_client\", \n  \"dsid_liv_"
+"dm1\".\"dim_client_d\".\"nom_precedent\"\nFROM \"dsid_liv_dm1\".\"dim_client_d\"";
		    

            	globalMap.put("tDBInput_4_QUERY",dbquery_tDBInput_4);
		    java.sql.ResultSet rs_tDBInput_4 = null;

		    try {
		    	rs_tDBInput_4 = stmt_tDBInput_4.executeQuery(dbquery_tDBInput_4);
		    	java.sql.ResultSetMetaData rsmd_tDBInput_4 = rs_tDBInput_4.getMetaData();
		    	int colQtyInRs_tDBInput_4 = rsmd_tDBInput_4.getColumnCount();

		    String tmpContent_tDBInput_4 = null;
		    
		    
		    while (rs_tDBInput_4.next()) {
		        nb_line_tDBInput_4++;
		        
							if(colQtyInRs_tDBInput_4 < 1) {
								row5.id_client = 0;
							} else {
		                          
            row5.id_client = rs_tDBInput_4.getInt(1);
            if(rs_tDBInput_4.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_4 < 2) {
								row5.id_client_src = null;
							} else {
		                          
            row5.id_client_src = rs_tDBInput_4.getInt(2);
            if(rs_tDBInput_4.wasNull()){
                    row5.id_client_src = null;
            }
		                    }
							if(colQtyInRs_tDBInput_4 < 3) {
								row5.nom_client = null;
							} else {
	                         		
        	row5.nom_client = routines.system.JDBCUtil.getString(rs_tDBInput_4, 3, false);
		                    }
							if(colQtyInRs_tDBInput_4 < 4) {
								row5.prenom_client = null;
							} else {
	                         		
        	row5.prenom_client = routines.system.JDBCUtil.getString(rs_tDBInput_4, 4, false);
		                    }
							if(colQtyInRs_tDBInput_4 < 5) {
								row5.nom_precedent = null;
							} else {
	                         		
        	row5.nom_precedent = routines.system.JDBCUtil.getString(rs_tDBInput_4, 5, false);
		                    }
					


 



/**
 * [tDBInput_4 begin ] stop
 */
	
	/**
	 * [tDBInput_4 main ] start
	 */

	

	
	
	currentComponent="tDBInput_4";

	

 


	tos_count_tDBInput_4++;

/**
 * [tDBInput_4 main ] stop
 */
	
	/**
	 * [tDBInput_4 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBInput_4";

	

 



/**
 * [tDBInput_4 process_data_begin ] stop
 */

	
	/**
	 * [tAdvancedHash_row5 main ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row5";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row5"
						
						);
					}
					


			   
			   

					row5Struct row5_HashRow = new row5Struct();
		   	   	   
				
				row5_HashRow.id_client = row5.id_client;
				
				row5_HashRow.id_client_src = row5.id_client_src;
				
				row5_HashRow.nom_client = row5.nom_client;
				
				row5_HashRow.prenom_client = row5.prenom_client;
				
				row5_HashRow.nom_precedent = row5.nom_precedent;
				
			tHash_Lookup_row5.put(row5_HashRow);
			
            




 


	tos_count_tAdvancedHash_row5++;

/**
 * [tAdvancedHash_row5 main ] stop
 */
	
	/**
	 * [tAdvancedHash_row5 process_data_begin ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row5";

	

 



/**
 * [tAdvancedHash_row5 process_data_begin ] stop
 */
	
	/**
	 * [tAdvancedHash_row5 process_data_end ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row5";

	

 



/**
 * [tAdvancedHash_row5 process_data_end ] stop
 */



	
	/**
	 * [tDBInput_4 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBInput_4";

	

 



/**
 * [tDBInput_4 process_data_end ] stop
 */
	
	/**
	 * [tDBInput_4 end ] start
	 */

	

	
	
	currentComponent="tDBInput_4";

	

	}
}finally{
	if (rs_tDBInput_4 != null) {
		rs_tDBInput_4.close();
	}
	if (stmt_tDBInput_4 != null) {
		stmt_tDBInput_4.close();
	}
	if(conn_tDBInput_4 != null && !conn_tDBInput_4.isClosed()) {
		
			conn_tDBInput_4.commit();
			
		
			conn_tDBInput_4.close();
			
			if("com.mysql.cj.jdbc.Driver".equals((String)globalMap.get("driverClass_"))
			    && routines.system.BundleUtils.inOSGi()) {
			        Class.forName("com.mysql.cj.jdbc.AbandonedConnectionCleanupThread").
			            getMethod("checkedShutdown").invoke(null, (Object[]) null);
			}
			
	}
	
}
globalMap.put("tDBInput_4_NB_LINE",nb_line_tDBInput_4);
 

ok_Hash.put("tDBInput_4", true);
end_Hash.put("tDBInput_4", System.currentTimeMillis());

tStatCatcher_1.addMessage("end","tDBInput_4", end_Hash.get("tDBInput_4")-start_Hash.get("tDBInput_4"));
tStatCatcher_1Process(globalMap);



/**
 * [tDBInput_4 end ] stop
 */

	
	/**
	 * [tAdvancedHash_row5 end ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row5";

	

tHash_Lookup_row5.endPut();

				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row5");
			  	}
			  	
 

ok_Hash.put("tAdvancedHash_row5", true);
end_Hash.put("tAdvancedHash_row5", System.currentTimeMillis());




/**
 * [tAdvancedHash_row5 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBInput_4 finally ] start
	 */

	

	
	
	currentComponent="tDBInput_4";

	

 



/**
 * [tDBInput_4 finally ] stop
 */

	
	/**
	 * [tAdvancedHash_row5 finally ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row5";

	

 



/**
 * [tAdvancedHash_row5 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBInput_4_SUBPROCESS_STATE", 1);
	}
	


public static class row6Struct implements routines.system.IPersistableComparableLookupRow<row6Struct> {
    final static byte[] commonByteArrayLock_ALIMENTATION_DM1_F_ALIM_FAIT = new byte[0];
    static byte[] commonByteArray_ALIMENTATION_DM1_F_ALIM_FAIT = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int id_date_commande;

				public int getId_date_commande () {
					return this.id_date_commande;
				}
				
			    public java.util.Date date_commande;

				public java.util.Date getDate_commande () {
					return this.date_commande;
				}
				
			    public String jour;

				public String getJour () {
					return this.jour;
				}
				
			    public String semaine;

				public String getSemaine () {
					return this.semaine;
				}
				
			    public String mois;

				public String getMois () {
					return this.mois;
				}
				
			    public String annee;

				public String getAnnee () {
					return this.annee;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
						result = prime * result + ((this.date_commande == null) ? 0 : this.date_commande.hashCode());
					
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row6Struct other = (row6Struct) obj;
		
						if (this.date_commande == null) {
							if (other.date_commande != null)
								return false;
						
						} else if (!this.date_commande.equals(other.date_commande))
						
							return false;
					

		return true;
    }

	public void copyDataTo(row6Struct other) {

		other.id_date_commande = this.id_date_commande;
	            other.date_commande = this.date_commande;
	            other.jour = this.jour;
	            other.semaine = this.semaine;
	            other.mois = this.mois;
	            other.annee = this.annee;
	            
	}

	public void copyKeysDataTo(row6Struct other) {

		other.date_commande = this.date_commande;
	            	
	}




	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }
	
	private String readString(DataInputStream dis, ObjectInputStream ois) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			byte[] byteArray = new byte[length];
			dis.read(byteArray);
			strReturn = new String(byteArray, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(DataInputStream dis, org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			byte[] byteArray = new byte[length];
			unmarshaller.read(byteArray);
			strReturn = new String(byteArray, utf8Charset);
		}
		return strReturn;
	}
	
	private void writeString(String str, DataOutputStream dos, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
	}

	private void writeString(String str, DataOutputStream dos, ObjectOutputStream oos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
	}

    public void readKeysData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_DM1_F_ALIM_FAIT) {

        	try {

        		int length = 0;
		
					this.date_commande = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readKeysData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_DM1_F_ALIM_FAIT) {

        	try {

        		int length = 0;
		
					this.date_commande = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeKeysData(ObjectOutputStream dos) {
        try {

		
					// java.util.Date
				
						writeDate(this.date_commande,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeKeysData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// java.util.Date
				
						writeDate(this.date_commande,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }



    /**
     * Fill Values data by reading ObjectInputStream.
     */
    public void readValuesData(DataInputStream dis, ObjectInputStream ois) {
        try {

			int length = 0;
		
			            this.id_date_commande = dis.readInt();
					
						this.jour = readString(dis,ois);
					
						this.semaine = readString(dis,ois);
					
						this.mois = readString(dis,ois);
					
						this.annee = readString(dis,ois);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

    }
    
    public void readValuesData(DataInputStream dis, org.jboss.marshalling.Unmarshaller objectIn) {
        try {
			int length = 0;
		
			            this.id_date_commande = objectIn.readInt();
					
						this.jour = readString(dis,objectIn);
					
						this.semaine = readString(dis,objectIn);
					
						this.mois = readString(dis,objectIn);
					
						this.annee = readString(dis,objectIn);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

    }

    /**
     * Return a byte array which represents Values data.
     */
    public void writeValuesData(DataOutputStream dos, ObjectOutputStream oos) {
        try {

		
		            	dos.writeInt(this.id_date_commande);
					
						writeString(this.jour, dos, oos);
					
						writeString(this.semaine, dos, oos);
					
						writeString(this.mois, dos, oos);
					
						writeString(this.annee, dos, oos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        	}

    }
    
    public void writeValuesData(DataOutputStream dos, org.jboss.marshalling.Marshaller objectOut){
                try {

		
					objectOut.writeInt(this.id_date_commande);
					
						writeString(this.jour, dos, objectOut);
					
						writeString(this.semaine, dos, objectOut);
					
						writeString(this.mois, dos, objectOut);
					
						writeString(this.annee, dos, objectOut);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        	}
    }


    
    public boolean supportMarshaller(){
        return true;
    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id_date_commande="+String.valueOf(id_date_commande));
		sb.append(",date_commande="+String.valueOf(date_commande));
		sb.append(",jour="+jour);
		sb.append(",semaine="+semaine);
		sb.append(",mois="+mois);
		sb.append(",annee="+annee);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row6Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.date_commande, other.date_commande);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tDBInput_5Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBInput_5_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row6Struct row6 = new row6Struct();




	
	/**
	 * [tAdvancedHash_row6 begin ] start
	 */

	

	
		
		ok_Hash.put("tAdvancedHash_row6", false);
		start_Hash.put("tAdvancedHash_row6", System.currentTimeMillis());
		
	
	currentComponent="tAdvancedHash_row6";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row6");
					}
				
		int tos_count_tAdvancedHash_row6 = 0;
		

			   		// connection name:row6
			   		// source node:tDBInput_5 - inputs:(after_tDBInput_1) outputs:(row6,row6) | target node:tAdvancedHash_row6 - inputs:(row6) outputs:()
			   		// linked node: tMap_1 - inputs:(row2,row3,row4,row5,row6,row7,row8,row9,row10,row11) outputs:(alim_fait)
			   
			   		org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE matchingModeEnum_row6 = 
			   			org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE.UNIQUE_MATCH;
			   			
			   
	   			org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row6Struct> tHash_Lookup_row6 =org.talend.designer.components.lookup.memory.AdvancedMemoryLookup.
	   						<row6Struct>getLookup(matchingModeEnum_row6);
	   						   
		   	   	   globalMap.put("tHash_Lookup_row6", tHash_Lookup_row6);
		   	   	   
				
           

 



/**
 * [tAdvancedHash_row6 begin ] stop
 */



	
	/**
	 * [tDBInput_5 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBInput_5", false);
		start_Hash.put("tDBInput_5", System.currentTimeMillis());
		
				tStatCatcher_1.addMessage("begin","tDBInput_5");
				tStatCatcher_1Process(globalMap);
			
	
	currentComponent="tDBInput_5";

	
		int tos_count_tDBInput_5 = 0;
		
	
    
	
		    int nb_line_tDBInput_5 = 0;
		    java.sql.Connection conn_tDBInput_5 = null;
				String driverClass_tDBInput_5 = "org.postgresql.Driver";
			    java.lang.Class jdbcclazz_tDBInput_5 = java.lang.Class.forName(driverClass_tDBInput_5);
				String dbUser_tDBInput_5 = "dsid_cc2_tos_rw";
				
				 
	final String decryptedPassword_tDBInput_5 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:c4WzpE5qNse2aryQMk44C9P8qPnnWNz+D6pDglDLYDw=");
				
				String dbPwd_tDBInput_5 = decryptedPassword_tDBInput_5;
				
				String url_tDBInput_5 = "jdbc:postgresql://" + "" + ":" + "5432" + "/" + "postgres";
				
				conn_tDBInput_5 = java.sql.DriverManager.getConnection(url_tDBInput_5,dbUser_tDBInput_5,dbPwd_tDBInput_5);
		        
				conn_tDBInput_5.setAutoCommit(false);
			
		    
			java.sql.Statement stmt_tDBInput_5 = conn_tDBInput_5.createStatement();

		    String dbquery_tDBInput_5 = "SELECT \n  \"dsid_liv_dm1\".\"dim_date_commande_d\".\"id_date_commande\", \n  \"dsid_liv_dm1\".\"dim_date_commande_d\".\""
+"date_commande\", \n  \"dsid_liv_dm1\".\"dim_date_commande_d\".\"jour\", \n  \"dsid_liv_dm1\".\"dim_date_commande_d\".\"sem"
+"aine\", \n  \"dsid_liv_dm1\".\"dim_date_commande_d\".\"mois\", \n  \"dsid_liv_dm1\".\"dim_date_commande_d\".\"annee\"\nFROM"
+" \"dsid_liv_dm1\".\"dim_date_commande_d\"";
		    

            	globalMap.put("tDBInput_5_QUERY",dbquery_tDBInput_5);
		    java.sql.ResultSet rs_tDBInput_5 = null;

		    try {
		    	rs_tDBInput_5 = stmt_tDBInput_5.executeQuery(dbquery_tDBInput_5);
		    	java.sql.ResultSetMetaData rsmd_tDBInput_5 = rs_tDBInput_5.getMetaData();
		    	int colQtyInRs_tDBInput_5 = rsmd_tDBInput_5.getColumnCount();

		    String tmpContent_tDBInput_5 = null;
		    
		    
		    while (rs_tDBInput_5.next()) {
		        nb_line_tDBInput_5++;
		        
							if(colQtyInRs_tDBInput_5 < 1) {
								row6.id_date_commande = 0;
							} else {
		                          
            row6.id_date_commande = rs_tDBInput_5.getInt(1);
            if(rs_tDBInput_5.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_5 < 2) {
								row6.date_commande = null;
							} else {
										
			row6.date_commande = routines.system.JDBCUtil.getDate(rs_tDBInput_5, 2);
		                    }
							if(colQtyInRs_tDBInput_5 < 3) {
								row6.jour = null;
							} else {
	                         		
        	row6.jour = routines.system.JDBCUtil.getString(rs_tDBInput_5, 3, false);
		                    }
							if(colQtyInRs_tDBInput_5 < 4) {
								row6.semaine = null;
							} else {
	                         		
        	row6.semaine = routines.system.JDBCUtil.getString(rs_tDBInput_5, 4, false);
		                    }
							if(colQtyInRs_tDBInput_5 < 5) {
								row6.mois = null;
							} else {
	                         		
        	row6.mois = routines.system.JDBCUtil.getString(rs_tDBInput_5, 5, false);
		                    }
							if(colQtyInRs_tDBInput_5 < 6) {
								row6.annee = null;
							} else {
	                         		
        	row6.annee = routines.system.JDBCUtil.getString(rs_tDBInput_5, 6, false);
		                    }
					


 



/**
 * [tDBInput_5 begin ] stop
 */
	
	/**
	 * [tDBInput_5 main ] start
	 */

	

	
	
	currentComponent="tDBInput_5";

	

 


	tos_count_tDBInput_5++;

/**
 * [tDBInput_5 main ] stop
 */
	
	/**
	 * [tDBInput_5 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBInput_5";

	

 



/**
 * [tDBInput_5 process_data_begin ] stop
 */

	
	/**
	 * [tAdvancedHash_row6 main ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row6";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row6"
						
						);
					}
					


			   
			   

					row6Struct row6_HashRow = new row6Struct();
		   	   	   
				
				row6_HashRow.id_date_commande = row6.id_date_commande;
				
				row6_HashRow.date_commande = row6.date_commande;
				
				row6_HashRow.jour = row6.jour;
				
				row6_HashRow.semaine = row6.semaine;
				
				row6_HashRow.mois = row6.mois;
				
				row6_HashRow.annee = row6.annee;
				
			tHash_Lookup_row6.put(row6_HashRow);
			
            




 


	tos_count_tAdvancedHash_row6++;

/**
 * [tAdvancedHash_row6 main ] stop
 */
	
	/**
	 * [tAdvancedHash_row6 process_data_begin ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row6";

	

 



/**
 * [tAdvancedHash_row6 process_data_begin ] stop
 */
	
	/**
	 * [tAdvancedHash_row6 process_data_end ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row6";

	

 



/**
 * [tAdvancedHash_row6 process_data_end ] stop
 */



	
	/**
	 * [tDBInput_5 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBInput_5";

	

 



/**
 * [tDBInput_5 process_data_end ] stop
 */
	
	/**
	 * [tDBInput_5 end ] start
	 */

	

	
	
	currentComponent="tDBInput_5";

	

	}
}finally{
	if (rs_tDBInput_5 != null) {
		rs_tDBInput_5.close();
	}
	if (stmt_tDBInput_5 != null) {
		stmt_tDBInput_5.close();
	}
	if(conn_tDBInput_5 != null && !conn_tDBInput_5.isClosed()) {
		
			conn_tDBInput_5.commit();
			
		
			conn_tDBInput_5.close();
			
			if("com.mysql.cj.jdbc.Driver".equals((String)globalMap.get("driverClass_"))
			    && routines.system.BundleUtils.inOSGi()) {
			        Class.forName("com.mysql.cj.jdbc.AbandonedConnectionCleanupThread").
			            getMethod("checkedShutdown").invoke(null, (Object[]) null);
			}
			
	}
	
}
globalMap.put("tDBInput_5_NB_LINE",nb_line_tDBInput_5);
 

ok_Hash.put("tDBInput_5", true);
end_Hash.put("tDBInput_5", System.currentTimeMillis());

tStatCatcher_1.addMessage("end","tDBInput_5", end_Hash.get("tDBInput_5")-start_Hash.get("tDBInput_5"));
tStatCatcher_1Process(globalMap);



/**
 * [tDBInput_5 end ] stop
 */

	
	/**
	 * [tAdvancedHash_row6 end ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row6";

	

tHash_Lookup_row6.endPut();

				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row6");
			  	}
			  	
 

ok_Hash.put("tAdvancedHash_row6", true);
end_Hash.put("tAdvancedHash_row6", System.currentTimeMillis());




/**
 * [tAdvancedHash_row6 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBInput_5 finally ] start
	 */

	

	
	
	currentComponent="tDBInput_5";

	

 



/**
 * [tDBInput_5 finally ] stop
 */

	
	/**
	 * [tAdvancedHash_row6 finally ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row6";

	

 



/**
 * [tAdvancedHash_row6 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBInput_5_SUBPROCESS_STATE", 1);
	}
	


public static class row7Struct implements routines.system.IPersistableComparableLookupRow<row7Struct> {
    final static byte[] commonByteArrayLock_ALIMENTATION_DM1_F_ALIM_FAIT = new byte[0];
    static byte[] commonByteArray_ALIMENTATION_DM1_F_ALIM_FAIT = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int id_moyen_paiement;

				public int getId_moyen_paiement () {
					return this.id_moyen_paiement;
				}
				
			    public Integer id_moyen_paiement_src;

				public Integer getId_moyen_paiement_src () {
					return this.id_moyen_paiement_src;
				}
				
			    public String code_moyen_paiement;

				public String getCode_moyen_paiement () {
					return this.code_moyen_paiement;
				}
				
			    public String livelle_moyen_paiement;

				public String getLivelle_moyen_paiement () {
					return this.livelle_moyen_paiement;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
						result = prime * result + ((this.id_moyen_paiement_src == null) ? 0 : this.id_moyen_paiement_src.hashCode());
					
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row7Struct other = (row7Struct) obj;
		
						if (this.id_moyen_paiement_src == null) {
							if (other.id_moyen_paiement_src != null)
								return false;
						
						} else if (!this.id_moyen_paiement_src.equals(other.id_moyen_paiement_src))
						
							return false;
					

		return true;
    }

	public void copyDataTo(row7Struct other) {

		other.id_moyen_paiement = this.id_moyen_paiement;
	            other.id_moyen_paiement_src = this.id_moyen_paiement_src;
	            other.code_moyen_paiement = this.code_moyen_paiement;
	            other.livelle_moyen_paiement = this.livelle_moyen_paiement;
	            
	}

	public void copyKeysDataTo(row7Struct other) {

		other.id_moyen_paiement_src = this.id_moyen_paiement_src;
	            	
	}



	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}
	
	private String readString(DataInputStream dis, ObjectInputStream ois) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			byte[] byteArray = new byte[length];
			dis.read(byteArray);
			strReturn = new String(byteArray, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(DataInputStream dis, org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			byte[] byteArray = new byte[length];
			unmarshaller.read(byteArray);
			strReturn = new String(byteArray, utf8Charset);
		}
		return strReturn;
	}
	
	private void writeString(String str, DataOutputStream dos, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
	}

	private void writeString(String str, DataOutputStream dos, ObjectOutputStream oos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
	}

    public void readKeysData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_DM1_F_ALIM_FAIT) {

        	try {

        		int length = 0;
		
						this.id_moyen_paiement_src = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readKeysData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_DM1_F_ALIM_FAIT) {

        	try {

        		int length = 0;
		
						this.id_moyen_paiement_src = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeKeysData(ObjectOutputStream dos) {
        try {

		
					// Integer
				
						writeInteger(this.id_moyen_paiement_src,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeKeysData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// Integer
				
						writeInteger(this.id_moyen_paiement_src,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }



    /**
     * Fill Values data by reading ObjectInputStream.
     */
    public void readValuesData(DataInputStream dis, ObjectInputStream ois) {
        try {

			int length = 0;
		
			            this.id_moyen_paiement = dis.readInt();
					
						this.code_moyen_paiement = readString(dis,ois);
					
						this.livelle_moyen_paiement = readString(dis,ois);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

    }
    
    public void readValuesData(DataInputStream dis, org.jboss.marshalling.Unmarshaller objectIn) {
        try {
			int length = 0;
		
			            this.id_moyen_paiement = objectIn.readInt();
					
						this.code_moyen_paiement = readString(dis,objectIn);
					
						this.livelle_moyen_paiement = readString(dis,objectIn);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

    }

    /**
     * Return a byte array which represents Values data.
     */
    public void writeValuesData(DataOutputStream dos, ObjectOutputStream oos) {
        try {

		
		            	dos.writeInt(this.id_moyen_paiement);
					
						writeString(this.code_moyen_paiement, dos, oos);
					
						writeString(this.livelle_moyen_paiement, dos, oos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        	}

    }
    
    public void writeValuesData(DataOutputStream dos, org.jboss.marshalling.Marshaller objectOut){
                try {

		
					objectOut.writeInt(this.id_moyen_paiement);
					
						writeString(this.code_moyen_paiement, dos, objectOut);
					
						writeString(this.livelle_moyen_paiement, dos, objectOut);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        	}
    }


    
    public boolean supportMarshaller(){
        return true;
    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id_moyen_paiement="+String.valueOf(id_moyen_paiement));
		sb.append(",id_moyen_paiement_src="+String.valueOf(id_moyen_paiement_src));
		sb.append(",code_moyen_paiement="+code_moyen_paiement);
		sb.append(",livelle_moyen_paiement="+livelle_moyen_paiement);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row7Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.id_moyen_paiement_src, other.id_moyen_paiement_src);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tDBInput_6Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBInput_6_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row7Struct row7 = new row7Struct();




	
	/**
	 * [tAdvancedHash_row7 begin ] start
	 */

	

	
		
		ok_Hash.put("tAdvancedHash_row7", false);
		start_Hash.put("tAdvancedHash_row7", System.currentTimeMillis());
		
	
	currentComponent="tAdvancedHash_row7";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row7");
					}
				
		int tos_count_tAdvancedHash_row7 = 0;
		

			   		// connection name:row7
			   		// source node:tDBInput_6 - inputs:(after_tDBInput_1) outputs:(row7,row7) | target node:tAdvancedHash_row7 - inputs:(row7) outputs:()
			   		// linked node: tMap_1 - inputs:(row2,row3,row4,row5,row6,row7,row8,row9,row10,row11) outputs:(alim_fait)
			   
			   		org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE matchingModeEnum_row7 = 
			   			org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE.UNIQUE_MATCH;
			   			
			   
	   			org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row7Struct> tHash_Lookup_row7 =org.talend.designer.components.lookup.memory.AdvancedMemoryLookup.
	   						<row7Struct>getLookup(matchingModeEnum_row7);
	   						   
		   	   	   globalMap.put("tHash_Lookup_row7", tHash_Lookup_row7);
		   	   	   
				
           

 



/**
 * [tAdvancedHash_row7 begin ] stop
 */



	
	/**
	 * [tDBInput_6 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBInput_6", false);
		start_Hash.put("tDBInput_6", System.currentTimeMillis());
		
				tStatCatcher_1.addMessage("begin","tDBInput_6");
				tStatCatcher_1Process(globalMap);
			
	
	currentComponent="tDBInput_6";

	
		int tos_count_tDBInput_6 = 0;
		
	
    
	
		    int nb_line_tDBInput_6 = 0;
		    java.sql.Connection conn_tDBInput_6 = null;
				String driverClass_tDBInput_6 = "org.postgresql.Driver";
			    java.lang.Class jdbcclazz_tDBInput_6 = java.lang.Class.forName(driverClass_tDBInput_6);
				String dbUser_tDBInput_6 = "dsid_cc2_tos_rw";
				
				 
	final String decryptedPassword_tDBInput_6 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:lDoynuzdeOwlZuhtHrGWf21/y0Au63LSTZ2GfrV/fio=");
				
				String dbPwd_tDBInput_6 = decryptedPassword_tDBInput_6;
				
				String url_tDBInput_6 = "jdbc:postgresql://" + "" + ":" + "5432" + "/" + "postgres";
				
				conn_tDBInput_6 = java.sql.DriverManager.getConnection(url_tDBInput_6,dbUser_tDBInput_6,dbPwd_tDBInput_6);
		        
				conn_tDBInput_6.setAutoCommit(false);
			
		    
			java.sql.Statement stmt_tDBInput_6 = conn_tDBInput_6.createStatement();

		    String dbquery_tDBInput_6 = "SELECT \n  \"dsid_liv_dm1\".\"dim_moyen_paiement_d\".\"id_moyen_paiement\", \n  \"dsid_liv_dm1\".\"dim_moyen_paiement_d\""
+".\"id_moyen_paiement_src\", \n  \"dsid_liv_dm1\".\"dim_moyen_paiement_d\".\"code_moyen_paiement\", \n  \"dsid_liv_dm1\".\""
+"dim_moyen_paiement_d\".\"livelle_moyen_paiement\"\nFROM \"dsid_liv_dm1\".\"dim_moyen_paiement_d\"";
		    

            	globalMap.put("tDBInput_6_QUERY",dbquery_tDBInput_6);
		    java.sql.ResultSet rs_tDBInput_6 = null;

		    try {
		    	rs_tDBInput_6 = stmt_tDBInput_6.executeQuery(dbquery_tDBInput_6);
		    	java.sql.ResultSetMetaData rsmd_tDBInput_6 = rs_tDBInput_6.getMetaData();
		    	int colQtyInRs_tDBInput_6 = rsmd_tDBInput_6.getColumnCount();

		    String tmpContent_tDBInput_6 = null;
		    
		    
		    while (rs_tDBInput_6.next()) {
		        nb_line_tDBInput_6++;
		        
							if(colQtyInRs_tDBInput_6 < 1) {
								row7.id_moyen_paiement = 0;
							} else {
		                          
            row7.id_moyen_paiement = rs_tDBInput_6.getInt(1);
            if(rs_tDBInput_6.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_6 < 2) {
								row7.id_moyen_paiement_src = null;
							} else {
		                          
            row7.id_moyen_paiement_src = rs_tDBInput_6.getInt(2);
            if(rs_tDBInput_6.wasNull()){
                    row7.id_moyen_paiement_src = null;
            }
		                    }
							if(colQtyInRs_tDBInput_6 < 3) {
								row7.code_moyen_paiement = null;
							} else {
	                         		
        	row7.code_moyen_paiement = routines.system.JDBCUtil.getString(rs_tDBInput_6, 3, false);
		                    }
							if(colQtyInRs_tDBInput_6 < 4) {
								row7.livelle_moyen_paiement = null;
							} else {
	                         		
        	row7.livelle_moyen_paiement = routines.system.JDBCUtil.getString(rs_tDBInput_6, 4, false);
		                    }
					


 



/**
 * [tDBInput_6 begin ] stop
 */
	
	/**
	 * [tDBInput_6 main ] start
	 */

	

	
	
	currentComponent="tDBInput_6";

	

 


	tos_count_tDBInput_6++;

/**
 * [tDBInput_6 main ] stop
 */
	
	/**
	 * [tDBInput_6 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBInput_6";

	

 



/**
 * [tDBInput_6 process_data_begin ] stop
 */

	
	/**
	 * [tAdvancedHash_row7 main ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row7";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row7"
						
						);
					}
					


			   
			   

					row7Struct row7_HashRow = new row7Struct();
		   	   	   
				
				row7_HashRow.id_moyen_paiement = row7.id_moyen_paiement;
				
				row7_HashRow.id_moyen_paiement_src = row7.id_moyen_paiement_src;
				
				row7_HashRow.code_moyen_paiement = row7.code_moyen_paiement;
				
				row7_HashRow.livelle_moyen_paiement = row7.livelle_moyen_paiement;
				
			tHash_Lookup_row7.put(row7_HashRow);
			
            




 


	tos_count_tAdvancedHash_row7++;

/**
 * [tAdvancedHash_row7 main ] stop
 */
	
	/**
	 * [tAdvancedHash_row7 process_data_begin ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row7";

	

 



/**
 * [tAdvancedHash_row7 process_data_begin ] stop
 */
	
	/**
	 * [tAdvancedHash_row7 process_data_end ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row7";

	

 



/**
 * [tAdvancedHash_row7 process_data_end ] stop
 */



	
	/**
	 * [tDBInput_6 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBInput_6";

	

 



/**
 * [tDBInput_6 process_data_end ] stop
 */
	
	/**
	 * [tDBInput_6 end ] start
	 */

	

	
	
	currentComponent="tDBInput_6";

	

	}
}finally{
	if (rs_tDBInput_6 != null) {
		rs_tDBInput_6.close();
	}
	if (stmt_tDBInput_6 != null) {
		stmt_tDBInput_6.close();
	}
	if(conn_tDBInput_6 != null && !conn_tDBInput_6.isClosed()) {
		
			conn_tDBInput_6.commit();
			
		
			conn_tDBInput_6.close();
			
			if("com.mysql.cj.jdbc.Driver".equals((String)globalMap.get("driverClass_"))
			    && routines.system.BundleUtils.inOSGi()) {
			        Class.forName("com.mysql.cj.jdbc.AbandonedConnectionCleanupThread").
			            getMethod("checkedShutdown").invoke(null, (Object[]) null);
			}
			
	}
	
}
globalMap.put("tDBInput_6_NB_LINE",nb_line_tDBInput_6);
 

ok_Hash.put("tDBInput_6", true);
end_Hash.put("tDBInput_6", System.currentTimeMillis());

tStatCatcher_1.addMessage("end","tDBInput_6", end_Hash.get("tDBInput_6")-start_Hash.get("tDBInput_6"));
tStatCatcher_1Process(globalMap);



/**
 * [tDBInput_6 end ] stop
 */

	
	/**
	 * [tAdvancedHash_row7 end ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row7";

	

tHash_Lookup_row7.endPut();

				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row7");
			  	}
			  	
 

ok_Hash.put("tAdvancedHash_row7", true);
end_Hash.put("tAdvancedHash_row7", System.currentTimeMillis());




/**
 * [tAdvancedHash_row7 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBInput_6 finally ] start
	 */

	

	
	
	currentComponent="tDBInput_6";

	

 



/**
 * [tDBInput_6 finally ] stop
 */

	
	/**
	 * [tAdvancedHash_row7 finally ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row7";

	

 



/**
 * [tAdvancedHash_row7 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBInput_6_SUBPROCESS_STATE", 1);
	}
	


public static class row8Struct implements routines.system.IPersistableComparableLookupRow<row8Struct> {
    final static byte[] commonByteArrayLock_ALIMENTATION_DM1_F_ALIM_FAIT = new byte[0];
    static byte[] commonByteArray_ALIMENTATION_DM1_F_ALIM_FAIT = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int id_preparation;

				public int getId_preparation () {
					return this.id_preparation;
				}
				
			    public Integer id_preparation_src;

				public Integer getId_preparation_src () {
					return this.id_preparation_src;
				}
				
			    public java.util.Date date_debut_preparation;

				public java.util.Date getDate_debut_preparation () {
					return this.date_debut_preparation;
				}
				
			    public java.util.Date date_fin_preparation;

				public java.util.Date getDate_fin_preparation () {
					return this.date_fin_preparation;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
						result = prime * result + ((this.id_preparation_src == null) ? 0 : this.id_preparation_src.hashCode());
					
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row8Struct other = (row8Struct) obj;
		
						if (this.id_preparation_src == null) {
							if (other.id_preparation_src != null)
								return false;
						
						} else if (!this.id_preparation_src.equals(other.id_preparation_src))
						
							return false;
					

		return true;
    }

	public void copyDataTo(row8Struct other) {

		other.id_preparation = this.id_preparation;
	            other.id_preparation_src = this.id_preparation_src;
	            other.date_debut_preparation = this.date_debut_preparation;
	            other.date_fin_preparation = this.date_fin_preparation;
	            
	}

	public void copyKeysDataTo(row8Struct other) {

		other.id_preparation_src = this.id_preparation_src;
	            	
	}



	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private java.util.Date readDate(DataInputStream dis, ObjectInputStream ois) throws IOException{
		java.util.Date dateReturn = null;
		int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(DataInputStream dis, org.jboss.marshalling.Unmarshaller unmarshaller ) throws IOException{
		java.util.Date dateReturn = null;
		int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

	private void writeDate(java.util.Date date1, DataOutputStream dos, ObjectOutputStream oos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
	}
	
	private void writeDate(java.util.Date date1, DataOutputStream dos, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
	}

    public void readKeysData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_DM1_F_ALIM_FAIT) {

        	try {

        		int length = 0;
		
						this.id_preparation_src = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readKeysData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_DM1_F_ALIM_FAIT) {

        	try {

        		int length = 0;
		
						this.id_preparation_src = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeKeysData(ObjectOutputStream dos) {
        try {

		
					// Integer
				
						writeInteger(this.id_preparation_src,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeKeysData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// Integer
				
						writeInteger(this.id_preparation_src,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }



    /**
     * Fill Values data by reading ObjectInputStream.
     */
    public void readValuesData(DataInputStream dis, ObjectInputStream ois) {
        try {

			int length = 0;
		
			            this.id_preparation = dis.readInt();
					
						this.date_debut_preparation = readDate(dis,ois);
					
						this.date_fin_preparation = readDate(dis,ois);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

    }
    
    public void readValuesData(DataInputStream dis, org.jboss.marshalling.Unmarshaller objectIn) {
        try {
			int length = 0;
		
			            this.id_preparation = objectIn.readInt();
					
						this.date_debut_preparation = readDate(dis,objectIn);
					
						this.date_fin_preparation = readDate(dis,objectIn);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

    }

    /**
     * Return a byte array which represents Values data.
     */
    public void writeValuesData(DataOutputStream dos, ObjectOutputStream oos) {
        try {

		
		            	dos.writeInt(this.id_preparation);
					
						writeDate(this.date_debut_preparation, dos, oos);
					
						writeDate(this.date_fin_preparation, dos, oos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        	}

    }
    
    public void writeValuesData(DataOutputStream dos, org.jboss.marshalling.Marshaller objectOut){
                try {

		
					objectOut.writeInt(this.id_preparation);
					
						writeDate(this.date_debut_preparation, dos, objectOut);
					
						writeDate(this.date_fin_preparation, dos, objectOut);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        	}
    }


    
    public boolean supportMarshaller(){
        return true;
    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id_preparation="+String.valueOf(id_preparation));
		sb.append(",id_preparation_src="+String.valueOf(id_preparation_src));
		sb.append(",date_debut_preparation="+String.valueOf(date_debut_preparation));
		sb.append(",date_fin_preparation="+String.valueOf(date_fin_preparation));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row8Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.id_preparation_src, other.id_preparation_src);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tDBInput_7Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBInput_7_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row8Struct row8 = new row8Struct();




	
	/**
	 * [tAdvancedHash_row8 begin ] start
	 */

	

	
		
		ok_Hash.put("tAdvancedHash_row8", false);
		start_Hash.put("tAdvancedHash_row8", System.currentTimeMillis());
		
	
	currentComponent="tAdvancedHash_row8";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row8");
					}
				
		int tos_count_tAdvancedHash_row8 = 0;
		

			   		// connection name:row8
			   		// source node:tDBInput_7 - inputs:(after_tDBInput_1) outputs:(row8,row8) | target node:tAdvancedHash_row8 - inputs:(row8) outputs:()
			   		// linked node: tMap_1 - inputs:(row2,row3,row4,row5,row6,row7,row8,row9,row10,row11) outputs:(alim_fait)
			   
			   		org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE matchingModeEnum_row8 = 
			   			org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE.UNIQUE_MATCH;
			   			
			   
	   			org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row8Struct> tHash_Lookup_row8 =org.talend.designer.components.lookup.memory.AdvancedMemoryLookup.
	   						<row8Struct>getLookup(matchingModeEnum_row8);
	   						   
		   	   	   globalMap.put("tHash_Lookup_row8", tHash_Lookup_row8);
		   	   	   
				
           

 



/**
 * [tAdvancedHash_row8 begin ] stop
 */



	
	/**
	 * [tDBInput_7 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBInput_7", false);
		start_Hash.put("tDBInput_7", System.currentTimeMillis());
		
				tStatCatcher_1.addMessage("begin","tDBInput_7");
				tStatCatcher_1Process(globalMap);
			
	
	currentComponent="tDBInput_7";

	
		int tos_count_tDBInput_7 = 0;
		
	
    
	
		    int nb_line_tDBInput_7 = 0;
		    java.sql.Connection conn_tDBInput_7 = null;
				String driverClass_tDBInput_7 = "org.postgresql.Driver";
			    java.lang.Class jdbcclazz_tDBInput_7 = java.lang.Class.forName(driverClass_tDBInput_7);
				String dbUser_tDBInput_7 = "dsid_cc2_tos_rw";
				
				 
	final String decryptedPassword_tDBInput_7 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:SbU36pLozlI9lIeg+EwCC1haLuw8hcDgU4boFKwfUNk=");
				
				String dbPwd_tDBInput_7 = decryptedPassword_tDBInput_7;
				
				String url_tDBInput_7 = "jdbc:postgresql://" + "" + ":" + "5432" + "/" + "postgres";
				
				conn_tDBInput_7 = java.sql.DriverManager.getConnection(url_tDBInput_7,dbUser_tDBInput_7,dbPwd_tDBInput_7);
		        
				conn_tDBInput_7.setAutoCommit(false);
			
		    
			java.sql.Statement stmt_tDBInput_7 = conn_tDBInput_7.createStatement();

		    String dbquery_tDBInput_7 = "SELECT \n  \"dsid_liv_dm1\".\"dim_preparation_d\".\"id_preparation\", \n  \"dsid_liv_dm1\".\"dim_preparation_d\".\"id_pre"
+"paration_src\", \n  \"dsid_liv_dm1\".\"dim_preparation_d\".\"date_debut_preparation\", \n  \"dsid_liv_dm1\".\"dim_preparat"
+"ion_d\".\"date_fin_preparation\"\nFROM \"dsid_liv_dm1\".\"dim_preparation_d\"";
		    

            	globalMap.put("tDBInput_7_QUERY",dbquery_tDBInput_7);
		    java.sql.ResultSet rs_tDBInput_7 = null;

		    try {
		    	rs_tDBInput_7 = stmt_tDBInput_7.executeQuery(dbquery_tDBInput_7);
		    	java.sql.ResultSetMetaData rsmd_tDBInput_7 = rs_tDBInput_7.getMetaData();
		    	int colQtyInRs_tDBInput_7 = rsmd_tDBInput_7.getColumnCount();

		    String tmpContent_tDBInput_7 = null;
		    
		    
		    while (rs_tDBInput_7.next()) {
		        nb_line_tDBInput_7++;
		        
							if(colQtyInRs_tDBInput_7 < 1) {
								row8.id_preparation = 0;
							} else {
		                          
            row8.id_preparation = rs_tDBInput_7.getInt(1);
            if(rs_tDBInput_7.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_7 < 2) {
								row8.id_preparation_src = null;
							} else {
		                          
            row8.id_preparation_src = rs_tDBInput_7.getInt(2);
            if(rs_tDBInput_7.wasNull()){
                    row8.id_preparation_src = null;
            }
		                    }
							if(colQtyInRs_tDBInput_7 < 3) {
								row8.date_debut_preparation = null;
							} else {
										
			row8.date_debut_preparation = routines.system.JDBCUtil.getDate(rs_tDBInput_7, 3);
		                    }
							if(colQtyInRs_tDBInput_7 < 4) {
								row8.date_fin_preparation = null;
							} else {
										
			row8.date_fin_preparation = routines.system.JDBCUtil.getDate(rs_tDBInput_7, 4);
		                    }
					


 



/**
 * [tDBInput_7 begin ] stop
 */
	
	/**
	 * [tDBInput_7 main ] start
	 */

	

	
	
	currentComponent="tDBInput_7";

	

 


	tos_count_tDBInput_7++;

/**
 * [tDBInput_7 main ] stop
 */
	
	/**
	 * [tDBInput_7 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBInput_7";

	

 



/**
 * [tDBInput_7 process_data_begin ] stop
 */

	
	/**
	 * [tAdvancedHash_row8 main ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row8";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row8"
						
						);
					}
					


			   
			   

					row8Struct row8_HashRow = new row8Struct();
		   	   	   
				
				row8_HashRow.id_preparation = row8.id_preparation;
				
				row8_HashRow.id_preparation_src = row8.id_preparation_src;
				
				row8_HashRow.date_debut_preparation = row8.date_debut_preparation;
				
				row8_HashRow.date_fin_preparation = row8.date_fin_preparation;
				
			tHash_Lookup_row8.put(row8_HashRow);
			
            




 


	tos_count_tAdvancedHash_row8++;

/**
 * [tAdvancedHash_row8 main ] stop
 */
	
	/**
	 * [tAdvancedHash_row8 process_data_begin ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row8";

	

 



/**
 * [tAdvancedHash_row8 process_data_begin ] stop
 */
	
	/**
	 * [tAdvancedHash_row8 process_data_end ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row8";

	

 



/**
 * [tAdvancedHash_row8 process_data_end ] stop
 */



	
	/**
	 * [tDBInput_7 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBInput_7";

	

 



/**
 * [tDBInput_7 process_data_end ] stop
 */
	
	/**
	 * [tDBInput_7 end ] start
	 */

	

	
	
	currentComponent="tDBInput_7";

	

	}
}finally{
	if (rs_tDBInput_7 != null) {
		rs_tDBInput_7.close();
	}
	if (stmt_tDBInput_7 != null) {
		stmt_tDBInput_7.close();
	}
	if(conn_tDBInput_7 != null && !conn_tDBInput_7.isClosed()) {
		
			conn_tDBInput_7.commit();
			
		
			conn_tDBInput_7.close();
			
			if("com.mysql.cj.jdbc.Driver".equals((String)globalMap.get("driverClass_"))
			    && routines.system.BundleUtils.inOSGi()) {
			        Class.forName("com.mysql.cj.jdbc.AbandonedConnectionCleanupThread").
			            getMethod("checkedShutdown").invoke(null, (Object[]) null);
			}
			
	}
	
}
globalMap.put("tDBInput_7_NB_LINE",nb_line_tDBInput_7);
 

ok_Hash.put("tDBInput_7", true);
end_Hash.put("tDBInput_7", System.currentTimeMillis());

tStatCatcher_1.addMessage("end","tDBInput_7", end_Hash.get("tDBInput_7")-start_Hash.get("tDBInput_7"));
tStatCatcher_1Process(globalMap);



/**
 * [tDBInput_7 end ] stop
 */

	
	/**
	 * [tAdvancedHash_row8 end ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row8";

	

tHash_Lookup_row8.endPut();

				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row8");
			  	}
			  	
 

ok_Hash.put("tAdvancedHash_row8", true);
end_Hash.put("tAdvancedHash_row8", System.currentTimeMillis());




/**
 * [tAdvancedHash_row8 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBInput_7 finally ] start
	 */

	

	
	
	currentComponent="tDBInput_7";

	

 



/**
 * [tDBInput_7 finally ] stop
 */

	
	/**
	 * [tAdvancedHash_row8 finally ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row8";

	

 



/**
 * [tAdvancedHash_row8 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBInput_7_SUBPROCESS_STATE", 1);
	}
	


public static class row9Struct implements routines.system.IPersistableComparableLookupRow<row9Struct> {
    final static byte[] commonByteArrayLock_ALIMENTATION_DM1_F_ALIM_FAIT = new byte[0];
    static byte[] commonByteArray_ALIMENTATION_DM1_F_ALIM_FAIT = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int id_restaurant;

				public int getId_restaurant () {
					return this.id_restaurant;
				}
				
			    public Integer id_restaurant_src;

				public Integer getId_restaurant_src () {
					return this.id_restaurant_src;
				}
				
			    public String code_restaurant;

				public String getCode_restaurant () {
					return this.code_restaurant;
				}
				
			    public String raison_sociale_restaurant;

				public String getRaison_sociale_restaurant () {
					return this.raison_sociale_restaurant;
				}
				
			    public java.util.Date scd_start;

				public java.util.Date getScd_start () {
					return this.scd_start;
				}
				
			    public java.util.Date scd_end;

				public java.util.Date getScd_end () {
					return this.scd_end;
				}
				
			    public Integer scd_version;

				public Integer getScd_version () {
					return this.scd_version;
				}
				
			    public String scd_active;

				public String getScd_active () {
					return this.scd_active;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
						result = prime * result + ((this.id_restaurant_src == null) ? 0 : this.id_restaurant_src.hashCode());
					
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row9Struct other = (row9Struct) obj;
		
						if (this.id_restaurant_src == null) {
							if (other.id_restaurant_src != null)
								return false;
						
						} else if (!this.id_restaurant_src.equals(other.id_restaurant_src))
						
							return false;
					

		return true;
    }

	public void copyDataTo(row9Struct other) {

		other.id_restaurant = this.id_restaurant;
	            other.id_restaurant_src = this.id_restaurant_src;
	            other.code_restaurant = this.code_restaurant;
	            other.raison_sociale_restaurant = this.raison_sociale_restaurant;
	            other.scd_start = this.scd_start;
	            other.scd_end = this.scd_end;
	            other.scd_version = this.scd_version;
	            other.scd_active = this.scd_active;
	            
	}

	public void copyKeysDataTo(row9Struct other) {

		other.id_restaurant_src = this.id_restaurant_src;
	            	
	}



	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}
	
	private String readString(DataInputStream dis, ObjectInputStream ois) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			byte[] byteArray = new byte[length];
			dis.read(byteArray);
			strReturn = new String(byteArray, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(DataInputStream dis, org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			byte[] byteArray = new byte[length];
			unmarshaller.read(byteArray);
			strReturn = new String(byteArray, utf8Charset);
		}
		return strReturn;
	}
	
	private void writeString(String str, DataOutputStream dos, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
	}

	private void writeString(String str, DataOutputStream dos, ObjectOutputStream oos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
	}

	private java.util.Date readDate(DataInputStream dis, ObjectInputStream ois) throws IOException{
		java.util.Date dateReturn = null;
		int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(DataInputStream dis, org.jboss.marshalling.Unmarshaller unmarshaller ) throws IOException{
		java.util.Date dateReturn = null;
		int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

	private void writeDate(java.util.Date date1, DataOutputStream dos, ObjectOutputStream oos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
	}
	
	private void writeDate(java.util.Date date1, DataOutputStream dos, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
	}
	private Integer readInteger(DataInputStream dis, ObjectInputStream ois) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
			intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(DataInputStream dis, org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		Integer intReturn;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
			intReturn = unmarshaller.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, DataOutputStream dos, ObjectOutputStream oos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, DataOutputStream dos,org.jboss.marshalling.Marshaller marshaller ) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

    public void readKeysData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_DM1_F_ALIM_FAIT) {

        	try {

        		int length = 0;
		
						this.id_restaurant_src = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readKeysData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_DM1_F_ALIM_FAIT) {

        	try {

        		int length = 0;
		
						this.id_restaurant_src = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeKeysData(ObjectOutputStream dos) {
        try {

		
					// Integer
				
						writeInteger(this.id_restaurant_src,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeKeysData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// Integer
				
						writeInteger(this.id_restaurant_src,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }



    /**
     * Fill Values data by reading ObjectInputStream.
     */
    public void readValuesData(DataInputStream dis, ObjectInputStream ois) {
        try {

			int length = 0;
		
			            this.id_restaurant = dis.readInt();
					
						this.code_restaurant = readString(dis,ois);
					
						this.raison_sociale_restaurant = readString(dis,ois);
					
						this.scd_start = readDate(dis,ois);
					
						this.scd_end = readDate(dis,ois);
					
						this.scd_version = readInteger(dis,ois);
					
						this.scd_active = readString(dis,ois);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

    }
    
    public void readValuesData(DataInputStream dis, org.jboss.marshalling.Unmarshaller objectIn) {
        try {
			int length = 0;
		
			            this.id_restaurant = objectIn.readInt();
					
						this.code_restaurant = readString(dis,objectIn);
					
						this.raison_sociale_restaurant = readString(dis,objectIn);
					
						this.scd_start = readDate(dis,objectIn);
					
						this.scd_end = readDate(dis,objectIn);
					
						this.scd_version = readInteger(dis,objectIn);
					
						this.scd_active = readString(dis,objectIn);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

    }

    /**
     * Return a byte array which represents Values data.
     */
    public void writeValuesData(DataOutputStream dos, ObjectOutputStream oos) {
        try {

		
		            	dos.writeInt(this.id_restaurant);
					
						writeString(this.code_restaurant, dos, oos);
					
						writeString(this.raison_sociale_restaurant, dos, oos);
					
						writeDate(this.scd_start, dos, oos);
					
						writeDate(this.scd_end, dos, oos);
					
					writeInteger(this.scd_version, dos, oos);
					
						writeString(this.scd_active, dos, oos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        	}

    }
    
    public void writeValuesData(DataOutputStream dos, org.jboss.marshalling.Marshaller objectOut){
                try {

		
					objectOut.writeInt(this.id_restaurant);
					
						writeString(this.code_restaurant, dos, objectOut);
					
						writeString(this.raison_sociale_restaurant, dos, objectOut);
					
						writeDate(this.scd_start, dos, objectOut);
					
						writeDate(this.scd_end, dos, objectOut);
					
					writeInteger(this.scd_version, dos, objectOut);
					
						writeString(this.scd_active, dos, objectOut);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        	}
    }


    
    public boolean supportMarshaller(){
        return true;
    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id_restaurant="+String.valueOf(id_restaurant));
		sb.append(",id_restaurant_src="+String.valueOf(id_restaurant_src));
		sb.append(",code_restaurant="+code_restaurant);
		sb.append(",raison_sociale_restaurant="+raison_sociale_restaurant);
		sb.append(",scd_start="+String.valueOf(scd_start));
		sb.append(",scd_end="+String.valueOf(scd_end));
		sb.append(",scd_version="+String.valueOf(scd_version));
		sb.append(",scd_active="+scd_active);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row9Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.id_restaurant_src, other.id_restaurant_src);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tDBInput_8Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBInput_8_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row9Struct row9 = new row9Struct();




	
	/**
	 * [tAdvancedHash_row9 begin ] start
	 */

	

	
		
		ok_Hash.put("tAdvancedHash_row9", false);
		start_Hash.put("tAdvancedHash_row9", System.currentTimeMillis());
		
	
	currentComponent="tAdvancedHash_row9";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row9");
					}
				
		int tos_count_tAdvancedHash_row9 = 0;
		

			   		// connection name:row9
			   		// source node:tDBInput_8 - inputs:(after_tDBInput_1) outputs:(row9,row9) | target node:tAdvancedHash_row9 - inputs:(row9) outputs:()
			   		// linked node: tMap_1 - inputs:(row2,row3,row4,row5,row6,row7,row8,row9,row10,row11) outputs:(alim_fait)
			   
			   		org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE matchingModeEnum_row9 = 
			   			org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE.UNIQUE_MATCH;
			   			
			   
	   			org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row9Struct> tHash_Lookup_row9 =org.talend.designer.components.lookup.memory.AdvancedMemoryLookup.
	   						<row9Struct>getLookup(matchingModeEnum_row9);
	   						   
		   	   	   globalMap.put("tHash_Lookup_row9", tHash_Lookup_row9);
		   	   	   
				
           

 



/**
 * [tAdvancedHash_row9 begin ] stop
 */



	
	/**
	 * [tDBInput_8 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBInput_8", false);
		start_Hash.put("tDBInput_8", System.currentTimeMillis());
		
	
	currentComponent="tDBInput_8";

	
		int tos_count_tDBInput_8 = 0;
		
	
    
	
		    int nb_line_tDBInput_8 = 0;
		    java.sql.Connection conn_tDBInput_8 = null;
				String driverClass_tDBInput_8 = "org.postgresql.Driver";
			    java.lang.Class jdbcclazz_tDBInput_8 = java.lang.Class.forName(driverClass_tDBInput_8);
				String dbUser_tDBInput_8 = "dsid_cc2_tos_rw";
				
				 
	final String decryptedPassword_tDBInput_8 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:1N2tB5PfL0rI2hvCug1p5oMRKt7Z3CGNS2ao5xiWSEU=");
				
				String dbPwd_tDBInput_8 = decryptedPassword_tDBInput_8;
				
				String url_tDBInput_8 = "jdbc:postgresql://" + "" + ":" + "5432" + "/" + "postgres";
				
				conn_tDBInput_8 = java.sql.DriverManager.getConnection(url_tDBInput_8,dbUser_tDBInput_8,dbPwd_tDBInput_8);
		        
				conn_tDBInput_8.setAutoCommit(false);
			
		    
			java.sql.Statement stmt_tDBInput_8 = conn_tDBInput_8.createStatement();

		    String dbquery_tDBInput_8 = "SELECT \n  \"dsid_liv_dm1\".\"dim_restaurant_d\".\"id_restaurant\", \n  \"dsid_liv_dm1\".\"dim_restaurant_d\".\"id_restau"
+"rant_src\", \n  \"dsid_liv_dm1\".\"dim_restaurant_d\".\"code_restaurant\", \n  \"dsid_liv_dm1\".\"dim_restaurant_d\".\"rai"
+"son_sociale_restaurant\", \n  \"dsid_liv_dm1\".\"dim_restaurant_d\".\"scd_start\", \n  \"dsid_liv_dm1\".\"dim_restaurant_d"
+"\".\"scd_end\", \n  \"dsid_liv_dm1\".\"dim_restaurant_d\".\"scd_version\", \n  \"dsid_liv_dm1\".\"dim_restaurant_d\".\"scd"
+"_active\"\nFROM \"dsid_liv_dm1\".\"dim_restaurant_d\"";
		    

            	globalMap.put("tDBInput_8_QUERY",dbquery_tDBInput_8);
		    java.sql.ResultSet rs_tDBInput_8 = null;

		    try {
		    	rs_tDBInput_8 = stmt_tDBInput_8.executeQuery(dbquery_tDBInput_8);
		    	java.sql.ResultSetMetaData rsmd_tDBInput_8 = rs_tDBInput_8.getMetaData();
		    	int colQtyInRs_tDBInput_8 = rsmd_tDBInput_8.getColumnCount();

		    String tmpContent_tDBInput_8 = null;
		    
		    
		    while (rs_tDBInput_8.next()) {
		        nb_line_tDBInput_8++;
		        
							if(colQtyInRs_tDBInput_8 < 1) {
								row9.id_restaurant = 0;
							} else {
		                          
            row9.id_restaurant = rs_tDBInput_8.getInt(1);
            if(rs_tDBInput_8.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_8 < 2) {
								row9.id_restaurant_src = null;
							} else {
		                          
            row9.id_restaurant_src = rs_tDBInput_8.getInt(2);
            if(rs_tDBInput_8.wasNull()){
                    row9.id_restaurant_src = null;
            }
		                    }
							if(colQtyInRs_tDBInput_8 < 3) {
								row9.code_restaurant = null;
							} else {
	                         		
        	row9.code_restaurant = routines.system.JDBCUtil.getString(rs_tDBInput_8, 3, false);
		                    }
							if(colQtyInRs_tDBInput_8 < 4) {
								row9.raison_sociale_restaurant = null;
							} else {
	                         		
        	row9.raison_sociale_restaurant = routines.system.JDBCUtil.getString(rs_tDBInput_8, 4, false);
		                    }
							if(colQtyInRs_tDBInput_8 < 5) {
								row9.scd_start = null;
							} else {
										
			row9.scd_start = routines.system.JDBCUtil.getDate(rs_tDBInput_8, 5);
		                    }
							if(colQtyInRs_tDBInput_8 < 6) {
								row9.scd_end = null;
							} else {
										
			row9.scd_end = routines.system.JDBCUtil.getDate(rs_tDBInput_8, 6);
		                    }
							if(colQtyInRs_tDBInput_8 < 7) {
								row9.scd_version = null;
							} else {
		                          
            row9.scd_version = rs_tDBInput_8.getInt(7);
            if(rs_tDBInput_8.wasNull()){
                    row9.scd_version = null;
            }
		                    }
							if(colQtyInRs_tDBInput_8 < 8) {
								row9.scd_active = null;
							} else {
	                         		
        	row9.scd_active = routines.system.JDBCUtil.getString(rs_tDBInput_8, 8, false);
		                    }
					


 



/**
 * [tDBInput_8 begin ] stop
 */
	
	/**
	 * [tDBInput_8 main ] start
	 */

	

	
	
	currentComponent="tDBInput_8";

	

 


	tos_count_tDBInput_8++;

/**
 * [tDBInput_8 main ] stop
 */
	
	/**
	 * [tDBInput_8 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBInput_8";

	

 



/**
 * [tDBInput_8 process_data_begin ] stop
 */

	
	/**
	 * [tAdvancedHash_row9 main ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row9";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row9"
						
						);
					}
					


			   
			   

					row9Struct row9_HashRow = new row9Struct();
		   	   	   
				
				row9_HashRow.id_restaurant = row9.id_restaurant;
				
				row9_HashRow.id_restaurant_src = row9.id_restaurant_src;
				
				row9_HashRow.code_restaurant = row9.code_restaurant;
				
				row9_HashRow.raison_sociale_restaurant = row9.raison_sociale_restaurant;
				
				row9_HashRow.scd_start = row9.scd_start;
				
				row9_HashRow.scd_end = row9.scd_end;
				
				row9_HashRow.scd_version = row9.scd_version;
				
				row9_HashRow.scd_active = row9.scd_active;
				
			tHash_Lookup_row9.put(row9_HashRow);
			
            




 


	tos_count_tAdvancedHash_row9++;

/**
 * [tAdvancedHash_row9 main ] stop
 */
	
	/**
	 * [tAdvancedHash_row9 process_data_begin ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row9";

	

 



/**
 * [tAdvancedHash_row9 process_data_begin ] stop
 */
	
	/**
	 * [tAdvancedHash_row9 process_data_end ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row9";

	

 



/**
 * [tAdvancedHash_row9 process_data_end ] stop
 */



	
	/**
	 * [tDBInput_8 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBInput_8";

	

 



/**
 * [tDBInput_8 process_data_end ] stop
 */
	
	/**
	 * [tDBInput_8 end ] start
	 */

	

	
	
	currentComponent="tDBInput_8";

	

	}
}finally{
	if (rs_tDBInput_8 != null) {
		rs_tDBInput_8.close();
	}
	if (stmt_tDBInput_8 != null) {
		stmt_tDBInput_8.close();
	}
	if(conn_tDBInput_8 != null && !conn_tDBInput_8.isClosed()) {
		
			conn_tDBInput_8.commit();
			
		
			conn_tDBInput_8.close();
			
			if("com.mysql.cj.jdbc.Driver".equals((String)globalMap.get("driverClass_"))
			    && routines.system.BundleUtils.inOSGi()) {
			        Class.forName("com.mysql.cj.jdbc.AbandonedConnectionCleanupThread").
			            getMethod("checkedShutdown").invoke(null, (Object[]) null);
			}
			
	}
	
}
globalMap.put("tDBInput_8_NB_LINE",nb_line_tDBInput_8);
 

ok_Hash.put("tDBInput_8", true);
end_Hash.put("tDBInput_8", System.currentTimeMillis());




/**
 * [tDBInput_8 end ] stop
 */

	
	/**
	 * [tAdvancedHash_row9 end ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row9";

	

tHash_Lookup_row9.endPut();

				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row9");
			  	}
			  	
 

ok_Hash.put("tAdvancedHash_row9", true);
end_Hash.put("tAdvancedHash_row9", System.currentTimeMillis());




/**
 * [tAdvancedHash_row9 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBInput_8 finally ] start
	 */

	

	
	
	currentComponent="tDBInput_8";

	

 



/**
 * [tDBInput_8 finally ] stop
 */

	
	/**
	 * [tAdvancedHash_row9 finally ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row9";

	

 



/**
 * [tAdvancedHash_row9 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBInput_8_SUBPROCESS_STATE", 1);
	}
	


public static class row10Struct implements routines.system.IPersistableComparableLookupRow<row10Struct> {
    final static byte[] commonByteArrayLock_ALIMENTATION_DM1_F_ALIM_FAIT = new byte[0];
    static byte[] commonByteArray_ALIMENTATION_DM1_F_ALIM_FAIT = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int id_menu;

				public int getId_menu () {
					return this.id_menu;
				}
				
			    public Integer id_menu_src;

				public Integer getId_menu_src () {
					return this.id_menu_src;
				}
				
			    public String code_menu;

				public String getCode_menu () {
					return this.code_menu;
				}
				
			    public String libelle_menu;

				public String getLibelle_menu () {
					return this.libelle_menu;
				}
				
			    public Integer nombre_articles;

				public Integer getNombre_articles () {
					return this.nombre_articles;
				}
				
			    public BigDecimal temps_theo_preparation;

				public BigDecimal getTemps_theo_preparation () {
					return this.temps_theo_preparation;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
						result = prime * result + ((this.id_menu_src == null) ? 0 : this.id_menu_src.hashCode());
					
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row10Struct other = (row10Struct) obj;
		
						if (this.id_menu_src == null) {
							if (other.id_menu_src != null)
								return false;
						
						} else if (!this.id_menu_src.equals(other.id_menu_src))
						
							return false;
					

		return true;
    }

	public void copyDataTo(row10Struct other) {

		other.id_menu = this.id_menu;
	            other.id_menu_src = this.id_menu_src;
	            other.code_menu = this.code_menu;
	            other.libelle_menu = this.libelle_menu;
	            other.nombre_articles = this.nombre_articles;
	            other.temps_theo_preparation = this.temps_theo_preparation;
	            
	}

	public void copyKeysDataTo(row10Struct other) {

		other.id_menu_src = this.id_menu_src;
	            	
	}



	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}
	
	private String readString(DataInputStream dis, ObjectInputStream ois) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			byte[] byteArray = new byte[length];
			dis.read(byteArray);
			strReturn = new String(byteArray, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(DataInputStream dis, org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			byte[] byteArray = new byte[length];
			unmarshaller.read(byteArray);
			strReturn = new String(byteArray, utf8Charset);
		}
		return strReturn;
	}
	
	private void writeString(String str, DataOutputStream dos, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
	}

	private void writeString(String str, DataOutputStream dos, ObjectOutputStream oos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
	}
	private Integer readInteger(DataInputStream dis, ObjectInputStream ois) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
			intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(DataInputStream dis, org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		Integer intReturn;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
			intReturn = unmarshaller.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, DataOutputStream dos, ObjectOutputStream oos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, DataOutputStream dos,org.jboss.marshalling.Marshaller marshaller ) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

    public void readKeysData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_DM1_F_ALIM_FAIT) {

        	try {

        		int length = 0;
		
						this.id_menu_src = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readKeysData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_DM1_F_ALIM_FAIT) {

        	try {

        		int length = 0;
		
						this.id_menu_src = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeKeysData(ObjectOutputStream dos) {
        try {

		
					// Integer
				
						writeInteger(this.id_menu_src,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeKeysData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// Integer
				
						writeInteger(this.id_menu_src,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }



    /**
     * Fill Values data by reading ObjectInputStream.
     */
    public void readValuesData(DataInputStream dis, ObjectInputStream ois) {
        try {

			int length = 0;
		
			            this.id_menu = dis.readInt();
					
						this.code_menu = readString(dis,ois);
					
						this.libelle_menu = readString(dis,ois);
					
						this.nombre_articles = readInteger(dis,ois);
					
       			    	this.temps_theo_preparation = (BigDecimal) ois.readObject();
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

    }
    
    public void readValuesData(DataInputStream dis, org.jboss.marshalling.Unmarshaller objectIn) {
        try {
			int length = 0;
		
			            this.id_menu = objectIn.readInt();
					
						this.code_menu = readString(dis,objectIn);
					
						this.libelle_menu = readString(dis,objectIn);
					
						this.nombre_articles = readInteger(dis,objectIn);
					
       			    	this.temps_theo_preparation = (BigDecimal) objectIn.readObject();
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

    }

    /**
     * Return a byte array which represents Values data.
     */
    public void writeValuesData(DataOutputStream dos, ObjectOutputStream oos) {
        try {

		
		            	dos.writeInt(this.id_menu);
					
						writeString(this.code_menu, dos, oos);
					
						writeString(this.libelle_menu, dos, oos);
					
					writeInteger(this.nombre_articles, dos, oos);
					
       			    	oos.writeObject(this.temps_theo_preparation);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        	}

    }
    
    public void writeValuesData(DataOutputStream dos, org.jboss.marshalling.Marshaller objectOut){
                try {

		
					objectOut.writeInt(this.id_menu);
					
						writeString(this.code_menu, dos, objectOut);
					
						writeString(this.libelle_menu, dos, objectOut);
					
					writeInteger(this.nombre_articles, dos, objectOut);
					
       			    	objectOut.writeObject(this.temps_theo_preparation);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        	}
    }


    
    public boolean supportMarshaller(){
        return true;
    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id_menu="+String.valueOf(id_menu));
		sb.append(",id_menu_src="+String.valueOf(id_menu_src));
		sb.append(",code_menu="+code_menu);
		sb.append(",libelle_menu="+libelle_menu);
		sb.append(",nombre_articles="+String.valueOf(nombre_articles));
		sb.append(",temps_theo_preparation="+String.valueOf(temps_theo_preparation));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row10Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.id_menu_src, other.id_menu_src);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tDBInput_9Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBInput_9_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row10Struct row10 = new row10Struct();




	
	/**
	 * [tAdvancedHash_row10 begin ] start
	 */

	

	
		
		ok_Hash.put("tAdvancedHash_row10", false);
		start_Hash.put("tAdvancedHash_row10", System.currentTimeMillis());
		
	
	currentComponent="tAdvancedHash_row10";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row10");
					}
				
		int tos_count_tAdvancedHash_row10 = 0;
		

			   		// connection name:row10
			   		// source node:tDBInput_9 - inputs:(after_tDBInput_1) outputs:(row10,row10) | target node:tAdvancedHash_row10 - inputs:(row10) outputs:()
			   		// linked node: tMap_1 - inputs:(row2,row3,row4,row5,row6,row7,row8,row9,row10,row11) outputs:(alim_fait)
			   
			   		org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE matchingModeEnum_row10 = 
			   			org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE.UNIQUE_MATCH;
			   			
			   
	   			org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row10Struct> tHash_Lookup_row10 =org.talend.designer.components.lookup.memory.AdvancedMemoryLookup.
	   						<row10Struct>getLookup(matchingModeEnum_row10);
	   						   
		   	   	   globalMap.put("tHash_Lookup_row10", tHash_Lookup_row10);
		   	   	   
				
           

 



/**
 * [tAdvancedHash_row10 begin ] stop
 */



	
	/**
	 * [tDBInput_9 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBInput_9", false);
		start_Hash.put("tDBInput_9", System.currentTimeMillis());
		
				tStatCatcher_1.addMessage("begin","tDBInput_9");
				tStatCatcher_1Process(globalMap);
			
	
	currentComponent="tDBInput_9";

	
		int tos_count_tDBInput_9 = 0;
		
	
    
	
		    int nb_line_tDBInput_9 = 0;
		    java.sql.Connection conn_tDBInput_9 = null;
				String driverClass_tDBInput_9 = "org.postgresql.Driver";
			    java.lang.Class jdbcclazz_tDBInput_9 = java.lang.Class.forName(driverClass_tDBInput_9);
				String dbUser_tDBInput_9 = "dsid_cc2_tos_rw";
				
				 
	final String decryptedPassword_tDBInput_9 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:Xw5qkthRcC5sJEaLjtVDGb0y41KPgJDR3R9+G5rlS9c=");
				
				String dbPwd_tDBInput_9 = decryptedPassword_tDBInput_9;
				
				String url_tDBInput_9 = "jdbc:postgresql://" + "" + ":" + "5432" + "/" + "postgres";
				
				conn_tDBInput_9 = java.sql.DriverManager.getConnection(url_tDBInput_9,dbUser_tDBInput_9,dbPwd_tDBInput_9);
		        
				conn_tDBInput_9.setAutoCommit(false);
			
		    
			java.sql.Statement stmt_tDBInput_9 = conn_tDBInput_9.createStatement();

		    String dbquery_tDBInput_9 = "SELECT \n  \"dsid_liv_dm1\".\"dim_menu_d\".\"id_menu\", \n  \"dsid_liv_dm1\".\"dim_menu_d\".\"id_menu_src\", \n  \"dsid_li"
+"v_dm1\".\"dim_menu_d\".\"code_menu\", \n  \"dsid_liv_dm1\".\"dim_menu_d\".\"libelle_menu\", \n  \"dsid_liv_dm1\".\"dim_men"
+"u_d\".\"nombre_articles\", \n  \"dsid_liv_dm1\".\"dim_menu_d\".\"temps_theo_preparation\"\nFROM \"dsid_liv_dm1\".\"dim_men"
+"u_d\"";
		    

            	globalMap.put("tDBInput_9_QUERY",dbquery_tDBInput_9);
		    java.sql.ResultSet rs_tDBInput_9 = null;

		    try {
		    	rs_tDBInput_9 = stmt_tDBInput_9.executeQuery(dbquery_tDBInput_9);
		    	java.sql.ResultSetMetaData rsmd_tDBInput_9 = rs_tDBInput_9.getMetaData();
		    	int colQtyInRs_tDBInput_9 = rsmd_tDBInput_9.getColumnCount();

		    String tmpContent_tDBInput_9 = null;
		    
		    
		    while (rs_tDBInput_9.next()) {
		        nb_line_tDBInput_9++;
		        
							if(colQtyInRs_tDBInput_9 < 1) {
								row10.id_menu = 0;
							} else {
		                          
            row10.id_menu = rs_tDBInput_9.getInt(1);
            if(rs_tDBInput_9.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_9 < 2) {
								row10.id_menu_src = null;
							} else {
		                          
            row10.id_menu_src = rs_tDBInput_9.getInt(2);
            if(rs_tDBInput_9.wasNull()){
                    row10.id_menu_src = null;
            }
		                    }
							if(colQtyInRs_tDBInput_9 < 3) {
								row10.code_menu = null;
							} else {
	                         		
        	row10.code_menu = routines.system.JDBCUtil.getString(rs_tDBInput_9, 3, false);
		                    }
							if(colQtyInRs_tDBInput_9 < 4) {
								row10.libelle_menu = null;
							} else {
	                         		
        	row10.libelle_menu = routines.system.JDBCUtil.getString(rs_tDBInput_9, 4, false);
		                    }
							if(colQtyInRs_tDBInput_9 < 5) {
								row10.nombre_articles = null;
							} else {
		                          
            row10.nombre_articles = rs_tDBInput_9.getInt(5);
            if(rs_tDBInput_9.wasNull()){
                    row10.nombre_articles = null;
            }
		                    }
							if(colQtyInRs_tDBInput_9 < 6) {
								row10.temps_theo_preparation = null;
							} else {
		                          
            row10.temps_theo_preparation = rs_tDBInput_9.getBigDecimal(6);
            if(rs_tDBInput_9.wasNull()){
                    row10.temps_theo_preparation = null;
            }
		                    }
					


 



/**
 * [tDBInput_9 begin ] stop
 */
	
	/**
	 * [tDBInput_9 main ] start
	 */

	

	
	
	currentComponent="tDBInput_9";

	

 


	tos_count_tDBInput_9++;

/**
 * [tDBInput_9 main ] stop
 */
	
	/**
	 * [tDBInput_9 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBInput_9";

	

 



/**
 * [tDBInput_9 process_data_begin ] stop
 */

	
	/**
	 * [tAdvancedHash_row10 main ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row10";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row10"
						
						);
					}
					


			   
			   

					row10Struct row10_HashRow = new row10Struct();
		   	   	   
				
				row10_HashRow.id_menu = row10.id_menu;
				
				row10_HashRow.id_menu_src = row10.id_menu_src;
				
				row10_HashRow.code_menu = row10.code_menu;
				
				row10_HashRow.libelle_menu = row10.libelle_menu;
				
				row10_HashRow.nombre_articles = row10.nombre_articles;
				
				row10_HashRow.temps_theo_preparation = row10.temps_theo_preparation;
				
			tHash_Lookup_row10.put(row10_HashRow);
			
            




 


	tos_count_tAdvancedHash_row10++;

/**
 * [tAdvancedHash_row10 main ] stop
 */
	
	/**
	 * [tAdvancedHash_row10 process_data_begin ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row10";

	

 



/**
 * [tAdvancedHash_row10 process_data_begin ] stop
 */
	
	/**
	 * [tAdvancedHash_row10 process_data_end ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row10";

	

 



/**
 * [tAdvancedHash_row10 process_data_end ] stop
 */



	
	/**
	 * [tDBInput_9 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBInput_9";

	

 



/**
 * [tDBInput_9 process_data_end ] stop
 */
	
	/**
	 * [tDBInput_9 end ] start
	 */

	

	
	
	currentComponent="tDBInput_9";

	

	}
}finally{
	if (rs_tDBInput_9 != null) {
		rs_tDBInput_9.close();
	}
	if (stmt_tDBInput_9 != null) {
		stmt_tDBInput_9.close();
	}
	if(conn_tDBInput_9 != null && !conn_tDBInput_9.isClosed()) {
		
			conn_tDBInput_9.commit();
			
		
			conn_tDBInput_9.close();
			
			if("com.mysql.cj.jdbc.Driver".equals((String)globalMap.get("driverClass_"))
			    && routines.system.BundleUtils.inOSGi()) {
			        Class.forName("com.mysql.cj.jdbc.AbandonedConnectionCleanupThread").
			            getMethod("checkedShutdown").invoke(null, (Object[]) null);
			}
			
	}
	
}
globalMap.put("tDBInput_9_NB_LINE",nb_line_tDBInput_9);
 

ok_Hash.put("tDBInput_9", true);
end_Hash.put("tDBInput_9", System.currentTimeMillis());

tStatCatcher_1.addMessage("end","tDBInput_9", end_Hash.get("tDBInput_9")-start_Hash.get("tDBInput_9"));
tStatCatcher_1Process(globalMap);



/**
 * [tDBInput_9 end ] stop
 */

	
	/**
	 * [tAdvancedHash_row10 end ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row10";

	

tHash_Lookup_row10.endPut();

				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row10");
			  	}
			  	
 

ok_Hash.put("tAdvancedHash_row10", true);
end_Hash.put("tAdvancedHash_row10", System.currentTimeMillis());




/**
 * [tAdvancedHash_row10 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBInput_9 finally ] start
	 */

	

	
	
	currentComponent="tDBInput_9";

	

 



/**
 * [tDBInput_9 finally ] stop
 */

	
	/**
	 * [tAdvancedHash_row10 finally ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row10";

	

 



/**
 * [tAdvancedHash_row10 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBInput_9_SUBPROCESS_STATE", 1);
	}
	


public static class row11Struct implements routines.system.IPersistableComparableLookupRow<row11Struct> {
    final static byte[] commonByteArrayLock_ALIMENTATION_DM1_F_ALIM_FAIT = new byte[0];
    static byte[] commonByteArray_ALIMENTATION_DM1_F_ALIM_FAIT = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int id_date_fin_preparation;

				public int getId_date_fin_preparation () {
					return this.id_date_fin_preparation;
				}
				
			    public java.util.Date date_fin_preparation;

				public java.util.Date getDate_fin_preparation () {
					return this.date_fin_preparation;
				}
				
			    public String jour;

				public String getJour () {
					return this.jour;
				}
				
			    public String semaine;

				public String getSemaine () {
					return this.semaine;
				}
				
			    public String mois;

				public String getMois () {
					return this.mois;
				}
				
			    public String annee;

				public String getAnnee () {
					return this.annee;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
						result = prime * result + ((this.date_fin_preparation == null) ? 0 : this.date_fin_preparation.hashCode());
					
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row11Struct other = (row11Struct) obj;
		
						if (this.date_fin_preparation == null) {
							if (other.date_fin_preparation != null)
								return false;
						
						} else if (!this.date_fin_preparation.equals(other.date_fin_preparation))
						
							return false;
					

		return true;
    }

	public void copyDataTo(row11Struct other) {

		other.id_date_fin_preparation = this.id_date_fin_preparation;
	            other.date_fin_preparation = this.date_fin_preparation;
	            other.jour = this.jour;
	            other.semaine = this.semaine;
	            other.mois = this.mois;
	            other.annee = this.annee;
	            
	}

	public void copyKeysDataTo(row11Struct other) {

		other.date_fin_preparation = this.date_fin_preparation;
	            	
	}




	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }
	
	private String readString(DataInputStream dis, ObjectInputStream ois) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			byte[] byteArray = new byte[length];
			dis.read(byteArray);
			strReturn = new String(byteArray, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(DataInputStream dis, org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			byte[] byteArray = new byte[length];
			unmarshaller.read(byteArray);
			strReturn = new String(byteArray, utf8Charset);
		}
		return strReturn;
	}
	
	private void writeString(String str, DataOutputStream dos, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
	}

	private void writeString(String str, DataOutputStream dos, ObjectOutputStream oos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
	}

    public void readKeysData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_DM1_F_ALIM_FAIT) {

        	try {

        		int length = 0;
		
					this.date_fin_preparation = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readKeysData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_DM1_F_ALIM_FAIT) {

        	try {

        		int length = 0;
		
					this.date_fin_preparation = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeKeysData(ObjectOutputStream dos) {
        try {

		
					// java.util.Date
				
						writeDate(this.date_fin_preparation,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeKeysData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// java.util.Date
				
						writeDate(this.date_fin_preparation,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }



    /**
     * Fill Values data by reading ObjectInputStream.
     */
    public void readValuesData(DataInputStream dis, ObjectInputStream ois) {
        try {

			int length = 0;
		
			            this.id_date_fin_preparation = dis.readInt();
					
						this.jour = readString(dis,ois);
					
						this.semaine = readString(dis,ois);
					
						this.mois = readString(dis,ois);
					
						this.annee = readString(dis,ois);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

    }
    
    public void readValuesData(DataInputStream dis, org.jboss.marshalling.Unmarshaller objectIn) {
        try {
			int length = 0;
		
			            this.id_date_fin_preparation = objectIn.readInt();
					
						this.jour = readString(dis,objectIn);
					
						this.semaine = readString(dis,objectIn);
					
						this.mois = readString(dis,objectIn);
					
						this.annee = readString(dis,objectIn);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

    }

    /**
     * Return a byte array which represents Values data.
     */
    public void writeValuesData(DataOutputStream dos, ObjectOutputStream oos) {
        try {

		
		            	dos.writeInt(this.id_date_fin_preparation);
					
						writeString(this.jour, dos, oos);
					
						writeString(this.semaine, dos, oos);
					
						writeString(this.mois, dos, oos);
					
						writeString(this.annee, dos, oos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        	}

    }
    
    public void writeValuesData(DataOutputStream dos, org.jboss.marshalling.Marshaller objectOut){
                try {

		
					objectOut.writeInt(this.id_date_fin_preparation);
					
						writeString(this.jour, dos, objectOut);
					
						writeString(this.semaine, dos, objectOut);
					
						writeString(this.mois, dos, objectOut);
					
						writeString(this.annee, dos, objectOut);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        	}
    }


    
    public boolean supportMarshaller(){
        return true;
    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id_date_fin_preparation="+String.valueOf(id_date_fin_preparation));
		sb.append(",date_fin_preparation="+String.valueOf(date_fin_preparation));
		sb.append(",jour="+jour);
		sb.append(",semaine="+semaine);
		sb.append(",mois="+mois);
		sb.append(",annee="+annee);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row11Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.date_fin_preparation, other.date_fin_preparation);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tDBInput_10Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBInput_10_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row11Struct row11 = new row11Struct();




	
	/**
	 * [tAdvancedHash_row11 begin ] start
	 */

	

	
		
		ok_Hash.put("tAdvancedHash_row11", false);
		start_Hash.put("tAdvancedHash_row11", System.currentTimeMillis());
		
	
	currentComponent="tAdvancedHash_row11";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row11");
					}
				
		int tos_count_tAdvancedHash_row11 = 0;
		

			   		// connection name:row11
			   		// source node:tDBInput_10 - inputs:(after_tDBInput_1) outputs:(row11,row11) | target node:tAdvancedHash_row11 - inputs:(row11) outputs:()
			   		// linked node: tMap_1 - inputs:(row2,row3,row4,row5,row6,row7,row8,row9,row10,row11) outputs:(alim_fait)
			   
			   		org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE matchingModeEnum_row11 = 
			   			org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE.UNIQUE_MATCH;
			   			
			   
	   			org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row11Struct> tHash_Lookup_row11 =org.talend.designer.components.lookup.memory.AdvancedMemoryLookup.
	   						<row11Struct>getLookup(matchingModeEnum_row11);
	   						   
		   	   	   globalMap.put("tHash_Lookup_row11", tHash_Lookup_row11);
		   	   	   
				
           

 



/**
 * [tAdvancedHash_row11 begin ] stop
 */



	
	/**
	 * [tDBInput_10 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBInput_10", false);
		start_Hash.put("tDBInput_10", System.currentTimeMillis());
		
				tStatCatcher_1.addMessage("begin","tDBInput_10");
				tStatCatcher_1Process(globalMap);
			
	
	currentComponent="tDBInput_10";

	
		int tos_count_tDBInput_10 = 0;
		
	
    
	
		    int nb_line_tDBInput_10 = 0;
		    java.sql.Connection conn_tDBInput_10 = null;
				String driverClass_tDBInput_10 = "org.postgresql.Driver";
			    java.lang.Class jdbcclazz_tDBInput_10 = java.lang.Class.forName(driverClass_tDBInput_10);
				String dbUser_tDBInput_10 = "dsid_cc2_tos_rw";
				
				 
	final String decryptedPassword_tDBInput_10 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:q33Ozt9p+RR0Rpip5HnQT/UrwjVlflVAAF4KvIvE3E8=");
				
				String dbPwd_tDBInput_10 = decryptedPassword_tDBInput_10;
				
				String url_tDBInput_10 = "jdbc:postgresql://" + "" + ":" + "5432" + "/" + "postgres";
				
				conn_tDBInput_10 = java.sql.DriverManager.getConnection(url_tDBInput_10,dbUser_tDBInput_10,dbPwd_tDBInput_10);
		        
				conn_tDBInput_10.setAutoCommit(false);
			
		    
			java.sql.Statement stmt_tDBInput_10 = conn_tDBInput_10.createStatement();

		    String dbquery_tDBInput_10 = "SELECT \n  \"dsid_liv_dm1\".\"dim_date_fin_preparation_d\".\"id_date_fin_preparation\", \n  \"dsid_liv_dm1\".\"dim_date_f"
+"in_preparation_d\".\"date_fin_preparation\", \n  \"dsid_liv_dm1\".\"dim_date_fin_preparation_d\".\"jour\", \n  \"dsid_liv_"
+"dm1\".\"dim_date_fin_preparation_d\".\"semaine\", \n  \"dsid_liv_dm1\".\"dim_date_fin_preparation_d\".\"mois\", \n  \"dsid"
+"_liv_dm1\".\"dim_date_fin_preparation_d\".\"annee\"\nFROM \"dsid_liv_dm1\".\"dim_date_fin_preparation_d\"";
		    

            	globalMap.put("tDBInput_10_QUERY",dbquery_tDBInput_10);
		    java.sql.ResultSet rs_tDBInput_10 = null;

		    try {
		    	rs_tDBInput_10 = stmt_tDBInput_10.executeQuery(dbquery_tDBInput_10);
		    	java.sql.ResultSetMetaData rsmd_tDBInput_10 = rs_tDBInput_10.getMetaData();
		    	int colQtyInRs_tDBInput_10 = rsmd_tDBInput_10.getColumnCount();

		    String tmpContent_tDBInput_10 = null;
		    
		    
		    while (rs_tDBInput_10.next()) {
		        nb_line_tDBInput_10++;
		        
							if(colQtyInRs_tDBInput_10 < 1) {
								row11.id_date_fin_preparation = 0;
							} else {
		                          
            row11.id_date_fin_preparation = rs_tDBInput_10.getInt(1);
            if(rs_tDBInput_10.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_10 < 2) {
								row11.date_fin_preparation = null;
							} else {
										
			row11.date_fin_preparation = routines.system.JDBCUtil.getDate(rs_tDBInput_10, 2);
		                    }
							if(colQtyInRs_tDBInput_10 < 3) {
								row11.jour = null;
							} else {
	                         		
        	row11.jour = routines.system.JDBCUtil.getString(rs_tDBInput_10, 3, false);
		                    }
							if(colQtyInRs_tDBInput_10 < 4) {
								row11.semaine = null;
							} else {
	                         		
        	row11.semaine = routines.system.JDBCUtil.getString(rs_tDBInput_10, 4, false);
		                    }
							if(colQtyInRs_tDBInput_10 < 5) {
								row11.mois = null;
							} else {
	                         		
        	row11.mois = routines.system.JDBCUtil.getString(rs_tDBInput_10, 5, false);
		                    }
							if(colQtyInRs_tDBInput_10 < 6) {
								row11.annee = null;
							} else {
	                         		
        	row11.annee = routines.system.JDBCUtil.getString(rs_tDBInput_10, 6, false);
		                    }
					


 



/**
 * [tDBInput_10 begin ] stop
 */
	
	/**
	 * [tDBInput_10 main ] start
	 */

	

	
	
	currentComponent="tDBInput_10";

	

 


	tos_count_tDBInput_10++;

/**
 * [tDBInput_10 main ] stop
 */
	
	/**
	 * [tDBInput_10 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBInput_10";

	

 



/**
 * [tDBInput_10 process_data_begin ] stop
 */

	
	/**
	 * [tAdvancedHash_row11 main ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row11";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row11"
						
						);
					}
					


			   
			   

					row11Struct row11_HashRow = new row11Struct();
		   	   	   
				
				row11_HashRow.id_date_fin_preparation = row11.id_date_fin_preparation;
				
				row11_HashRow.date_fin_preparation = row11.date_fin_preparation;
				
				row11_HashRow.jour = row11.jour;
				
				row11_HashRow.semaine = row11.semaine;
				
				row11_HashRow.mois = row11.mois;
				
				row11_HashRow.annee = row11.annee;
				
			tHash_Lookup_row11.put(row11_HashRow);
			
            




 


	tos_count_tAdvancedHash_row11++;

/**
 * [tAdvancedHash_row11 main ] stop
 */
	
	/**
	 * [tAdvancedHash_row11 process_data_begin ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row11";

	

 



/**
 * [tAdvancedHash_row11 process_data_begin ] stop
 */
	
	/**
	 * [tAdvancedHash_row11 process_data_end ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row11";

	

 



/**
 * [tAdvancedHash_row11 process_data_end ] stop
 */



	
	/**
	 * [tDBInput_10 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBInput_10";

	

 



/**
 * [tDBInput_10 process_data_end ] stop
 */
	
	/**
	 * [tDBInput_10 end ] start
	 */

	

	
	
	currentComponent="tDBInput_10";

	

	}
}finally{
	if (rs_tDBInput_10 != null) {
		rs_tDBInput_10.close();
	}
	if (stmt_tDBInput_10 != null) {
		stmt_tDBInput_10.close();
	}
	if(conn_tDBInput_10 != null && !conn_tDBInput_10.isClosed()) {
		
			conn_tDBInput_10.commit();
			
		
			conn_tDBInput_10.close();
			
			if("com.mysql.cj.jdbc.Driver".equals((String)globalMap.get("driverClass_"))
			    && routines.system.BundleUtils.inOSGi()) {
			        Class.forName("com.mysql.cj.jdbc.AbandonedConnectionCleanupThread").
			            getMethod("checkedShutdown").invoke(null, (Object[]) null);
			}
			
	}
	
}
globalMap.put("tDBInput_10_NB_LINE",nb_line_tDBInput_10);
 

ok_Hash.put("tDBInput_10", true);
end_Hash.put("tDBInput_10", System.currentTimeMillis());

tStatCatcher_1.addMessage("end","tDBInput_10", end_Hash.get("tDBInput_10")-start_Hash.get("tDBInput_10"));
tStatCatcher_1Process(globalMap);



/**
 * [tDBInput_10 end ] stop
 */

	
	/**
	 * [tAdvancedHash_row11 end ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row11";

	

tHash_Lookup_row11.endPut();

				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row11");
			  	}
			  	
 

ok_Hash.put("tAdvancedHash_row11", true);
end_Hash.put("tAdvancedHash_row11", System.currentTimeMillis());




/**
 * [tAdvancedHash_row11 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBInput_10 finally ] start
	 */

	

	
	
	currentComponent="tDBInput_10";

	

 



/**
 * [tDBInput_10 finally ] stop
 */

	
	/**
	 * [tAdvancedHash_row11 finally ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row11";

	

 



/**
 * [tAdvancedHash_row11 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBInput_10_SUBPROCESS_STATE", 1);
	}
	
    public String resuming_logs_dir_path = null;
    public String resuming_checkpoint_path = null;
    public String parent_part_launcher = null;
    private String resumeEntryMethodName = null;
    private boolean globalResumeTicket = false;

    public boolean watch = false;
    // portStats is null, it means don't execute the statistics
    public Integer portStats = null;
    public int portTraces = 4334;
    public String clientHost;
    public String defaultClientHost = "localhost";
    public String contextStr = "Default";
    public boolean isDefaultContext = true;
    public String pid = "0";
    public String rootPid = null;
    public String fatherPid = null;
    public String fatherNode = null;
    public long startTime = 0;
    public boolean isChildJob = false;
    public String log4jLevel = "";
    
    private boolean enableLogStash;

    private boolean execStat = true;

    private ThreadLocal<java.util.Map<String, String>> threadLocal = new ThreadLocal<java.util.Map<String, String>>() {
        protected java.util.Map<String, String> initialValue() {
            java.util.Map<String,String> threadRunResultMap = new java.util.HashMap<String, String>();
            threadRunResultMap.put("errorCode", null);
            threadRunResultMap.put("status", "");
            return threadRunResultMap;
        };
    };


    protected PropertiesWithType context_param = new PropertiesWithType();
    public java.util.Map<String, Object> parentContextMap = new java.util.HashMap<String, Object>();

    public String status= "";
    

    public static void main(String[] args){
        final F_ALIM_FAIT F_ALIM_FAITClass = new F_ALIM_FAIT();

        int exitCode = F_ALIM_FAITClass.runJobInTOS(args);

        System.exit(exitCode);
    }


    public String[][] runJob(String[] args) {

        int exitCode = runJobInTOS(args);
        String[][] bufferValue = new String[][] { { Integer.toString(exitCode) } };

        return bufferValue;
    }

    public boolean hastBufferOutputComponent() {
		boolean hastBufferOutput = false;
    	
        return hastBufferOutput;
    }

    public int runJobInTOS(String[] args) {
	   	// reset status
	   	status = "";
	   	
        String lastStr = "";
        for (String arg : args) {
            if (arg.equalsIgnoreCase("--context_param")) {
                lastStr = arg;
            } else if (lastStr.equals("")) {
                evalParam(arg);
            } else {
                evalParam(lastStr + " " + arg);
                lastStr = "";
            }
        }
        enableLogStash = "true".equalsIgnoreCase(System.getProperty("audit.enabled"));

    	
    	

        if(clientHost == null) {
            clientHost = defaultClientHost;
        }

        if(pid == null || "0".equals(pid)) {
            pid = TalendString.getAsciiRandomString(6);
        }

        if (rootPid==null) {
            rootPid = pid;
        }
        if (fatherPid==null) {
            fatherPid = pid;
        }else{
            isChildJob = true;
        }

        if (portStats != null) {
            // portStats = -1; //for testing
            if (portStats < 0 || portStats > 65535) {
                // issue:10869, the portStats is invalid, so this client socket can't open
                System.err.println("The statistics socket port " + portStats + " is invalid.");
                execStat = false;
            }
        } else {
            execStat = false;
        }
        boolean inOSGi = routines.system.BundleUtils.inOSGi();

        if (inOSGi) {
            java.util.Dictionary<String, Object> jobProperties = routines.system.BundleUtils.getJobProperties(jobName);

            if (jobProperties != null && jobProperties.get("context") != null) {
                contextStr = (String)jobProperties.get("context");
            }
        }

        try {
            //call job/subjob with an existing context, like: --context=production. if without this parameter, there will use the default context instead.
            java.io.InputStream inContext = F_ALIM_FAIT.class.getClassLoader().getResourceAsStream("alimentation_dm1/f_alim_fait_0_1/contexts/" + contextStr + ".properties");
            if (inContext == null) {
                inContext = F_ALIM_FAIT.class.getClassLoader().getResourceAsStream("config/contexts/" + contextStr + ".properties");
            }
            if (inContext != null) {
                try {
                    //defaultProps is in order to keep the original context value
                    if(context != null && context.isEmpty()) {
	                defaultProps.load(inContext);
	                context = new ContextProperties(defaultProps);
                    }
                } finally {
                    inContext.close();
                }
            } else if (!isDefaultContext) {
                //print info and job continue to run, for case: context_param is not empty.
                System.err.println("Could not find the context " + contextStr);
            }

            if(!context_param.isEmpty()) {
                context.putAll(context_param);
				//set types for params from parentJobs
				for (Object key: context_param.keySet()){
					String context_key = key.toString();
					String context_type = context_param.getContextType(context_key);
					context.setContextType(context_key, context_type);

				}
            }
            class ContextProcessing {
                private void processContext_0() {
                } 
                public void processAllContext() {
                        processContext_0();
                }
            }

            new ContextProcessing().processAllContext();
        } catch (java.io.IOException ie) {
            System.err.println("Could not load context "+contextStr);
            ie.printStackTrace();
        }

        // get context value from parent directly
        if (parentContextMap != null && !parentContextMap.isEmpty()) {
        }

        //Resume: init the resumeUtil
        resumeEntryMethodName = ResumeUtil.getResumeEntryMethodName(resuming_checkpoint_path);
        resumeUtil = new ResumeUtil(resuming_logs_dir_path, isChildJob, rootPid);
        resumeUtil.initCommonInfo(pid, rootPid, fatherPid, projectName, jobName, contextStr, jobVersion);

		List<String> parametersToEncrypt = new java.util.ArrayList<String>();
        //Resume: jobStart
        resumeUtil.addLog("JOB_STARTED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","","","",resumeUtil.convertToJsonText(context,parametersToEncrypt));

if(execStat) {
    try {
        runStat.openSocket(!isChildJob);
        runStat.setAllPID(rootPid, fatherPid, pid, jobName);
        runStat.startThreadStat(clientHost, portStats);
        runStat.updateStatOnJob(RunStat.JOBSTART, fatherNode);
    } catch (java.io.IOException ioException) {
        ioException.printStackTrace();
    }
}



	
	    java.util.concurrent.ConcurrentHashMap<Object, Object> concurrentHashMap = new java.util.concurrent.ConcurrentHashMap<Object, Object>();
	    globalMap.put("concurrentHashMap", concurrentHashMap);
	

    long startUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
    long endUsedMemory = 0;
    long end = 0;

    startTime = System.currentTimeMillis();
        tStatCatcher_1.addMessage("begin");


this.globalResumeTicket = true;//to run tPreJob




        try {
            tStatCatcher_1Process(globalMap);
        } catch (java.lang.Exception e) {
            e.printStackTrace();
        }

this.globalResumeTicket = false;//to run others jobs

try {
errorCode = null;tDBInput_1Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tDBInput_1) {
globalMap.put("tDBInput_1_SUBPROCESS_STATE", -1);

e_tDBInput_1.printStackTrace();

}

this.globalResumeTicket = true;//to run tPostJob




        end = System.currentTimeMillis();

        if (watch) {
            System.out.println((end-startTime)+" milliseconds");
        }

        endUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        if (false) {
            System.out.println((endUsedMemory - startUsedMemory) + " bytes memory increase when running : F_ALIM_FAIT");
        }
        tStatCatcher_1.addMessage(status==""?"end":status, (end-startTime));
        try {
            tStatCatcher_1Process(globalMap);
        } catch (java.lang.Exception e) {
            e.printStackTrace();
        }



if (execStat) {
    runStat.updateStatOnJob(RunStat.JOBEND, fatherNode);
    runStat.stopThreadStat();
}
    int returnCode = 0;


    if(errorCode == null) {
         returnCode = status != null && status.equals("failure") ? 1 : 0;
    } else {
         returnCode = errorCode.intValue();
    }
    resumeUtil.addLog("JOB_ENDED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","" + returnCode,"","","");

    return returnCode;

  }

    // only for OSGi env
    public void destroy() {


    }














    private java.util.Map<String, Object> getSharedConnections4REST() {
        java.util.Map<String, Object> connections = new java.util.HashMap<String, Object>();






        return connections;
    }

    private void evalParam(String arg) {
        if (arg.startsWith("--resuming_logs_dir_path")) {
            resuming_logs_dir_path = arg.substring(25);
        } else if (arg.startsWith("--resuming_checkpoint_path")) {
            resuming_checkpoint_path = arg.substring(27);
        } else if (arg.startsWith("--parent_part_launcher")) {
            parent_part_launcher = arg.substring(23);
        } else if (arg.startsWith("--watch")) {
            watch = true;
        } else if (arg.startsWith("--stat_port=")) {
            String portStatsStr = arg.substring(12);
            if (portStatsStr != null && !portStatsStr.equals("null")) {
                portStats = Integer.parseInt(portStatsStr);
            }
        } else if (arg.startsWith("--trace_port=")) {
            portTraces = Integer.parseInt(arg.substring(13));
        } else if (arg.startsWith("--client_host=")) {
            clientHost = arg.substring(14);
        } else if (arg.startsWith("--context=")) {
            contextStr = arg.substring(10);
            isDefaultContext = false;
        } else if (arg.startsWith("--father_pid=")) {
            fatherPid = arg.substring(13);
        } else if (arg.startsWith("--root_pid=")) {
            rootPid = arg.substring(11);
        } else if (arg.startsWith("--father_node=")) {
            fatherNode = arg.substring(14);
        } else if (arg.startsWith("--pid=")) {
            pid = arg.substring(6);
        } else if (arg.startsWith("--context_type")) {
            String keyValue = arg.substring(15);
			int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.setContextType(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.setContextType(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }

            }

		} else if (arg.startsWith("--context_param")) {
            String keyValue = arg.substring(16);
            int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.put(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.put(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }
            }
        } else if (arg.startsWith("--log4jLevel=")) {
            log4jLevel = arg.substring(13);
		} else if (arg.startsWith("--audit.enabled") && arg.contains("=")) {//for trunjob call
		    final int equal = arg.indexOf('=');
			final String key = arg.substring("--".length(), equal);
			System.setProperty(key, arg.substring(equal + 1));
		}
    }
    
    private static final String NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY = "<TALEND_NULL>";

    private final String[][] escapeChars = {
        {"\\\\","\\"},{"\\n","\n"},{"\\'","\'"},{"\\r","\r"},
        {"\\f","\f"},{"\\b","\b"},{"\\t","\t"}
        };
    private String replaceEscapeChars (String keyValue) {

		if (keyValue == null || ("").equals(keyValue.trim())) {
			return keyValue;
		}

		StringBuilder result = new StringBuilder();
		int currIndex = 0;
		while (currIndex < keyValue.length()) {
			int index = -1;
			// judege if the left string includes escape chars
			for (String[] strArray : escapeChars) {
				index = keyValue.indexOf(strArray[0],currIndex);
				if (index>=0) {

					result.append(keyValue.substring(currIndex, index + strArray[0].length()).replace(strArray[0], strArray[1]));
					currIndex = index + strArray[0].length();
					break;
				}
			}
			// if the left string doesn't include escape chars, append the left into the result
			if (index < 0) {
				result.append(keyValue.substring(currIndex));
				currIndex = currIndex + keyValue.length();
			}
		}

		return result.toString();
    }

    public Integer getErrorCode() {
        return errorCode;
    }


    public String getStatus() {
        return status;
    }

    ResumeUtil resumeUtil = null;
}
/************************************************************************************************
 *     381443 characters generated by Talend Open Studio for Data Integration 
 *     on the 18 janvier 2024 à 23:35:34 CET
 ************************************************************************************************/