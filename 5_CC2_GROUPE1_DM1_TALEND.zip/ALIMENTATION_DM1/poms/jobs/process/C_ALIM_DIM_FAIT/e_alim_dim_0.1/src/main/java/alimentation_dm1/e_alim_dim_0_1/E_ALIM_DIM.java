// ============================================================================
//
// Copyright (c) 2006-2015, Talend SA
//
// Ce code source a été automatiquement généré par_Talend Open Studio for Data Integration
// / Soumis à la Licence Apache, Version 2.0 (la "Licence") ;
// votre utilisation de ce fichier doit respecter les termes de la Licence.
// Vous pouvez obtenir une copie de la Licence sur
// http://www.apache.org/licenses/LICENSE-2.0
// 
// Sauf lorsqu'explicitement prévu par la loi en vigueur ou accepté par écrit, le logiciel
// distribué sous la Licence est distribué "TEL QUEL",
// SANS GARANTIE OU CONDITION D'AUCUNE SORTE, expresse ou implicite.
// Consultez la Licence pour connaître la terminologie spécifique régissant les autorisations et
// les limites prévues par la Licence.


package alimentation_dm1.e_alim_dim_0_1;

import routines.Numeric;
import routines.DataOperation;
import routines.TalendDataGenerator;
import routines.TalendStringUtil;
import routines.TalendString;
import routines.StringHandling;
import routines.Relational;
import routines.TalendDate;
import routines.Mathematical;
import routines.system.*;
import routines.system.api.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.math.BigDecimal;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.util.Comparator;
 





@SuppressWarnings("unused")

/**
 * Job: E_ALIM_DIM Purpose: Job pour alimenter les tables de dimension<br>
 * Description: Job pour alimenter les tables de dimension <br>
 * @author user@talend.com
 * @version 8.0.1.20211109_1610
 * @status 
 */
public class E_ALIM_DIM implements TalendJob {

protected static void logIgnoredError(String message, Throwable cause) {
       System.err.println(message);
       if (cause != null) {
               cause.printStackTrace();
       }

}


	public final Object obj = new Object();

	// for transmiting parameters purpose
	private Object valueObject = null;

	public Object getValueObject() {
		return this.valueObject;
	}

	public void setValueObject(Object valueObject) {
		this.valueObject = valueObject;
	}
	
	private final static String defaultCharset = java.nio.charset.Charset.defaultCharset().name();

	
	private final static String utf8Charset = "UTF-8";
	//contains type for every context property
	public class PropertiesWithType extends java.util.Properties {
		private static final long serialVersionUID = 1L;
		private java.util.Map<String,String> propertyTypes = new java.util.HashMap<>();
		
		public PropertiesWithType(java.util.Properties properties){
			super(properties);
		}
		public PropertiesWithType(){
			super();
		}
		
		public void setContextType(String key, String type) {
			propertyTypes.put(key,type);
		}
	
		public String getContextType(String key) {
			return propertyTypes.get(key);
		}
	}
	
	// create and load default properties
	private java.util.Properties defaultProps = new java.util.Properties();
	// create application properties with default
	public class ContextProperties extends PropertiesWithType {

		private static final long serialVersionUID = 1L;

		public ContextProperties(java.util.Properties properties){
			super(properties);
		}
		public ContextProperties(){
			super();
		}

		public void synchronizeContext(){
			
		}
		
		//if the stored or passed value is "<TALEND_NULL>" string, it mean null
		public String getStringValue(String key) {
			String origin_value = this.getProperty(key);
			if(NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY.equals(origin_value)) {
				return null;
			}
			return origin_value;
		}

	}
	protected ContextProperties context = new ContextProperties(); // will be instanciated by MS.
	public ContextProperties getContext() {
		return this.context;
	}
	private final String jobVersion = "0.1";
	private final String jobName = "E_ALIM_DIM";
	private final String projectName = "ALIMENTATION_DM1";
	public Integer errorCode = null;
	private String currentComponent = "";
	
		private final java.util.Map<String, Object> globalMap = new java.util.HashMap<String, Object>();
        private final static java.util.Map<String, Object> junitGlobalMap = new java.util.HashMap<String, Object>();
	
		private final java.util.Map<String, Long> start_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Long> end_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Boolean> ok_Hash = new java.util.HashMap<String, Boolean>();
		public  final java.util.List<String[]> globalBuffer = new java.util.ArrayList<String[]>();
	

private RunStat runStat = new RunStat();

	// OSGi DataSource
	private final static String KEY_DB_DATASOURCES = "KEY_DB_DATASOURCES";
	
	private final static String KEY_DB_DATASOURCES_RAW = "KEY_DB_DATASOURCES_RAW";

	public void setDataSources(java.util.Map<String, javax.sql.DataSource> dataSources) {
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		for (java.util.Map.Entry<String, javax.sql.DataSource> dataSourceEntry : dataSources.entrySet()) {
			talendDataSources.put(dataSourceEntry.getKey(), new routines.system.TalendDataSource(dataSourceEntry.getValue()));
		}
		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}
	
	public void setDataSourceReferences(List serviceReferences) throws Exception{
		
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		java.util.Map<String, javax.sql.DataSource> dataSources = new java.util.HashMap<String, javax.sql.DataSource>();
		
		for (java.util.Map.Entry<String, javax.sql.DataSource> entry : BundleUtils.getServices(serviceReferences,  javax.sql.DataSource.class).entrySet()) {
                    dataSources.put(entry.getKey(), entry.getValue());
                    talendDataSources.put(entry.getKey(), new routines.system.TalendDataSource(entry.getValue()));
		}

		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}

	StatCatcherUtils tStatCatcher_1 = new StatCatcherUtils("_vhR0QKTtEe6HdLQjDeTAqA", "0.1");

private final java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
private final java.io.PrintStream errorMessagePS = new java.io.PrintStream(new java.io.BufferedOutputStream(baos));

public String getExceptionStackTrace() {
	if ("failure".equals(this.getStatus())) {
		errorMessagePS.flush();
		return baos.toString();
	}
	return null;
}

private Exception exception;

public Exception getException() {
	if ("failure".equals(this.getStatus())) {
		return this.exception;
	}
	return null;
}

private class TalendException extends Exception {

	private static final long serialVersionUID = 1L;

	private java.util.Map<String, Object> globalMap = null;
	private Exception e = null;
	private String currentComponent = null;
	private String virtualComponentName = null;
	
	public void setVirtualComponentName (String virtualComponentName){
		this.virtualComponentName = virtualComponentName;
	}

	private TalendException(Exception e, String errorComponent, final java.util.Map<String, Object> globalMap) {
		this.currentComponent= errorComponent;
		this.globalMap = globalMap;
		this.e = e;
	}

	public Exception getException() {
		return this.e;
	}

	public String getCurrentComponent() {
		return this.currentComponent;
	}

	
    public String getExceptionCauseMessage(Exception e){
        Throwable cause = e;
        String message = null;
        int i = 10;
        while (null != cause && 0 < i--) {
            message = cause.getMessage();
            if (null == message) {
                cause = cause.getCause();
            } else {
                break;          
            }
        }
        if (null == message) {
            message = e.getClass().getName();
        }   
        return message;
    }

	@Override
	public void printStackTrace() {
		if (!(e instanceof TalendException || e instanceof TDieException)) {
			if(virtualComponentName!=null && currentComponent.indexOf(virtualComponentName+"_")==0){
				globalMap.put(virtualComponentName+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			}
			globalMap.put(currentComponent+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			System.err.println("Exception in component " + currentComponent + " (" + jobName + ")");
		}
		if (!(e instanceof TDieException)) {
			if(e instanceof TalendException){
				e.printStackTrace();
			} else {
				e.printStackTrace();
				e.printStackTrace(errorMessagePS);
				E_ALIM_DIM.this.exception = e;
			}
		}
		if (!(e instanceof TalendException)) {
		try {
			for (java.lang.reflect.Method m : this.getClass().getEnclosingClass().getMethods()) {
				if (m.getName().compareTo(currentComponent + "_error") == 0) {
					m.invoke(E_ALIM_DIM.this, new Object[] { e , currentComponent, globalMap});
					break;
				}
			}

			if(!(e instanceof TDieException)){
			}
		} catch (Exception e) {
			this.e.printStackTrace();
		}
		}
	}
}

			public void tStatCatcher_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tStatCatcher_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tStatCatcher_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBInput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
							tStatCatcher_1.addMessage("failure",errorComponent, end_Hash.get(errorComponent)-start_Hash.get(errorComponent));
							tStatCatcher_1Process(globalMap);
							
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMap_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
							tStatCatcher_1.addMessage("failure",errorComponent, end_Hash.get(errorComponent)-start_Hash.get(errorComponent));
							tStatCatcher_1Process(globalMap);
							
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBSCD_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBSCD_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBSCD_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBSCD_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBSCD_5_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBSCD_6_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBSCD_7_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBSCD_8_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tStatCatcher_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBInput_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
	






public static class row1Struct implements routines.system.IPersistableRow<row1Struct> {
    final static byte[] commonByteArrayLock_ALIMENTATION_DM1_E_ALIM_DIM = new byte[0];
    static byte[] commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM = new byte[0];

	
			    public java.util.Date moment;

				public java.util.Date getMoment () {
					return this.moment;
				}
				
			    public String pid;

				public String getPid () {
					return this.pid;
				}
				
			    public String father_pid;

				public String getFather_pid () {
					return this.father_pid;
				}
				
			    public String root_pid;

				public String getRoot_pid () {
					return this.root_pid;
				}
				
			    public Long system_pid;

				public Long getSystem_pid () {
					return this.system_pid;
				}
				
			    public String project;

				public String getProject () {
					return this.project;
				}
				
			    public String job;

				public String getJob () {
					return this.job;
				}
				
			    public String job_repository_id;

				public String getJob_repository_id () {
					return this.job_repository_id;
				}
				
			    public String job_version;

				public String getJob_version () {
					return this.job_version;
				}
				
			    public String context;

				public String getContext () {
					return this.context;
				}
				
			    public String origin;

				public String getOrigin () {
					return this.origin;
				}
				
			    public String message_type;

				public String getMessage_type () {
					return this.message_type;
				}
				
			    public String message;

				public String getMessage () {
					return this.message;
				}
				
			    public Long duration;

				public Long getDuration () {
					return this.duration;
				}
				



	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM.length == 0) {
   					commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM.length == 0) {
   					commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_DM1_E_ALIM_DIM) {

        	try {

        		int length = 0;
		
					this.moment = readDate(dis);
					
					this.pid = readString(dis);
					
					this.father_pid = readString(dis);
					
					this.root_pid = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.system_pid = null;
           				} else {
           			    	this.system_pid = dis.readLong();
           				}
					
					this.project = readString(dis);
					
					this.job = readString(dis);
					
					this.job_repository_id = readString(dis);
					
					this.job_version = readString(dis);
					
					this.context = readString(dis);
					
					this.origin = readString(dis);
					
					this.message_type = readString(dis);
					
					this.message = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.duration = null;
           				} else {
           			    	this.duration = dis.readLong();
           				}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_DM1_E_ALIM_DIM) {

        	try {

        		int length = 0;
		
					this.moment = readDate(dis);
					
					this.pid = readString(dis);
					
					this.father_pid = readString(dis);
					
					this.root_pid = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.system_pid = null;
           				} else {
           			    	this.system_pid = dis.readLong();
           				}
					
					this.project = readString(dis);
					
					this.job = readString(dis);
					
					this.job_repository_id = readString(dis);
					
					this.job_version = readString(dis);
					
					this.context = readString(dis);
					
					this.origin = readString(dis);
					
					this.message_type = readString(dis);
					
					this.message = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.duration = null;
           				} else {
           			    	this.duration = dis.readLong();
           				}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// java.util.Date
				
						writeDate(this.moment,dos);
					
					// String
				
						writeString(this.pid,dos);
					
					// String
				
						writeString(this.father_pid,dos);
					
					// String
				
						writeString(this.root_pid,dos);
					
					// Long
				
						if(this.system_pid == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.system_pid);
		            	}
					
					// String
				
						writeString(this.project,dos);
					
					// String
				
						writeString(this.job,dos);
					
					// String
				
						writeString(this.job_repository_id,dos);
					
					// String
				
						writeString(this.job_version,dos);
					
					// String
				
						writeString(this.context,dos);
					
					// String
				
						writeString(this.origin,dos);
					
					// String
				
						writeString(this.message_type,dos);
					
					// String
				
						writeString(this.message,dos);
					
					// Long
				
						if(this.duration == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.duration);
		            	}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// java.util.Date
				
						writeDate(this.moment,dos);
					
					// String
				
						writeString(this.pid,dos);
					
					// String
				
						writeString(this.father_pid,dos);
					
					// String
				
						writeString(this.root_pid,dos);
					
					// Long
				
						if(this.system_pid == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.system_pid);
		            	}
					
					// String
				
						writeString(this.project,dos);
					
					// String
				
						writeString(this.job,dos);
					
					// String
				
						writeString(this.job_repository_id,dos);
					
					// String
				
						writeString(this.job_version,dos);
					
					// String
				
						writeString(this.context,dos);
					
					// String
				
						writeString(this.origin,dos);
					
					// String
				
						writeString(this.message_type,dos);
					
					// String
				
						writeString(this.message,dos);
					
					// Long
				
						if(this.duration == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.duration);
		            	}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("moment="+String.valueOf(moment));
		sb.append(",pid="+pid);
		sb.append(",father_pid="+father_pid);
		sb.append(",root_pid="+root_pid);
		sb.append(",system_pid="+String.valueOf(system_pid));
		sb.append(",project="+project);
		sb.append(",job="+job);
		sb.append(",job_repository_id="+job_repository_id);
		sb.append(",job_version="+job_version);
		sb.append(",context="+context);
		sb.append(",origin="+origin);
		sb.append(",message_type="+message_type);
		sb.append(",message="+message);
		sb.append(",duration="+String.valueOf(duration));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row1Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tStatCatcher_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tStatCatcher_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row1Struct row1 = new row1Struct();




	
	/**
	 * [tDBOutput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_1", false);
		start_Hash.put("tDBOutput_1", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_1";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row1");
					}
				
		int tos_count_tDBOutput_1 = 0;
		





String dbschema_tDBOutput_1 = null;
	dbschema_tDBOutput_1 = "dsid_liv_met";
	

String tableName_tDBOutput_1 = null;
if(dbschema_tDBOutput_1 == null || dbschema_tDBOutput_1.trim().length() == 0) {
	tableName_tDBOutput_1 = ("JOB_STATS");
} else {
	tableName_tDBOutput_1 = dbschema_tDBOutput_1 + "\".\"" + ("JOB_STATS");
}


int nb_line_tDBOutput_1 = 0;
int nb_line_update_tDBOutput_1 = 0;
int nb_line_inserted_tDBOutput_1 = 0;
int nb_line_deleted_tDBOutput_1 = 0;
int nb_line_rejected_tDBOutput_1 = 0;

int deletedCount_tDBOutput_1=0;
int updatedCount_tDBOutput_1=0;
int insertedCount_tDBOutput_1=0;
int rowsToCommitCount_tDBOutput_1=0;
int rejectedCount_tDBOutput_1=0;

boolean whetherReject_tDBOutput_1 = false;

java.sql.Connection conn_tDBOutput_1 = null;
String dbUser_tDBOutput_1 = null;

	
    java.lang.Class.forName("org.postgresql.Driver");
    
        String url_tDBOutput_1 = "jdbc:postgresql://"+""+":"+"5432"+"/"+"postgres";
    dbUser_tDBOutput_1 = "dsid_cc2_tos_rw";
 
	final String decryptedPassword_tDBOutput_1 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:yRtb4jxNfhEzYaFSxY/4YpEMmRU8zwpSPUntQVJ3DHM=");

    String dbPwd_tDBOutput_1 = decryptedPassword_tDBOutput_1;

    conn_tDBOutput_1 = java.sql.DriverManager.getConnection(url_tDBOutput_1,dbUser_tDBOutput_1,dbPwd_tDBOutput_1);
	
	resourceMap.put("conn_tDBOutput_1", conn_tDBOutput_1);
        conn_tDBOutput_1.setAutoCommit(false);
        int commitEvery_tDBOutput_1 = 10000;
        int commitCounter_tDBOutput_1 = 0;


   int batchSize_tDBOutput_1 = 10000;
   int batchSizeCounter_tDBOutput_1=0;

int count_tDBOutput_1=0;
	    String insert_tDBOutput_1 = "INSERT INTO \"" + tableName_tDBOutput_1 + "\" (\"moment\",\"pid\",\"father_pid\",\"root_pid\",\"system_pid\",\"project\",\"job\",\"job_repository_id\",\"job_version\",\"context\",\"origin\",\"message_type\",\"message\",\"duration\") VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
	    
	    java.sql.PreparedStatement pstmt_tDBOutput_1 = conn_tDBOutput_1.prepareStatement(insert_tDBOutput_1);
	    resourceMap.put("pstmt_tDBOutput_1", pstmt_tDBOutput_1);
	    

 



/**
 * [tDBOutput_1 begin ] stop
 */



	
	/**
	 * [tStatCatcher_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tStatCatcher_1", false);
		start_Hash.put("tStatCatcher_1", System.currentTimeMillis());
		
	
	currentComponent="tStatCatcher_1";

	
		int tos_count_tStatCatcher_1 = 0;
		

	for (StatCatcherUtils.StatCatcherMessage scm : tStatCatcher_1.getMessages()) {
		row1.pid = pid;
		row1.root_pid = rootPid;
		row1.father_pid = fatherPid;	
    	row1.project = projectName;
    	row1.job = jobName;
    	row1.context = contextStr;
		row1.origin = (scm.getOrigin()==null || scm.getOrigin().length()<1 ? null : scm.getOrigin());
		row1.message = scm.getMessage();
		row1.duration = scm.getDuration();
		row1.moment = scm.getMoment();
		row1.message_type = scm.getMessageType();
		row1.job_version = scm.getJobVersion();
		row1.job_repository_id = scm.getJobId();
		row1.system_pid = scm.getSystemPid();

 



/**
 * [tStatCatcher_1 begin ] stop
 */
	
	/**
	 * [tStatCatcher_1 main ] start
	 */

	

	
	
	currentComponent="tStatCatcher_1";

	

 


	tos_count_tStatCatcher_1++;

/**
 * [tStatCatcher_1 main ] stop
 */
	
	/**
	 * [tStatCatcher_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tStatCatcher_1";

	

 



/**
 * [tStatCatcher_1 process_data_begin ] stop
 */

	
	/**
	 * [tDBOutput_1 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row1"
						
						);
					}
					



        whetherReject_tDBOutput_1 = false;
                    if(row1.moment != null) {
pstmt_tDBOutput_1.setTimestamp(1, new java.sql.Timestamp(row1.moment.getTime()));
} else {
pstmt_tDBOutput_1.setNull(1, java.sql.Types.TIMESTAMP);
}

                    if(row1.pid == null) {
pstmt_tDBOutput_1.setNull(2, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(2, row1.pid);
}

                    if(row1.father_pid == null) {
pstmt_tDBOutput_1.setNull(3, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(3, row1.father_pid);
}

                    if(row1.root_pid == null) {
pstmt_tDBOutput_1.setNull(4, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(4, row1.root_pid);
}

                    if(row1.system_pid == null) {
pstmt_tDBOutput_1.setNull(5, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_1.setLong(5, row1.system_pid);
}

                    if(row1.project == null) {
pstmt_tDBOutput_1.setNull(6, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(6, row1.project);
}

                    if(row1.job == null) {
pstmt_tDBOutput_1.setNull(7, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(7, row1.job);
}

                    if(row1.job_repository_id == null) {
pstmt_tDBOutput_1.setNull(8, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(8, row1.job_repository_id);
}

                    if(row1.job_version == null) {
pstmt_tDBOutput_1.setNull(9, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(9, row1.job_version);
}

                    if(row1.context == null) {
pstmt_tDBOutput_1.setNull(10, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(10, row1.context);
}

                    if(row1.origin == null) {
pstmt_tDBOutput_1.setNull(11, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(11, row1.origin);
}

                    if(row1.message_type == null) {
pstmt_tDBOutput_1.setNull(12, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(12, row1.message_type);
}

                    if(row1.message == null) {
pstmt_tDBOutput_1.setNull(13, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(13, row1.message);
}

                    if(row1.duration == null) {
pstmt_tDBOutput_1.setNull(14, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_1.setLong(14, row1.duration);
}

			
    		pstmt_tDBOutput_1.addBatch();
    		nb_line_tDBOutput_1++;
    		  
    		  
    		  batchSizeCounter_tDBOutput_1++;
    		  
    			if ((batchSize_tDBOutput_1 > 0) && (batchSize_tDBOutput_1 <= batchSizeCounter_tDBOutput_1)) {
                try {
						int countSum_tDBOutput_1 = 0;
						    
						for(int countEach_tDBOutput_1: pstmt_tDBOutput_1.executeBatch()) {
							countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
						}
				    	rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
				    	
				    		insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
				    	
            	    	batchSizeCounter_tDBOutput_1 = 0;
                }catch (java.sql.BatchUpdateException e_tDBOutput_1){
globalMap.put("tDBOutput_1_ERROR_MESSAGE",e_tDBOutput_1.getMessage());
				    	java.sql.SQLException ne_tDBOutput_1 = e_tDBOutput_1.getNextException(),sqle_tDBOutput_1=null;
				    	String errormessage_tDBOutput_1;
						if (ne_tDBOutput_1 != null) {
							// build new exception to provide the original cause
							sqle_tDBOutput_1 = new java.sql.SQLException(e_tDBOutput_1.getMessage() + "\ncaused by: " + ne_tDBOutput_1.getMessage(), ne_tDBOutput_1.getSQLState(), ne_tDBOutput_1.getErrorCode(), ne_tDBOutput_1);
							errormessage_tDBOutput_1 = sqle_tDBOutput_1.getMessage();
						}else{
							errormessage_tDBOutput_1 = e_tDBOutput_1.getMessage();
						}
				    	
				    	int countSum_tDBOutput_1 = 0;
						for(int countEach_tDBOutput_1: e_tDBOutput_1.getUpdateCounts()) {
							countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
						}
						rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
						
				    		insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
				    	
				    	System.err.println(errormessage_tDBOutput_1);
				    	
					}
    			}
    		
    		    commitCounter_tDBOutput_1++;
                if(commitEvery_tDBOutput_1 <= commitCounter_tDBOutput_1) {
                if ((batchSize_tDBOutput_1 > 0) && (batchSizeCounter_tDBOutput_1 > 0)) {
                try {
                		int countSum_tDBOutput_1 = 0;
                		    
						for(int countEach_tDBOutput_1: pstmt_tDBOutput_1.executeBatch()) {
							countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
						}
            	    	rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
            	    	
            	    		insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
            	    	
                batchSizeCounter_tDBOutput_1 = 0;
               }catch (java.sql.BatchUpdateException e_tDBOutput_1){
globalMap.put("tDBOutput_1_ERROR_MESSAGE",e_tDBOutput_1.getMessage());
			    	java.sql.SQLException ne_tDBOutput_1 = e_tDBOutput_1.getNextException(),sqle_tDBOutput_1=null;
			    	String errormessage_tDBOutput_1;
					if (ne_tDBOutput_1 != null) {
						// build new exception to provide the original cause
						sqle_tDBOutput_1 = new java.sql.SQLException(e_tDBOutput_1.getMessage() + "\ncaused by: " + ne_tDBOutput_1.getMessage(), ne_tDBOutput_1.getSQLState(), ne_tDBOutput_1.getErrorCode(), ne_tDBOutput_1);
						errormessage_tDBOutput_1 = sqle_tDBOutput_1.getMessage();
					}else{
						errormessage_tDBOutput_1 = e_tDBOutput_1.getMessage();
					}
			    	
			    	int countSum_tDBOutput_1 = 0;
					for(int countEach_tDBOutput_1: e_tDBOutput_1.getUpdateCounts()) {
						countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
					}
					rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
					
			    		insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
			    	
			    	System.err.println(errormessage_tDBOutput_1);
			    	
				}
            }
                    if(rowsToCommitCount_tDBOutput_1 != 0){
                    	
                    }
                    conn_tDBOutput_1.commit();
                    if(rowsToCommitCount_tDBOutput_1 != 0){
                    	
                    	rowsToCommitCount_tDBOutput_1 = 0;
                    }
                    commitCounter_tDBOutput_1=0;
                }

 


	tos_count_tDBOutput_1++;

/**
 * [tDBOutput_1 main ] stop
 */
	
	/**
	 * [tDBOutput_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";

	

 



/**
 * [tDBOutput_1 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";

	

 



/**
 * [tDBOutput_1 process_data_end ] stop
 */



	
	/**
	 * [tStatCatcher_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tStatCatcher_1";

	

 



/**
 * [tStatCatcher_1 process_data_end ] stop
 */
	
	/**
	 * [tStatCatcher_1 end ] start
	 */

	

	
	
	currentComponent="tStatCatcher_1";

	

	}


 

ok_Hash.put("tStatCatcher_1", true);
end_Hash.put("tStatCatcher_1", System.currentTimeMillis());




/**
 * [tStatCatcher_1 end ] stop
 */

	
	/**
	 * [tDBOutput_1 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";

	



	    try {
				int countSum_tDBOutput_1 = 0;
				if (pstmt_tDBOutput_1 != null && batchSizeCounter_tDBOutput_1 > 0) {
						
					for(int countEach_tDBOutput_1: pstmt_tDBOutput_1.executeBatch()) {
						countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
					}
					rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
						
				}
		    	
		    		insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
		    	
	    }catch (java.sql.BatchUpdateException e_tDBOutput_1){
globalMap.put("tDBOutput_1_ERROR_MESSAGE",e_tDBOutput_1.getMessage());
	    	java.sql.SQLException ne_tDBOutput_1 = e_tDBOutput_1.getNextException(),sqle_tDBOutput_1=null;
	    	String errormessage_tDBOutput_1;
			if (ne_tDBOutput_1 != null) {
				// build new exception to provide the original cause
				sqle_tDBOutput_1 = new java.sql.SQLException(e_tDBOutput_1.getMessage() + "\ncaused by: " + ne_tDBOutput_1.getMessage(), ne_tDBOutput_1.getSQLState(), ne_tDBOutput_1.getErrorCode(), ne_tDBOutput_1);
				errormessage_tDBOutput_1 = sqle_tDBOutput_1.getMessage();
			}else{
				errormessage_tDBOutput_1 = e_tDBOutput_1.getMessage();
			}
	    	
	    	int countSum_tDBOutput_1 = 0;
			for(int countEach_tDBOutput_1: e_tDBOutput_1.getUpdateCounts()) {
				countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
			}
			rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
			
	    		insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
	    	
	    	System.err.println(errormessage_tDBOutput_1);
	    	
		}
	    
        if(pstmt_tDBOutput_1 != null) {
        		
            pstmt_tDBOutput_1.close();
            resourceMap.remove("pstmt_tDBOutput_1");
        }
    resourceMap.put("statementClosed_tDBOutput_1", true);
			if(rowsToCommitCount_tDBOutput_1 != 0){
				
			}
			conn_tDBOutput_1.commit();
			if(rowsToCommitCount_tDBOutput_1 != 0){
				
				rowsToCommitCount_tDBOutput_1 = 0;
			}
			commitCounter_tDBOutput_1 = 0;
		
    	conn_tDBOutput_1 .close();
    	
    	resourceMap.put("finish_tDBOutput_1", true);
    	

	nb_line_deleted_tDBOutput_1=nb_line_deleted_tDBOutput_1+ deletedCount_tDBOutput_1;
	nb_line_update_tDBOutput_1=nb_line_update_tDBOutput_1 + updatedCount_tDBOutput_1;
	nb_line_inserted_tDBOutput_1=nb_line_inserted_tDBOutput_1 + insertedCount_tDBOutput_1;
	nb_line_rejected_tDBOutput_1=nb_line_rejected_tDBOutput_1 + rejectedCount_tDBOutput_1;
	
        globalMap.put("tDBOutput_1_NB_LINE",nb_line_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_UPDATED",nb_line_update_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_DELETED",nb_line_deleted_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_1);
    

	


				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row1");
			  	}
			  	
 

ok_Hash.put("tDBOutput_1", true);
end_Hash.put("tDBOutput_1", System.currentTimeMillis());




/**
 * [tDBOutput_1 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tStatCatcher_1 finally ] start
	 */

	

	
	
	currentComponent="tStatCatcher_1";

	

 



/**
 * [tStatCatcher_1 finally ] stop
 */

	
	/**
	 * [tDBOutput_1 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";

	



    try {
    if (resourceMap.get("statementClosed_tDBOutput_1") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_1 = null;
                if ((pstmtToClose_tDBOutput_1 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_1")) != null) {
                    pstmtToClose_tDBOutput_1.close();
                }
    }
    } finally {
        if(resourceMap.get("finish_tDBOutput_1") == null){
            java.sql.Connection ctn_tDBOutput_1 = null;
            if((ctn_tDBOutput_1 = (java.sql.Connection)resourceMap.get("conn_tDBOutput_1")) != null){
                try {
                    ctn_tDBOutput_1.close();
                } catch (java.sql.SQLException sqlEx_tDBOutput_1) {
                    String errorMessage_tDBOutput_1 = "failed to close the connection in tDBOutput_1 :" + sqlEx_tDBOutput_1.getMessage();
                    System.err.println(errorMessage_tDBOutput_1);
                }
            }
        }
    }
 



/**
 * [tDBOutput_1 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tStatCatcher_1_SUBPROCESS_STATE", 1);
	}
	


public static class allim_adresse_normStruct implements routines.system.IPersistableRow<allim_adresse_normStruct> {
    final static byte[] commonByteArrayLock_ALIMENTATION_DM1_E_ALIM_DIM = new byte[0];
    static byte[] commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int id_adresse_norm_client;

				public int getId_adresse_norm_client () {
					return this.id_adresse_norm_client;
				}
				
			    public Integer id_adresse_norm_client_src;

				public Integer getId_adresse_norm_client_src () {
					return this.id_adresse_norm_client_src;
				}
				
			    public String numero_voie;

				public String getNumero_voie () {
					return this.numero_voie;
				}
				
			    public String nom_voie;

				public String getNom_voie () {
					return this.nom_voie;
				}
				
			    public String code_postal;

				public String getCode_postal () {
					return this.code_postal;
				}
				
			    public String nom_ville;

				public String getNom_ville () {
					return this.nom_ville;
				}
				
			    public String longitude;

				public String getLongitude () {
					return this.longitude;
				}
				
			    public String latitude;

				public String getLatitude () {
					return this.latitude;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.id_adresse_norm_client;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final allim_adresse_normStruct other = (allim_adresse_normStruct) obj;
		
						if (this.id_adresse_norm_client != other.id_adresse_norm_client)
							return false;
					

		return true;
    }

	public void copyDataTo(allim_adresse_normStruct other) {

		other.id_adresse_norm_client = this.id_adresse_norm_client;
	            other.id_adresse_norm_client_src = this.id_adresse_norm_client_src;
	            other.numero_voie = this.numero_voie;
	            other.nom_voie = this.nom_voie;
	            other.code_postal = this.code_postal;
	            other.nom_ville = this.nom_ville;
	            other.longitude = this.longitude;
	            other.latitude = this.latitude;
	            
	}

	public void copyKeysDataTo(allim_adresse_normStruct other) {

		other.id_adresse_norm_client = this.id_adresse_norm_client;
	            	
	}



	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM.length == 0) {
   					commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM.length == 0) {
   					commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_DM1_E_ALIM_DIM) {

        	try {

        		int length = 0;
		
			        this.id_adresse_norm_client = dis.readInt();
					
						this.id_adresse_norm_client_src = readInteger(dis);
					
					this.numero_voie = readString(dis);
					
					this.nom_voie = readString(dis);
					
					this.code_postal = readString(dis);
					
					this.nom_ville = readString(dis);
					
					this.longitude = readString(dis);
					
					this.latitude = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_DM1_E_ALIM_DIM) {

        	try {

        		int length = 0;
		
			        this.id_adresse_norm_client = dis.readInt();
					
						this.id_adresse_norm_client_src = readInteger(dis);
					
					this.numero_voie = readString(dis);
					
					this.nom_voie = readString(dis);
					
					this.code_postal = readString(dis);
					
					this.nom_ville = readString(dis);
					
					this.longitude = readString(dis);
					
					this.latitude = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id_adresse_norm_client);
					
					// Integer
				
						writeInteger(this.id_adresse_norm_client_src,dos);
					
					// String
				
						writeString(this.numero_voie,dos);
					
					// String
				
						writeString(this.nom_voie,dos);
					
					// String
				
						writeString(this.code_postal,dos);
					
					// String
				
						writeString(this.nom_ville,dos);
					
					// String
				
						writeString(this.longitude,dos);
					
					// String
				
						writeString(this.latitude,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id_adresse_norm_client);
					
					// Integer
				
						writeInteger(this.id_adresse_norm_client_src,dos);
					
					// String
				
						writeString(this.numero_voie,dos);
					
					// String
				
						writeString(this.nom_voie,dos);
					
					// String
				
						writeString(this.code_postal,dos);
					
					// String
				
						writeString(this.nom_ville,dos);
					
					// String
				
						writeString(this.longitude,dos);
					
					// String
				
						writeString(this.latitude,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id_adresse_norm_client="+String.valueOf(id_adresse_norm_client));
		sb.append(",id_adresse_norm_client_src="+String.valueOf(id_adresse_norm_client_src));
		sb.append(",numero_voie="+numero_voie);
		sb.append(",nom_voie="+nom_voie);
		sb.append(",code_postal="+code_postal);
		sb.append(",nom_ville="+nom_ville);
		sb.append(",longitude="+longitude);
		sb.append(",latitude="+latitude);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(allim_adresse_normStruct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.id_adresse_norm_client, other.id_adresse_norm_client);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class alim_adresse_norm_restauStruct implements routines.system.IPersistableRow<alim_adresse_norm_restauStruct> {
    final static byte[] commonByteArrayLock_ALIMENTATION_DM1_E_ALIM_DIM = new byte[0];
    static byte[] commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int id_adresse_norm_restaurant;

				public int getId_adresse_norm_restaurant () {
					return this.id_adresse_norm_restaurant;
				}
				
			    public Integer id_adresse_norm_restau_src;

				public Integer getId_adresse_norm_restau_src () {
					return this.id_adresse_norm_restau_src;
				}
				
			    public String numero_voie;

				public String getNumero_voie () {
					return this.numero_voie;
				}
				
			    public String nom_voie;

				public String getNom_voie () {
					return this.nom_voie;
				}
				
			    public String code_postal;

				public String getCode_postal () {
					return this.code_postal;
				}
				
			    public String nom_ville;

				public String getNom_ville () {
					return this.nom_ville;
				}
				
			    public String longitude;

				public String getLongitude () {
					return this.longitude;
				}
				
			    public String latitude;

				public String getLatitude () {
					return this.latitude;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.id_adresse_norm_restaurant;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final alim_adresse_norm_restauStruct other = (alim_adresse_norm_restauStruct) obj;
		
						if (this.id_adresse_norm_restaurant != other.id_adresse_norm_restaurant)
							return false;
					

		return true;
    }

	public void copyDataTo(alim_adresse_norm_restauStruct other) {

		other.id_adresse_norm_restaurant = this.id_adresse_norm_restaurant;
	            other.id_adresse_norm_restau_src = this.id_adresse_norm_restau_src;
	            other.numero_voie = this.numero_voie;
	            other.nom_voie = this.nom_voie;
	            other.code_postal = this.code_postal;
	            other.nom_ville = this.nom_ville;
	            other.longitude = this.longitude;
	            other.latitude = this.latitude;
	            
	}

	public void copyKeysDataTo(alim_adresse_norm_restauStruct other) {

		other.id_adresse_norm_restaurant = this.id_adresse_norm_restaurant;
	            	
	}



	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM.length == 0) {
   					commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM.length == 0) {
   					commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_DM1_E_ALIM_DIM) {

        	try {

        		int length = 0;
		
			        this.id_adresse_norm_restaurant = dis.readInt();
					
						this.id_adresse_norm_restau_src = readInteger(dis);
					
					this.numero_voie = readString(dis);
					
					this.nom_voie = readString(dis);
					
					this.code_postal = readString(dis);
					
					this.nom_ville = readString(dis);
					
					this.longitude = readString(dis);
					
					this.latitude = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_DM1_E_ALIM_DIM) {

        	try {

        		int length = 0;
		
			        this.id_adresse_norm_restaurant = dis.readInt();
					
						this.id_adresse_norm_restau_src = readInteger(dis);
					
					this.numero_voie = readString(dis);
					
					this.nom_voie = readString(dis);
					
					this.code_postal = readString(dis);
					
					this.nom_ville = readString(dis);
					
					this.longitude = readString(dis);
					
					this.latitude = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id_adresse_norm_restaurant);
					
					// Integer
				
						writeInteger(this.id_adresse_norm_restau_src,dos);
					
					// String
				
						writeString(this.numero_voie,dos);
					
					// String
				
						writeString(this.nom_voie,dos);
					
					// String
				
						writeString(this.code_postal,dos);
					
					// String
				
						writeString(this.nom_ville,dos);
					
					// String
				
						writeString(this.longitude,dos);
					
					// String
				
						writeString(this.latitude,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id_adresse_norm_restaurant);
					
					// Integer
				
						writeInteger(this.id_adresse_norm_restau_src,dos);
					
					// String
				
						writeString(this.numero_voie,dos);
					
					// String
				
						writeString(this.nom_voie,dos);
					
					// String
				
						writeString(this.code_postal,dos);
					
					// String
				
						writeString(this.nom_ville,dos);
					
					// String
				
						writeString(this.longitude,dos);
					
					// String
				
						writeString(this.latitude,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id_adresse_norm_restaurant="+String.valueOf(id_adresse_norm_restaurant));
		sb.append(",id_adresse_norm_restau_src="+String.valueOf(id_adresse_norm_restau_src));
		sb.append(",numero_voie="+numero_voie);
		sb.append(",nom_voie="+nom_voie);
		sb.append(",code_postal="+code_postal);
		sb.append(",nom_ville="+nom_ville);
		sb.append(",longitude="+longitude);
		sb.append(",latitude="+latitude);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(alim_adresse_norm_restauStruct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.id_adresse_norm_restaurant, other.id_adresse_norm_restaurant);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class alim_clientStruct implements routines.system.IPersistableRow<alim_clientStruct> {
    final static byte[] commonByteArrayLock_ALIMENTATION_DM1_E_ALIM_DIM = new byte[0];
    static byte[] commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int id_client;

				public int getId_client () {
					return this.id_client;
				}
				
			    public Integer id_client_src;

				public Integer getId_client_src () {
					return this.id_client_src;
				}
				
			    public String nom_client;

				public String getNom_client () {
					return this.nom_client;
				}
				
			    public String prenom_client;

				public String getPrenom_client () {
					return this.prenom_client;
				}
				
			    public String nom_precedent;

				public String getNom_precedent () {
					return this.nom_precedent;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.id_client;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final alim_clientStruct other = (alim_clientStruct) obj;
		
						if (this.id_client != other.id_client)
							return false;
					

		return true;
    }

	public void copyDataTo(alim_clientStruct other) {

		other.id_client = this.id_client;
	            other.id_client_src = this.id_client_src;
	            other.nom_client = this.nom_client;
	            other.prenom_client = this.prenom_client;
	            other.nom_precedent = this.nom_precedent;
	            
	}

	public void copyKeysDataTo(alim_clientStruct other) {

		other.id_client = this.id_client;
	            	
	}



	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM.length == 0) {
   					commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM.length == 0) {
   					commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_DM1_E_ALIM_DIM) {

        	try {

        		int length = 0;
		
			        this.id_client = dis.readInt();
					
						this.id_client_src = readInteger(dis);
					
					this.nom_client = readString(dis);
					
					this.prenom_client = readString(dis);
					
					this.nom_precedent = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_DM1_E_ALIM_DIM) {

        	try {

        		int length = 0;
		
			        this.id_client = dis.readInt();
					
						this.id_client_src = readInteger(dis);
					
					this.nom_client = readString(dis);
					
					this.prenom_client = readString(dis);
					
					this.nom_precedent = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id_client);
					
					// Integer
				
						writeInteger(this.id_client_src,dos);
					
					// String
				
						writeString(this.nom_client,dos);
					
					// String
				
						writeString(this.prenom_client,dos);
					
					// String
				
						writeString(this.nom_precedent,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id_client);
					
					// Integer
				
						writeInteger(this.id_client_src,dos);
					
					// String
				
						writeString(this.nom_client,dos);
					
					// String
				
						writeString(this.prenom_client,dos);
					
					// String
				
						writeString(this.nom_precedent,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id_client="+String.valueOf(id_client));
		sb.append(",id_client_src="+String.valueOf(id_client_src));
		sb.append(",nom_client="+nom_client);
		sb.append(",prenom_client="+prenom_client);
		sb.append(",nom_precedent="+nom_precedent);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(alim_clientStruct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.id_client, other.id_client);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class aim_date_commandeStruct implements routines.system.IPersistableRow<aim_date_commandeStruct> {
    final static byte[] commonByteArrayLock_ALIMENTATION_DM1_E_ALIM_DIM = new byte[0];
    static byte[] commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int id_date_commande;

				public int getId_date_commande () {
					return this.id_date_commande;
				}
				
			    public java.util.Date date_commande;

				public java.util.Date getDate_commande () {
					return this.date_commande;
				}
				
			    public String jour;

				public String getJour () {
					return this.jour;
				}
				
			    public String semaine;

				public String getSemaine () {
					return this.semaine;
				}
				
			    public String mois;

				public String getMois () {
					return this.mois;
				}
				
			    public String annee;

				public String getAnnee () {
					return this.annee;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.id_date_commande;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final aim_date_commandeStruct other = (aim_date_commandeStruct) obj;
		
						if (this.id_date_commande != other.id_date_commande)
							return false;
					

		return true;
    }

	public void copyDataTo(aim_date_commandeStruct other) {

		other.id_date_commande = this.id_date_commande;
	            other.date_commande = this.date_commande;
	            other.jour = this.jour;
	            other.semaine = this.semaine;
	            other.mois = this.mois;
	            other.annee = this.annee;
	            
	}

	public void copyKeysDataTo(aim_date_commandeStruct other) {

		other.id_date_commande = this.id_date_commande;
	            	
	}




	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM.length == 0) {
   					commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM.length == 0) {
   					commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_DM1_E_ALIM_DIM) {

        	try {

        		int length = 0;
		
			        this.id_date_commande = dis.readInt();
					
					this.date_commande = readDate(dis);
					
					this.jour = readString(dis);
					
					this.semaine = readString(dis);
					
					this.mois = readString(dis);
					
					this.annee = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_DM1_E_ALIM_DIM) {

        	try {

        		int length = 0;
		
			        this.id_date_commande = dis.readInt();
					
					this.date_commande = readDate(dis);
					
					this.jour = readString(dis);
					
					this.semaine = readString(dis);
					
					this.mois = readString(dis);
					
					this.annee = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id_date_commande);
					
					// java.util.Date
				
						writeDate(this.date_commande,dos);
					
					// String
				
						writeString(this.jour,dos);
					
					// String
				
						writeString(this.semaine,dos);
					
					// String
				
						writeString(this.mois,dos);
					
					// String
				
						writeString(this.annee,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id_date_commande);
					
					// java.util.Date
				
						writeDate(this.date_commande,dos);
					
					// String
				
						writeString(this.jour,dos);
					
					// String
				
						writeString(this.semaine,dos);
					
					// String
				
						writeString(this.mois,dos);
					
					// String
				
						writeString(this.annee,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id_date_commande="+String.valueOf(id_date_commande));
		sb.append(",date_commande="+String.valueOf(date_commande));
		sb.append(",jour="+jour);
		sb.append(",semaine="+semaine);
		sb.append(",mois="+mois);
		sb.append(",annee="+annee);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(aim_date_commandeStruct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.id_date_commande, other.id_date_commande);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class alim_moyen_paiementStruct implements routines.system.IPersistableRow<alim_moyen_paiementStruct> {
    final static byte[] commonByteArrayLock_ALIMENTATION_DM1_E_ALIM_DIM = new byte[0];
    static byte[] commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int id_moyen_paiement;

				public int getId_moyen_paiement () {
					return this.id_moyen_paiement;
				}
				
			    public Integer id_moyen_paiement_src;

				public Integer getId_moyen_paiement_src () {
					return this.id_moyen_paiement_src;
				}
				
			    public String code_moyen_paiement;

				public String getCode_moyen_paiement () {
					return this.code_moyen_paiement;
				}
				
			    public String livelle_moyen_paiement;

				public String getLivelle_moyen_paiement () {
					return this.livelle_moyen_paiement;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.id_moyen_paiement;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final alim_moyen_paiementStruct other = (alim_moyen_paiementStruct) obj;
		
						if (this.id_moyen_paiement != other.id_moyen_paiement)
							return false;
					

		return true;
    }

	public void copyDataTo(alim_moyen_paiementStruct other) {

		other.id_moyen_paiement = this.id_moyen_paiement;
	            other.id_moyen_paiement_src = this.id_moyen_paiement_src;
	            other.code_moyen_paiement = this.code_moyen_paiement;
	            other.livelle_moyen_paiement = this.livelle_moyen_paiement;
	            
	}

	public void copyKeysDataTo(alim_moyen_paiementStruct other) {

		other.id_moyen_paiement = this.id_moyen_paiement;
	            	
	}



	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM.length == 0) {
   					commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM.length == 0) {
   					commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_DM1_E_ALIM_DIM) {

        	try {

        		int length = 0;
		
			        this.id_moyen_paiement = dis.readInt();
					
						this.id_moyen_paiement_src = readInteger(dis);
					
					this.code_moyen_paiement = readString(dis);
					
					this.livelle_moyen_paiement = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_DM1_E_ALIM_DIM) {

        	try {

        		int length = 0;
		
			        this.id_moyen_paiement = dis.readInt();
					
						this.id_moyen_paiement_src = readInteger(dis);
					
					this.code_moyen_paiement = readString(dis);
					
					this.livelle_moyen_paiement = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id_moyen_paiement);
					
					// Integer
				
						writeInteger(this.id_moyen_paiement_src,dos);
					
					// String
				
						writeString(this.code_moyen_paiement,dos);
					
					// String
				
						writeString(this.livelle_moyen_paiement,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id_moyen_paiement);
					
					// Integer
				
						writeInteger(this.id_moyen_paiement_src,dos);
					
					// String
				
						writeString(this.code_moyen_paiement,dos);
					
					// String
				
						writeString(this.livelle_moyen_paiement,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id_moyen_paiement="+String.valueOf(id_moyen_paiement));
		sb.append(",id_moyen_paiement_src="+String.valueOf(id_moyen_paiement_src));
		sb.append(",code_moyen_paiement="+code_moyen_paiement);
		sb.append(",livelle_moyen_paiement="+livelle_moyen_paiement);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(alim_moyen_paiementStruct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.id_moyen_paiement, other.id_moyen_paiement);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class alim_preparationStruct implements routines.system.IPersistableRow<alim_preparationStruct> {
    final static byte[] commonByteArrayLock_ALIMENTATION_DM1_E_ALIM_DIM = new byte[0];
    static byte[] commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int id_preparation;

				public int getId_preparation () {
					return this.id_preparation;
				}
				
			    public Integer id_preparation_src;

				public Integer getId_preparation_src () {
					return this.id_preparation_src;
				}
				
			    public java.util.Date date_debut_preparation;

				public java.util.Date getDate_debut_preparation () {
					return this.date_debut_preparation;
				}
				
			    public java.util.Date date_fin_preparation;

				public java.util.Date getDate_fin_preparation () {
					return this.date_fin_preparation;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.id_preparation;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final alim_preparationStruct other = (alim_preparationStruct) obj;
		
						if (this.id_preparation != other.id_preparation)
							return false;
					

		return true;
    }

	public void copyDataTo(alim_preparationStruct other) {

		other.id_preparation = this.id_preparation;
	            other.id_preparation_src = this.id_preparation_src;
	            other.date_debut_preparation = this.date_debut_preparation;
	            other.date_fin_preparation = this.date_fin_preparation;
	            
	}

	public void copyKeysDataTo(alim_preparationStruct other) {

		other.id_preparation = this.id_preparation;
	            	
	}



	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_DM1_E_ALIM_DIM) {

        	try {

        		int length = 0;
		
			        this.id_preparation = dis.readInt();
					
						this.id_preparation_src = readInteger(dis);
					
					this.date_debut_preparation = readDate(dis);
					
					this.date_fin_preparation = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_DM1_E_ALIM_DIM) {

        	try {

        		int length = 0;
		
			        this.id_preparation = dis.readInt();
					
						this.id_preparation_src = readInteger(dis);
					
					this.date_debut_preparation = readDate(dis);
					
					this.date_fin_preparation = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id_preparation);
					
					// Integer
				
						writeInteger(this.id_preparation_src,dos);
					
					// java.util.Date
				
						writeDate(this.date_debut_preparation,dos);
					
					// java.util.Date
				
						writeDate(this.date_fin_preparation,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id_preparation);
					
					// Integer
				
						writeInteger(this.id_preparation_src,dos);
					
					// java.util.Date
				
						writeDate(this.date_debut_preparation,dos);
					
					// java.util.Date
				
						writeDate(this.date_fin_preparation,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id_preparation="+String.valueOf(id_preparation));
		sb.append(",id_preparation_src="+String.valueOf(id_preparation_src));
		sb.append(",date_debut_preparation="+String.valueOf(date_debut_preparation));
		sb.append(",date_fin_preparation="+String.valueOf(date_fin_preparation));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(alim_preparationStruct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.id_preparation, other.id_preparation);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class alim_restauStruct implements routines.system.IPersistableRow<alim_restauStruct> {
    final static byte[] commonByteArrayLock_ALIMENTATION_DM1_E_ALIM_DIM = new byte[0];
    static byte[] commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int id_restaurant;

				public int getId_restaurant () {
					return this.id_restaurant;
				}
				
			    public Integer id_restaurant_src;

				public Integer getId_restaurant_src () {
					return this.id_restaurant_src;
				}
				
			    public String code_restaurant;

				public String getCode_restaurant () {
					return this.code_restaurant;
				}
				
			    public String raison_sociale_restaurant;

				public String getRaison_sociale_restaurant () {
					return this.raison_sociale_restaurant;
				}
				
			    public java.util.Date scd_start;

				public java.util.Date getScd_start () {
					return this.scd_start;
				}
				
			    public java.util.Date scd_end;

				public java.util.Date getScd_end () {
					return this.scd_end;
				}
				
			    public Integer scd_version;

				public Integer getScd_version () {
					return this.scd_version;
				}
				
			    public String scd_active;

				public String getScd_active () {
					return this.scd_active;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.id_restaurant;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final alim_restauStruct other = (alim_restauStruct) obj;
		
						if (this.id_restaurant != other.id_restaurant)
							return false;
					

		return true;
    }

	public void copyDataTo(alim_restauStruct other) {

		other.id_restaurant = this.id_restaurant;
	            other.id_restaurant_src = this.id_restaurant_src;
	            other.code_restaurant = this.code_restaurant;
	            other.raison_sociale_restaurant = this.raison_sociale_restaurant;
	            other.scd_start = this.scd_start;
	            other.scd_end = this.scd_end;
	            other.scd_version = this.scd_version;
	            other.scd_active = this.scd_active;
	            
	}

	public void copyKeysDataTo(alim_restauStruct other) {

		other.id_restaurant = this.id_restaurant;
	            	
	}



	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM.length == 0) {
   					commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM.length == 0) {
   					commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_DM1_E_ALIM_DIM) {

        	try {

        		int length = 0;
		
			        this.id_restaurant = dis.readInt();
					
						this.id_restaurant_src = readInteger(dis);
					
					this.code_restaurant = readString(dis);
					
					this.raison_sociale_restaurant = readString(dis);
					
					this.scd_start = readDate(dis);
					
					this.scd_end = readDate(dis);
					
						this.scd_version = readInteger(dis);
					
					this.scd_active = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_DM1_E_ALIM_DIM) {

        	try {

        		int length = 0;
		
			        this.id_restaurant = dis.readInt();
					
						this.id_restaurant_src = readInteger(dis);
					
					this.code_restaurant = readString(dis);
					
					this.raison_sociale_restaurant = readString(dis);
					
					this.scd_start = readDate(dis);
					
					this.scd_end = readDate(dis);
					
						this.scd_version = readInteger(dis);
					
					this.scd_active = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id_restaurant);
					
					// Integer
				
						writeInteger(this.id_restaurant_src,dos);
					
					// String
				
						writeString(this.code_restaurant,dos);
					
					// String
				
						writeString(this.raison_sociale_restaurant,dos);
					
					// java.util.Date
				
						writeDate(this.scd_start,dos);
					
					// java.util.Date
				
						writeDate(this.scd_end,dos);
					
					// Integer
				
						writeInteger(this.scd_version,dos);
					
					// String
				
						writeString(this.scd_active,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id_restaurant);
					
					// Integer
				
						writeInteger(this.id_restaurant_src,dos);
					
					// String
				
						writeString(this.code_restaurant,dos);
					
					// String
				
						writeString(this.raison_sociale_restaurant,dos);
					
					// java.util.Date
				
						writeDate(this.scd_start,dos);
					
					// java.util.Date
				
						writeDate(this.scd_end,dos);
					
					// Integer
				
						writeInteger(this.scd_version,dos);
					
					// String
				
						writeString(this.scd_active,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id_restaurant="+String.valueOf(id_restaurant));
		sb.append(",id_restaurant_src="+String.valueOf(id_restaurant_src));
		sb.append(",code_restaurant="+code_restaurant);
		sb.append(",raison_sociale_restaurant="+raison_sociale_restaurant);
		sb.append(",scd_start="+String.valueOf(scd_start));
		sb.append(",scd_end="+String.valueOf(scd_end));
		sb.append(",scd_version="+String.valueOf(scd_version));
		sb.append(",scd_active="+scd_active);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(alim_restauStruct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.id_restaurant, other.id_restaurant);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class alim_menuStruct implements routines.system.IPersistableRow<alim_menuStruct> {
    final static byte[] commonByteArrayLock_ALIMENTATION_DM1_E_ALIM_DIM = new byte[0];
    static byte[] commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int id_menu;

				public int getId_menu () {
					return this.id_menu;
				}
				
			    public Integer id_menu_src;

				public Integer getId_menu_src () {
					return this.id_menu_src;
				}
				
			    public String code_menu;

				public String getCode_menu () {
					return this.code_menu;
				}
				
			    public String libelle_menu;

				public String getLibelle_menu () {
					return this.libelle_menu;
				}
				
			    public Integer nombre_articles;

				public Integer getNombre_articles () {
					return this.nombre_articles;
				}
				
			    public String temps_theo_preparation;

				public String getTemps_theo_preparation () {
					return this.temps_theo_preparation;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.id_menu;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final alim_menuStruct other = (alim_menuStruct) obj;
		
						if (this.id_menu != other.id_menu)
							return false;
					

		return true;
    }

	public void copyDataTo(alim_menuStruct other) {

		other.id_menu = this.id_menu;
	            other.id_menu_src = this.id_menu_src;
	            other.code_menu = this.code_menu;
	            other.libelle_menu = this.libelle_menu;
	            other.nombre_articles = this.nombre_articles;
	            other.temps_theo_preparation = this.temps_theo_preparation;
	            
	}

	public void copyKeysDataTo(alim_menuStruct other) {

		other.id_menu = this.id_menu;
	            	
	}



	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM.length == 0) {
   					commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM.length == 0) {
   					commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_DM1_E_ALIM_DIM) {

        	try {

        		int length = 0;
		
			        this.id_menu = dis.readInt();
					
						this.id_menu_src = readInteger(dis);
					
					this.code_menu = readString(dis);
					
					this.libelle_menu = readString(dis);
					
						this.nombre_articles = readInteger(dis);
					
					this.temps_theo_preparation = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_DM1_E_ALIM_DIM) {

        	try {

        		int length = 0;
		
			        this.id_menu = dis.readInt();
					
						this.id_menu_src = readInteger(dis);
					
					this.code_menu = readString(dis);
					
					this.libelle_menu = readString(dis);
					
						this.nombre_articles = readInteger(dis);
					
					this.temps_theo_preparation = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id_menu);
					
					// Integer
				
						writeInteger(this.id_menu_src,dos);
					
					// String
				
						writeString(this.code_menu,dos);
					
					// String
				
						writeString(this.libelle_menu,dos);
					
					// Integer
				
						writeInteger(this.nombre_articles,dos);
					
					// String
				
						writeString(this.temps_theo_preparation,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id_menu);
					
					// Integer
				
						writeInteger(this.id_menu_src,dos);
					
					// String
				
						writeString(this.code_menu,dos);
					
					// String
				
						writeString(this.libelle_menu,dos);
					
					// Integer
				
						writeInteger(this.nombre_articles,dos);
					
					// String
				
						writeString(this.temps_theo_preparation,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id_menu="+String.valueOf(id_menu));
		sb.append(",id_menu_src="+String.valueOf(id_menu_src));
		sb.append(",code_menu="+code_menu);
		sb.append(",libelle_menu="+libelle_menu);
		sb.append(",nombre_articles="+String.valueOf(nombre_articles));
		sb.append(",temps_theo_preparation="+temps_theo_preparation);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(alim_menuStruct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.id_menu, other.id_menu);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row2Struct implements routines.system.IPersistableRow<row2Struct> {
    final static byte[] commonByteArrayLock_ALIMENTATION_DM1_E_ALIM_DIM = new byte[0];
    static byte[] commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM = new byte[0];

	
			    public int id_ods_dm1;

				public int getId_ods_dm1 () {
					return this.id_ods_dm1;
				}
				
			    public Integer id_preparation;

				public Integer getId_preparation () {
					return this.id_preparation;
				}
				
			    public java.util.Date date_debut_preparation;

				public java.util.Date getDate_debut_preparation () {
					return this.date_debut_preparation;
				}
				
			    public java.util.Date date_fin_preparation;

				public java.util.Date getDate_fin_preparation () {
					return this.date_fin_preparation;
				}
				
			    public String temps_reel_preparation;

				public String getTemps_reel_preparation () {
					return this.temps_reel_preparation;
				}
				
			    public Integer id_moyen_paiement;

				public Integer getId_moyen_paiement () {
					return this.id_moyen_paiement;
				}
				
			    public String code_moyen_paiement;

				public String getCode_moyen_paiement () {
					return this.code_moyen_paiement;
				}
				
			    public String livelle_moyen_paiement;

				public String getLivelle_moyen_paiement () {
					return this.livelle_moyen_paiement;
				}
				
			    public Integer id_menu;

				public Integer getId_menu () {
					return this.id_menu;
				}
				
			    public String code_menu;

				public String getCode_menu () {
					return this.code_menu;
				}
				
			    public String libelle_menu;

				public String getLibelle_menu () {
					return this.libelle_menu;
				}
				
			    public Integer nombre_articles;

				public Integer getNombre_articles () {
					return this.nombre_articles;
				}
				
			    public String temps_theo_preparation;

				public String getTemps_theo_preparation () {
					return this.temps_theo_preparation;
				}
				
			    public Integer id_commande;

				public Integer getId_commande () {
					return this.id_commande;
				}
				
			    public Integer numero_commande;

				public Integer getNumero_commande () {
					return this.numero_commande;
				}
				
			    public java.util.Date date_commande;

				public java.util.Date getDate_commande () {
					return this.date_commande;
				}
				
			    public Float montant_total;

				public Float getMontant_total () {
					return this.montant_total;
				}
				
			    public Integer id_adresse_norm_restaurant;

				public Integer getId_adresse_norm_restaurant () {
					return this.id_adresse_norm_restaurant;
				}
				
			    public String numero_voie_restau;

				public String getNumero_voie_restau () {
					return this.numero_voie_restau;
				}
				
			    public String nom_voie_restau;

				public String getNom_voie_restau () {
					return this.nom_voie_restau;
				}
				
			    public String code_postal_restau;

				public String getCode_postal_restau () {
					return this.code_postal_restau;
				}
				
			    public String nom_ville_restau;

				public String getNom_ville_restau () {
					return this.nom_ville_restau;
				}
				
			    public String longitude_restau;

				public String getLongitude_restau () {
					return this.longitude_restau;
				}
				
			    public String latitude_restau;

				public String getLatitude_restau () {
					return this.latitude_restau;
				}
				
			    public Integer id_adresse_restaurant;

				public Integer getId_adresse_restaurant () {
					return this.id_adresse_restaurant;
				}
				
			    public String adresse_restaurant;

				public String getAdresse_restaurant () {
					return this.adresse_restaurant;
				}
				
			    public Integer id_restaurant;

				public Integer getId_restaurant () {
					return this.id_restaurant;
				}
				
			    public String code_restaurant;

				public String getCode_restaurant () {
					return this.code_restaurant;
				}
				
			    public String raison_sociale_restaurant;

				public String getRaison_sociale_restaurant () {
					return this.raison_sociale_restaurant;
				}
				
			    public Integer id_adresse_norm_client;

				public Integer getId_adresse_norm_client () {
					return this.id_adresse_norm_client;
				}
				
			    public String numero_voie;

				public String getNumero_voie () {
					return this.numero_voie;
				}
				
			    public String nom_voie;

				public String getNom_voie () {
					return this.nom_voie;
				}
				
			    public String code_postal;

				public String getCode_postal () {
					return this.code_postal;
				}
				
			    public String nom_ville;

				public String getNom_ville () {
					return this.nom_ville;
				}
				
			    public String longitude;

				public String getLongitude () {
					return this.longitude;
				}
				
			    public String latitude;

				public String getLatitude () {
					return this.latitude;
				}
				
			    public Integer id_adresse_client;

				public Integer getId_adresse_client () {
					return this.id_adresse_client;
				}
				
			    public String adresse_client;

				public String getAdresse_client () {
					return this.adresse_client;
				}
				
			    public Integer id_client;

				public Integer getId_client () {
					return this.id_client;
				}
				
			    public String nom_client;

				public String getNom_client () {
					return this.nom_client;
				}
				
			    public String prenom_client;

				public String getPrenom_client () {
					return this.prenom_client;
				}
				


	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM.length == 0) {
   					commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM.length == 0) {
   					commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_DM1_E_ALIM_DIM, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_DM1_E_ALIM_DIM) {

        	try {

        		int length = 0;
		
			        this.id_ods_dm1 = dis.readInt();
					
						this.id_preparation = readInteger(dis);
					
					this.date_debut_preparation = readDate(dis);
					
					this.date_fin_preparation = readDate(dis);
					
					this.temps_reel_preparation = readString(dis);
					
						this.id_moyen_paiement = readInteger(dis);
					
					this.code_moyen_paiement = readString(dis);
					
					this.livelle_moyen_paiement = readString(dis);
					
						this.id_menu = readInteger(dis);
					
					this.code_menu = readString(dis);
					
					this.libelle_menu = readString(dis);
					
						this.nombre_articles = readInteger(dis);
					
					this.temps_theo_preparation = readString(dis);
					
						this.id_commande = readInteger(dis);
					
						this.numero_commande = readInteger(dis);
					
					this.date_commande = readDate(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.montant_total = null;
           				} else {
           			    	this.montant_total = dis.readFloat();
           				}
					
						this.id_adresse_norm_restaurant = readInteger(dis);
					
					this.numero_voie_restau = readString(dis);
					
					this.nom_voie_restau = readString(dis);
					
					this.code_postal_restau = readString(dis);
					
					this.nom_ville_restau = readString(dis);
					
					this.longitude_restau = readString(dis);
					
					this.latitude_restau = readString(dis);
					
						this.id_adresse_restaurant = readInteger(dis);
					
					this.adresse_restaurant = readString(dis);
					
						this.id_restaurant = readInteger(dis);
					
					this.code_restaurant = readString(dis);
					
					this.raison_sociale_restaurant = readString(dis);
					
						this.id_adresse_norm_client = readInteger(dis);
					
					this.numero_voie = readString(dis);
					
					this.nom_voie = readString(dis);
					
					this.code_postal = readString(dis);
					
					this.nom_ville = readString(dis);
					
					this.longitude = readString(dis);
					
					this.latitude = readString(dis);
					
						this.id_adresse_client = readInteger(dis);
					
					this.adresse_client = readString(dis);
					
						this.id_client = readInteger(dis);
					
					this.nom_client = readString(dis);
					
					this.prenom_client = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_DM1_E_ALIM_DIM) {

        	try {

        		int length = 0;
		
			        this.id_ods_dm1 = dis.readInt();
					
						this.id_preparation = readInteger(dis);
					
					this.date_debut_preparation = readDate(dis);
					
					this.date_fin_preparation = readDate(dis);
					
					this.temps_reel_preparation = readString(dis);
					
						this.id_moyen_paiement = readInteger(dis);
					
					this.code_moyen_paiement = readString(dis);
					
					this.livelle_moyen_paiement = readString(dis);
					
						this.id_menu = readInteger(dis);
					
					this.code_menu = readString(dis);
					
					this.libelle_menu = readString(dis);
					
						this.nombre_articles = readInteger(dis);
					
					this.temps_theo_preparation = readString(dis);
					
						this.id_commande = readInteger(dis);
					
						this.numero_commande = readInteger(dis);
					
					this.date_commande = readDate(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.montant_total = null;
           				} else {
           			    	this.montant_total = dis.readFloat();
           				}
					
						this.id_adresse_norm_restaurant = readInteger(dis);
					
					this.numero_voie_restau = readString(dis);
					
					this.nom_voie_restau = readString(dis);
					
					this.code_postal_restau = readString(dis);
					
					this.nom_ville_restau = readString(dis);
					
					this.longitude_restau = readString(dis);
					
					this.latitude_restau = readString(dis);
					
						this.id_adresse_restaurant = readInteger(dis);
					
					this.adresse_restaurant = readString(dis);
					
						this.id_restaurant = readInteger(dis);
					
					this.code_restaurant = readString(dis);
					
					this.raison_sociale_restaurant = readString(dis);
					
						this.id_adresse_norm_client = readInteger(dis);
					
					this.numero_voie = readString(dis);
					
					this.nom_voie = readString(dis);
					
					this.code_postal = readString(dis);
					
					this.nom_ville = readString(dis);
					
					this.longitude = readString(dis);
					
					this.latitude = readString(dis);
					
						this.id_adresse_client = readInteger(dis);
					
					this.adresse_client = readString(dis);
					
						this.id_client = readInteger(dis);
					
					this.nom_client = readString(dis);
					
					this.prenom_client = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id_ods_dm1);
					
					// Integer
				
						writeInteger(this.id_preparation,dos);
					
					// java.util.Date
				
						writeDate(this.date_debut_preparation,dos);
					
					// java.util.Date
				
						writeDate(this.date_fin_preparation,dos);
					
					// String
				
						writeString(this.temps_reel_preparation,dos);
					
					// Integer
				
						writeInteger(this.id_moyen_paiement,dos);
					
					// String
				
						writeString(this.code_moyen_paiement,dos);
					
					// String
				
						writeString(this.livelle_moyen_paiement,dos);
					
					// Integer
				
						writeInteger(this.id_menu,dos);
					
					// String
				
						writeString(this.code_menu,dos);
					
					// String
				
						writeString(this.libelle_menu,dos);
					
					// Integer
				
						writeInteger(this.nombre_articles,dos);
					
					// String
				
						writeString(this.temps_theo_preparation,dos);
					
					// Integer
				
						writeInteger(this.id_commande,dos);
					
					// Integer
				
						writeInteger(this.numero_commande,dos);
					
					// java.util.Date
				
						writeDate(this.date_commande,dos);
					
					// Float
				
						if(this.montant_total == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.montant_total);
		            	}
					
					// Integer
				
						writeInteger(this.id_adresse_norm_restaurant,dos);
					
					// String
				
						writeString(this.numero_voie_restau,dos);
					
					// String
				
						writeString(this.nom_voie_restau,dos);
					
					// String
				
						writeString(this.code_postal_restau,dos);
					
					// String
				
						writeString(this.nom_ville_restau,dos);
					
					// String
				
						writeString(this.longitude_restau,dos);
					
					// String
				
						writeString(this.latitude_restau,dos);
					
					// Integer
				
						writeInteger(this.id_adresse_restaurant,dos);
					
					// String
				
						writeString(this.adresse_restaurant,dos);
					
					// Integer
				
						writeInteger(this.id_restaurant,dos);
					
					// String
				
						writeString(this.code_restaurant,dos);
					
					// String
				
						writeString(this.raison_sociale_restaurant,dos);
					
					// Integer
				
						writeInteger(this.id_adresse_norm_client,dos);
					
					// String
				
						writeString(this.numero_voie,dos);
					
					// String
				
						writeString(this.nom_voie,dos);
					
					// String
				
						writeString(this.code_postal,dos);
					
					// String
				
						writeString(this.nom_ville,dos);
					
					// String
				
						writeString(this.longitude,dos);
					
					// String
				
						writeString(this.latitude,dos);
					
					// Integer
				
						writeInteger(this.id_adresse_client,dos);
					
					// String
				
						writeString(this.adresse_client,dos);
					
					// Integer
				
						writeInteger(this.id_client,dos);
					
					// String
				
						writeString(this.nom_client,dos);
					
					// String
				
						writeString(this.prenom_client,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id_ods_dm1);
					
					// Integer
				
						writeInteger(this.id_preparation,dos);
					
					// java.util.Date
				
						writeDate(this.date_debut_preparation,dos);
					
					// java.util.Date
				
						writeDate(this.date_fin_preparation,dos);
					
					// String
				
						writeString(this.temps_reel_preparation,dos);
					
					// Integer
				
						writeInteger(this.id_moyen_paiement,dos);
					
					// String
				
						writeString(this.code_moyen_paiement,dos);
					
					// String
				
						writeString(this.livelle_moyen_paiement,dos);
					
					// Integer
				
						writeInteger(this.id_menu,dos);
					
					// String
				
						writeString(this.code_menu,dos);
					
					// String
				
						writeString(this.libelle_menu,dos);
					
					// Integer
				
						writeInteger(this.nombre_articles,dos);
					
					// String
				
						writeString(this.temps_theo_preparation,dos);
					
					// Integer
				
						writeInteger(this.id_commande,dos);
					
					// Integer
				
						writeInteger(this.numero_commande,dos);
					
					// java.util.Date
				
						writeDate(this.date_commande,dos);
					
					// Float
				
						if(this.montant_total == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.montant_total);
		            	}
					
					// Integer
				
						writeInteger(this.id_adresse_norm_restaurant,dos);
					
					// String
				
						writeString(this.numero_voie_restau,dos);
					
					// String
				
						writeString(this.nom_voie_restau,dos);
					
					// String
				
						writeString(this.code_postal_restau,dos);
					
					// String
				
						writeString(this.nom_ville_restau,dos);
					
					// String
				
						writeString(this.longitude_restau,dos);
					
					// String
				
						writeString(this.latitude_restau,dos);
					
					// Integer
				
						writeInteger(this.id_adresse_restaurant,dos);
					
					// String
				
						writeString(this.adresse_restaurant,dos);
					
					// Integer
				
						writeInteger(this.id_restaurant,dos);
					
					// String
				
						writeString(this.code_restaurant,dos);
					
					// String
				
						writeString(this.raison_sociale_restaurant,dos);
					
					// Integer
				
						writeInteger(this.id_adresse_norm_client,dos);
					
					// String
				
						writeString(this.numero_voie,dos);
					
					// String
				
						writeString(this.nom_voie,dos);
					
					// String
				
						writeString(this.code_postal,dos);
					
					// String
				
						writeString(this.nom_ville,dos);
					
					// String
				
						writeString(this.longitude,dos);
					
					// String
				
						writeString(this.latitude,dos);
					
					// Integer
				
						writeInteger(this.id_adresse_client,dos);
					
					// String
				
						writeString(this.adresse_client,dos);
					
					// Integer
				
						writeInteger(this.id_client,dos);
					
					// String
				
						writeString(this.nom_client,dos);
					
					// String
				
						writeString(this.prenom_client,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id_ods_dm1="+String.valueOf(id_ods_dm1));
		sb.append(",id_preparation="+String.valueOf(id_preparation));
		sb.append(",date_debut_preparation="+String.valueOf(date_debut_preparation));
		sb.append(",date_fin_preparation="+String.valueOf(date_fin_preparation));
		sb.append(",temps_reel_preparation="+temps_reel_preparation);
		sb.append(",id_moyen_paiement="+String.valueOf(id_moyen_paiement));
		sb.append(",code_moyen_paiement="+code_moyen_paiement);
		sb.append(",livelle_moyen_paiement="+livelle_moyen_paiement);
		sb.append(",id_menu="+String.valueOf(id_menu));
		sb.append(",code_menu="+code_menu);
		sb.append(",libelle_menu="+libelle_menu);
		sb.append(",nombre_articles="+String.valueOf(nombre_articles));
		sb.append(",temps_theo_preparation="+temps_theo_preparation);
		sb.append(",id_commande="+String.valueOf(id_commande));
		sb.append(",numero_commande="+String.valueOf(numero_commande));
		sb.append(",date_commande="+String.valueOf(date_commande));
		sb.append(",montant_total="+String.valueOf(montant_total));
		sb.append(",id_adresse_norm_restaurant="+String.valueOf(id_adresse_norm_restaurant));
		sb.append(",numero_voie_restau="+numero_voie_restau);
		sb.append(",nom_voie_restau="+nom_voie_restau);
		sb.append(",code_postal_restau="+code_postal_restau);
		sb.append(",nom_ville_restau="+nom_ville_restau);
		sb.append(",longitude_restau="+longitude_restau);
		sb.append(",latitude_restau="+latitude_restau);
		sb.append(",id_adresse_restaurant="+String.valueOf(id_adresse_restaurant));
		sb.append(",adresse_restaurant="+adresse_restaurant);
		sb.append(",id_restaurant="+String.valueOf(id_restaurant));
		sb.append(",code_restaurant="+code_restaurant);
		sb.append(",raison_sociale_restaurant="+raison_sociale_restaurant);
		sb.append(",id_adresse_norm_client="+String.valueOf(id_adresse_norm_client));
		sb.append(",numero_voie="+numero_voie);
		sb.append(",nom_voie="+nom_voie);
		sb.append(",code_postal="+code_postal);
		sb.append(",nom_ville="+nom_ville);
		sb.append(",longitude="+longitude);
		sb.append(",latitude="+latitude);
		sb.append(",id_adresse_client="+String.valueOf(id_adresse_client));
		sb.append(",adresse_client="+adresse_client);
		sb.append(",id_client="+String.valueOf(id_client));
		sb.append(",nom_client="+nom_client);
		sb.append(",prenom_client="+prenom_client);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row2Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tDBInput_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBInput_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row2Struct row2 = new row2Struct();
allim_adresse_normStruct allim_adresse_norm = new allim_adresse_normStruct();
alim_adresse_norm_restauStruct alim_adresse_norm_restau = new alim_adresse_norm_restauStruct();
alim_clientStruct alim_client = new alim_clientStruct();
aim_date_commandeStruct aim_date_commande = new aim_date_commandeStruct();
alim_moyen_paiementStruct alim_moyen_paiement = new alim_moyen_paiementStruct();
alim_preparationStruct alim_preparation = new alim_preparationStruct();
alim_restauStruct alim_restau = new alim_restauStruct();
alim_menuStruct alim_menu = new alim_menuStruct();





	
	/**
	 * [tDBSCD_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBSCD_1", false);
		start_Hash.put("tDBSCD_1", System.currentTimeMillis());
		
	
	currentComponent="tDBSCD_1";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"allim_adresse_norm");
					}
				
		int tos_count_tDBSCD_1 = 0;
		

        class SCDSK_tDBSCD_1 {
private int hashCode;
public boolean hashCodeDirty = true;
Integer id_adresse_norm_client_src;
public boolean equals(Object obj) {
if (this == obj) return true;
if (obj == null) return false;
if (getClass() != obj.getClass()) return false;
final SCDSK_tDBSCD_1 other = (SCDSK_tDBSCD_1) obj;
if (this.id_adresse_norm_client_src == null) {
if (other.id_adresse_norm_client_src!= null)
return false;
} else if (!this.id_adresse_norm_client_src.equals(other.id_adresse_norm_client_src))
return false;

return true;
}
public int hashCode() {
if(hashCodeDirty) {
int prime = 31;hashCode = prime * hashCode + (id_adresse_norm_client_src == null ? 0 : id_adresse_norm_client_src.hashCode());
hashCodeDirty = false;
}
return hashCode;
}
}

    class SCDStruct_tDBSCD_1 {
private String code_postal;
private String latitude;
private String longitude;
private String nom_ville;
private String numero_voie;
private String nom_voie;
}

    int nb_line_update_tDBSCD_1 = 0;
    int nb_line_inserted_tDBSCD_1 = 0;
    int nb_line_rejected_tDBSCD_1 = 0;
        String dbSchema_tDBSCD_1 = "dsid_liv_dm1";
        java.lang.Class.forName("org.postgresql.Driver");
            String connectionString_tDBSCD_1 = "jdbc:postgresql://" + "" + ":" + "5432" + "/" + "postgres";
		
		
		 
	final String decryptedPassword_tDBSCD_1 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:AeYlmLFqgyEPPjmh3X4syFTBx/QIPLGvqXmpu7vf/98=");
	   	
        java.sql.Connection connection_tDBSCD_1 = java.sql.DriverManager.getConnection(connectionString_tDBSCD_1, "dsid_cc2_tos_rw", decryptedPassword_tDBSCD_1);
    String tableName_tDBSCD_1 = null;
    if(dbSchema_tDBSCD_1 == null || dbSchema_tDBSCD_1.trim().length() == 0) {
        tableName_tDBSCD_1 = "dim_adresse_norm_client_d";
    } else {
        tableName_tDBSCD_1 = dbSchema_tDBSCD_1 + "\".\"" + "dim_adresse_norm_client_d";
    }
    java.sql.Timestamp timestamp_tDBSCD_1 = null;
    String tmpValue_tDBSCD_1 = null;    
        String search_tDBSCD_1 = "SELECT \"id_adresse_norm_client_src\", \"code_postal\", \"latitude\", \"longitude\", \"nom_ville\", \"numero_voie\", \"nom_voie\" FROM \"" + tableName_tDBSCD_1 + "\"";
        java.sql.Statement statement_tDBSCD_1 = connection_tDBSCD_1.createStatement();
        java.sql.ResultSet resultSet_tDBSCD_1 = statement_tDBSCD_1.executeQuery(search_tDBSCD_1);
        java.util.Map<SCDSK_tDBSCD_1, SCDStruct_tDBSCD_1> cache_tDBSCD_1 = new java.util.HashMap<SCDSK_tDBSCD_1, SCDStruct_tDBSCD_1>();
        while(resultSet_tDBSCD_1.next()) {
            SCDSK_tDBSCD_1 sk_tDBSCD_1 = new SCDSK_tDBSCD_1();
            SCDStruct_tDBSCD_1 row_tDBSCD_1 = new SCDStruct_tDBSCD_1();
                    if(resultSet_tDBSCD_1.getObject(1) != null) {
                        sk_tDBSCD_1.id_adresse_norm_client_src = resultSet_tDBSCD_1.getInt(1);
                    }
                    if(resultSet_tDBSCD_1.getObject(2) != null) {
                        row_tDBSCD_1.code_postal = resultSet_tDBSCD_1.getString(2);
                    }
                    if(resultSet_tDBSCD_1.getObject(3) != null) {
                        row_tDBSCD_1.latitude = resultSet_tDBSCD_1.getString(3);
                    }
                    if(resultSet_tDBSCD_1.getObject(4) != null) {
                        row_tDBSCD_1.longitude = resultSet_tDBSCD_1.getString(4);
                    }
                    if(resultSet_tDBSCD_1.getObject(5) != null) {
                        row_tDBSCD_1.nom_ville = resultSet_tDBSCD_1.getString(5);
                    }
                    if(resultSet_tDBSCD_1.getObject(6) != null) {
                        row_tDBSCD_1.numero_voie = resultSet_tDBSCD_1.getString(6);
                    }
                    if(resultSet_tDBSCD_1.getObject(7) != null) {
                        row_tDBSCD_1.nom_voie = resultSet_tDBSCD_1.getString(7);
                    }
            cache_tDBSCD_1.put(sk_tDBSCD_1, row_tDBSCD_1);
        }
        resultSet_tDBSCD_1.close();
        statement_tDBSCD_1.close();
    String insertionSQL_tDBSCD_1 = "INSERT INTO \"" + tableName_tDBSCD_1 + "\"(\"id_adresse_norm_client\", \"id_adresse_norm_client_src\", \"code_postal\", \"latitude\", \"longitude\", \"nom_ville\", \"numero_voie\", \"nom_voie\") VALUES(" + "nextval('"+((dbSchema_tDBSCD_1!= null && dbSchema_tDBSCD_1.trim().length()!=0)?dbSchema_tDBSCD_1 +".":"") +"seq_id_adresse_norm_client"+ "')" + ", ?, ?, ?, ?, ?, ?, ?)";
    java.sql.PreparedStatement insertionStatement_tDBSCD_1 = connection_tDBSCD_1.prepareStatement(insertionSQL_tDBSCD_1);
        String updateSQLForType1_tDBSCD_1 = "UPDATE \"" + tableName_tDBSCD_1 + "\" SET \"nom_ville\" = ?, \"numero_voie\" = ?, \"nom_voie\" = ? WHERE \"id_adresse_norm_client_src\" = ?";
        java.sql.PreparedStatement updateForType1_tDBSCD_1 = connection_tDBSCD_1.prepareStatement(updateSQLForType1_tDBSCD_1);        
    
        SCDSK_tDBSCD_1 lookUpKey_tDBSCD_1 = null;        
    SCDStruct_tDBSCD_1 lookUpValue_tDBSCD_1 = null;

 



/**
 * [tDBSCD_1 begin ] stop
 */




	
	/**
	 * [tDBSCD_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBSCD_2", false);
		start_Hash.put("tDBSCD_2", System.currentTimeMillis());
		
	
	currentComponent="tDBSCD_2";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"alim_adresse_norm_restau");
					}
				
		int tos_count_tDBSCD_2 = 0;
		

        class SCDSK_tDBSCD_2 {
private int hashCode;
public boolean hashCodeDirty = true;
Integer id_adresse_norm_restau_src;
public boolean equals(Object obj) {
if (this == obj) return true;
if (obj == null) return false;
if (getClass() != obj.getClass()) return false;
final SCDSK_tDBSCD_2 other = (SCDSK_tDBSCD_2) obj;
if (this.id_adresse_norm_restau_src == null) {
if (other.id_adresse_norm_restau_src!= null)
return false;
} else if (!this.id_adresse_norm_restau_src.equals(other.id_adresse_norm_restau_src))
return false;

return true;
}
public int hashCode() {
if(hashCodeDirty) {
int prime = 31;hashCode = prime * hashCode + (id_adresse_norm_restau_src == null ? 0 : id_adresse_norm_restau_src.hashCode());
hashCodeDirty = false;
}
return hashCode;
}
}

    class SCDStruct_tDBSCD_2 {
private String code_postal;
private String latitude;
private String longitude;
private String nom_ville;
private String nom_voie;
private String numero_voie;
}

    int nb_line_update_tDBSCD_2 = 0;
    int nb_line_inserted_tDBSCD_2 = 0;
    int nb_line_rejected_tDBSCD_2 = 0;
        String dbSchema_tDBSCD_2 = "dsid_liv_dm1";
        java.lang.Class.forName("org.postgresql.Driver");
            String connectionString_tDBSCD_2 = "jdbc:postgresql://" + "" + ":" + "5432" + "/" + "postgres";
		
		
		 
	final String decryptedPassword_tDBSCD_2 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:17FkstqpWU+tgfcV3O9DisT23oRKHrtJvOy1dt4nt/Y=");
	   	
        java.sql.Connection connection_tDBSCD_2 = java.sql.DriverManager.getConnection(connectionString_tDBSCD_2, "dsid_cc2_tos_rw", decryptedPassword_tDBSCD_2);
    String tableName_tDBSCD_2 = null;
    if(dbSchema_tDBSCD_2 == null || dbSchema_tDBSCD_2.trim().length() == 0) {
        tableName_tDBSCD_2 = "dim_adresse_norm_restaurant_d";
    } else {
        tableName_tDBSCD_2 = dbSchema_tDBSCD_2 + "\".\"" + "dim_adresse_norm_restaurant_d";
    }
    java.sql.Timestamp timestamp_tDBSCD_2 = null;
    String tmpValue_tDBSCD_2 = null;    
        String search_tDBSCD_2 = "SELECT \"id_adresse_norm_restau_src\", \"code_postal\", \"latitude\", \"longitude\", \"nom_ville\", \"nom_voie\", \"numero_voie\" FROM \"" + tableName_tDBSCD_2 + "\"";
        java.sql.Statement statement_tDBSCD_2 = connection_tDBSCD_2.createStatement();
        java.sql.ResultSet resultSet_tDBSCD_2 = statement_tDBSCD_2.executeQuery(search_tDBSCD_2);
        java.util.Map<SCDSK_tDBSCD_2, SCDStruct_tDBSCD_2> cache_tDBSCD_2 = new java.util.HashMap<SCDSK_tDBSCD_2, SCDStruct_tDBSCD_2>();
        while(resultSet_tDBSCD_2.next()) {
            SCDSK_tDBSCD_2 sk_tDBSCD_2 = new SCDSK_tDBSCD_2();
            SCDStruct_tDBSCD_2 row_tDBSCD_2 = new SCDStruct_tDBSCD_2();
                    if(resultSet_tDBSCD_2.getObject(1) != null) {
                        sk_tDBSCD_2.id_adresse_norm_restau_src = resultSet_tDBSCD_2.getInt(1);
                    }
                    if(resultSet_tDBSCD_2.getObject(2) != null) {
                        row_tDBSCD_2.code_postal = resultSet_tDBSCD_2.getString(2);
                    }
                    if(resultSet_tDBSCD_2.getObject(3) != null) {
                        row_tDBSCD_2.latitude = resultSet_tDBSCD_2.getString(3);
                    }
                    if(resultSet_tDBSCD_2.getObject(4) != null) {
                        row_tDBSCD_2.longitude = resultSet_tDBSCD_2.getString(4);
                    }
                    if(resultSet_tDBSCD_2.getObject(5) != null) {
                        row_tDBSCD_2.nom_ville = resultSet_tDBSCD_2.getString(5);
                    }
                    if(resultSet_tDBSCD_2.getObject(6) != null) {
                        row_tDBSCD_2.nom_voie = resultSet_tDBSCD_2.getString(6);
                    }
                    if(resultSet_tDBSCD_2.getObject(7) != null) {
                        row_tDBSCD_2.numero_voie = resultSet_tDBSCD_2.getString(7);
                    }
            cache_tDBSCD_2.put(sk_tDBSCD_2, row_tDBSCD_2);
        }
        resultSet_tDBSCD_2.close();
        statement_tDBSCD_2.close();
    String insertionSQL_tDBSCD_2 = "INSERT INTO \"" + tableName_tDBSCD_2 + "\"(\"id_adresse_norm_restaurant\", \"id_adresse_norm_restau_src\", \"code_postal\", \"latitude\", \"longitude\", \"nom_ville\", \"nom_voie\", \"numero_voie\") VALUES(" + "nextval('"+((dbSchema_tDBSCD_2!= null && dbSchema_tDBSCD_2.trim().length()!=0)?dbSchema_tDBSCD_2 +".":"") +"seq_id_adresse_norm_restaurant"+ "')" + ", ?, ?, ?, ?, ?, ?, ?)";
    java.sql.PreparedStatement insertionStatement_tDBSCD_2 = connection_tDBSCD_2.prepareStatement(insertionSQL_tDBSCD_2);
        String updateSQLForType1_tDBSCD_2 = "UPDATE \"" + tableName_tDBSCD_2 + "\" SET \"nom_ville\" = ?, \"nom_voie\" = ?, \"numero_voie\" = ? WHERE \"id_adresse_norm_restau_src\" = ?";
        java.sql.PreparedStatement updateForType1_tDBSCD_2 = connection_tDBSCD_2.prepareStatement(updateSQLForType1_tDBSCD_2);        
    
        SCDSK_tDBSCD_2 lookUpKey_tDBSCD_2 = null;        
    SCDStruct_tDBSCD_2 lookUpValue_tDBSCD_2 = null;

 



/**
 * [tDBSCD_2 begin ] stop
 */




	
	/**
	 * [tDBSCD_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBSCD_3", false);
		start_Hash.put("tDBSCD_3", System.currentTimeMillis());
		
	
	currentComponent="tDBSCD_3";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"alim_client");
					}
				
		int tos_count_tDBSCD_3 = 0;
		

        class SCDSK_tDBSCD_3 {
private int hashCode;
public boolean hashCodeDirty = true;
Integer id_client_src;
public boolean equals(Object obj) {
if (this == obj) return true;
if (obj == null) return false;
if (getClass() != obj.getClass()) return false;
final SCDSK_tDBSCD_3 other = (SCDSK_tDBSCD_3) obj;
if (this.id_client_src == null) {
if (other.id_client_src!= null)
return false;
} else if (!this.id_client_src.equals(other.id_client_src))
return false;

return true;
}
public int hashCode() {
if(hashCodeDirty) {
int prime = 31;hashCode = prime * hashCode + (id_client_src == null ? 0 : id_client_src.hashCode());
hashCodeDirty = false;
}
return hashCode;
}
}

    class SCDStruct_tDBSCD_3 {
private String prenom_client;
private String nom_client;
private String nom_precedent;
}

    int nb_line_update_tDBSCD_3 = 0;
    int nb_line_inserted_tDBSCD_3 = 0;
    int nb_line_rejected_tDBSCD_3 = 0;
        String dbSchema_tDBSCD_3 = "dsid_liv_dm1";
        java.lang.Class.forName("org.postgresql.Driver");
            String connectionString_tDBSCD_3 = "jdbc:postgresql://" + "" + ":" + "5432" + "/" + "postgres";
		
		
		 
	final String decryptedPassword_tDBSCD_3 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:T+tlpBEkVA91mcg9zBljKrGFT4PaD+d9U/sDK0hzADg=");
	   	
        java.sql.Connection connection_tDBSCD_3 = java.sql.DriverManager.getConnection(connectionString_tDBSCD_3, "dsid_cc2_tos_rw", decryptedPassword_tDBSCD_3);
    String tableName_tDBSCD_3 = null;
    if(dbSchema_tDBSCD_3 == null || dbSchema_tDBSCD_3.trim().length() == 0) {
        tableName_tDBSCD_3 = "dim_client_d";
    } else {
        tableName_tDBSCD_3 = dbSchema_tDBSCD_3 + "\".\"" + "dim_client_d";
    }
    java.sql.Timestamp timestamp_tDBSCD_3 = null;
    String tmpValue_tDBSCD_3 = null;    
        String search_tDBSCD_3 = "SELECT \"id_client_src\", \"prenom_client\", \"nom_client\", \"nom_precedent\" FROM \"" + tableName_tDBSCD_3 + "\"";
        java.sql.Statement statement_tDBSCD_3 = connection_tDBSCD_3.createStatement();
        java.sql.ResultSet resultSet_tDBSCD_3 = statement_tDBSCD_3.executeQuery(search_tDBSCD_3);
        java.util.Map<SCDSK_tDBSCD_3, SCDStruct_tDBSCD_3> cache_tDBSCD_3 = new java.util.HashMap<SCDSK_tDBSCD_3, SCDStruct_tDBSCD_3>();
        while(resultSet_tDBSCD_3.next()) {
            SCDSK_tDBSCD_3 sk_tDBSCD_3 = new SCDSK_tDBSCD_3();
            SCDStruct_tDBSCD_3 row_tDBSCD_3 = new SCDStruct_tDBSCD_3();
                    if(resultSet_tDBSCD_3.getObject(1) != null) {
                        sk_tDBSCD_3.id_client_src = resultSet_tDBSCD_3.getInt(1);
                    }
                    if(resultSet_tDBSCD_3.getObject(2) != null) {
                        row_tDBSCD_3.prenom_client = resultSet_tDBSCD_3.getString(2);
                    }
                    if(resultSet_tDBSCD_3.getObject(3) != null) {
                        row_tDBSCD_3.nom_client = resultSet_tDBSCD_3.getString(3);
                    }
                    if(resultSet_tDBSCD_3.getObject(4) != null) {
                        row_tDBSCD_3.nom_precedent = resultSet_tDBSCD_3.getString(4);
                    }
            cache_tDBSCD_3.put(sk_tDBSCD_3, row_tDBSCD_3);
        }
        resultSet_tDBSCD_3.close();
        statement_tDBSCD_3.close();
    String insertionSQL_tDBSCD_3 = "INSERT INTO \"" + tableName_tDBSCD_3 + "\"(\"id_client\", \"id_client_src\", \"prenom_client\", \"nom_client\") VALUES(" + "nextval('"+((dbSchema_tDBSCD_3!= null && dbSchema_tDBSCD_3.trim().length()!=0)?dbSchema_tDBSCD_3 +".":"") +"seq_id_client"+ "')" + ", ?, ?, ?)";
    java.sql.PreparedStatement insertionStatement_tDBSCD_3 = connection_tDBSCD_3.prepareStatement(insertionSQL_tDBSCD_3);
        String updateSQLForType1_tDBSCD_3 = "UPDATE \"" + tableName_tDBSCD_3 + "\" SET \"prenom_client\" = ? WHERE \"id_client_src\" = ?";
        java.sql.PreparedStatement updateForType1_tDBSCD_3 = connection_tDBSCD_3.prepareStatement(updateSQLForType1_tDBSCD_3);        
        String updateSQLForType3_tDBSCD_3 = "UPDATE \"" + tableName_tDBSCD_3 + "\" SET \"nom_client\" = ?, \"nom_precedent\" = ? WHERE \"id_client_src\" = ?";
        java.sql.PreparedStatement updateForType3_tDBSCD_3 = connection_tDBSCD_3.prepareStatement(updateSQLForType3_tDBSCD_3);
    
        SCDSK_tDBSCD_3 lookUpKey_tDBSCD_3 = null;        
    SCDStruct_tDBSCD_3 lookUpValue_tDBSCD_3 = null;

 



/**
 * [tDBSCD_3 begin ] stop
 */




	
	/**
	 * [tDBSCD_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBSCD_4", false);
		start_Hash.put("tDBSCD_4", System.currentTimeMillis());
		
	
	currentComponent="tDBSCD_4";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"aim_date_commande");
					}
				
		int tos_count_tDBSCD_4 = 0;
		

        class SCDSK_tDBSCD_4 {
private int hashCode;
public boolean hashCodeDirty = true;
String annee;
java.util.Date date_commande;
String jour;
String mois;
String semaine;
public boolean equals(Object obj) {
if (this == obj) return true;
if (obj == null) return false;
if (getClass() != obj.getClass()) return false;
final SCDSK_tDBSCD_4 other = (SCDSK_tDBSCD_4) obj;
if (this.annee == null) {
if (other.annee!= null)
return false;
} else if (!this.annee.equals(other.annee))
return false;

if (this.date_commande == null) {
if (other.date_commande!= null)
return false;
} else if (!this.date_commande.equals(other.date_commande))
return false;

if (this.jour == null) {
if (other.jour!= null)
return false;
} else if (!this.jour.equals(other.jour))
return false;

if (this.mois == null) {
if (other.mois!= null)
return false;
} else if (!this.mois.equals(other.mois))
return false;

if (this.semaine == null) {
if (other.semaine!= null)
return false;
} else if (!this.semaine.equals(other.semaine))
return false;

return true;
}
public int hashCode() {
if(hashCodeDirty) {
int prime = 31;hashCode = prime * hashCode + (annee == null ? 0 : annee.hashCode());
hashCode = prime * hashCode + (date_commande == null ? 0 : date_commande.hashCode());
hashCode = prime * hashCode + (jour == null ? 0 : jour.hashCode());
hashCode = prime * hashCode + (mois == null ? 0 : mois.hashCode());
hashCode = prime * hashCode + (semaine == null ? 0 : semaine.hashCode());
hashCodeDirty = false;
}
return hashCode;
}
}

    class SCDStruct_tDBSCD_4 {
}

    int nb_line_update_tDBSCD_4 = 0;
    int nb_line_inserted_tDBSCD_4 = 0;
    int nb_line_rejected_tDBSCD_4 = 0;
        String dbSchema_tDBSCD_4 = "dsid_liv_dm1";
        java.lang.Class.forName("org.postgresql.Driver");
            String connectionString_tDBSCD_4 = "jdbc:postgresql://" + "" + ":" + "5432" + "/" + "postgres";
		
		
		 
	final String decryptedPassword_tDBSCD_4 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:9vQGno+ZMzqqjl8WqNCna5jfBC7JoPacrHIKoJTnBtg=");
	   	
        java.sql.Connection connection_tDBSCD_4 = java.sql.DriverManager.getConnection(connectionString_tDBSCD_4, "dsid_cc2_tos_rw", decryptedPassword_tDBSCD_4);
    String tableName_tDBSCD_4 = null;
    if(dbSchema_tDBSCD_4 == null || dbSchema_tDBSCD_4.trim().length() == 0) {
        tableName_tDBSCD_4 = "dim_date_commande_d";
    } else {
        tableName_tDBSCD_4 = dbSchema_tDBSCD_4 + "\".\"" + "dim_date_commande_d";
    }
    java.sql.Timestamp timestamp_tDBSCD_4 = null;
    String tmpValue_tDBSCD_4 = null;    
        String search_tDBSCD_4 = "SELECT \"annee\", \"date_commande\", \"jour\", \"mois\", \"semaine\" FROM \"" + tableName_tDBSCD_4 + "\"";
        java.sql.Statement statement_tDBSCD_4 = connection_tDBSCD_4.createStatement();
        java.sql.ResultSet resultSet_tDBSCD_4 = statement_tDBSCD_4.executeQuery(search_tDBSCD_4);
        java.util.Map<SCDSK_tDBSCD_4, SCDStruct_tDBSCD_4> cache_tDBSCD_4 = new java.util.HashMap<SCDSK_tDBSCD_4, SCDStruct_tDBSCD_4>();
        while(resultSet_tDBSCD_4.next()) {
            SCDSK_tDBSCD_4 sk_tDBSCD_4 = new SCDSK_tDBSCD_4();
            SCDStruct_tDBSCD_4 row_tDBSCD_4 = new SCDStruct_tDBSCD_4();
                    if(resultSet_tDBSCD_4.getObject(1) != null) {
                        sk_tDBSCD_4.annee = resultSet_tDBSCD_4.getString(1);
                    }
                    timestamp_tDBSCD_4 = resultSet_tDBSCD_4.getTimestamp(2);
                    if(timestamp_tDBSCD_4 != null) {
                        sk_tDBSCD_4.date_commande = new java.util.Date(timestamp_tDBSCD_4.getTime());
                    } else {
                        sk_tDBSCD_4.date_commande = null;
                    }
                    if(resultSet_tDBSCD_4.getObject(3) != null) {
                        sk_tDBSCD_4.jour = resultSet_tDBSCD_4.getString(3);
                    }
                    if(resultSet_tDBSCD_4.getObject(4) != null) {
                        sk_tDBSCD_4.mois = resultSet_tDBSCD_4.getString(4);
                    }
                    if(resultSet_tDBSCD_4.getObject(5) != null) {
                        sk_tDBSCD_4.semaine = resultSet_tDBSCD_4.getString(5);
                    }
            cache_tDBSCD_4.put(sk_tDBSCD_4, row_tDBSCD_4);
        }
        resultSet_tDBSCD_4.close();
        statement_tDBSCD_4.close();
    String insertionSQL_tDBSCD_4 = "INSERT INTO \"" + tableName_tDBSCD_4 + "\"(\"id_date_commande\", \"annee\", \"date_commande\", \"jour\", \"mois\", \"semaine\") VALUES(" + "nextval('"+((dbSchema_tDBSCD_4!= null && dbSchema_tDBSCD_4.trim().length()!=0)?dbSchema_tDBSCD_4 +".":"") +"seq_id_date_commande"+ "')" + ", ?, ?, ?, ?, ?)";
    java.sql.PreparedStatement insertionStatement_tDBSCD_4 = connection_tDBSCD_4.prepareStatement(insertionSQL_tDBSCD_4);
    
        SCDSK_tDBSCD_4 lookUpKey_tDBSCD_4 = null;        
    SCDStruct_tDBSCD_4 lookUpValue_tDBSCD_4 = null;

 



/**
 * [tDBSCD_4 begin ] stop
 */




	
	/**
	 * [tDBSCD_5 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBSCD_5", false);
		start_Hash.put("tDBSCD_5", System.currentTimeMillis());
		
	
	currentComponent="tDBSCD_5";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"alim_moyen_paiement");
					}
				
		int tos_count_tDBSCD_5 = 0;
		

        class SCDSK_tDBSCD_5 {
private int hashCode;
public boolean hashCodeDirty = true;
Integer id_moyen_paiement_src;
public boolean equals(Object obj) {
if (this == obj) return true;
if (obj == null) return false;
if (getClass() != obj.getClass()) return false;
final SCDSK_tDBSCD_5 other = (SCDSK_tDBSCD_5) obj;
if (this.id_moyen_paiement_src == null) {
if (other.id_moyen_paiement_src!= null)
return false;
} else if (!this.id_moyen_paiement_src.equals(other.id_moyen_paiement_src))
return false;

return true;
}
public int hashCode() {
if(hashCodeDirty) {
int prime = 31;hashCode = prime * hashCode + (id_moyen_paiement_src == null ? 0 : id_moyen_paiement_src.hashCode());
hashCodeDirty = false;
}
return hashCode;
}
}

    class SCDStruct_tDBSCD_5 {
private String code_moyen_paiement;
private String livelle_moyen_paiement;
}

    int nb_line_update_tDBSCD_5 = 0;
    int nb_line_inserted_tDBSCD_5 = 0;
    int nb_line_rejected_tDBSCD_5 = 0;
        String dbSchema_tDBSCD_5 = "dsid_liv_dm1";
        java.lang.Class.forName("org.postgresql.Driver");
            String connectionString_tDBSCD_5 = "jdbc:postgresql://" + "" + ":" + "5432" + "/" + "postgres";
		
		
		 
	final String decryptedPassword_tDBSCD_5 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:5Gi+kUdbxV93TCSTASuN4Nd8B3s3/gdiRJ0ENSS9ITY=");
	   	
        java.sql.Connection connection_tDBSCD_5 = java.sql.DriverManager.getConnection(connectionString_tDBSCD_5, "dsid_cc2_tos_rw", decryptedPassword_tDBSCD_5);
    String tableName_tDBSCD_5 = null;
    if(dbSchema_tDBSCD_5 == null || dbSchema_tDBSCD_5.trim().length() == 0) {
        tableName_tDBSCD_5 = "dim_moyen_paiement_d";
    } else {
        tableName_tDBSCD_5 = dbSchema_tDBSCD_5 + "\".\"" + "dim_moyen_paiement_d";
    }
    java.sql.Timestamp timestamp_tDBSCD_5 = null;
    String tmpValue_tDBSCD_5 = null;    
        String search_tDBSCD_5 = "SELECT \"id_moyen_paiement_src\", \"code_moyen_paiement\", \"livelle_moyen_paiement\" FROM \"" + tableName_tDBSCD_5 + "\"";
        java.sql.Statement statement_tDBSCD_5 = connection_tDBSCD_5.createStatement();
        java.sql.ResultSet resultSet_tDBSCD_5 = statement_tDBSCD_5.executeQuery(search_tDBSCD_5);
        java.util.Map<SCDSK_tDBSCD_5, SCDStruct_tDBSCD_5> cache_tDBSCD_5 = new java.util.HashMap<SCDSK_tDBSCD_5, SCDStruct_tDBSCD_5>();
        while(resultSet_tDBSCD_5.next()) {
            SCDSK_tDBSCD_5 sk_tDBSCD_5 = new SCDSK_tDBSCD_5();
            SCDStruct_tDBSCD_5 row_tDBSCD_5 = new SCDStruct_tDBSCD_5();
                    if(resultSet_tDBSCD_5.getObject(1) != null) {
                        sk_tDBSCD_5.id_moyen_paiement_src = resultSet_tDBSCD_5.getInt(1);
                    }
                    if(resultSet_tDBSCD_5.getObject(2) != null) {
                        row_tDBSCD_5.code_moyen_paiement = resultSet_tDBSCD_5.getString(2);
                    }
                    if(resultSet_tDBSCD_5.getObject(3) != null) {
                        row_tDBSCD_5.livelle_moyen_paiement = resultSet_tDBSCD_5.getString(3);
                    }
            cache_tDBSCD_5.put(sk_tDBSCD_5, row_tDBSCD_5);
        }
        resultSet_tDBSCD_5.close();
        statement_tDBSCD_5.close();
    String insertionSQL_tDBSCD_5 = "INSERT INTO \"" + tableName_tDBSCD_5 + "\"(\"id_moyen_paiement\", \"id_moyen_paiement_src\", \"code_moyen_paiement\", \"livelle_moyen_paiement\") VALUES(" + "nextval('"+((dbSchema_tDBSCD_5!= null && dbSchema_tDBSCD_5.trim().length()!=0)?dbSchema_tDBSCD_5 +".":"") +"seq_id_moyen_paiement"+ "')" + ", ?, ?, ?)";
    java.sql.PreparedStatement insertionStatement_tDBSCD_5 = connection_tDBSCD_5.prepareStatement(insertionSQL_tDBSCD_5);
        String updateSQLForType1_tDBSCD_5 = "UPDATE \"" + tableName_tDBSCD_5 + "\" SET \"livelle_moyen_paiement\" = ? WHERE \"id_moyen_paiement_src\" = ?";
        java.sql.PreparedStatement updateForType1_tDBSCD_5 = connection_tDBSCD_5.prepareStatement(updateSQLForType1_tDBSCD_5);        
    
        SCDSK_tDBSCD_5 lookUpKey_tDBSCD_5 = null;        
    SCDStruct_tDBSCD_5 lookUpValue_tDBSCD_5 = null;

 



/**
 * [tDBSCD_5 begin ] stop
 */




	
	/**
	 * [tDBSCD_6 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBSCD_6", false);
		start_Hash.put("tDBSCD_6", System.currentTimeMillis());
		
	
	currentComponent="tDBSCD_6";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"alim_preparation");
					}
				
		int tos_count_tDBSCD_6 = 0;
		

        class SCDSK_tDBSCD_6 {
private int hashCode;
public boolean hashCodeDirty = true;
Integer id_preparation_src;
public boolean equals(Object obj) {
if (this == obj) return true;
if (obj == null) return false;
if (getClass() != obj.getClass()) return false;
final SCDSK_tDBSCD_6 other = (SCDSK_tDBSCD_6) obj;
if (this.id_preparation_src == null) {
if (other.id_preparation_src!= null)
return false;
} else if (!this.id_preparation_src.equals(other.id_preparation_src))
return false;

return true;
}
public int hashCode() {
if(hashCodeDirty) {
int prime = 31;hashCode = prime * hashCode + (id_preparation_src == null ? 0 : id_preparation_src.hashCode());
hashCodeDirty = false;
}
return hashCode;
}
}

    class SCDStruct_tDBSCD_6 {
private java.util.Date date_debut_preparation;
private java.util.Date date_fin_preparation;
}

    int nb_line_update_tDBSCD_6 = 0;
    int nb_line_inserted_tDBSCD_6 = 0;
    int nb_line_rejected_tDBSCD_6 = 0;
        String dbSchema_tDBSCD_6 = "dsid_liv_dm1";
        java.lang.Class.forName("org.postgresql.Driver");
            String connectionString_tDBSCD_6 = "jdbc:postgresql://" + "" + ":" + "5432" + "/" + "postgres";
		
		
		 
	final String decryptedPassword_tDBSCD_6 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:jHJiRfydjtaCdTe7PU1LImbwSDDjqgoYGavIVUKCHHQ=");
	   	
        java.sql.Connection connection_tDBSCD_6 = java.sql.DriverManager.getConnection(connectionString_tDBSCD_6, "dsid_cc2_tos_rw", decryptedPassword_tDBSCD_6);
    String tableName_tDBSCD_6 = null;
    if(dbSchema_tDBSCD_6 == null || dbSchema_tDBSCD_6.trim().length() == 0) {
        tableName_tDBSCD_6 = "dim_preparation_d";
    } else {
        tableName_tDBSCD_6 = dbSchema_tDBSCD_6 + "\".\"" + "dim_preparation_d";
    }
    java.sql.Timestamp timestamp_tDBSCD_6 = null;
    String tmpValue_tDBSCD_6 = null;    
        String search_tDBSCD_6 = "SELECT \"id_preparation_src\", \"date_debut_preparation\", \"date_fin_preparation\" FROM \"" + tableName_tDBSCD_6 + "\"";
        java.sql.Statement statement_tDBSCD_6 = connection_tDBSCD_6.createStatement();
        java.sql.ResultSet resultSet_tDBSCD_6 = statement_tDBSCD_6.executeQuery(search_tDBSCD_6);
        java.util.Map<SCDSK_tDBSCD_6, SCDStruct_tDBSCD_6> cache_tDBSCD_6 = new java.util.HashMap<SCDSK_tDBSCD_6, SCDStruct_tDBSCD_6>();
        while(resultSet_tDBSCD_6.next()) {
            SCDSK_tDBSCD_6 sk_tDBSCD_6 = new SCDSK_tDBSCD_6();
            SCDStruct_tDBSCD_6 row_tDBSCD_6 = new SCDStruct_tDBSCD_6();
                    if(resultSet_tDBSCD_6.getObject(1) != null) {
                        sk_tDBSCD_6.id_preparation_src = resultSet_tDBSCD_6.getInt(1);
                    }
                    timestamp_tDBSCD_6 = resultSet_tDBSCD_6.getTimestamp(2);
                    if(timestamp_tDBSCD_6 != null) {
                        row_tDBSCD_6.date_debut_preparation = new java.util.Date(timestamp_tDBSCD_6.getTime());
                    } else {
                        row_tDBSCD_6.date_debut_preparation = null;
                    }
                    timestamp_tDBSCD_6 = resultSet_tDBSCD_6.getTimestamp(3);
                    if(timestamp_tDBSCD_6 != null) {
                        row_tDBSCD_6.date_fin_preparation = new java.util.Date(timestamp_tDBSCD_6.getTime());
                    } else {
                        row_tDBSCD_6.date_fin_preparation = null;
                    }
            cache_tDBSCD_6.put(sk_tDBSCD_6, row_tDBSCD_6);
        }
        resultSet_tDBSCD_6.close();
        statement_tDBSCD_6.close();
    String insertionSQL_tDBSCD_6 = "INSERT INTO \"" + tableName_tDBSCD_6 + "\"(\"id_preparation\", \"id_preparation_src\", \"date_debut_preparation\", \"date_fin_preparation\") VALUES(" + "nextval('"+((dbSchema_tDBSCD_6!= null && dbSchema_tDBSCD_6.trim().length()!=0)?dbSchema_tDBSCD_6 +".":"") +"seq_id_preparation"+ "')" + ", ?, ?, ?)";
    java.sql.PreparedStatement insertionStatement_tDBSCD_6 = connection_tDBSCD_6.prepareStatement(insertionSQL_tDBSCD_6);
    
        SCDSK_tDBSCD_6 lookUpKey_tDBSCD_6 = null;        
    SCDStruct_tDBSCD_6 lookUpValue_tDBSCD_6 = null;

 



/**
 * [tDBSCD_6 begin ] stop
 */




	
	/**
	 * [tDBSCD_7 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBSCD_7", false);
		start_Hash.put("tDBSCD_7", System.currentTimeMillis());
		
	
	currentComponent="tDBSCD_7";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"alim_restau");
					}
				
		int tos_count_tDBSCD_7 = 0;
		

        class SCDSK_tDBSCD_7 {
private int hashCode;
public boolean hashCodeDirty = true;
Integer id_restaurant_src;
public boolean equals(Object obj) {
if (this == obj) return true;
if (obj == null) return false;
if (getClass() != obj.getClass()) return false;
final SCDSK_tDBSCD_7 other = (SCDSK_tDBSCD_7) obj;
if (this.id_restaurant_src == null) {
if (other.id_restaurant_src!= null)
return false;
} else if (!this.id_restaurant_src.equals(other.id_restaurant_src))
return false;

return true;
}
public int hashCode() {
if(hashCodeDirty) {
int prime = 31;hashCode = prime * hashCode + (id_restaurant_src == null ? 0 : id_restaurant_src.hashCode());
hashCodeDirty = false;
}
return hashCode;
}
}

    class SCDStruct_tDBSCD_7 {
private String code_restaurant;
private String raison_sociale_restaurant;
private Integer scd_version;
}

    int nb_line_update_tDBSCD_7 = 0;
    int nb_line_inserted_tDBSCD_7 = 0;
    int nb_line_rejected_tDBSCD_7 = 0;
        String dbSchema_tDBSCD_7 = "dsid_liv_dm1";
        java.lang.Class.forName("org.postgresql.Driver");
            String connectionString_tDBSCD_7 = "jdbc:postgresql://" + "" + ":" + "5432" + "/" + "postgres";
		
		
		 
	final String decryptedPassword_tDBSCD_7 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:3VWP/cO/yzvSQ3xctMxar0ZGhPTshBoEfEGiG7VxonM=");
	   	
        java.sql.Connection connection_tDBSCD_7 = java.sql.DriverManager.getConnection(connectionString_tDBSCD_7, "dsid_cc2_tos_rw", decryptedPassword_tDBSCD_7);
    String tableName_tDBSCD_7 = null;
    if(dbSchema_tDBSCD_7 == null || dbSchema_tDBSCD_7.trim().length() == 0) {
        tableName_tDBSCD_7 = "dim_restaurant_d";
    } else {
        tableName_tDBSCD_7 = dbSchema_tDBSCD_7 + "\".\"" + "dim_restaurant_d";
    }
    java.sql.Timestamp timestamp_tDBSCD_7 = null;
    String tmpValue_tDBSCD_7 = null;    
        String search_tDBSCD_7 = "SELECT \"id_restaurant_src\", \"code_restaurant\", \"raison_sociale_restaurant\", \"scd_version\" FROM \"" + tableName_tDBSCD_7 + "\" WHERE \"scd_end\" IS NULL";
        java.sql.Statement statement_tDBSCD_7 = connection_tDBSCD_7.createStatement();
        java.sql.ResultSet resultSet_tDBSCD_7 = statement_tDBSCD_7.executeQuery(search_tDBSCD_7);
        java.util.Map<SCDSK_tDBSCD_7, SCDStruct_tDBSCD_7> cache_tDBSCD_7 = new java.util.HashMap<SCDSK_tDBSCD_7, SCDStruct_tDBSCD_7>();
        while(resultSet_tDBSCD_7.next()) {
            SCDSK_tDBSCD_7 sk_tDBSCD_7 = new SCDSK_tDBSCD_7();
            SCDStruct_tDBSCD_7 row_tDBSCD_7 = new SCDStruct_tDBSCD_7();
                    if(resultSet_tDBSCD_7.getObject(1) != null) {
                        sk_tDBSCD_7.id_restaurant_src = resultSet_tDBSCD_7.getInt(1);
                    }
                    if(resultSet_tDBSCD_7.getObject(2) != null) {
                        row_tDBSCD_7.code_restaurant = resultSet_tDBSCD_7.getString(2);
                    }
                    if(resultSet_tDBSCD_7.getObject(3) != null) {
                        row_tDBSCD_7.raison_sociale_restaurant = resultSet_tDBSCD_7.getString(3);
                    }
                    if(resultSet_tDBSCD_7.getObject(4) != null) {
                        row_tDBSCD_7.scd_version = resultSet_tDBSCD_7.getInt(4);
                    }
            cache_tDBSCD_7.put(sk_tDBSCD_7, row_tDBSCD_7);
        }
        resultSet_tDBSCD_7.close();
        statement_tDBSCD_7.close();
    String insertionSQL_tDBSCD_7 = "INSERT INTO \"" + tableName_tDBSCD_7 + "\"(\"id_restaurant\", \"id_restaurant_src\", \"code_restaurant\", \"raison_sociale_restaurant\", \"scd_active\", \"scd_version\", \"scd_start\", \"scd_end\") VALUES(" + "nextval('"+((dbSchema_tDBSCD_7!= null && dbSchema_tDBSCD_7.trim().length()!=0)?dbSchema_tDBSCD_7 +".":"") +"seq_id_restaurant"+ "')" + ", ?, ?, ?, 'true', ?, ?, ?)";
    java.sql.PreparedStatement insertionStatement_tDBSCD_7 = connection_tDBSCD_7.prepareStatement(insertionSQL_tDBSCD_7);
            insertionStatement_tDBSCD_7.setTimestamp(5, new java.sql.Timestamp(start_Hash.get("tDBSCD_7")));
            insertionStatement_tDBSCD_7.setNull(6, java.sql.Types.DATE);
        String updateSQLForType2_tDBSCD_7 = "UPDATE \"" + tableName_tDBSCD_7 + "\" SET \"scd_end\" = ?, \"scd_active\" = 'false' WHERE \"id_restaurant_src\" = ? AND \"scd_end\" IS NULL";
        java.sql.PreparedStatement updateForType2_tDBSCD_7 = connection_tDBSCD_7.prepareStatement(updateSQLForType2_tDBSCD_7);
            updateForType2_tDBSCD_7.setTimestamp(1, new java.sql.Timestamp(start_Hash.get("tDBSCD_7")));
    
        SCDSK_tDBSCD_7 lookUpKey_tDBSCD_7 = null;        
    SCDStruct_tDBSCD_7 lookUpValue_tDBSCD_7 = null;

 



/**
 * [tDBSCD_7 begin ] stop
 */




	
	/**
	 * [tDBSCD_8 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBSCD_8", false);
		start_Hash.put("tDBSCD_8", System.currentTimeMillis());
		
	
	currentComponent="tDBSCD_8";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"alim_menu");
					}
				
		int tos_count_tDBSCD_8 = 0;
		

        class SCDSK_tDBSCD_8 {
private int hashCode;
public boolean hashCodeDirty = true;
Integer id_menu_src;
public boolean equals(Object obj) {
if (this == obj) return true;
if (obj == null) return false;
if (getClass() != obj.getClass()) return false;
final SCDSK_tDBSCD_8 other = (SCDSK_tDBSCD_8) obj;
if (this.id_menu_src == null) {
if (other.id_menu_src!= null)
return false;
} else if (!this.id_menu_src.equals(other.id_menu_src))
return false;

return true;
}
public int hashCode() {
if(hashCodeDirty) {
int prime = 31;hashCode = prime * hashCode + (id_menu_src == null ? 0 : id_menu_src.hashCode());
hashCodeDirty = false;
}
return hashCode;
}
}

    class SCDStruct_tDBSCD_8 {
private String code_menu;
private String temps_theo_preparation;
private Integer nombre_articles;
private String libelle_menu;
}

    int nb_line_update_tDBSCD_8 = 0;
    int nb_line_inserted_tDBSCD_8 = 0;
    int nb_line_rejected_tDBSCD_8 = 0;
        String dbSchema_tDBSCD_8 = "dsid_liv_dm1";
        java.lang.Class.forName("org.postgresql.Driver");
            String connectionString_tDBSCD_8 = "jdbc:postgresql://" + "" + ":" + "5432" + "/" + "postgres";
		
		
		 
	final String decryptedPassword_tDBSCD_8 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:OrGOjwYUytfNqxuphqhjimM2ZNJuNB7k5VcC64hlcsI=");
	   	
        java.sql.Connection connection_tDBSCD_8 = java.sql.DriverManager.getConnection(connectionString_tDBSCD_8, "dsid_cc2_tos_rw", decryptedPassword_tDBSCD_8);
    String tableName_tDBSCD_8 = null;
    if(dbSchema_tDBSCD_8 == null || dbSchema_tDBSCD_8.trim().length() == 0) {
        tableName_tDBSCD_8 = "dim_menu_d";
    } else {
        tableName_tDBSCD_8 = dbSchema_tDBSCD_8 + "\".\"" + "dim_menu_d";
    }
    java.sql.Timestamp timestamp_tDBSCD_8 = null;
    String tmpValue_tDBSCD_8 = null;    
        String search_tDBSCD_8 = "SELECT \"id_menu_src\", \"code_menu\", \"temps_theo_preparation\", \"nombre_articles\", \"libelle_menu\" FROM \"" + tableName_tDBSCD_8 + "\"";
        java.sql.Statement statement_tDBSCD_8 = connection_tDBSCD_8.createStatement();
        java.sql.ResultSet resultSet_tDBSCD_8 = statement_tDBSCD_8.executeQuery(search_tDBSCD_8);
        java.util.Map<SCDSK_tDBSCD_8, SCDStruct_tDBSCD_8> cache_tDBSCD_8 = new java.util.HashMap<SCDSK_tDBSCD_8, SCDStruct_tDBSCD_8>();
        while(resultSet_tDBSCD_8.next()) {
            SCDSK_tDBSCD_8 sk_tDBSCD_8 = new SCDSK_tDBSCD_8();
            SCDStruct_tDBSCD_8 row_tDBSCD_8 = new SCDStruct_tDBSCD_8();
                    if(resultSet_tDBSCD_8.getObject(1) != null) {
                        sk_tDBSCD_8.id_menu_src = resultSet_tDBSCD_8.getInt(1);
                    }
                    if(resultSet_tDBSCD_8.getObject(2) != null) {
                        row_tDBSCD_8.code_menu = resultSet_tDBSCD_8.getString(2);
                    }
                    if(resultSet_tDBSCD_8.getObject(3) != null) {
                        row_tDBSCD_8.temps_theo_preparation = resultSet_tDBSCD_8.getString(3);
                    }
                    if(resultSet_tDBSCD_8.getObject(4) != null) {
                        row_tDBSCD_8.nombre_articles = resultSet_tDBSCD_8.getInt(4);
                    }
                    if(resultSet_tDBSCD_8.getObject(5) != null) {
                        row_tDBSCD_8.libelle_menu = resultSet_tDBSCD_8.getString(5);
                    }
            cache_tDBSCD_8.put(sk_tDBSCD_8, row_tDBSCD_8);
        }
        resultSet_tDBSCD_8.close();
        statement_tDBSCD_8.close();
    String insertionSQL_tDBSCD_8 = "INSERT INTO \"" + tableName_tDBSCD_8 + "\"(\"id_menu\", \"id_menu_src\", \"code_menu\", \"temps_theo_preparation\", \"nombre_articles\", \"libelle_menu\") VALUES(" + "nextval('"+((dbSchema_tDBSCD_8!= null && dbSchema_tDBSCD_8.trim().length()!=0)?dbSchema_tDBSCD_8 +".":"") +"seq_id_menu"+ "')" + ", ?, ?, ?, ?, ?)";
    java.sql.PreparedStatement insertionStatement_tDBSCD_8 = connection_tDBSCD_8.prepareStatement(insertionSQL_tDBSCD_8);
        String updateSQLForType1_tDBSCD_8 = "UPDATE \"" + tableName_tDBSCD_8 + "\" SET \"temps_theo_preparation\" = ?, \"nombre_articles\" = ?, \"libelle_menu\" = ? WHERE \"id_menu_src\" = ?";
        java.sql.PreparedStatement updateForType1_tDBSCD_8 = connection_tDBSCD_8.prepareStatement(updateSQLForType1_tDBSCD_8);        
    
        SCDSK_tDBSCD_8 lookUpKey_tDBSCD_8 = null;        
    SCDStruct_tDBSCD_8 lookUpValue_tDBSCD_8 = null;

 



/**
 * [tDBSCD_8 begin ] stop
 */



	
	/**
	 * [tMap_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tMap_1", false);
		start_Hash.put("tMap_1", System.currentTimeMillis());
		
				tStatCatcher_1.addMessage("begin","tMap_1");
				tStatCatcher_1Process(globalMap);
			
	
	currentComponent="tMap_1";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row2");
					}
				
		int tos_count_tMap_1 = 0;
		




// ###############################
// # Lookup's keys initialization
// ###############################        

// ###############################
// # Vars initialization
class  Var__tMap_1__Struct  {
}
Var__tMap_1__Struct Var__tMap_1 = new Var__tMap_1__Struct();
// ###############################

// ###############################
// # Outputs initialization
allim_adresse_normStruct allim_adresse_norm_tmp = new allim_adresse_normStruct();
alim_adresse_norm_restauStruct alim_adresse_norm_restau_tmp = new alim_adresse_norm_restauStruct();
alim_clientStruct alim_client_tmp = new alim_clientStruct();
aim_date_commandeStruct aim_date_commande_tmp = new aim_date_commandeStruct();
alim_moyen_paiementStruct alim_moyen_paiement_tmp = new alim_moyen_paiementStruct();
alim_preparationStruct alim_preparation_tmp = new alim_preparationStruct();
alim_restauStruct alim_restau_tmp = new alim_restauStruct();
alim_menuStruct alim_menu_tmp = new alim_menuStruct();
// ###############################

        
        



        









 



/**
 * [tMap_1 begin ] stop
 */



	
	/**
	 * [tDBInput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBInput_1", false);
		start_Hash.put("tDBInput_1", System.currentTimeMillis());
		
				tStatCatcher_1.addMessage("begin","tDBInput_1");
				tStatCatcher_1Process(globalMap);
			
	
	currentComponent="tDBInput_1";

	
		int tos_count_tDBInput_1 = 0;
		
	
    
	
		    int nb_line_tDBInput_1 = 0;
		    java.sql.Connection conn_tDBInput_1 = null;
				String driverClass_tDBInput_1 = "org.postgresql.Driver";
			    java.lang.Class jdbcclazz_tDBInput_1 = java.lang.Class.forName(driverClass_tDBInput_1);
				String dbUser_tDBInput_1 = "dsid_cc2_tos_rw";
				
				 
	final String decryptedPassword_tDBInput_1 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:75JUEgvjKPvGQoQ/fCMgy76m+g2ZM/2K6jfA3DFtGfo=");
				
				String dbPwd_tDBInput_1 = decryptedPassword_tDBInput_1;
				
				String url_tDBInput_1 = "jdbc:postgresql://" + "" + ":" + "5432" + "/" + "postgres";
				
				conn_tDBInput_1 = java.sql.DriverManager.getConnection(url_tDBInput_1,dbUser_tDBInput_1,dbPwd_tDBInput_1);
		        
				conn_tDBInput_1.setAutoCommit(false);
			
		    
			java.sql.Statement stmt_tDBInput_1 = conn_tDBInput_1.createStatement();

		    String dbquery_tDBInput_1 = "SELECT \n  \"dsid_liv_wrk\".\"dm1_ods\".\"id_ods_dm1\", \n  \"dsid_liv_wrk\".\"dm1_ods\".\"id_preparation\", \n  \"dsid_li"
+"v_wrk\".\"dm1_ods\".\"date_debut_preparation\", \n  \"dsid_liv_wrk\".\"dm1_ods\".\"date_fin_preparation\", \n  \"dsid_liv_"
+"wrk\".\"dm1_ods\".\"temps_reel_preparation\", \n  \"dsid_liv_wrk\".\"dm1_ods\".\"id_moyen_paiement\", \n  \"dsid_liv_wrk\""
+".\"dm1_ods\".\"code_moyen_paiement\", \n  \"dsid_liv_wrk\".\"dm1_ods\".\"livelle_moyen_paiement\", \n  \"dsid_liv_wrk\".\""
+"dm1_ods\".\"id_menu\", \n  \"dsid_liv_wrk\".\"dm1_ods\".\"code_menu\", \n  \"dsid_liv_wrk\".\"dm1_ods\".\"libelle_menu\", "
+"\n  \"dsid_liv_wrk\".\"dm1_ods\".\"nombre_articles\", \n  \"dsid_liv_wrk\".\"dm1_ods\".\"temps_theo_preparation\", \n  \"ds"
+"id_liv_wrk\".\"dm1_ods\".\"id_commande\", \n  \"dsid_liv_wrk\".\"dm1_ods\".\"numero_commande\", \n  \"dsid_liv_wrk\".\"dm1"
+"_ods\".\"date_commande\", \n  \"dsid_liv_wrk\".\"dm1_ods\".\"montant_total\", \n  \"dsid_liv_wrk\".\"dm1_ods\".\"id_adress"
+"e_norm_restaurant\", \n  \"dsid_liv_wrk\".\"dm1_ods\".\"numero_voie_restau\", \n  \"dsid_liv_wrk\".\"dm1_ods\".\"nom_voie_"
+"restau\", \n  \"dsid_liv_wrk\".\"dm1_ods\".\"code_postal_restau\", \n  \"dsid_liv_wrk\".\"dm1_ods\".\"nom_ville_restau\", "
+"\n  \"dsid_liv_wrk\".\"dm1_ods\".\"longitude_restau\", \n  \"dsid_liv_wrk\".\"dm1_ods\".\"latitude_restau\", \n  \"dsid_liv"
+"_wrk\".\"dm1_ods\".\"id_adresse_restaurant\", \n  \"dsid_liv_wrk\".\"dm1_ods\".\"adresse_restaurant\", \n  \"dsid_liv_wrk"
+"\".\"dm1_ods\".\"id_restaurant\", \n  \"dsid_liv_wrk\".\"dm1_ods\".\"code_restaurant\", \n  \"dsid_liv_wrk\".\"dm1_ods\"."
+"\"raison_sociale_restaurant\", \n  \"dsid_liv_wrk\".\"dm1_ods\".\"id_adresse_norm_client\", \n  \"dsid_liv_wrk\".\"dm1_ods"
+"\".\"numero_voie\", \n  \"dsid_liv_wrk\".\"dm1_ods\".\"nom_voie\", \n  \"dsid_liv_wrk\".\"dm1_ods\".\"code_postal\", \n  \""
+"dsid_liv_wrk\".\"dm1_ods\".\"nom_ville\", \n  \"dsid_liv_wrk\".\"dm1_ods\".\"longitude\", \n  \"dsid_liv_wrk\".\"dm1_ods\""
+".\"latitude\", \n  \"dsid_liv_wrk\".\"dm1_ods\".\"id_adresse_client\", \n  \"dsid_liv_wrk\".\"dm1_ods\".\"adresse_client\""
+", \n  \"dsid_liv_wrk\".\"dm1_ods\".\"id_client\", \n  \"dsid_liv_wrk\".\"dm1_ods\".\"nom_client\", \n  \"dsid_liv_wrk\".\"d"
+"m1_ods\".\"prenom_client\"\nFROM \"dsid_liv_wrk\".\"dm1_ods\"";
		    

            	globalMap.put("tDBInput_1_QUERY",dbquery_tDBInput_1);
		    java.sql.ResultSet rs_tDBInput_1 = null;

		    try {
		    	rs_tDBInput_1 = stmt_tDBInput_1.executeQuery(dbquery_tDBInput_1);
		    	java.sql.ResultSetMetaData rsmd_tDBInput_1 = rs_tDBInput_1.getMetaData();
		    	int colQtyInRs_tDBInput_1 = rsmd_tDBInput_1.getColumnCount();

		    String tmpContent_tDBInput_1 = null;
		    
		    
		    while (rs_tDBInput_1.next()) {
		        nb_line_tDBInput_1++;
		        
							if(colQtyInRs_tDBInput_1 < 1) {
								row2.id_ods_dm1 = 0;
							} else {
		                          
            row2.id_ods_dm1 = rs_tDBInput_1.getInt(1);
            if(rs_tDBInput_1.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 2) {
								row2.id_preparation = null;
							} else {
		                          
            row2.id_preparation = rs_tDBInput_1.getInt(2);
            if(rs_tDBInput_1.wasNull()){
                    row2.id_preparation = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 3) {
								row2.date_debut_preparation = null;
							} else {
										
			row2.date_debut_preparation = routines.system.JDBCUtil.getDate(rs_tDBInput_1, 3);
		                    }
							if(colQtyInRs_tDBInput_1 < 4) {
								row2.date_fin_preparation = null;
							} else {
										
			row2.date_fin_preparation = routines.system.JDBCUtil.getDate(rs_tDBInput_1, 4);
		                    }
							if(colQtyInRs_tDBInput_1 < 5) {
								row2.temps_reel_preparation = null;
							} else {
	                         		
        	row2.temps_reel_preparation = routines.system.JDBCUtil.getString(rs_tDBInput_1, 5, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 6) {
								row2.id_moyen_paiement = null;
							} else {
		                          
            row2.id_moyen_paiement = rs_tDBInput_1.getInt(6);
            if(rs_tDBInput_1.wasNull()){
                    row2.id_moyen_paiement = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 7) {
								row2.code_moyen_paiement = null;
							} else {
	                         		
        	row2.code_moyen_paiement = routines.system.JDBCUtil.getString(rs_tDBInput_1, 7, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 8) {
								row2.livelle_moyen_paiement = null;
							} else {
	                         		
        	row2.livelle_moyen_paiement = routines.system.JDBCUtil.getString(rs_tDBInput_1, 8, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 9) {
								row2.id_menu = null;
							} else {
		                          
            row2.id_menu = rs_tDBInput_1.getInt(9);
            if(rs_tDBInput_1.wasNull()){
                    row2.id_menu = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 10) {
								row2.code_menu = null;
							} else {
	                         		
        	row2.code_menu = routines.system.JDBCUtil.getString(rs_tDBInput_1, 10, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 11) {
								row2.libelle_menu = null;
							} else {
	                         		
        	row2.libelle_menu = routines.system.JDBCUtil.getString(rs_tDBInput_1, 11, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 12) {
								row2.nombre_articles = null;
							} else {
		                          
            row2.nombre_articles = rs_tDBInput_1.getInt(12);
            if(rs_tDBInput_1.wasNull()){
                    row2.nombre_articles = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 13) {
								row2.temps_theo_preparation = null;
							} else {
	                         		
        	row2.temps_theo_preparation = routines.system.JDBCUtil.getString(rs_tDBInput_1, 13, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 14) {
								row2.id_commande = null;
							} else {
		                          
            row2.id_commande = rs_tDBInput_1.getInt(14);
            if(rs_tDBInput_1.wasNull()){
                    row2.id_commande = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 15) {
								row2.numero_commande = null;
							} else {
		                          
            row2.numero_commande = rs_tDBInput_1.getInt(15);
            if(rs_tDBInput_1.wasNull()){
                    row2.numero_commande = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 16) {
								row2.date_commande = null;
							} else {
										
			row2.date_commande = routines.system.JDBCUtil.getDate(rs_tDBInput_1, 16);
		                    }
							if(colQtyInRs_tDBInput_1 < 17) {
								row2.montant_total = null;
							} else {
		                          
            row2.montant_total = rs_tDBInput_1.getFloat(17);
            if(rs_tDBInput_1.wasNull()){
                    row2.montant_total = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 18) {
								row2.id_adresse_norm_restaurant = null;
							} else {
		                          
            row2.id_adresse_norm_restaurant = rs_tDBInput_1.getInt(18);
            if(rs_tDBInput_1.wasNull()){
                    row2.id_adresse_norm_restaurant = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 19) {
								row2.numero_voie_restau = null;
							} else {
	                         		
        	row2.numero_voie_restau = routines.system.JDBCUtil.getString(rs_tDBInput_1, 19, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 20) {
								row2.nom_voie_restau = null;
							} else {
	                         		
        	row2.nom_voie_restau = routines.system.JDBCUtil.getString(rs_tDBInput_1, 20, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 21) {
								row2.code_postal_restau = null;
							} else {
	                         		
        	row2.code_postal_restau = routines.system.JDBCUtil.getString(rs_tDBInput_1, 21, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 22) {
								row2.nom_ville_restau = null;
							} else {
	                         		
        	row2.nom_ville_restau = routines.system.JDBCUtil.getString(rs_tDBInput_1, 22, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 23) {
								row2.longitude_restau = null;
							} else {
	                         		
        	row2.longitude_restau = routines.system.JDBCUtil.getString(rs_tDBInput_1, 23, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 24) {
								row2.latitude_restau = null;
							} else {
	                         		
        	row2.latitude_restau = routines.system.JDBCUtil.getString(rs_tDBInput_1, 24, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 25) {
								row2.id_adresse_restaurant = null;
							} else {
		                          
            row2.id_adresse_restaurant = rs_tDBInput_1.getInt(25);
            if(rs_tDBInput_1.wasNull()){
                    row2.id_adresse_restaurant = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 26) {
								row2.adresse_restaurant = null;
							} else {
	                         		
        	row2.adresse_restaurant = routines.system.JDBCUtil.getString(rs_tDBInput_1, 26, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 27) {
								row2.id_restaurant = null;
							} else {
		                          
            row2.id_restaurant = rs_tDBInput_1.getInt(27);
            if(rs_tDBInput_1.wasNull()){
                    row2.id_restaurant = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 28) {
								row2.code_restaurant = null;
							} else {
	                         		
        	row2.code_restaurant = routines.system.JDBCUtil.getString(rs_tDBInput_1, 28, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 29) {
								row2.raison_sociale_restaurant = null;
							} else {
	                         		
        	row2.raison_sociale_restaurant = routines.system.JDBCUtil.getString(rs_tDBInput_1, 29, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 30) {
								row2.id_adresse_norm_client = null;
							} else {
		                          
            row2.id_adresse_norm_client = rs_tDBInput_1.getInt(30);
            if(rs_tDBInput_1.wasNull()){
                    row2.id_adresse_norm_client = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 31) {
								row2.numero_voie = null;
							} else {
	                         		
        	row2.numero_voie = routines.system.JDBCUtil.getString(rs_tDBInput_1, 31, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 32) {
								row2.nom_voie = null;
							} else {
	                         		
        	row2.nom_voie = routines.system.JDBCUtil.getString(rs_tDBInput_1, 32, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 33) {
								row2.code_postal = null;
							} else {
	                         		
        	row2.code_postal = routines.system.JDBCUtil.getString(rs_tDBInput_1, 33, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 34) {
								row2.nom_ville = null;
							} else {
	                         		
        	row2.nom_ville = routines.system.JDBCUtil.getString(rs_tDBInput_1, 34, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 35) {
								row2.longitude = null;
							} else {
	                         		
        	row2.longitude = routines.system.JDBCUtil.getString(rs_tDBInput_1, 35, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 36) {
								row2.latitude = null;
							} else {
	                         		
        	row2.latitude = routines.system.JDBCUtil.getString(rs_tDBInput_1, 36, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 37) {
								row2.id_adresse_client = null;
							} else {
		                          
            row2.id_adresse_client = rs_tDBInput_1.getInt(37);
            if(rs_tDBInput_1.wasNull()){
                    row2.id_adresse_client = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 38) {
								row2.adresse_client = null;
							} else {
	                         		
        	row2.adresse_client = routines.system.JDBCUtil.getString(rs_tDBInput_1, 38, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 39) {
								row2.id_client = null;
							} else {
		                          
            row2.id_client = rs_tDBInput_1.getInt(39);
            if(rs_tDBInput_1.wasNull()){
                    row2.id_client = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 40) {
								row2.nom_client = null;
							} else {
	                         		
        	row2.nom_client = routines.system.JDBCUtil.getString(rs_tDBInput_1, 40, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 41) {
								row2.prenom_client = null;
							} else {
	                         		
        	row2.prenom_client = routines.system.JDBCUtil.getString(rs_tDBInput_1, 41, false);
		                    }
					


 



/**
 * [tDBInput_1 begin ] stop
 */
	
	/**
	 * [tDBInput_1 main ] start
	 */

	

	
	
	currentComponent="tDBInput_1";

	

 


	tos_count_tDBInput_1++;

/**
 * [tDBInput_1 main ] stop
 */
	
	/**
	 * [tDBInput_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBInput_1";

	

 



/**
 * [tDBInput_1 process_data_begin ] stop
 */

	
	/**
	 * [tMap_1 main ] start
	 */

	

	
	
	currentComponent="tMap_1";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row2"
						
						);
					}
					

		
		
		boolean hasCasePrimitiveKeyWithNull_tMap_1 = false;
		

        // ###############################
        // # Input tables (lookups)
		  boolean rejectedInnerJoin_tMap_1 = false;
		  boolean mainRowRejected_tMap_1 = false;
            				    								  
		// ###############################
        { // start of Var scope
        
	        // ###############################
        	// # Vars tables
        
Var__tMap_1__Struct Var = Var__tMap_1;// ###############################
        // ###############################
        // # Output tables

allim_adresse_norm = null;
alim_adresse_norm_restau = null;
alim_client = null;
aim_date_commande = null;
alim_moyen_paiement = null;
alim_preparation = null;
alim_restau = null;
alim_menu = null;


// # Output table : 'allim_adresse_norm'
allim_adresse_norm_tmp.id_adresse_norm_client = 0;
allim_adresse_norm_tmp.id_adresse_norm_client_src = row2.id_adresse_norm_client;
allim_adresse_norm_tmp.numero_voie = row2.numero_voie;
allim_adresse_norm_tmp.nom_voie = row2.nom_voie;
allim_adresse_norm_tmp.code_postal = row2.code_postal;
allim_adresse_norm_tmp.nom_ville = row2.nom_ville;
allim_adresse_norm_tmp.longitude = row2.longitude;
allim_adresse_norm_tmp.latitude = row2.latitude;
allim_adresse_norm = allim_adresse_norm_tmp;

// # Output table : 'alim_adresse_norm_restau'
alim_adresse_norm_restau_tmp.id_adresse_norm_restaurant = 0;
alim_adresse_norm_restau_tmp.id_adresse_norm_restau_src = row2.id_adresse_norm_restaurant;
alim_adresse_norm_restau_tmp.numero_voie = row2.numero_voie_restau ;
alim_adresse_norm_restau_tmp.nom_voie = row2.nom_voie_restau;
alim_adresse_norm_restau_tmp.code_postal = row2.code_postal_restau;
alim_adresse_norm_restau_tmp.nom_ville = row2.nom_ville_restau;
alim_adresse_norm_restau_tmp.longitude = row2.longitude_restau;
alim_adresse_norm_restau_tmp.latitude = row2.latitude_restau;
alim_adresse_norm_restau = alim_adresse_norm_restau_tmp;

// # Output table : 'alim_client'
alim_client_tmp.id_client = 0;
alim_client_tmp.id_client_src = row2.id_client;
alim_client_tmp.nom_client = row2.nom_client;
alim_client_tmp.prenom_client = row2.prenom_client;
alim_client_tmp.nom_precedent = null;
alim_client = alim_client_tmp;

// # Output table : 'aim_date_commande'
aim_date_commande_tmp.id_date_commande = 0;
aim_date_commande_tmp.date_commande = row2.date_commande;
aim_date_commande_tmp.jour = "D" + TalendDate.getPartOfDate("DAY_OF_MONTH", row2.date_commande) ;
aim_date_commande_tmp.semaine = "W" + TalendDate.getPartOfDate("WEEK_OF_YEAR", row2.date_commande) ;
aim_date_commande_tmp.mois = "M" + TalendDate.getPartOfDate("MONTH_OF_YEAR", row2.date_commande) ;
aim_date_commande_tmp.annee = "Y" + TalendDate.getPartOfDate("YEAR", row2.date_commande) ;
aim_date_commande = aim_date_commande_tmp;

// # Output table : 'alim_moyen_paiement'
alim_moyen_paiement_tmp.id_moyen_paiement = 0;
alim_moyen_paiement_tmp.id_moyen_paiement_src = row2.id_moyen_paiement;
alim_moyen_paiement_tmp.code_moyen_paiement = row2.code_moyen_paiement;
alim_moyen_paiement_tmp.livelle_moyen_paiement = row2.livelle_moyen_paiement;
alim_moyen_paiement = alim_moyen_paiement_tmp;

// # Output table : 'alim_preparation'
alim_preparation_tmp.id_preparation = 0;
alim_preparation_tmp.id_preparation_src = row2.id_preparation;
alim_preparation_tmp.date_debut_preparation = row2.date_debut_preparation;
alim_preparation_tmp.date_fin_preparation = row2.date_fin_preparation;
alim_preparation = alim_preparation_tmp;

// # Output table : 'alim_restau'
alim_restau_tmp.id_restaurant = 0;
alim_restau_tmp.id_restaurant_src = row2.id_restaurant;
alim_restau_tmp.code_restaurant = row2.code_restaurant;
alim_restau_tmp.raison_sociale_restaurant = row2.raison_sociale_restaurant;
alim_restau_tmp.scd_start = null;
alim_restau_tmp.scd_end = null;
alim_restau_tmp.scd_version = null;
alim_restau_tmp.scd_active = null;
alim_restau = alim_restau_tmp;

// # Output table : 'alim_menu'
alim_menu_tmp.id_menu = 0;
alim_menu_tmp.id_menu_src = row2.id_menu ;
alim_menu_tmp.code_menu = row2.code_menu ;
alim_menu_tmp.libelle_menu = row2.libelle_menu ;
alim_menu_tmp.nombre_articles = row2.nombre_articles;
alim_menu_tmp.temps_theo_preparation =  row2.temps_theo_preparation ;
alim_menu = alim_menu_tmp;
// ###############################

} // end of Var scope

rejectedInnerJoin_tMap_1 = false;










 


	tos_count_tMap_1++;

/**
 * [tMap_1 main ] stop
 */
	
	/**
	 * [tMap_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tMap_1";

	

 



/**
 * [tMap_1 process_data_begin ] stop
 */
// Start of branch "allim_adresse_norm"
if(allim_adresse_norm != null) { 



	
	/**
	 * [tDBSCD_1 main ] start
	 */

	

	
	
	currentComponent="tDBSCD_1";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"allim_adresse_norm"
						
						);
					}
					

 	try {
        lookUpKey_tDBSCD_1 = new SCDSK_tDBSCD_1();
            lookUpKey_tDBSCD_1.id_adresse_norm_client_src = allim_adresse_norm.id_adresse_norm_client_src;
        lookUpKey_tDBSCD_1.hashCodeDirty = true;
        lookUpValue_tDBSCD_1 = cache_tDBSCD_1.get(lookUpKey_tDBSCD_1);    
    if(lookUpValue_tDBSCD_1 == null) {
            lookUpValue_tDBSCD_1 = new SCDStruct_tDBSCD_1();
        
                    if(allim_adresse_norm.id_adresse_norm_client_src == null) {
insertionStatement_tDBSCD_1.setNull(1, java.sql.Types.INTEGER);
} else {
insertionStatement_tDBSCD_1.setInt(1, allim_adresse_norm.id_adresse_norm_client_src);
}

                    if(allim_adresse_norm.code_postal == null) {
insertionStatement_tDBSCD_1.setNull(2, java.sql.Types.VARCHAR);
} else {
insertionStatement_tDBSCD_1.setString(2, allim_adresse_norm.code_postal);
}

                    if(allim_adresse_norm.latitude == null) {
insertionStatement_tDBSCD_1.setNull(3, java.sql.Types.VARCHAR);
} else {
insertionStatement_tDBSCD_1.setString(3, allim_adresse_norm.latitude);
}

                    if(allim_adresse_norm.longitude == null) {
insertionStatement_tDBSCD_1.setNull(4, java.sql.Types.VARCHAR);
} else {
insertionStatement_tDBSCD_1.setString(4, allim_adresse_norm.longitude);
}

                    if(allim_adresse_norm.nom_ville == null) {
insertionStatement_tDBSCD_1.setNull(5, java.sql.Types.VARCHAR);
} else {
insertionStatement_tDBSCD_1.setString(5, allim_adresse_norm.nom_ville);
}

                    if(allim_adresse_norm.numero_voie == null) {
insertionStatement_tDBSCD_1.setNull(6, java.sql.Types.VARCHAR);
} else {
insertionStatement_tDBSCD_1.setString(6, allim_adresse_norm.numero_voie);
}

                    if(allim_adresse_norm.nom_voie == null) {
insertionStatement_tDBSCD_1.setNull(7, java.sql.Types.VARCHAR);
} else {
insertionStatement_tDBSCD_1.setString(7, allim_adresse_norm.nom_voie);
}

        nb_line_inserted_tDBSCD_1 += insertionStatement_tDBSCD_1.executeUpdate();
    } else {
            if((lookUpValue_tDBSCD_1.nom_ville == null && allim_adresse_norm.nom_ville!= null) || (lookUpValue_tDBSCD_1.nom_ville != null && !lookUpValue_tDBSCD_1.nom_ville.equals(allim_adresse_norm.nom_ville)) || (lookUpValue_tDBSCD_1.numero_voie == null && allim_adresse_norm.numero_voie!= null) || (lookUpValue_tDBSCD_1.numero_voie != null && !lookUpValue_tDBSCD_1.numero_voie.equals(allim_adresse_norm.numero_voie)) || (lookUpValue_tDBSCD_1.nom_voie == null && allim_adresse_norm.nom_voie!= null) || (lookUpValue_tDBSCD_1.nom_voie != null && !lookUpValue_tDBSCD_1.nom_voie.equals(allim_adresse_norm.nom_voie))) {
                    if(allim_adresse_norm.nom_ville == null) {
updateForType1_tDBSCD_1.setNull(1, java.sql.Types.VARCHAR);
} else {
updateForType1_tDBSCD_1.setString(1, allim_adresse_norm.nom_ville);
}

                    if(allim_adresse_norm.numero_voie == null) {
updateForType1_tDBSCD_1.setNull(2, java.sql.Types.VARCHAR);
} else {
updateForType1_tDBSCD_1.setString(2, allim_adresse_norm.numero_voie);
}

                    if(allim_adresse_norm.nom_voie == null) {
updateForType1_tDBSCD_1.setNull(3, java.sql.Types.VARCHAR);
} else {
updateForType1_tDBSCD_1.setString(3, allim_adresse_norm.nom_voie);
}

                    if(allim_adresse_norm.id_adresse_norm_client_src == null) {
updateForType1_tDBSCD_1.setNull(4, java.sql.Types.INTEGER);
} else {
updateForType1_tDBSCD_1.setInt(4, allim_adresse_norm.id_adresse_norm_client_src);
}

                nb_line_update_tDBSCD_1 += updateForType1_tDBSCD_1.executeUpdate();
            }
    }

	} catch (java.lang.Exception e) {//catch
globalMap.put("tDBSCD_1_ERROR_MESSAGE",e.getMessage());
  		
                System.err.print(e.getMessage());
	}//end catch
	
                lookUpValue_tDBSCD_1.nom_ville = allim_adresse_norm.nom_ville;
                lookUpValue_tDBSCD_1.numero_voie = allim_adresse_norm.numero_voie;
                lookUpValue_tDBSCD_1.nom_voie = allim_adresse_norm.nom_voie;
        cache_tDBSCD_1.put(lookUpKey_tDBSCD_1, lookUpValue_tDBSCD_1);

 


	tos_count_tDBSCD_1++;

/**
 * [tDBSCD_1 main ] stop
 */
	
	/**
	 * [tDBSCD_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBSCD_1";

	

 



/**
 * [tDBSCD_1 process_data_begin ] stop
 */
	
	/**
	 * [tDBSCD_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBSCD_1";

	

 



/**
 * [tDBSCD_1 process_data_end ] stop
 */

} // End of branch "allim_adresse_norm"




// Start of branch "alim_adresse_norm_restau"
if(alim_adresse_norm_restau != null) { 



	
	/**
	 * [tDBSCD_2 main ] start
	 */

	

	
	
	currentComponent="tDBSCD_2";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"alim_adresse_norm_restau"
						
						);
					}
					

 	try {
        lookUpKey_tDBSCD_2 = new SCDSK_tDBSCD_2();
            lookUpKey_tDBSCD_2.id_adresse_norm_restau_src = alim_adresse_norm_restau.id_adresse_norm_restau_src;
        lookUpKey_tDBSCD_2.hashCodeDirty = true;
        lookUpValue_tDBSCD_2 = cache_tDBSCD_2.get(lookUpKey_tDBSCD_2);    
    if(lookUpValue_tDBSCD_2 == null) {
            lookUpValue_tDBSCD_2 = new SCDStruct_tDBSCD_2();
        
                    if(alim_adresse_norm_restau.id_adresse_norm_restau_src == null) {
insertionStatement_tDBSCD_2.setNull(1, java.sql.Types.INTEGER);
} else {
insertionStatement_tDBSCD_2.setInt(1, alim_adresse_norm_restau.id_adresse_norm_restau_src);
}

                    if(alim_adresse_norm_restau.code_postal == null) {
insertionStatement_tDBSCD_2.setNull(2, java.sql.Types.VARCHAR);
} else {
insertionStatement_tDBSCD_2.setString(2, alim_adresse_norm_restau.code_postal);
}

                    if(alim_adresse_norm_restau.latitude == null) {
insertionStatement_tDBSCD_2.setNull(3, java.sql.Types.VARCHAR);
} else {
insertionStatement_tDBSCD_2.setString(3, alim_adresse_norm_restau.latitude);
}

                    if(alim_adresse_norm_restau.longitude == null) {
insertionStatement_tDBSCD_2.setNull(4, java.sql.Types.VARCHAR);
} else {
insertionStatement_tDBSCD_2.setString(4, alim_adresse_norm_restau.longitude);
}

                    if(alim_adresse_norm_restau.nom_ville == null) {
insertionStatement_tDBSCD_2.setNull(5, java.sql.Types.VARCHAR);
} else {
insertionStatement_tDBSCD_2.setString(5, alim_adresse_norm_restau.nom_ville);
}

                    if(alim_adresse_norm_restau.nom_voie == null) {
insertionStatement_tDBSCD_2.setNull(6, java.sql.Types.VARCHAR);
} else {
insertionStatement_tDBSCD_2.setString(6, alim_adresse_norm_restau.nom_voie);
}

                    if(alim_adresse_norm_restau.numero_voie == null) {
insertionStatement_tDBSCD_2.setNull(7, java.sql.Types.VARCHAR);
} else {
insertionStatement_tDBSCD_2.setString(7, alim_adresse_norm_restau.numero_voie);
}

        nb_line_inserted_tDBSCD_2 += insertionStatement_tDBSCD_2.executeUpdate();
    } else {
            if((lookUpValue_tDBSCD_2.nom_ville == null && alim_adresse_norm_restau.nom_ville!= null) || (lookUpValue_tDBSCD_2.nom_ville != null && !lookUpValue_tDBSCD_2.nom_ville.equals(alim_adresse_norm_restau.nom_ville)) || (lookUpValue_tDBSCD_2.nom_voie == null && alim_adresse_norm_restau.nom_voie!= null) || (lookUpValue_tDBSCD_2.nom_voie != null && !lookUpValue_tDBSCD_2.nom_voie.equals(alim_adresse_norm_restau.nom_voie)) || (lookUpValue_tDBSCD_2.numero_voie == null && alim_adresse_norm_restau.numero_voie!= null) || (lookUpValue_tDBSCD_2.numero_voie != null && !lookUpValue_tDBSCD_2.numero_voie.equals(alim_adresse_norm_restau.numero_voie))) {
                    if(alim_adresse_norm_restau.nom_ville == null) {
updateForType1_tDBSCD_2.setNull(1, java.sql.Types.VARCHAR);
} else {
updateForType1_tDBSCD_2.setString(1, alim_adresse_norm_restau.nom_ville);
}

                    if(alim_adresse_norm_restau.nom_voie == null) {
updateForType1_tDBSCD_2.setNull(2, java.sql.Types.VARCHAR);
} else {
updateForType1_tDBSCD_2.setString(2, alim_adresse_norm_restau.nom_voie);
}

                    if(alim_adresse_norm_restau.numero_voie == null) {
updateForType1_tDBSCD_2.setNull(3, java.sql.Types.VARCHAR);
} else {
updateForType1_tDBSCD_2.setString(3, alim_adresse_norm_restau.numero_voie);
}

                    if(alim_adresse_norm_restau.id_adresse_norm_restau_src == null) {
updateForType1_tDBSCD_2.setNull(4, java.sql.Types.INTEGER);
} else {
updateForType1_tDBSCD_2.setInt(4, alim_adresse_norm_restau.id_adresse_norm_restau_src);
}

                nb_line_update_tDBSCD_2 += updateForType1_tDBSCD_2.executeUpdate();
            }
    }

	} catch (java.lang.Exception e) {//catch
globalMap.put("tDBSCD_2_ERROR_MESSAGE",e.getMessage());
  		
                System.err.print(e.getMessage());
	}//end catch
	
                lookUpValue_tDBSCD_2.nom_ville = alim_adresse_norm_restau.nom_ville;
                lookUpValue_tDBSCD_2.nom_voie = alim_adresse_norm_restau.nom_voie;
                lookUpValue_tDBSCD_2.numero_voie = alim_adresse_norm_restau.numero_voie;
        cache_tDBSCD_2.put(lookUpKey_tDBSCD_2, lookUpValue_tDBSCD_2);

 


	tos_count_tDBSCD_2++;

/**
 * [tDBSCD_2 main ] stop
 */
	
	/**
	 * [tDBSCD_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBSCD_2";

	

 



/**
 * [tDBSCD_2 process_data_begin ] stop
 */
	
	/**
	 * [tDBSCD_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBSCD_2";

	

 



/**
 * [tDBSCD_2 process_data_end ] stop
 */

} // End of branch "alim_adresse_norm_restau"




// Start of branch "alim_client"
if(alim_client != null) { 



	
	/**
	 * [tDBSCD_3 main ] start
	 */

	

	
	
	currentComponent="tDBSCD_3";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"alim_client"
						
						);
					}
					

 	try {
        lookUpKey_tDBSCD_3 = new SCDSK_tDBSCD_3();
            lookUpKey_tDBSCD_3.id_client_src = alim_client.id_client_src;
        lookUpKey_tDBSCD_3.hashCodeDirty = true;
        lookUpValue_tDBSCD_3 = cache_tDBSCD_3.get(lookUpKey_tDBSCD_3);    
    if(lookUpValue_tDBSCD_3 == null) {
            lookUpValue_tDBSCD_3 = new SCDStruct_tDBSCD_3();
        
                    if(alim_client.id_client_src == null) {
insertionStatement_tDBSCD_3.setNull(1, java.sql.Types.INTEGER);
} else {
insertionStatement_tDBSCD_3.setInt(1, alim_client.id_client_src);
}

                    if(alim_client.prenom_client == null) {
insertionStatement_tDBSCD_3.setNull(2, java.sql.Types.VARCHAR);
} else {
insertionStatement_tDBSCD_3.setString(2, alim_client.prenom_client);
}

                    if(alim_client.nom_client == null) {
insertionStatement_tDBSCD_3.setNull(3, java.sql.Types.VARCHAR);
} else {
insertionStatement_tDBSCD_3.setString(3, alim_client.nom_client);
}

        nb_line_inserted_tDBSCD_3 += insertionStatement_tDBSCD_3.executeUpdate();
    } else {
            if((lookUpValue_tDBSCD_3.prenom_client == null && alim_client.prenom_client!= null) || (lookUpValue_tDBSCD_3.prenom_client != null && !lookUpValue_tDBSCD_3.prenom_client.equals(alim_client.prenom_client))) {
                    if(alim_client.prenom_client == null) {
updateForType1_tDBSCD_3.setNull(1, java.sql.Types.VARCHAR);
} else {
updateForType1_tDBSCD_3.setString(1, alim_client.prenom_client);
}

                    if(alim_client.id_client_src == null) {
updateForType1_tDBSCD_3.setNull(2, java.sql.Types.INTEGER);
} else {
updateForType1_tDBSCD_3.setInt(2, alim_client.id_client_src);
}

                nb_line_update_tDBSCD_3 += updateForType1_tDBSCD_3.executeUpdate();
            }
            if((lookUpValue_tDBSCD_3.nom_client == null && alim_client.nom_client!= null) || (lookUpValue_tDBSCD_3.nom_client != null && !lookUpValue_tDBSCD_3.nom_client.equals(alim_client.nom_client))) {
                    if(alim_client.nom_client == null) {
updateForType3_tDBSCD_3.setNull(1, java.sql.Types.VARCHAR);
} else {
updateForType3_tDBSCD_3.setString(1, alim_client.nom_client);
}

                   	if(lookUpValue_tDBSCD_3.nom_client == null) {
updateForType3_tDBSCD_3.setNull(2, java.sql.Types.VARCHAR);
} else {
updateForType3_tDBSCD_3.setString(2, lookUpValue_tDBSCD_3.nom_client);
}

                   	
                    if(alim_client.id_client_src == null) {
updateForType3_tDBSCD_3.setNull(3, java.sql.Types.INTEGER);
} else {
updateForType3_tDBSCD_3.setInt(3, alim_client.id_client_src);
}

                nb_line_update_tDBSCD_3 += updateForType3_tDBSCD_3.executeUpdate();
            }
    }

	} catch (java.lang.Exception e) {//catch
globalMap.put("tDBSCD_3_ERROR_MESSAGE",e.getMessage());
  		
                System.err.print(e.getMessage());
	}//end catch
	
                lookUpValue_tDBSCD_3.prenom_client = alim_client.prenom_client;
                lookUpValue_tDBSCD_3.nom_client = alim_client.nom_client;
        cache_tDBSCD_3.put(lookUpKey_tDBSCD_3, lookUpValue_tDBSCD_3);

 


	tos_count_tDBSCD_3++;

/**
 * [tDBSCD_3 main ] stop
 */
	
	/**
	 * [tDBSCD_3 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBSCD_3";

	

 



/**
 * [tDBSCD_3 process_data_begin ] stop
 */
	
	/**
	 * [tDBSCD_3 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBSCD_3";

	

 



/**
 * [tDBSCD_3 process_data_end ] stop
 */

} // End of branch "alim_client"




// Start of branch "aim_date_commande"
if(aim_date_commande != null) { 



	
	/**
	 * [tDBSCD_4 main ] start
	 */

	

	
	
	currentComponent="tDBSCD_4";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"aim_date_commande"
						
						);
					}
					

 	try {
        lookUpKey_tDBSCD_4 = new SCDSK_tDBSCD_4();
            lookUpKey_tDBSCD_4.annee = aim_date_commande.annee;
            lookUpKey_tDBSCD_4.date_commande = aim_date_commande.date_commande;
            lookUpKey_tDBSCD_4.jour = aim_date_commande.jour;
            lookUpKey_tDBSCD_4.mois = aim_date_commande.mois;
            lookUpKey_tDBSCD_4.semaine = aim_date_commande.semaine;
        lookUpKey_tDBSCD_4.hashCodeDirty = true;
        lookUpValue_tDBSCD_4 = cache_tDBSCD_4.get(lookUpKey_tDBSCD_4);    
    if(lookUpValue_tDBSCD_4 == null) {
            lookUpValue_tDBSCD_4 = new SCDStruct_tDBSCD_4();
        
                    if(aim_date_commande.annee == null) {
insertionStatement_tDBSCD_4.setNull(1, java.sql.Types.VARCHAR);
} else {
insertionStatement_tDBSCD_4.setString(1, aim_date_commande.annee);
}

                    if(aim_date_commande.date_commande == null) {
insertionStatement_tDBSCD_4.setNull(2, java.sql.Types.TIMESTAMP);
} else {
if(aim_date_commande.date_commande != null) {
insertionStatement_tDBSCD_4.setTimestamp(2, new java.sql.Timestamp(aim_date_commande.date_commande.getTime()));
} else {
insertionStatement_tDBSCD_4.setNull(2, java.sql.Types.TIMESTAMP);
}
}

                    if(aim_date_commande.jour == null) {
insertionStatement_tDBSCD_4.setNull(3, java.sql.Types.VARCHAR);
} else {
insertionStatement_tDBSCD_4.setString(3, aim_date_commande.jour);
}

                    if(aim_date_commande.mois == null) {
insertionStatement_tDBSCD_4.setNull(4, java.sql.Types.VARCHAR);
} else {
insertionStatement_tDBSCD_4.setString(4, aim_date_commande.mois);
}

                    if(aim_date_commande.semaine == null) {
insertionStatement_tDBSCD_4.setNull(5, java.sql.Types.VARCHAR);
} else {
insertionStatement_tDBSCD_4.setString(5, aim_date_commande.semaine);
}

        nb_line_inserted_tDBSCD_4 += insertionStatement_tDBSCD_4.executeUpdate();
    } else {
    }

	} catch (java.lang.Exception e) {//catch
globalMap.put("tDBSCD_4_ERROR_MESSAGE",e.getMessage());
  		
                System.err.print(e.getMessage());
	}//end catch
	
        cache_tDBSCD_4.put(lookUpKey_tDBSCD_4, lookUpValue_tDBSCD_4);

 


	tos_count_tDBSCD_4++;

/**
 * [tDBSCD_4 main ] stop
 */
	
	/**
	 * [tDBSCD_4 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBSCD_4";

	

 



/**
 * [tDBSCD_4 process_data_begin ] stop
 */
	
	/**
	 * [tDBSCD_4 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBSCD_4";

	

 



/**
 * [tDBSCD_4 process_data_end ] stop
 */

} // End of branch "aim_date_commande"




// Start of branch "alim_moyen_paiement"
if(alim_moyen_paiement != null) { 



	
	/**
	 * [tDBSCD_5 main ] start
	 */

	

	
	
	currentComponent="tDBSCD_5";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"alim_moyen_paiement"
						
						);
					}
					

 	try {
        lookUpKey_tDBSCD_5 = new SCDSK_tDBSCD_5();
            lookUpKey_tDBSCD_5.id_moyen_paiement_src = alim_moyen_paiement.id_moyen_paiement_src;
        lookUpKey_tDBSCD_5.hashCodeDirty = true;
        lookUpValue_tDBSCD_5 = cache_tDBSCD_5.get(lookUpKey_tDBSCD_5);    
    if(lookUpValue_tDBSCD_5 == null) {
            lookUpValue_tDBSCD_5 = new SCDStruct_tDBSCD_5();
        
                    if(alim_moyen_paiement.id_moyen_paiement_src == null) {
insertionStatement_tDBSCD_5.setNull(1, java.sql.Types.INTEGER);
} else {
insertionStatement_tDBSCD_5.setInt(1, alim_moyen_paiement.id_moyen_paiement_src);
}

                    if(alim_moyen_paiement.code_moyen_paiement == null) {
insertionStatement_tDBSCD_5.setNull(2, java.sql.Types.VARCHAR);
} else {
insertionStatement_tDBSCD_5.setString(2, alim_moyen_paiement.code_moyen_paiement);
}

                    if(alim_moyen_paiement.livelle_moyen_paiement == null) {
insertionStatement_tDBSCD_5.setNull(3, java.sql.Types.VARCHAR);
} else {
insertionStatement_tDBSCD_5.setString(3, alim_moyen_paiement.livelle_moyen_paiement);
}

        nb_line_inserted_tDBSCD_5 += insertionStatement_tDBSCD_5.executeUpdate();
    } else {
            if((lookUpValue_tDBSCD_5.livelle_moyen_paiement == null && alim_moyen_paiement.livelle_moyen_paiement!= null) || (lookUpValue_tDBSCD_5.livelle_moyen_paiement != null && !lookUpValue_tDBSCD_5.livelle_moyen_paiement.equals(alim_moyen_paiement.livelle_moyen_paiement))) {
                    if(alim_moyen_paiement.livelle_moyen_paiement == null) {
updateForType1_tDBSCD_5.setNull(1, java.sql.Types.VARCHAR);
} else {
updateForType1_tDBSCD_5.setString(1, alim_moyen_paiement.livelle_moyen_paiement);
}

                    if(alim_moyen_paiement.id_moyen_paiement_src == null) {
updateForType1_tDBSCD_5.setNull(2, java.sql.Types.INTEGER);
} else {
updateForType1_tDBSCD_5.setInt(2, alim_moyen_paiement.id_moyen_paiement_src);
}

                nb_line_update_tDBSCD_5 += updateForType1_tDBSCD_5.executeUpdate();
            }
    }

	} catch (java.lang.Exception e) {//catch
globalMap.put("tDBSCD_5_ERROR_MESSAGE",e.getMessage());
  		
                System.err.print(e.getMessage());
	}//end catch
	
                lookUpValue_tDBSCD_5.livelle_moyen_paiement = alim_moyen_paiement.livelle_moyen_paiement;
        cache_tDBSCD_5.put(lookUpKey_tDBSCD_5, lookUpValue_tDBSCD_5);

 


	tos_count_tDBSCD_5++;

/**
 * [tDBSCD_5 main ] stop
 */
	
	/**
	 * [tDBSCD_5 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBSCD_5";

	

 



/**
 * [tDBSCD_5 process_data_begin ] stop
 */
	
	/**
	 * [tDBSCD_5 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBSCD_5";

	

 



/**
 * [tDBSCD_5 process_data_end ] stop
 */

} // End of branch "alim_moyen_paiement"




// Start of branch "alim_preparation"
if(alim_preparation != null) { 



	
	/**
	 * [tDBSCD_6 main ] start
	 */

	

	
	
	currentComponent="tDBSCD_6";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"alim_preparation"
						
						);
					}
					

 	try {
        lookUpKey_tDBSCD_6 = new SCDSK_tDBSCD_6();
            lookUpKey_tDBSCD_6.id_preparation_src = alim_preparation.id_preparation_src;
        lookUpKey_tDBSCD_6.hashCodeDirty = true;
        lookUpValue_tDBSCD_6 = cache_tDBSCD_6.get(lookUpKey_tDBSCD_6);    
    if(lookUpValue_tDBSCD_6 == null) {
            lookUpValue_tDBSCD_6 = new SCDStruct_tDBSCD_6();
        
                    if(alim_preparation.id_preparation_src == null) {
insertionStatement_tDBSCD_6.setNull(1, java.sql.Types.INTEGER);
} else {
insertionStatement_tDBSCD_6.setInt(1, alim_preparation.id_preparation_src);
}

                    if(alim_preparation.date_debut_preparation == null) {
insertionStatement_tDBSCD_6.setNull(2, java.sql.Types.TIMESTAMP);
} else {
if(alim_preparation.date_debut_preparation != null) {
insertionStatement_tDBSCD_6.setTimestamp(2, new java.sql.Timestamp(alim_preparation.date_debut_preparation.getTime()));
} else {
insertionStatement_tDBSCD_6.setNull(2, java.sql.Types.TIMESTAMP);
}
}

                    if(alim_preparation.date_fin_preparation == null) {
insertionStatement_tDBSCD_6.setNull(3, java.sql.Types.TIMESTAMP);
} else {
if(alim_preparation.date_fin_preparation != null) {
insertionStatement_tDBSCD_6.setTimestamp(3, new java.sql.Timestamp(alim_preparation.date_fin_preparation.getTime()));
} else {
insertionStatement_tDBSCD_6.setNull(3, java.sql.Types.TIMESTAMP);
}
}

        nb_line_inserted_tDBSCD_6 += insertionStatement_tDBSCD_6.executeUpdate();
    } else {
    }

	} catch (java.lang.Exception e) {//catch
globalMap.put("tDBSCD_6_ERROR_MESSAGE",e.getMessage());
  		
                System.err.print(e.getMessage());
	}//end catch
	
        cache_tDBSCD_6.put(lookUpKey_tDBSCD_6, lookUpValue_tDBSCD_6);

 


	tos_count_tDBSCD_6++;

/**
 * [tDBSCD_6 main ] stop
 */
	
	/**
	 * [tDBSCD_6 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBSCD_6";

	

 



/**
 * [tDBSCD_6 process_data_begin ] stop
 */
	
	/**
	 * [tDBSCD_6 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBSCD_6";

	

 



/**
 * [tDBSCD_6 process_data_end ] stop
 */

} // End of branch "alim_preparation"




// Start of branch "alim_restau"
if(alim_restau != null) { 



	
	/**
	 * [tDBSCD_7 main ] start
	 */

	

	
	
	currentComponent="tDBSCD_7";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"alim_restau"
						
						);
					}
					

 	try {
        lookUpKey_tDBSCD_7 = new SCDSK_tDBSCD_7();
            lookUpKey_tDBSCD_7.id_restaurant_src = alim_restau.id_restaurant_src;
        lookUpKey_tDBSCD_7.hashCodeDirty = true;
        lookUpValue_tDBSCD_7 = cache_tDBSCD_7.get(lookUpKey_tDBSCD_7);    
    if(lookUpValue_tDBSCD_7 == null) {
            lookUpValue_tDBSCD_7 = new SCDStruct_tDBSCD_7();
                lookUpValue_tDBSCD_7.scd_version = 1;
        
                    if(alim_restau.id_restaurant_src == null) {
insertionStatement_tDBSCD_7.setNull(1, java.sql.Types.INTEGER);
} else {
insertionStatement_tDBSCD_7.setInt(1, alim_restau.id_restaurant_src);
}

                    if(alim_restau.code_restaurant == null) {
insertionStatement_tDBSCD_7.setNull(2, java.sql.Types.VARCHAR);
} else {
insertionStatement_tDBSCD_7.setString(2, alim_restau.code_restaurant);
}

                    if(alim_restau.raison_sociale_restaurant == null) {
insertionStatement_tDBSCD_7.setNull(3, java.sql.Types.VARCHAR);
} else {
insertionStatement_tDBSCD_7.setString(3, alim_restau.raison_sociale_restaurant);
}

                Integer version_tDBSCD_7 = 1;
                if(version_tDBSCD_7 == null) {
insertionStatement_tDBSCD_7.setNull(4, java.sql.Types.INTEGER);
} else {
insertionStatement_tDBSCD_7.setInt(4, version_tDBSCD_7);
}

        nb_line_inserted_tDBSCD_7 += insertionStatement_tDBSCD_7.executeUpdate();
    } else {
            if((lookUpValue_tDBSCD_7.code_restaurant == null && alim_restau.code_restaurant!= null) || (lookUpValue_tDBSCD_7.code_restaurant != null && !lookUpValue_tDBSCD_7.code_restaurant.equals(alim_restau.code_restaurant)) || (lookUpValue_tDBSCD_7.raison_sociale_restaurant == null && alim_restau.raison_sociale_restaurant!= null) || (lookUpValue_tDBSCD_7.raison_sociale_restaurant != null && !lookUpValue_tDBSCD_7.raison_sociale_restaurant.equals(alim_restau.raison_sociale_restaurant))) {
                    if(alim_restau.id_restaurant_src == null) {
updateForType2_tDBSCD_7.setNull(2, java.sql.Types.INTEGER);
} else {
updateForType2_tDBSCD_7.setInt(2, alim_restau.id_restaurant_src);
}

                nb_line_update_tDBSCD_7 += updateForType2_tDBSCD_7.executeUpdate();
                            if(alim_restau.id_restaurant_src == null) {
insertionStatement_tDBSCD_7.setNull(1, java.sql.Types.INTEGER);
} else {
insertionStatement_tDBSCD_7.setInt(1, alim_restau.id_restaurant_src);
}

                            if(alim_restau.code_restaurant == null) {
insertionStatement_tDBSCD_7.setNull(2, java.sql.Types.VARCHAR);
} else {
insertionStatement_tDBSCD_7.setString(2, alim_restau.code_restaurant);
}

                            if(alim_restau.raison_sociale_restaurant == null) {
insertionStatement_tDBSCD_7.setNull(3, java.sql.Types.VARCHAR);
} else {
insertionStatement_tDBSCD_7.setString(3, alim_restau.raison_sociale_restaurant);
}

                        Integer maxVersion_tDBSCD_7 = lookUpValue_tDBSCD_7.scd_version + 1;
                            lookUpValue_tDBSCD_7.scd_version = lookUpValue_tDBSCD_7.scd_version + 1;                            
                        if(maxVersion_tDBSCD_7 == null) {
insertionStatement_tDBSCD_7.setNull(4, java.sql.Types.INTEGER);
} else {
insertionStatement_tDBSCD_7.setInt(4, maxVersion_tDBSCD_7);
}

                nb_line_inserted_tDBSCD_7 += insertionStatement_tDBSCD_7.executeUpdate();
            }
    }

	} catch (java.lang.Exception e) {//catch
globalMap.put("tDBSCD_7_ERROR_MESSAGE",e.getMessage());
  		
                System.err.print(e.getMessage());
	}//end catch
	
                lookUpValue_tDBSCD_7.code_restaurant = alim_restau.code_restaurant;
                lookUpValue_tDBSCD_7.raison_sociale_restaurant = alim_restau.raison_sociale_restaurant;
        cache_tDBSCD_7.put(lookUpKey_tDBSCD_7, lookUpValue_tDBSCD_7);

 


	tos_count_tDBSCD_7++;

/**
 * [tDBSCD_7 main ] stop
 */
	
	/**
	 * [tDBSCD_7 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBSCD_7";

	

 



/**
 * [tDBSCD_7 process_data_begin ] stop
 */
	
	/**
	 * [tDBSCD_7 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBSCD_7";

	

 



/**
 * [tDBSCD_7 process_data_end ] stop
 */

} // End of branch "alim_restau"




// Start of branch "alim_menu"
if(alim_menu != null) { 



	
	/**
	 * [tDBSCD_8 main ] start
	 */

	

	
	
	currentComponent="tDBSCD_8";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"alim_menu"
						
						);
					}
					

 	try {
        lookUpKey_tDBSCD_8 = new SCDSK_tDBSCD_8();
            lookUpKey_tDBSCD_8.id_menu_src = alim_menu.id_menu_src;
        lookUpKey_tDBSCD_8.hashCodeDirty = true;
        lookUpValue_tDBSCD_8 = cache_tDBSCD_8.get(lookUpKey_tDBSCD_8);    
    if(lookUpValue_tDBSCD_8 == null) {
            lookUpValue_tDBSCD_8 = new SCDStruct_tDBSCD_8();
        
                    if(alim_menu.id_menu_src == null) {
insertionStatement_tDBSCD_8.setNull(1, java.sql.Types.INTEGER);
} else {
insertionStatement_tDBSCD_8.setInt(1, alim_menu.id_menu_src);
}

                    if(alim_menu.code_menu == null) {
insertionStatement_tDBSCD_8.setNull(2, java.sql.Types.VARCHAR);
} else {
insertionStatement_tDBSCD_8.setString(2, alim_menu.code_menu);
}

                    if(alim_menu.temps_theo_preparation == null) {
insertionStatement_tDBSCD_8.setNull(3, java.sql.Types.VARCHAR);
} else {
insertionStatement_tDBSCD_8.setString(3, alim_menu.temps_theo_preparation);
}

                    if(alim_menu.nombre_articles == null) {
insertionStatement_tDBSCD_8.setNull(4, java.sql.Types.INTEGER);
} else {
insertionStatement_tDBSCD_8.setInt(4, alim_menu.nombre_articles);
}

                    if(alim_menu.libelle_menu == null) {
insertionStatement_tDBSCD_8.setNull(5, java.sql.Types.VARCHAR);
} else {
insertionStatement_tDBSCD_8.setString(5, alim_menu.libelle_menu);
}

        nb_line_inserted_tDBSCD_8 += insertionStatement_tDBSCD_8.executeUpdate();
    } else {
            if((lookUpValue_tDBSCD_8.temps_theo_preparation == null && alim_menu.temps_theo_preparation!= null) || (lookUpValue_tDBSCD_8.temps_theo_preparation != null && !lookUpValue_tDBSCD_8.temps_theo_preparation.equals(alim_menu.temps_theo_preparation)) || (lookUpValue_tDBSCD_8.nombre_articles == null && alim_menu.nombre_articles!= null) || (lookUpValue_tDBSCD_8.nombre_articles != null && !lookUpValue_tDBSCD_8.nombre_articles.equals(alim_menu.nombre_articles)) || (lookUpValue_tDBSCD_8.libelle_menu == null && alim_menu.libelle_menu!= null) || (lookUpValue_tDBSCD_8.libelle_menu != null && !lookUpValue_tDBSCD_8.libelle_menu.equals(alim_menu.libelle_menu))) {
                    if(alim_menu.temps_theo_preparation == null) {
updateForType1_tDBSCD_8.setNull(1, java.sql.Types.VARCHAR);
} else {
updateForType1_tDBSCD_8.setString(1, alim_menu.temps_theo_preparation);
}

                    if(alim_menu.nombre_articles == null) {
updateForType1_tDBSCD_8.setNull(2, java.sql.Types.INTEGER);
} else {
updateForType1_tDBSCD_8.setInt(2, alim_menu.nombre_articles);
}

                    if(alim_menu.libelle_menu == null) {
updateForType1_tDBSCD_8.setNull(3, java.sql.Types.VARCHAR);
} else {
updateForType1_tDBSCD_8.setString(3, alim_menu.libelle_menu);
}

                    if(alim_menu.id_menu_src == null) {
updateForType1_tDBSCD_8.setNull(4, java.sql.Types.INTEGER);
} else {
updateForType1_tDBSCD_8.setInt(4, alim_menu.id_menu_src);
}

                nb_line_update_tDBSCD_8 += updateForType1_tDBSCD_8.executeUpdate();
            }
    }

	} catch (java.lang.Exception e) {//catch
globalMap.put("tDBSCD_8_ERROR_MESSAGE",e.getMessage());
  		
                System.err.print(e.getMessage());
	}//end catch
	
                lookUpValue_tDBSCD_8.temps_theo_preparation = alim_menu.temps_theo_preparation;
                lookUpValue_tDBSCD_8.nombre_articles = alim_menu.nombre_articles;
                lookUpValue_tDBSCD_8.libelle_menu = alim_menu.libelle_menu;
        cache_tDBSCD_8.put(lookUpKey_tDBSCD_8, lookUpValue_tDBSCD_8);

 


	tos_count_tDBSCD_8++;

/**
 * [tDBSCD_8 main ] stop
 */
	
	/**
	 * [tDBSCD_8 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBSCD_8";

	

 



/**
 * [tDBSCD_8 process_data_begin ] stop
 */
	
	/**
	 * [tDBSCD_8 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBSCD_8";

	

 



/**
 * [tDBSCD_8 process_data_end ] stop
 */

} // End of branch "alim_menu"




	
	/**
	 * [tMap_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tMap_1";

	

 



/**
 * [tMap_1 process_data_end ] stop
 */



	
	/**
	 * [tDBInput_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBInput_1";

	

 



/**
 * [tDBInput_1 process_data_end ] stop
 */
	
	/**
	 * [tDBInput_1 end ] start
	 */

	

	
	
	currentComponent="tDBInput_1";

	

	}
}finally{
	if (rs_tDBInput_1 != null) {
		rs_tDBInput_1.close();
	}
	if (stmt_tDBInput_1 != null) {
		stmt_tDBInput_1.close();
	}
	if(conn_tDBInput_1 != null && !conn_tDBInput_1.isClosed()) {
		
			conn_tDBInput_1.commit();
			
		
			conn_tDBInput_1.close();
			
			if("com.mysql.cj.jdbc.Driver".equals((String)globalMap.get("driverClass_"))
			    && routines.system.BundleUtils.inOSGi()) {
			        Class.forName("com.mysql.cj.jdbc.AbandonedConnectionCleanupThread").
			            getMethod("checkedShutdown").invoke(null, (Object[]) null);
			}
			
	}
	
}
globalMap.put("tDBInput_1_NB_LINE",nb_line_tDBInput_1);
 

ok_Hash.put("tDBInput_1", true);
end_Hash.put("tDBInput_1", System.currentTimeMillis());

tStatCatcher_1.addMessage("end","tDBInput_1", end_Hash.get("tDBInput_1")-start_Hash.get("tDBInput_1"));
tStatCatcher_1Process(globalMap);



/**
 * [tDBInput_1 end ] stop
 */

	
	/**
	 * [tMap_1 end ] start
	 */

	

	
	
	currentComponent="tMap_1";

	


// ###############################
// # Lookup hashes releasing
// ###############################      





				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row2");
			  	}
			  	
 

ok_Hash.put("tMap_1", true);
end_Hash.put("tMap_1", System.currentTimeMillis());

tStatCatcher_1.addMessage("end","tMap_1", end_Hash.get("tMap_1")-start_Hash.get("tMap_1"));
tStatCatcher_1Process(globalMap);



/**
 * [tMap_1 end ] stop
 */

	
	/**
	 * [tDBSCD_1 end ] start
	 */

	

	
	
	currentComponent="tDBSCD_1";

	

    insertionStatement_tDBSCD_1.close();
        updateForType1_tDBSCD_1.close();
        if(connection_tDBSCD_1 != null && !connection_tDBSCD_1.isClosed()) {
            connection_tDBSCD_1.close();
        }
    globalMap.put("tDBSCD_1_NB_LINE_UPDATED", nb_line_update_tDBSCD_1);
    globalMap.put("tDBSCD_1_NB_LINE_INSERTED", nb_line_inserted_tDBSCD_1);
    globalMap.put("tDBSCD_1_NB_LINE_REJECTED",nb_line_rejected_tDBSCD_1);

				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"allim_adresse_norm");
			  	}
			  	
 

ok_Hash.put("tDBSCD_1", true);
end_Hash.put("tDBSCD_1", System.currentTimeMillis());




/**
 * [tDBSCD_1 end ] stop
 */




	
	/**
	 * [tDBSCD_2 end ] start
	 */

	

	
	
	currentComponent="tDBSCD_2";

	

    insertionStatement_tDBSCD_2.close();
        updateForType1_tDBSCD_2.close();
        if(connection_tDBSCD_2 != null && !connection_tDBSCD_2.isClosed()) {
            connection_tDBSCD_2.close();
        }
    globalMap.put("tDBSCD_2_NB_LINE_UPDATED", nb_line_update_tDBSCD_2);
    globalMap.put("tDBSCD_2_NB_LINE_INSERTED", nb_line_inserted_tDBSCD_2);
    globalMap.put("tDBSCD_2_NB_LINE_REJECTED",nb_line_rejected_tDBSCD_2);

				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"alim_adresse_norm_restau");
			  	}
			  	
 

ok_Hash.put("tDBSCD_2", true);
end_Hash.put("tDBSCD_2", System.currentTimeMillis());




/**
 * [tDBSCD_2 end ] stop
 */




	
	/**
	 * [tDBSCD_3 end ] start
	 */

	

	
	
	currentComponent="tDBSCD_3";

	

    insertionStatement_tDBSCD_3.close();
        updateForType1_tDBSCD_3.close();
        updateForType3_tDBSCD_3.close();
        if(connection_tDBSCD_3 != null && !connection_tDBSCD_3.isClosed()) {
            connection_tDBSCD_3.close();
        }
    globalMap.put("tDBSCD_3_NB_LINE_UPDATED", nb_line_update_tDBSCD_3);
    globalMap.put("tDBSCD_3_NB_LINE_INSERTED", nb_line_inserted_tDBSCD_3);
    globalMap.put("tDBSCD_3_NB_LINE_REJECTED",nb_line_rejected_tDBSCD_3);

				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"alim_client");
			  	}
			  	
 

ok_Hash.put("tDBSCD_3", true);
end_Hash.put("tDBSCD_3", System.currentTimeMillis());




/**
 * [tDBSCD_3 end ] stop
 */




	
	/**
	 * [tDBSCD_4 end ] start
	 */

	

	
	
	currentComponent="tDBSCD_4";

	

    insertionStatement_tDBSCD_4.close();
        if(connection_tDBSCD_4 != null && !connection_tDBSCD_4.isClosed()) {
            connection_tDBSCD_4.close();
        }
    globalMap.put("tDBSCD_4_NB_LINE_UPDATED", nb_line_update_tDBSCD_4);
    globalMap.put("tDBSCD_4_NB_LINE_INSERTED", nb_line_inserted_tDBSCD_4);
    globalMap.put("tDBSCD_4_NB_LINE_REJECTED",nb_line_rejected_tDBSCD_4);

				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"aim_date_commande");
			  	}
			  	
 

ok_Hash.put("tDBSCD_4", true);
end_Hash.put("tDBSCD_4", System.currentTimeMillis());




/**
 * [tDBSCD_4 end ] stop
 */




	
	/**
	 * [tDBSCD_5 end ] start
	 */

	

	
	
	currentComponent="tDBSCD_5";

	

    insertionStatement_tDBSCD_5.close();
        updateForType1_tDBSCD_5.close();
        if(connection_tDBSCD_5 != null && !connection_tDBSCD_5.isClosed()) {
            connection_tDBSCD_5.close();
        }
    globalMap.put("tDBSCD_5_NB_LINE_UPDATED", nb_line_update_tDBSCD_5);
    globalMap.put("tDBSCD_5_NB_LINE_INSERTED", nb_line_inserted_tDBSCD_5);
    globalMap.put("tDBSCD_5_NB_LINE_REJECTED",nb_line_rejected_tDBSCD_5);

				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"alim_moyen_paiement");
			  	}
			  	
 

ok_Hash.put("tDBSCD_5", true);
end_Hash.put("tDBSCD_5", System.currentTimeMillis());




/**
 * [tDBSCD_5 end ] stop
 */




	
	/**
	 * [tDBSCD_6 end ] start
	 */

	

	
	
	currentComponent="tDBSCD_6";

	

    insertionStatement_tDBSCD_6.close();
        if(connection_tDBSCD_6 != null && !connection_tDBSCD_6.isClosed()) {
            connection_tDBSCD_6.close();
        }
    globalMap.put("tDBSCD_6_NB_LINE_UPDATED", nb_line_update_tDBSCD_6);
    globalMap.put("tDBSCD_6_NB_LINE_INSERTED", nb_line_inserted_tDBSCD_6);
    globalMap.put("tDBSCD_6_NB_LINE_REJECTED",nb_line_rejected_tDBSCD_6);

				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"alim_preparation");
			  	}
			  	
 

ok_Hash.put("tDBSCD_6", true);
end_Hash.put("tDBSCD_6", System.currentTimeMillis());




/**
 * [tDBSCD_6 end ] stop
 */




	
	/**
	 * [tDBSCD_7 end ] start
	 */

	

	
	
	currentComponent="tDBSCD_7";

	

    insertionStatement_tDBSCD_7.close();
        updateForType2_tDBSCD_7.close();
        if(connection_tDBSCD_7 != null && !connection_tDBSCD_7.isClosed()) {
            connection_tDBSCD_7.close();
        }
    globalMap.put("tDBSCD_7_NB_LINE_UPDATED", nb_line_update_tDBSCD_7);
    globalMap.put("tDBSCD_7_NB_LINE_INSERTED", nb_line_inserted_tDBSCD_7);
    globalMap.put("tDBSCD_7_NB_LINE_REJECTED",nb_line_rejected_tDBSCD_7);

				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"alim_restau");
			  	}
			  	
 

ok_Hash.put("tDBSCD_7", true);
end_Hash.put("tDBSCD_7", System.currentTimeMillis());




/**
 * [tDBSCD_7 end ] stop
 */




	
	/**
	 * [tDBSCD_8 end ] start
	 */

	

	
	
	currentComponent="tDBSCD_8";

	

    insertionStatement_tDBSCD_8.close();
        updateForType1_tDBSCD_8.close();
        if(connection_tDBSCD_8 != null && !connection_tDBSCD_8.isClosed()) {
            connection_tDBSCD_8.close();
        }
    globalMap.put("tDBSCD_8_NB_LINE_UPDATED", nb_line_update_tDBSCD_8);
    globalMap.put("tDBSCD_8_NB_LINE_INSERTED", nb_line_inserted_tDBSCD_8);
    globalMap.put("tDBSCD_8_NB_LINE_REJECTED",nb_line_rejected_tDBSCD_8);

				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"alim_menu");
			  	}
			  	
 

ok_Hash.put("tDBSCD_8", true);
end_Hash.put("tDBSCD_8", System.currentTimeMillis());




/**
 * [tDBSCD_8 end ] stop
 */






				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBInput_1 finally ] start
	 */

	

	
	
	currentComponent="tDBInput_1";

	

 



/**
 * [tDBInput_1 finally ] stop
 */

	
	/**
	 * [tMap_1 finally ] start
	 */

	

	
	
	currentComponent="tMap_1";

	

 



/**
 * [tMap_1 finally ] stop
 */

	
	/**
	 * [tDBSCD_1 finally ] start
	 */

	

	
	
	currentComponent="tDBSCD_1";

	

 



/**
 * [tDBSCD_1 finally ] stop
 */




	
	/**
	 * [tDBSCD_2 finally ] start
	 */

	

	
	
	currentComponent="tDBSCD_2";

	

 



/**
 * [tDBSCD_2 finally ] stop
 */




	
	/**
	 * [tDBSCD_3 finally ] start
	 */

	

	
	
	currentComponent="tDBSCD_3";

	

 



/**
 * [tDBSCD_3 finally ] stop
 */




	
	/**
	 * [tDBSCD_4 finally ] start
	 */

	

	
	
	currentComponent="tDBSCD_4";

	

 



/**
 * [tDBSCD_4 finally ] stop
 */




	
	/**
	 * [tDBSCD_5 finally ] start
	 */

	

	
	
	currentComponent="tDBSCD_5";

	

 



/**
 * [tDBSCD_5 finally ] stop
 */




	
	/**
	 * [tDBSCD_6 finally ] start
	 */

	

	
	
	currentComponent="tDBSCD_6";

	

 



/**
 * [tDBSCD_6 finally ] stop
 */




	
	/**
	 * [tDBSCD_7 finally ] start
	 */

	

	
	
	currentComponent="tDBSCD_7";

	

 



/**
 * [tDBSCD_7 finally ] stop
 */




	
	/**
	 * [tDBSCD_8 finally ] start
	 */

	

	
	
	currentComponent="tDBSCD_8";

	

 



/**
 * [tDBSCD_8 finally ] stop
 */






				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBInput_1_SUBPROCESS_STATE", 1);
	}
	
    public String resuming_logs_dir_path = null;
    public String resuming_checkpoint_path = null;
    public String parent_part_launcher = null;
    private String resumeEntryMethodName = null;
    private boolean globalResumeTicket = false;

    public boolean watch = false;
    // portStats is null, it means don't execute the statistics
    public Integer portStats = null;
    public int portTraces = 4334;
    public String clientHost;
    public String defaultClientHost = "localhost";
    public String contextStr = "Default";
    public boolean isDefaultContext = true;
    public String pid = "0";
    public String rootPid = null;
    public String fatherPid = null;
    public String fatherNode = null;
    public long startTime = 0;
    public boolean isChildJob = false;
    public String log4jLevel = "";
    
    private boolean enableLogStash;

    private boolean execStat = true;

    private ThreadLocal<java.util.Map<String, String>> threadLocal = new ThreadLocal<java.util.Map<String, String>>() {
        protected java.util.Map<String, String> initialValue() {
            java.util.Map<String,String> threadRunResultMap = new java.util.HashMap<String, String>();
            threadRunResultMap.put("errorCode", null);
            threadRunResultMap.put("status", "");
            return threadRunResultMap;
        };
    };


    protected PropertiesWithType context_param = new PropertiesWithType();
    public java.util.Map<String, Object> parentContextMap = new java.util.HashMap<String, Object>();

    public String status= "";
    

    public static void main(String[] args){
        final E_ALIM_DIM E_ALIM_DIMClass = new E_ALIM_DIM();

        int exitCode = E_ALIM_DIMClass.runJobInTOS(args);

        System.exit(exitCode);
    }


    public String[][] runJob(String[] args) {

        int exitCode = runJobInTOS(args);
        String[][] bufferValue = new String[][] { { Integer.toString(exitCode) } };

        return bufferValue;
    }

    public boolean hastBufferOutputComponent() {
		boolean hastBufferOutput = false;
    	
        return hastBufferOutput;
    }

    public int runJobInTOS(String[] args) {
	   	// reset status
	   	status = "";
	   	
        String lastStr = "";
        for (String arg : args) {
            if (arg.equalsIgnoreCase("--context_param")) {
                lastStr = arg;
            } else if (lastStr.equals("")) {
                evalParam(arg);
            } else {
                evalParam(lastStr + " " + arg);
                lastStr = "";
            }
        }
        enableLogStash = "true".equalsIgnoreCase(System.getProperty("audit.enabled"));

    	
    	

        if(clientHost == null) {
            clientHost = defaultClientHost;
        }

        if(pid == null || "0".equals(pid)) {
            pid = TalendString.getAsciiRandomString(6);
        }

        if (rootPid==null) {
            rootPid = pid;
        }
        if (fatherPid==null) {
            fatherPid = pid;
        }else{
            isChildJob = true;
        }

        if (portStats != null) {
            // portStats = -1; //for testing
            if (portStats < 0 || portStats > 65535) {
                // issue:10869, the portStats is invalid, so this client socket can't open
                System.err.println("The statistics socket port " + portStats + " is invalid.");
                execStat = false;
            }
        } else {
            execStat = false;
        }
        boolean inOSGi = routines.system.BundleUtils.inOSGi();

        if (inOSGi) {
            java.util.Dictionary<String, Object> jobProperties = routines.system.BundleUtils.getJobProperties(jobName);

            if (jobProperties != null && jobProperties.get("context") != null) {
                contextStr = (String)jobProperties.get("context");
            }
        }

        try {
            //call job/subjob with an existing context, like: --context=production. if without this parameter, there will use the default context instead.
            java.io.InputStream inContext = E_ALIM_DIM.class.getClassLoader().getResourceAsStream("alimentation_dm1/e_alim_dim_0_1/contexts/" + contextStr + ".properties");
            if (inContext == null) {
                inContext = E_ALIM_DIM.class.getClassLoader().getResourceAsStream("config/contexts/" + contextStr + ".properties");
            }
            if (inContext != null) {
                try {
                    //defaultProps is in order to keep the original context value
                    if(context != null && context.isEmpty()) {
	                defaultProps.load(inContext);
	                context = new ContextProperties(defaultProps);
                    }
                } finally {
                    inContext.close();
                }
            } else if (!isDefaultContext) {
                //print info and job continue to run, for case: context_param is not empty.
                System.err.println("Could not find the context " + contextStr);
            }

            if(!context_param.isEmpty()) {
                context.putAll(context_param);
				//set types for params from parentJobs
				for (Object key: context_param.keySet()){
					String context_key = key.toString();
					String context_type = context_param.getContextType(context_key);
					context.setContextType(context_key, context_type);

				}
            }
            class ContextProcessing {
                private void processContext_0() {
                } 
                public void processAllContext() {
                        processContext_0();
                }
            }

            new ContextProcessing().processAllContext();
        } catch (java.io.IOException ie) {
            System.err.println("Could not load context "+contextStr);
            ie.printStackTrace();
        }

        // get context value from parent directly
        if (parentContextMap != null && !parentContextMap.isEmpty()) {
        }

        //Resume: init the resumeUtil
        resumeEntryMethodName = ResumeUtil.getResumeEntryMethodName(resuming_checkpoint_path);
        resumeUtil = new ResumeUtil(resuming_logs_dir_path, isChildJob, rootPid);
        resumeUtil.initCommonInfo(pid, rootPid, fatherPid, projectName, jobName, contextStr, jobVersion);

		List<String> parametersToEncrypt = new java.util.ArrayList<String>();
        //Resume: jobStart
        resumeUtil.addLog("JOB_STARTED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","","","",resumeUtil.convertToJsonText(context,parametersToEncrypt));

if(execStat) {
    try {
        runStat.openSocket(!isChildJob);
        runStat.setAllPID(rootPid, fatherPid, pid, jobName);
        runStat.startThreadStat(clientHost, portStats);
        runStat.updateStatOnJob(RunStat.JOBSTART, fatherNode);
    } catch (java.io.IOException ioException) {
        ioException.printStackTrace();
    }
}



	
	    java.util.concurrent.ConcurrentHashMap<Object, Object> concurrentHashMap = new java.util.concurrent.ConcurrentHashMap<Object, Object>();
	    globalMap.put("concurrentHashMap", concurrentHashMap);
	

    long startUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
    long endUsedMemory = 0;
    long end = 0;

    startTime = System.currentTimeMillis();
        tStatCatcher_1.addMessage("begin");


this.globalResumeTicket = true;//to run tPreJob




        try {
            tStatCatcher_1Process(globalMap);
        } catch (java.lang.Exception e) {
            e.printStackTrace();
        }

this.globalResumeTicket = false;//to run others jobs

try {
errorCode = null;tDBInput_1Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tDBInput_1) {
globalMap.put("tDBInput_1_SUBPROCESS_STATE", -1);

e_tDBInput_1.printStackTrace();

}

this.globalResumeTicket = true;//to run tPostJob




        end = System.currentTimeMillis();

        if (watch) {
            System.out.println((end-startTime)+" milliseconds");
        }

        endUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        if (false) {
            System.out.println((endUsedMemory - startUsedMemory) + " bytes memory increase when running : E_ALIM_DIM");
        }
        tStatCatcher_1.addMessage(status==""?"end":status, (end-startTime));
        try {
            tStatCatcher_1Process(globalMap);
        } catch (java.lang.Exception e) {
            e.printStackTrace();
        }



if (execStat) {
    runStat.updateStatOnJob(RunStat.JOBEND, fatherNode);
    runStat.stopThreadStat();
}
    int returnCode = 0;


    if(errorCode == null) {
         returnCode = status != null && status.equals("failure") ? 1 : 0;
    } else {
         returnCode = errorCode.intValue();
    }
    resumeUtil.addLog("JOB_ENDED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","" + returnCode,"","","");

    return returnCode;

  }

    // only for OSGi env
    public void destroy() {


    }














    private java.util.Map<String, Object> getSharedConnections4REST() {
        java.util.Map<String, Object> connections = new java.util.HashMap<String, Object>();






        return connections;
    }

    private void evalParam(String arg) {
        if (arg.startsWith("--resuming_logs_dir_path")) {
            resuming_logs_dir_path = arg.substring(25);
        } else if (arg.startsWith("--resuming_checkpoint_path")) {
            resuming_checkpoint_path = arg.substring(27);
        } else if (arg.startsWith("--parent_part_launcher")) {
            parent_part_launcher = arg.substring(23);
        } else if (arg.startsWith("--watch")) {
            watch = true;
        } else if (arg.startsWith("--stat_port=")) {
            String portStatsStr = arg.substring(12);
            if (portStatsStr != null && !portStatsStr.equals("null")) {
                portStats = Integer.parseInt(portStatsStr);
            }
        } else if (arg.startsWith("--trace_port=")) {
            portTraces = Integer.parseInt(arg.substring(13));
        } else if (arg.startsWith("--client_host=")) {
            clientHost = arg.substring(14);
        } else if (arg.startsWith("--context=")) {
            contextStr = arg.substring(10);
            isDefaultContext = false;
        } else if (arg.startsWith("--father_pid=")) {
            fatherPid = arg.substring(13);
        } else if (arg.startsWith("--root_pid=")) {
            rootPid = arg.substring(11);
        } else if (arg.startsWith("--father_node=")) {
            fatherNode = arg.substring(14);
        } else if (arg.startsWith("--pid=")) {
            pid = arg.substring(6);
        } else if (arg.startsWith("--context_type")) {
            String keyValue = arg.substring(15);
			int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.setContextType(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.setContextType(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }

            }

		} else if (arg.startsWith("--context_param")) {
            String keyValue = arg.substring(16);
            int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.put(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.put(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }
            }
        } else if (arg.startsWith("--log4jLevel=")) {
            log4jLevel = arg.substring(13);
		} else if (arg.startsWith("--audit.enabled") && arg.contains("=")) {//for trunjob call
		    final int equal = arg.indexOf('=');
			final String key = arg.substring("--".length(), equal);
			System.setProperty(key, arg.substring(equal + 1));
		}
    }
    
    private static final String NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY = "<TALEND_NULL>";

    private final String[][] escapeChars = {
        {"\\\\","\\"},{"\\n","\n"},{"\\'","\'"},{"\\r","\r"},
        {"\\f","\f"},{"\\b","\b"},{"\\t","\t"}
        };
    private String replaceEscapeChars (String keyValue) {

		if (keyValue == null || ("").equals(keyValue.trim())) {
			return keyValue;
		}

		StringBuilder result = new StringBuilder();
		int currIndex = 0;
		while (currIndex < keyValue.length()) {
			int index = -1;
			// judege if the left string includes escape chars
			for (String[] strArray : escapeChars) {
				index = keyValue.indexOf(strArray[0],currIndex);
				if (index>=0) {

					result.append(keyValue.substring(currIndex, index + strArray[0].length()).replace(strArray[0], strArray[1]));
					currIndex = index + strArray[0].length();
					break;
				}
			}
			// if the left string doesn't include escape chars, append the left into the result
			if (index < 0) {
				result.append(keyValue.substring(currIndex));
				currIndex = currIndex + keyValue.length();
			}
		}

		return result.toString();
    }

    public Integer getErrorCode() {
        return errorCode;
    }


    public String getStatus() {
        return status;
    }

    ResumeUtil resumeUtil = null;
}
/************************************************************************************************
 *     270377 characters generated by Talend Open Studio for Data Integration 
 *     on the 9 janvier 2024 à 20:33:19 CET
 ************************************************************************************************/