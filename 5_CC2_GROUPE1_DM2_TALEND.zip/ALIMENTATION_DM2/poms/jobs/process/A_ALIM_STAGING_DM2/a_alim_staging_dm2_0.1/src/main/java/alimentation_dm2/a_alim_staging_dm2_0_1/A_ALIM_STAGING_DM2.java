// ============================================================================
//
// Copyright (c) 2006-2015, Talend SA
//
// Ce code source a été automatiquement généré par_Talend Open Studio for Data Integration
// / Soumis à la Licence Apache, Version 2.0 (la "Licence") ;
// votre utilisation de ce fichier doit respecter les termes de la Licence.
// Vous pouvez obtenir une copie de la Licence sur
// http://www.apache.org/licenses/LICENSE-2.0
// 
// Sauf lorsqu'explicitement prévu par la loi en vigueur ou accepté par écrit, le logiciel
// distribué sous la Licence est distribué "TEL QUEL",
// SANS GARANTIE OU CONDITION D'AUCUNE SORTE, expresse ou implicite.
// Consultez la Licence pour connaître la terminologie spécifique régissant les autorisations et
// les limites prévues par la Licence.


package alimentation_dm2.a_alim_staging_dm2_0_1;

import routines.Numeric;
import routines.DataOperation;
import routines.TalendDataGenerator;
import routines.TalendStringUtil;
import routines.TalendString;
import routines.StringHandling;
import routines.Relational;
import routines.TalendDate;
import routines.Mathematical;
import routines.system.*;
import routines.system.api.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.math.BigDecimal;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.util.Comparator;
 





@SuppressWarnings("unused")

/**
 * Job: A_ALIM_STAGING_DM2 Purpose: <br>
 * Description:  <br>
 * @author user@talend.com
 * @version 8.0.1.20211109_1610
 * @status 
 */
public class A_ALIM_STAGING_DM2 implements TalendJob {

protected static void logIgnoredError(String message, Throwable cause) {
       System.err.println(message);
       if (cause != null) {
               cause.printStackTrace();
       }

}


	public final Object obj = new Object();

	// for transmiting parameters purpose
	private Object valueObject = null;

	public Object getValueObject() {
		return this.valueObject;
	}

	public void setValueObject(Object valueObject) {
		this.valueObject = valueObject;
	}
	
	private final static String defaultCharset = java.nio.charset.Charset.defaultCharset().name();

	
	private final static String utf8Charset = "UTF-8";
	//contains type for every context property
	public class PropertiesWithType extends java.util.Properties {
		private static final long serialVersionUID = 1L;
		private java.util.Map<String,String> propertyTypes = new java.util.HashMap<>();
		
		public PropertiesWithType(java.util.Properties properties){
			super(properties);
		}
		public PropertiesWithType(){
			super();
		}
		
		public void setContextType(String key, String type) {
			propertyTypes.put(key,type);
		}
	
		public String getContextType(String key) {
			return propertyTypes.get(key);
		}
	}
	
	// create and load default properties
	private java.util.Properties defaultProps = new java.util.Properties();
	// create application properties with default
	public class ContextProperties extends PropertiesWithType {

		private static final long serialVersionUID = 1L;

		public ContextProperties(java.util.Properties properties){
			super(properties);
		}
		public ContextProperties(){
			super();
		}

		public void synchronizeContext(){
			
		}
		
		//if the stored or passed value is "<TALEND_NULL>" string, it mean null
		public String getStringValue(String key) {
			String origin_value = this.getProperty(key);
			if(NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY.equals(origin_value)) {
				return null;
			}
			return origin_value;
		}

	}
	protected ContextProperties context = new ContextProperties(); // will be instanciated by MS.
	public ContextProperties getContext() {
		return this.context;
	}
	private final String jobVersion = "0.1";
	private final String jobName = "A_ALIM_STAGING_DM2";
	private final String projectName = "ALIMENTATION_DM2";
	public Integer errorCode = null;
	private String currentComponent = "";
	
		private final java.util.Map<String, Object> globalMap = new java.util.HashMap<String, Object>();
        private final static java.util.Map<String, Object> junitGlobalMap = new java.util.HashMap<String, Object>();
	
		private final java.util.Map<String, Long> start_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Long> end_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Boolean> ok_Hash = new java.util.HashMap<String, Boolean>();
		public  final java.util.List<String[]> globalBuffer = new java.util.ArrayList<String[]>();
	

private RunStat runStat = new RunStat();

	// OSGi DataSource
	private final static String KEY_DB_DATASOURCES = "KEY_DB_DATASOURCES";
	
	private final static String KEY_DB_DATASOURCES_RAW = "KEY_DB_DATASOURCES_RAW";

	public void setDataSources(java.util.Map<String, javax.sql.DataSource> dataSources) {
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		for (java.util.Map.Entry<String, javax.sql.DataSource> dataSourceEntry : dataSources.entrySet()) {
			talendDataSources.put(dataSourceEntry.getKey(), new routines.system.TalendDataSource(dataSourceEntry.getValue()));
		}
		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}
	
	public void setDataSourceReferences(List serviceReferences) throws Exception{
		
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		java.util.Map<String, javax.sql.DataSource> dataSources = new java.util.HashMap<String, javax.sql.DataSource>();
		
		for (java.util.Map.Entry<String, javax.sql.DataSource> entry : BundleUtils.getServices(serviceReferences,  javax.sql.DataSource.class).entrySet()) {
                    dataSources.put(entry.getKey(), entry.getValue());
                    talendDataSources.put(entry.getKey(), new routines.system.TalendDataSource(entry.getValue()));
		}

		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}

	StatCatcherUtils tStatCatcher_1 = new StatCatcherUtils("_xdYwcLPnEe6RvvlVPddZpQ", "0.1");

private final java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
private final java.io.PrintStream errorMessagePS = new java.io.PrintStream(new java.io.BufferedOutputStream(baos));

public String getExceptionStackTrace() {
	if ("failure".equals(this.getStatus())) {
		errorMessagePS.flush();
		return baos.toString();
	}
	return null;
}

private Exception exception;

public Exception getException() {
	if ("failure".equals(this.getStatus())) {
		return this.exception;
	}
	return null;
}

private class TalendException extends Exception {

	private static final long serialVersionUID = 1L;

	private java.util.Map<String, Object> globalMap = null;
	private Exception e = null;
	private String currentComponent = null;
	private String virtualComponentName = null;
	
	public void setVirtualComponentName (String virtualComponentName){
		this.virtualComponentName = virtualComponentName;
	}

	private TalendException(Exception e, String errorComponent, final java.util.Map<String, Object> globalMap) {
		this.currentComponent= errorComponent;
		this.globalMap = globalMap;
		this.e = e;
	}

	public Exception getException() {
		return this.e;
	}

	public String getCurrentComponent() {
		return this.currentComponent;
	}

	
    public String getExceptionCauseMessage(Exception e){
        Throwable cause = e;
        String message = null;
        int i = 10;
        while (null != cause && 0 < i--) {
            message = cause.getMessage();
            if (null == message) {
                cause = cause.getCause();
            } else {
                break;          
            }
        }
        if (null == message) {
            message = e.getClass().getName();
        }   
        return message;
    }

	@Override
	public void printStackTrace() {
		if (!(e instanceof TalendException || e instanceof TDieException)) {
			if(virtualComponentName!=null && currentComponent.indexOf(virtualComponentName+"_")==0){
				globalMap.put(virtualComponentName+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			}
			globalMap.put(currentComponent+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			System.err.println("Exception in component " + currentComponent + " (" + jobName + ")");
		}
		if (!(e instanceof TDieException)) {
			if(e instanceof TalendException){
				e.printStackTrace();
			} else {
				e.printStackTrace();
				e.printStackTrace(errorMessagePS);
				A_ALIM_STAGING_DM2.this.exception = e;
			}
		}
		if (!(e instanceof TalendException)) {
		try {
			for (java.lang.reflect.Method m : this.getClass().getEnclosingClass().getMethods()) {
				if (m.getName().compareTo(currentComponent + "_error") == 0) {
					m.invoke(A_ALIM_STAGING_DM2.this, new Object[] { e , currentComponent, globalMap});
					break;
				}
			}

			if(!(e instanceof TDieException)){
			}
		} catch (Exception e) {
			this.e.printStackTrace();
		}
		}
	}
}

			public void tStatCatcher_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tStatCatcher_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tStatCatcher_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBInput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
							tStatCatcher_1.addMessage("failure",errorComponent, end_Hash.get(errorComponent)-start_Hash.get(errorComponent));
							tStatCatcher_1Process(globalMap);
							
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMap_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
							tStatCatcher_1.addMessage("failure",errorComponent, end_Hash.get(errorComponent)-start_Hash.get(errorComponent));
							tStatCatcher_1Process(globalMap);
							
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileArchive_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
							tStatCatcher_1.addMessage("failure",errorComponent, end_Hash.get(errorComponent)-start_Hash.get(errorComponent));
							tStatCatcher_1Process(globalMap);
							
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tStatCatcher_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBInput_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
	






public static class row1Struct implements routines.system.IPersistableRow<row1Struct> {
    final static byte[] commonByteArrayLock_ALIMENTATION_DM2_A_ALIM_STAGING_DM2 = new byte[0];
    static byte[] commonByteArray_ALIMENTATION_DM2_A_ALIM_STAGING_DM2 = new byte[0];

	
			    public java.util.Date moment;

				public java.util.Date getMoment () {
					return this.moment;
				}
				
			    public String pid;

				public String getPid () {
					return this.pid;
				}
				
			    public String father_pid;

				public String getFather_pid () {
					return this.father_pid;
				}
				
			    public String root_pid;

				public String getRoot_pid () {
					return this.root_pid;
				}
				
			    public Long system_pid;

				public Long getSystem_pid () {
					return this.system_pid;
				}
				
			    public String project;

				public String getProject () {
					return this.project;
				}
				
			    public String job;

				public String getJob () {
					return this.job;
				}
				
			    public String job_repository_id;

				public String getJob_repository_id () {
					return this.job_repository_id;
				}
				
			    public String job_version;

				public String getJob_version () {
					return this.job_version;
				}
				
			    public String context;

				public String getContext () {
					return this.context;
				}
				
			    public String origin;

				public String getOrigin () {
					return this.origin;
				}
				
			    public String message_type;

				public String getMessage_type () {
					return this.message_type;
				}
				
			    public String message;

				public String getMessage () {
					return this.message;
				}
				
			    public Long duration;

				public Long getDuration () {
					return this.duration;
				}
				



	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_DM2_A_ALIM_STAGING_DM2.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_DM2_A_ALIM_STAGING_DM2.length == 0) {
   					commonByteArray_ALIMENTATION_DM2_A_ALIM_STAGING_DM2 = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_DM2_A_ALIM_STAGING_DM2 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ALIMENTATION_DM2_A_ALIM_STAGING_DM2, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_DM2_A_ALIM_STAGING_DM2, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_DM2_A_ALIM_STAGING_DM2.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_DM2_A_ALIM_STAGING_DM2.length == 0) {
   					commonByteArray_ALIMENTATION_DM2_A_ALIM_STAGING_DM2 = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_DM2_A_ALIM_STAGING_DM2 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ALIMENTATION_DM2_A_ALIM_STAGING_DM2, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_DM2_A_ALIM_STAGING_DM2, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_DM2_A_ALIM_STAGING_DM2) {

        	try {

        		int length = 0;
		
					this.moment = readDate(dis);
					
					this.pid = readString(dis);
					
					this.father_pid = readString(dis);
					
					this.root_pid = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.system_pid = null;
           				} else {
           			    	this.system_pid = dis.readLong();
           				}
					
					this.project = readString(dis);
					
					this.job = readString(dis);
					
					this.job_repository_id = readString(dis);
					
					this.job_version = readString(dis);
					
					this.context = readString(dis);
					
					this.origin = readString(dis);
					
					this.message_type = readString(dis);
					
					this.message = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.duration = null;
           				} else {
           			    	this.duration = dis.readLong();
           				}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_DM2_A_ALIM_STAGING_DM2) {

        	try {

        		int length = 0;
		
					this.moment = readDate(dis);
					
					this.pid = readString(dis);
					
					this.father_pid = readString(dis);
					
					this.root_pid = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.system_pid = null;
           				} else {
           			    	this.system_pid = dis.readLong();
           				}
					
					this.project = readString(dis);
					
					this.job = readString(dis);
					
					this.job_repository_id = readString(dis);
					
					this.job_version = readString(dis);
					
					this.context = readString(dis);
					
					this.origin = readString(dis);
					
					this.message_type = readString(dis);
					
					this.message = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.duration = null;
           				} else {
           			    	this.duration = dis.readLong();
           				}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// java.util.Date
				
						writeDate(this.moment,dos);
					
					// String
				
						writeString(this.pid,dos);
					
					// String
				
						writeString(this.father_pid,dos);
					
					// String
				
						writeString(this.root_pid,dos);
					
					// Long
				
						if(this.system_pid == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.system_pid);
		            	}
					
					// String
				
						writeString(this.project,dos);
					
					// String
				
						writeString(this.job,dos);
					
					// String
				
						writeString(this.job_repository_id,dos);
					
					// String
				
						writeString(this.job_version,dos);
					
					// String
				
						writeString(this.context,dos);
					
					// String
				
						writeString(this.origin,dos);
					
					// String
				
						writeString(this.message_type,dos);
					
					// String
				
						writeString(this.message,dos);
					
					// Long
				
						if(this.duration == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.duration);
		            	}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// java.util.Date
				
						writeDate(this.moment,dos);
					
					// String
				
						writeString(this.pid,dos);
					
					// String
				
						writeString(this.father_pid,dos);
					
					// String
				
						writeString(this.root_pid,dos);
					
					// Long
				
						if(this.system_pid == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.system_pid);
		            	}
					
					// String
				
						writeString(this.project,dos);
					
					// String
				
						writeString(this.job,dos);
					
					// String
				
						writeString(this.job_repository_id,dos);
					
					// String
				
						writeString(this.job_version,dos);
					
					// String
				
						writeString(this.context,dos);
					
					// String
				
						writeString(this.origin,dos);
					
					// String
				
						writeString(this.message_type,dos);
					
					// String
				
						writeString(this.message,dos);
					
					// Long
				
						if(this.duration == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.duration);
		            	}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("moment="+String.valueOf(moment));
		sb.append(",pid="+pid);
		sb.append(",father_pid="+father_pid);
		sb.append(",root_pid="+root_pid);
		sb.append(",system_pid="+String.valueOf(system_pid));
		sb.append(",project="+project);
		sb.append(",job="+job);
		sb.append(",job_repository_id="+job_repository_id);
		sb.append(",job_version="+job_version);
		sb.append(",context="+context);
		sb.append(",origin="+origin);
		sb.append(",message_type="+message_type);
		sb.append(",message="+message);
		sb.append(",duration="+String.valueOf(duration));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row1Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tStatCatcher_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tStatCatcher_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row1Struct row1 = new row1Struct();




	
	/**
	 * [tDBOutput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_1", false);
		start_Hash.put("tDBOutput_1", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_1";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row1");
					}
				
		int tos_count_tDBOutput_1 = 0;
		





String dbschema_tDBOutput_1 = null;
	dbschema_tDBOutput_1 = "dsid_liv_met";
	

String tableName_tDBOutput_1 = null;
if(dbschema_tDBOutput_1 == null || dbschema_tDBOutput_1.trim().length() == 0) {
	tableName_tDBOutput_1 = ("JOB_STATS");
} else {
	tableName_tDBOutput_1 = dbschema_tDBOutput_1 + "\".\"" + ("JOB_STATS");
}


int nb_line_tDBOutput_1 = 0;
int nb_line_update_tDBOutput_1 = 0;
int nb_line_inserted_tDBOutput_1 = 0;
int nb_line_deleted_tDBOutput_1 = 0;
int nb_line_rejected_tDBOutput_1 = 0;

int deletedCount_tDBOutput_1=0;
int updatedCount_tDBOutput_1=0;
int insertedCount_tDBOutput_1=0;
int rowsToCommitCount_tDBOutput_1=0;
int rejectedCount_tDBOutput_1=0;

boolean whetherReject_tDBOutput_1 = false;

java.sql.Connection conn_tDBOutput_1 = null;
String dbUser_tDBOutput_1 = null;

	
    java.lang.Class.forName("org.postgresql.Driver");
    
        String url_tDBOutput_1 = "jdbc:postgresql://"+"localhost"+":"+"5432"+"/"+"postgres";
    dbUser_tDBOutput_1 = "dsid_cc2_tos_rw";
 
	final String decryptedPassword_tDBOutput_1 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:xpb/Uqnj3R9rDsyPQkxfHU8oYRhfLsdHuWSzdQ5JBCM=");

    String dbPwd_tDBOutput_1 = decryptedPassword_tDBOutput_1;

    conn_tDBOutput_1 = java.sql.DriverManager.getConnection(url_tDBOutput_1,dbUser_tDBOutput_1,dbPwd_tDBOutput_1);
	
	resourceMap.put("conn_tDBOutput_1", conn_tDBOutput_1);
        conn_tDBOutput_1.setAutoCommit(false);
        int commitEvery_tDBOutput_1 = 10000;
        int commitCounter_tDBOutput_1 = 0;


   int batchSize_tDBOutput_1 = 10000;
   int batchSizeCounter_tDBOutput_1=0;

int count_tDBOutput_1=0;
	    String insert_tDBOutput_1 = "INSERT INTO \"" + tableName_tDBOutput_1 + "\" (\"moment\",\"pid\",\"father_pid\",\"root_pid\",\"system_pid\",\"project\",\"job\",\"job_repository_id\",\"job_version\",\"context\",\"origin\",\"message_type\",\"message\",\"duration\") VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
	    
	    java.sql.PreparedStatement pstmt_tDBOutput_1 = conn_tDBOutput_1.prepareStatement(insert_tDBOutput_1);
	    resourceMap.put("pstmt_tDBOutput_1", pstmt_tDBOutput_1);
	    

 



/**
 * [tDBOutput_1 begin ] stop
 */



	
	/**
	 * [tStatCatcher_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tStatCatcher_1", false);
		start_Hash.put("tStatCatcher_1", System.currentTimeMillis());
		
	
	currentComponent="tStatCatcher_1";

	
		int tos_count_tStatCatcher_1 = 0;
		

	for (StatCatcherUtils.StatCatcherMessage scm : tStatCatcher_1.getMessages()) {
		row1.pid = pid;
		row1.root_pid = rootPid;
		row1.father_pid = fatherPid;	
    	row1.project = projectName;
    	row1.job = jobName;
    	row1.context = contextStr;
		row1.origin = (scm.getOrigin()==null || scm.getOrigin().length()<1 ? null : scm.getOrigin());
		row1.message = scm.getMessage();
		row1.duration = scm.getDuration();
		row1.moment = scm.getMoment();
		row1.message_type = scm.getMessageType();
		row1.job_version = scm.getJobVersion();
		row1.job_repository_id = scm.getJobId();
		row1.system_pid = scm.getSystemPid();

 



/**
 * [tStatCatcher_1 begin ] stop
 */
	
	/**
	 * [tStatCatcher_1 main ] start
	 */

	

	
	
	currentComponent="tStatCatcher_1";

	

 


	tos_count_tStatCatcher_1++;

/**
 * [tStatCatcher_1 main ] stop
 */
	
	/**
	 * [tStatCatcher_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tStatCatcher_1";

	

 



/**
 * [tStatCatcher_1 process_data_begin ] stop
 */

	
	/**
	 * [tDBOutput_1 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row1"
						
						);
					}
					



        whetherReject_tDBOutput_1 = false;
                    if(row1.moment != null) {
pstmt_tDBOutput_1.setTimestamp(1, new java.sql.Timestamp(row1.moment.getTime()));
} else {
pstmt_tDBOutput_1.setNull(1, java.sql.Types.TIMESTAMP);
}

                    if(row1.pid == null) {
pstmt_tDBOutput_1.setNull(2, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(2, row1.pid);
}

                    if(row1.father_pid == null) {
pstmt_tDBOutput_1.setNull(3, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(3, row1.father_pid);
}

                    if(row1.root_pid == null) {
pstmt_tDBOutput_1.setNull(4, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(4, row1.root_pid);
}

                    if(row1.system_pid == null) {
pstmt_tDBOutput_1.setNull(5, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_1.setLong(5, row1.system_pid);
}

                    if(row1.project == null) {
pstmt_tDBOutput_1.setNull(6, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(6, row1.project);
}

                    if(row1.job == null) {
pstmt_tDBOutput_1.setNull(7, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(7, row1.job);
}

                    if(row1.job_repository_id == null) {
pstmt_tDBOutput_1.setNull(8, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(8, row1.job_repository_id);
}

                    if(row1.job_version == null) {
pstmt_tDBOutput_1.setNull(9, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(9, row1.job_version);
}

                    if(row1.context == null) {
pstmt_tDBOutput_1.setNull(10, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(10, row1.context);
}

                    if(row1.origin == null) {
pstmt_tDBOutput_1.setNull(11, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(11, row1.origin);
}

                    if(row1.message_type == null) {
pstmt_tDBOutput_1.setNull(12, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(12, row1.message_type);
}

                    if(row1.message == null) {
pstmt_tDBOutput_1.setNull(13, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(13, row1.message);
}

                    if(row1.duration == null) {
pstmt_tDBOutput_1.setNull(14, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_1.setLong(14, row1.duration);
}

			
    		pstmt_tDBOutput_1.addBatch();
    		nb_line_tDBOutput_1++;
    		  
    		  
    		  batchSizeCounter_tDBOutput_1++;
    		  
    			if ((batchSize_tDBOutput_1 > 0) && (batchSize_tDBOutput_1 <= batchSizeCounter_tDBOutput_1)) {
                try {
						int countSum_tDBOutput_1 = 0;
						    
						for(int countEach_tDBOutput_1: pstmt_tDBOutput_1.executeBatch()) {
							countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
						}
				    	rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
				    	
				    		insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
				    	
            	    	batchSizeCounter_tDBOutput_1 = 0;
                }catch (java.sql.BatchUpdateException e_tDBOutput_1){
globalMap.put("tDBOutput_1_ERROR_MESSAGE",e_tDBOutput_1.getMessage());
				    	java.sql.SQLException ne_tDBOutput_1 = e_tDBOutput_1.getNextException(),sqle_tDBOutput_1=null;
				    	String errormessage_tDBOutput_1;
						if (ne_tDBOutput_1 != null) {
							// build new exception to provide the original cause
							sqle_tDBOutput_1 = new java.sql.SQLException(e_tDBOutput_1.getMessage() + "\ncaused by: " + ne_tDBOutput_1.getMessage(), ne_tDBOutput_1.getSQLState(), ne_tDBOutput_1.getErrorCode(), ne_tDBOutput_1);
							errormessage_tDBOutput_1 = sqle_tDBOutput_1.getMessage();
						}else{
							errormessage_tDBOutput_1 = e_tDBOutput_1.getMessage();
						}
				    	
				    	int countSum_tDBOutput_1 = 0;
						for(int countEach_tDBOutput_1: e_tDBOutput_1.getUpdateCounts()) {
							countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
						}
						rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
						
				    		insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
				    	
				    	System.err.println(errormessage_tDBOutput_1);
				    	
					}
    			}
    		
    		    commitCounter_tDBOutput_1++;
                if(commitEvery_tDBOutput_1 <= commitCounter_tDBOutput_1) {
                if ((batchSize_tDBOutput_1 > 0) && (batchSizeCounter_tDBOutput_1 > 0)) {
                try {
                		int countSum_tDBOutput_1 = 0;
                		    
						for(int countEach_tDBOutput_1: pstmt_tDBOutput_1.executeBatch()) {
							countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
						}
            	    	rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
            	    	
            	    		insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
            	    	
                batchSizeCounter_tDBOutput_1 = 0;
               }catch (java.sql.BatchUpdateException e_tDBOutput_1){
globalMap.put("tDBOutput_1_ERROR_MESSAGE",e_tDBOutput_1.getMessage());
			    	java.sql.SQLException ne_tDBOutput_1 = e_tDBOutput_1.getNextException(),sqle_tDBOutput_1=null;
			    	String errormessage_tDBOutput_1;
					if (ne_tDBOutput_1 != null) {
						// build new exception to provide the original cause
						sqle_tDBOutput_1 = new java.sql.SQLException(e_tDBOutput_1.getMessage() + "\ncaused by: " + ne_tDBOutput_1.getMessage(), ne_tDBOutput_1.getSQLState(), ne_tDBOutput_1.getErrorCode(), ne_tDBOutput_1);
						errormessage_tDBOutput_1 = sqle_tDBOutput_1.getMessage();
					}else{
						errormessage_tDBOutput_1 = e_tDBOutput_1.getMessage();
					}
			    	
			    	int countSum_tDBOutput_1 = 0;
					for(int countEach_tDBOutput_1: e_tDBOutput_1.getUpdateCounts()) {
						countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
					}
					rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
					
			    		insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
			    	
			    	System.err.println(errormessage_tDBOutput_1);
			    	
				}
            }
                    if(rowsToCommitCount_tDBOutput_1 != 0){
                    	
                    }
                    conn_tDBOutput_1.commit();
                    if(rowsToCommitCount_tDBOutput_1 != 0){
                    	
                    	rowsToCommitCount_tDBOutput_1 = 0;
                    }
                    commitCounter_tDBOutput_1=0;
                }

 


	tos_count_tDBOutput_1++;

/**
 * [tDBOutput_1 main ] stop
 */
	
	/**
	 * [tDBOutput_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";

	

 



/**
 * [tDBOutput_1 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";

	

 



/**
 * [tDBOutput_1 process_data_end ] stop
 */



	
	/**
	 * [tStatCatcher_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tStatCatcher_1";

	

 



/**
 * [tStatCatcher_1 process_data_end ] stop
 */
	
	/**
	 * [tStatCatcher_1 end ] start
	 */

	

	
	
	currentComponent="tStatCatcher_1";

	

	}


 

ok_Hash.put("tStatCatcher_1", true);
end_Hash.put("tStatCatcher_1", System.currentTimeMillis());




/**
 * [tStatCatcher_1 end ] stop
 */

	
	/**
	 * [tDBOutput_1 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";

	



	    try {
				int countSum_tDBOutput_1 = 0;
				if (pstmt_tDBOutput_1 != null && batchSizeCounter_tDBOutput_1 > 0) {
						
					for(int countEach_tDBOutput_1: pstmt_tDBOutput_1.executeBatch()) {
						countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
					}
					rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
						
				}
		    	
		    		insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
		    	
	    }catch (java.sql.BatchUpdateException e_tDBOutput_1){
globalMap.put("tDBOutput_1_ERROR_MESSAGE",e_tDBOutput_1.getMessage());
	    	java.sql.SQLException ne_tDBOutput_1 = e_tDBOutput_1.getNextException(),sqle_tDBOutput_1=null;
	    	String errormessage_tDBOutput_1;
			if (ne_tDBOutput_1 != null) {
				// build new exception to provide the original cause
				sqle_tDBOutput_1 = new java.sql.SQLException(e_tDBOutput_1.getMessage() + "\ncaused by: " + ne_tDBOutput_1.getMessage(), ne_tDBOutput_1.getSQLState(), ne_tDBOutput_1.getErrorCode(), ne_tDBOutput_1);
				errormessage_tDBOutput_1 = sqle_tDBOutput_1.getMessage();
			}else{
				errormessage_tDBOutput_1 = e_tDBOutput_1.getMessage();
			}
	    	
	    	int countSum_tDBOutput_1 = 0;
			for(int countEach_tDBOutput_1: e_tDBOutput_1.getUpdateCounts()) {
				countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
			}
			rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
			
	    		insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
	    	
	    	System.err.println(errormessage_tDBOutput_1);
	    	
		}
	    
        if(pstmt_tDBOutput_1 != null) {
        		
            pstmt_tDBOutput_1.close();
            resourceMap.remove("pstmt_tDBOutput_1");
        }
    resourceMap.put("statementClosed_tDBOutput_1", true);
			if(rowsToCommitCount_tDBOutput_1 != 0){
				
			}
			conn_tDBOutput_1.commit();
			if(rowsToCommitCount_tDBOutput_1 != 0){
				
				rowsToCommitCount_tDBOutput_1 = 0;
			}
			commitCounter_tDBOutput_1 = 0;
		
    	conn_tDBOutput_1 .close();
    	
    	resourceMap.put("finish_tDBOutput_1", true);
    	

	nb_line_deleted_tDBOutput_1=nb_line_deleted_tDBOutput_1+ deletedCount_tDBOutput_1;
	nb_line_update_tDBOutput_1=nb_line_update_tDBOutput_1 + updatedCount_tDBOutput_1;
	nb_line_inserted_tDBOutput_1=nb_line_inserted_tDBOutput_1 + insertedCount_tDBOutput_1;
	nb_line_rejected_tDBOutput_1=nb_line_rejected_tDBOutput_1 + rejectedCount_tDBOutput_1;
	
        globalMap.put("tDBOutput_1_NB_LINE",nb_line_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_UPDATED",nb_line_update_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_DELETED",nb_line_deleted_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_1);
    

	


				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row1");
			  	}
			  	
 

ok_Hash.put("tDBOutput_1", true);
end_Hash.put("tDBOutput_1", System.currentTimeMillis());




/**
 * [tDBOutput_1 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tStatCatcher_1 finally ] start
	 */

	

	
	
	currentComponent="tStatCatcher_1";

	

 



/**
 * [tStatCatcher_1 finally ] stop
 */

	
	/**
	 * [tDBOutput_1 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";

	



    try {
    if (resourceMap.get("statementClosed_tDBOutput_1") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_1 = null;
                if ((pstmtToClose_tDBOutput_1 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_1")) != null) {
                    pstmtToClose_tDBOutput_1.close();
                }
    }
    } finally {
        if(resourceMap.get("finish_tDBOutput_1") == null){
            java.sql.Connection ctn_tDBOutput_1 = null;
            if((ctn_tDBOutput_1 = (java.sql.Connection)resourceMap.get("conn_tDBOutput_1")) != null){
                try {
                    ctn_tDBOutput_1.close();
                } catch (java.sql.SQLException sqlEx_tDBOutput_1) {
                    String errorMessage_tDBOutput_1 = "failed to close the connection in tDBOutput_1 :" + sqlEx_tDBOutput_1.getMessage();
                    System.err.println(errorMessage_tDBOutput_1);
                }
            }
        }
    }
 



/**
 * [tDBOutput_1 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tStatCatcher_1_SUBPROCESS_STATE", 1);
	}
	


public static class row3Struct implements routines.system.IPersistableRow<row3Struct> {
    final static byte[] commonByteArrayLock_ALIMENTATION_DM2_A_ALIM_STAGING_DM2 = new byte[0];
    static byte[] commonByteArray_ALIMENTATION_DM2_A_ALIM_STAGING_DM2 = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int id_staging_dm2;

				public int getId_staging_dm2 () {
					return this.id_staging_dm2;
				}
				
			    public Integer id_adresse_norm_client;

				public Integer getId_adresse_norm_client () {
					return this.id_adresse_norm_client;
				}
				
			    public String numero_voie;

				public String getNumero_voie () {
					return this.numero_voie;
				}
				
			    public String nom_voie;

				public String getNom_voie () {
					return this.nom_voie;
				}
				
			    public String code_postal;

				public String getCode_postal () {
					return this.code_postal;
				}
				
			    public String nom_ville;

				public String getNom_ville () {
					return this.nom_ville;
				}
				
			    public String longitude;

				public String getLongitude () {
					return this.longitude;
				}
				
			    public String latitude;

				public String getLatitude () {
					return this.latitude;
				}
				
			    public Integer id_restaurant;

				public Integer getId_restaurant () {
					return this.id_restaurant;
				}
				
			    public String code_restaurant;

				public String getCode_restaurant () {
					return this.code_restaurant;
				}
				
			    public String raison_sociale_restaurant;

				public String getRaison_sociale_restaurant () {
					return this.raison_sociale_restaurant;
				}
				
			    public Integer id_adresse_norm_restaurant;

				public Integer getId_adresse_norm_restaurant () {
					return this.id_adresse_norm_restaurant;
				}
				
			    public String numero_voie_restau;

				public String getNumero_voie_restau () {
					return this.numero_voie_restau;
				}
				
			    public String nom_voie_restau;

				public String getNom_voie_restau () {
					return this.nom_voie_restau;
				}
				
			    public String code_postal_restau;

				public String getCode_postal_restau () {
					return this.code_postal_restau;
				}
				
			    public String nom_ville_restau;

				public String getNom_ville_restau () {
					return this.nom_ville_restau;
				}
				
			    public String longitude_restau;

				public String getLongitude_restau () {
					return this.longitude_restau;
				}
				
			    public String latitude_restau;

				public String getLatitude_restau () {
					return this.latitude_restau;
				}
				
			    public Integer id_client;

				public Integer getId_client () {
					return this.id_client;
				}
				
			    public Integer id_livraison;

				public Integer getId_livraison () {
					return this.id_livraison;
				}
				
			    public Integer id_commande;

				public Integer getId_commande () {
					return this.id_commande;
				}
				
			    public Integer numero_commande;

				public Integer getNumero_commande () {
					return this.numero_commande;
				}
				
			    public java.util.Date date_commande;

				public java.util.Date getDate_commande () {
					return this.date_commande;
				}
				
			    public Float montant_total;

				public Float getMontant_total () {
					return this.montant_total;
				}
				
			    public Integer id_menu;

				public Integer getId_menu () {
					return this.id_menu;
				}
				
			    public String code_menu;

				public String getCode_menu () {
					return this.code_menu;
				}
				
			    public String libelle_menu;

				public String getLibelle_menu () {
					return this.libelle_menu;
				}
				
			    public Integer nombre_articles;

				public Integer getNombre_articles () {
					return this.nombre_articles;
				}
				
			    public Integer temps_theo_preparation;

				public Integer getTemps_theo_preparation () {
					return this.temps_theo_preparation;
				}
				
			    public Integer numero_livraison;

				public Integer getNumero_livraison () {
					return this.numero_livraison;
				}
				
			    public java.util.Date date_debut_livraison;

				public java.util.Date getDate_debut_livraison () {
					return this.date_debut_livraison;
				}
				
			    public java.util.Date date_fin_livraison;

				public java.util.Date getDate_fin_livraison () {
					return this.date_fin_livraison;
				}
				
			    public Integer id_livreur;

				public Integer getId_livreur () {
					return this.id_livreur;
				}
				
			    public String nom_livreur;

				public String getNom_livreur () {
					return this.nom_livreur;
				}
				
			    public String prenom_livreur;

				public String getPrenom_livreur () {
					return this.prenom_livreur;
				}
				
			    public Integer id_moyen_livraison;

				public Integer getId_moyen_livraison () {
					return this.id_moyen_livraison;
				}
				
			    public String code_moyen_livraison;

				public String getCode_moyen_livraison () {
					return this.code_moyen_livraison;
				}
				
			    public String libelle_moyen_livraison;

				public String getLibelle_moyen_livraison () {
					return this.libelle_moyen_livraison;
				}
				
			    public String nom_client;

				public String getNom_client () {
					return this.nom_client;
				}
				
			    public String prenom_client;

				public String getPrenom_client () {
					return this.prenom_client;
				}
				
			    public Integer id_preparation;

				public Integer getId_preparation () {
					return this.id_preparation;
				}
				
			    public java.util.Date date_debut_preparation;

				public java.util.Date getDate_debut_preparation () {
					return this.date_debut_preparation;
				}
				
			    public java.util.Date date_fin_preparation;

				public java.util.Date getDate_fin_preparation () {
					return this.date_fin_preparation;
				}
				
			    public Integer nombre_article_livres;

				public Integer getNombre_article_livres () {
					return this.nombre_article_livres;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.id_staging_dm2;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row3Struct other = (row3Struct) obj;
		
						if (this.id_staging_dm2 != other.id_staging_dm2)
							return false;
					

		return true;
    }

	public void copyDataTo(row3Struct other) {

		other.id_staging_dm2 = this.id_staging_dm2;
	            other.id_adresse_norm_client = this.id_adresse_norm_client;
	            other.numero_voie = this.numero_voie;
	            other.nom_voie = this.nom_voie;
	            other.code_postal = this.code_postal;
	            other.nom_ville = this.nom_ville;
	            other.longitude = this.longitude;
	            other.latitude = this.latitude;
	            other.id_restaurant = this.id_restaurant;
	            other.code_restaurant = this.code_restaurant;
	            other.raison_sociale_restaurant = this.raison_sociale_restaurant;
	            other.id_adresse_norm_restaurant = this.id_adresse_norm_restaurant;
	            other.numero_voie_restau = this.numero_voie_restau;
	            other.nom_voie_restau = this.nom_voie_restau;
	            other.code_postal_restau = this.code_postal_restau;
	            other.nom_ville_restau = this.nom_ville_restau;
	            other.longitude_restau = this.longitude_restau;
	            other.latitude_restau = this.latitude_restau;
	            other.id_client = this.id_client;
	            other.id_livraison = this.id_livraison;
	            other.id_commande = this.id_commande;
	            other.numero_commande = this.numero_commande;
	            other.date_commande = this.date_commande;
	            other.montant_total = this.montant_total;
	            other.id_menu = this.id_menu;
	            other.code_menu = this.code_menu;
	            other.libelle_menu = this.libelle_menu;
	            other.nombre_articles = this.nombre_articles;
	            other.temps_theo_preparation = this.temps_theo_preparation;
	            other.numero_livraison = this.numero_livraison;
	            other.date_debut_livraison = this.date_debut_livraison;
	            other.date_fin_livraison = this.date_fin_livraison;
	            other.id_livreur = this.id_livreur;
	            other.nom_livreur = this.nom_livreur;
	            other.prenom_livreur = this.prenom_livreur;
	            other.id_moyen_livraison = this.id_moyen_livraison;
	            other.code_moyen_livraison = this.code_moyen_livraison;
	            other.libelle_moyen_livraison = this.libelle_moyen_livraison;
	            other.nom_client = this.nom_client;
	            other.prenom_client = this.prenom_client;
	            other.id_preparation = this.id_preparation;
	            other.date_debut_preparation = this.date_debut_preparation;
	            other.date_fin_preparation = this.date_fin_preparation;
	            other.nombre_article_livres = this.nombre_article_livres;
	            
	}

	public void copyKeysDataTo(row3Struct other) {

		other.id_staging_dm2 = this.id_staging_dm2;
	            	
	}



	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_DM2_A_ALIM_STAGING_DM2.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_DM2_A_ALIM_STAGING_DM2.length == 0) {
   					commonByteArray_ALIMENTATION_DM2_A_ALIM_STAGING_DM2 = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_DM2_A_ALIM_STAGING_DM2 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ALIMENTATION_DM2_A_ALIM_STAGING_DM2, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_DM2_A_ALIM_STAGING_DM2, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_DM2_A_ALIM_STAGING_DM2.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_DM2_A_ALIM_STAGING_DM2.length == 0) {
   					commonByteArray_ALIMENTATION_DM2_A_ALIM_STAGING_DM2 = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_DM2_A_ALIM_STAGING_DM2 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ALIMENTATION_DM2_A_ALIM_STAGING_DM2, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_DM2_A_ALIM_STAGING_DM2, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_DM2_A_ALIM_STAGING_DM2) {

        	try {

        		int length = 0;
		
			        this.id_staging_dm2 = dis.readInt();
					
						this.id_adresse_norm_client = readInteger(dis);
					
					this.numero_voie = readString(dis);
					
					this.nom_voie = readString(dis);
					
					this.code_postal = readString(dis);
					
					this.nom_ville = readString(dis);
					
					this.longitude = readString(dis);
					
					this.latitude = readString(dis);
					
						this.id_restaurant = readInteger(dis);
					
					this.code_restaurant = readString(dis);
					
					this.raison_sociale_restaurant = readString(dis);
					
						this.id_adresse_norm_restaurant = readInteger(dis);
					
					this.numero_voie_restau = readString(dis);
					
					this.nom_voie_restau = readString(dis);
					
					this.code_postal_restau = readString(dis);
					
					this.nom_ville_restau = readString(dis);
					
					this.longitude_restau = readString(dis);
					
					this.latitude_restau = readString(dis);
					
						this.id_client = readInteger(dis);
					
						this.id_livraison = readInteger(dis);
					
						this.id_commande = readInteger(dis);
					
						this.numero_commande = readInteger(dis);
					
					this.date_commande = readDate(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.montant_total = null;
           				} else {
           			    	this.montant_total = dis.readFloat();
           				}
					
						this.id_menu = readInteger(dis);
					
					this.code_menu = readString(dis);
					
					this.libelle_menu = readString(dis);
					
						this.nombre_articles = readInteger(dis);
					
						this.temps_theo_preparation = readInteger(dis);
					
						this.numero_livraison = readInteger(dis);
					
					this.date_debut_livraison = readDate(dis);
					
					this.date_fin_livraison = readDate(dis);
					
						this.id_livreur = readInteger(dis);
					
					this.nom_livreur = readString(dis);
					
					this.prenom_livreur = readString(dis);
					
						this.id_moyen_livraison = readInteger(dis);
					
					this.code_moyen_livraison = readString(dis);
					
					this.libelle_moyen_livraison = readString(dis);
					
					this.nom_client = readString(dis);
					
					this.prenom_client = readString(dis);
					
						this.id_preparation = readInteger(dis);
					
					this.date_debut_preparation = readDate(dis);
					
					this.date_fin_preparation = readDate(dis);
					
						this.nombre_article_livres = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_DM2_A_ALIM_STAGING_DM2) {

        	try {

        		int length = 0;
		
			        this.id_staging_dm2 = dis.readInt();
					
						this.id_adresse_norm_client = readInteger(dis);
					
					this.numero_voie = readString(dis);
					
					this.nom_voie = readString(dis);
					
					this.code_postal = readString(dis);
					
					this.nom_ville = readString(dis);
					
					this.longitude = readString(dis);
					
					this.latitude = readString(dis);
					
						this.id_restaurant = readInteger(dis);
					
					this.code_restaurant = readString(dis);
					
					this.raison_sociale_restaurant = readString(dis);
					
						this.id_adresse_norm_restaurant = readInteger(dis);
					
					this.numero_voie_restau = readString(dis);
					
					this.nom_voie_restau = readString(dis);
					
					this.code_postal_restau = readString(dis);
					
					this.nom_ville_restau = readString(dis);
					
					this.longitude_restau = readString(dis);
					
					this.latitude_restau = readString(dis);
					
						this.id_client = readInteger(dis);
					
						this.id_livraison = readInteger(dis);
					
						this.id_commande = readInteger(dis);
					
						this.numero_commande = readInteger(dis);
					
					this.date_commande = readDate(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.montant_total = null;
           				} else {
           			    	this.montant_total = dis.readFloat();
           				}
					
						this.id_menu = readInteger(dis);
					
					this.code_menu = readString(dis);
					
					this.libelle_menu = readString(dis);
					
						this.nombre_articles = readInteger(dis);
					
						this.temps_theo_preparation = readInteger(dis);
					
						this.numero_livraison = readInteger(dis);
					
					this.date_debut_livraison = readDate(dis);
					
					this.date_fin_livraison = readDate(dis);
					
						this.id_livreur = readInteger(dis);
					
					this.nom_livreur = readString(dis);
					
					this.prenom_livreur = readString(dis);
					
						this.id_moyen_livraison = readInteger(dis);
					
					this.code_moyen_livraison = readString(dis);
					
					this.libelle_moyen_livraison = readString(dis);
					
					this.nom_client = readString(dis);
					
					this.prenom_client = readString(dis);
					
						this.id_preparation = readInteger(dis);
					
					this.date_debut_preparation = readDate(dis);
					
					this.date_fin_preparation = readDate(dis);
					
						this.nombre_article_livres = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id_staging_dm2);
					
					// Integer
				
						writeInteger(this.id_adresse_norm_client,dos);
					
					// String
				
						writeString(this.numero_voie,dos);
					
					// String
				
						writeString(this.nom_voie,dos);
					
					// String
				
						writeString(this.code_postal,dos);
					
					// String
				
						writeString(this.nom_ville,dos);
					
					// String
				
						writeString(this.longitude,dos);
					
					// String
				
						writeString(this.latitude,dos);
					
					// Integer
				
						writeInteger(this.id_restaurant,dos);
					
					// String
				
						writeString(this.code_restaurant,dos);
					
					// String
				
						writeString(this.raison_sociale_restaurant,dos);
					
					// Integer
				
						writeInteger(this.id_adresse_norm_restaurant,dos);
					
					// String
				
						writeString(this.numero_voie_restau,dos);
					
					// String
				
						writeString(this.nom_voie_restau,dos);
					
					// String
				
						writeString(this.code_postal_restau,dos);
					
					// String
				
						writeString(this.nom_ville_restau,dos);
					
					// String
				
						writeString(this.longitude_restau,dos);
					
					// String
				
						writeString(this.latitude_restau,dos);
					
					// Integer
				
						writeInteger(this.id_client,dos);
					
					// Integer
				
						writeInteger(this.id_livraison,dos);
					
					// Integer
				
						writeInteger(this.id_commande,dos);
					
					// Integer
				
						writeInteger(this.numero_commande,dos);
					
					// java.util.Date
				
						writeDate(this.date_commande,dos);
					
					// Float
				
						if(this.montant_total == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.montant_total);
		            	}
					
					// Integer
				
						writeInteger(this.id_menu,dos);
					
					// String
				
						writeString(this.code_menu,dos);
					
					// String
				
						writeString(this.libelle_menu,dos);
					
					// Integer
				
						writeInteger(this.nombre_articles,dos);
					
					// Integer
				
						writeInteger(this.temps_theo_preparation,dos);
					
					// Integer
				
						writeInteger(this.numero_livraison,dos);
					
					// java.util.Date
				
						writeDate(this.date_debut_livraison,dos);
					
					// java.util.Date
				
						writeDate(this.date_fin_livraison,dos);
					
					// Integer
				
						writeInteger(this.id_livreur,dos);
					
					// String
				
						writeString(this.nom_livreur,dos);
					
					// String
				
						writeString(this.prenom_livreur,dos);
					
					// Integer
				
						writeInteger(this.id_moyen_livraison,dos);
					
					// String
				
						writeString(this.code_moyen_livraison,dos);
					
					// String
				
						writeString(this.libelle_moyen_livraison,dos);
					
					// String
				
						writeString(this.nom_client,dos);
					
					// String
				
						writeString(this.prenom_client,dos);
					
					// Integer
				
						writeInteger(this.id_preparation,dos);
					
					// java.util.Date
				
						writeDate(this.date_debut_preparation,dos);
					
					// java.util.Date
				
						writeDate(this.date_fin_preparation,dos);
					
					// Integer
				
						writeInteger(this.nombre_article_livres,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id_staging_dm2);
					
					// Integer
				
						writeInteger(this.id_adresse_norm_client,dos);
					
					// String
				
						writeString(this.numero_voie,dos);
					
					// String
				
						writeString(this.nom_voie,dos);
					
					// String
				
						writeString(this.code_postal,dos);
					
					// String
				
						writeString(this.nom_ville,dos);
					
					// String
				
						writeString(this.longitude,dos);
					
					// String
				
						writeString(this.latitude,dos);
					
					// Integer
				
						writeInteger(this.id_restaurant,dos);
					
					// String
				
						writeString(this.code_restaurant,dos);
					
					// String
				
						writeString(this.raison_sociale_restaurant,dos);
					
					// Integer
				
						writeInteger(this.id_adresse_norm_restaurant,dos);
					
					// String
				
						writeString(this.numero_voie_restau,dos);
					
					// String
				
						writeString(this.nom_voie_restau,dos);
					
					// String
				
						writeString(this.code_postal_restau,dos);
					
					// String
				
						writeString(this.nom_ville_restau,dos);
					
					// String
				
						writeString(this.longitude_restau,dos);
					
					// String
				
						writeString(this.latitude_restau,dos);
					
					// Integer
				
						writeInteger(this.id_client,dos);
					
					// Integer
				
						writeInteger(this.id_livraison,dos);
					
					// Integer
				
						writeInteger(this.id_commande,dos);
					
					// Integer
				
						writeInteger(this.numero_commande,dos);
					
					// java.util.Date
				
						writeDate(this.date_commande,dos);
					
					// Float
				
						if(this.montant_total == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.montant_total);
		            	}
					
					// Integer
				
						writeInteger(this.id_menu,dos);
					
					// String
				
						writeString(this.code_menu,dos);
					
					// String
				
						writeString(this.libelle_menu,dos);
					
					// Integer
				
						writeInteger(this.nombre_articles,dos);
					
					// Integer
				
						writeInteger(this.temps_theo_preparation,dos);
					
					// Integer
				
						writeInteger(this.numero_livraison,dos);
					
					// java.util.Date
				
						writeDate(this.date_debut_livraison,dos);
					
					// java.util.Date
				
						writeDate(this.date_fin_livraison,dos);
					
					// Integer
				
						writeInteger(this.id_livreur,dos);
					
					// String
				
						writeString(this.nom_livreur,dos);
					
					// String
				
						writeString(this.prenom_livreur,dos);
					
					// Integer
				
						writeInteger(this.id_moyen_livraison,dos);
					
					// String
				
						writeString(this.code_moyen_livraison,dos);
					
					// String
				
						writeString(this.libelle_moyen_livraison,dos);
					
					// String
				
						writeString(this.nom_client,dos);
					
					// String
				
						writeString(this.prenom_client,dos);
					
					// Integer
				
						writeInteger(this.id_preparation,dos);
					
					// java.util.Date
				
						writeDate(this.date_debut_preparation,dos);
					
					// java.util.Date
				
						writeDate(this.date_fin_preparation,dos);
					
					// Integer
				
						writeInteger(this.nombre_article_livres,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id_staging_dm2="+String.valueOf(id_staging_dm2));
		sb.append(",id_adresse_norm_client="+String.valueOf(id_adresse_norm_client));
		sb.append(",numero_voie="+numero_voie);
		sb.append(",nom_voie="+nom_voie);
		sb.append(",code_postal="+code_postal);
		sb.append(",nom_ville="+nom_ville);
		sb.append(",longitude="+longitude);
		sb.append(",latitude="+latitude);
		sb.append(",id_restaurant="+String.valueOf(id_restaurant));
		sb.append(",code_restaurant="+code_restaurant);
		sb.append(",raison_sociale_restaurant="+raison_sociale_restaurant);
		sb.append(",id_adresse_norm_restaurant="+String.valueOf(id_adresse_norm_restaurant));
		sb.append(",numero_voie_restau="+numero_voie_restau);
		sb.append(",nom_voie_restau="+nom_voie_restau);
		sb.append(",code_postal_restau="+code_postal_restau);
		sb.append(",nom_ville_restau="+nom_ville_restau);
		sb.append(",longitude_restau="+longitude_restau);
		sb.append(",latitude_restau="+latitude_restau);
		sb.append(",id_client="+String.valueOf(id_client));
		sb.append(",id_livraison="+String.valueOf(id_livraison));
		sb.append(",id_commande="+String.valueOf(id_commande));
		sb.append(",numero_commande="+String.valueOf(numero_commande));
		sb.append(",date_commande="+String.valueOf(date_commande));
		sb.append(",montant_total="+String.valueOf(montant_total));
		sb.append(",id_menu="+String.valueOf(id_menu));
		sb.append(",code_menu="+code_menu);
		sb.append(",libelle_menu="+libelle_menu);
		sb.append(",nombre_articles="+String.valueOf(nombre_articles));
		sb.append(",temps_theo_preparation="+String.valueOf(temps_theo_preparation));
		sb.append(",numero_livraison="+String.valueOf(numero_livraison));
		sb.append(",date_debut_livraison="+String.valueOf(date_debut_livraison));
		sb.append(",date_fin_livraison="+String.valueOf(date_fin_livraison));
		sb.append(",id_livreur="+String.valueOf(id_livreur));
		sb.append(",nom_livreur="+nom_livreur);
		sb.append(",prenom_livreur="+prenom_livreur);
		sb.append(",id_moyen_livraison="+String.valueOf(id_moyen_livraison));
		sb.append(",code_moyen_livraison="+code_moyen_livraison);
		sb.append(",libelle_moyen_livraison="+libelle_moyen_livraison);
		sb.append(",nom_client="+nom_client);
		sb.append(",prenom_client="+prenom_client);
		sb.append(",id_preparation="+String.valueOf(id_preparation));
		sb.append(",date_debut_preparation="+String.valueOf(date_debut_preparation));
		sb.append(",date_fin_preparation="+String.valueOf(date_fin_preparation));
		sb.append(",nombre_article_livres="+String.valueOf(nombre_article_livres));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row3Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.id_staging_dm2, other.id_staging_dm2);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class ALIM_STAGINGStruct implements routines.system.IPersistableRow<ALIM_STAGINGStruct> {
    final static byte[] commonByteArrayLock_ALIMENTATION_DM2_A_ALIM_STAGING_DM2 = new byte[0];
    static byte[] commonByteArray_ALIMENTATION_DM2_A_ALIM_STAGING_DM2 = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int id_staging_dm2;

				public int getId_staging_dm2 () {
					return this.id_staging_dm2;
				}
				
			    public Integer id_adresse_norm_client;

				public Integer getId_adresse_norm_client () {
					return this.id_adresse_norm_client;
				}
				
			    public String numero_voie;

				public String getNumero_voie () {
					return this.numero_voie;
				}
				
			    public String nom_voie;

				public String getNom_voie () {
					return this.nom_voie;
				}
				
			    public String code_postal;

				public String getCode_postal () {
					return this.code_postal;
				}
				
			    public String nom_ville;

				public String getNom_ville () {
					return this.nom_ville;
				}
				
			    public String longitude;

				public String getLongitude () {
					return this.longitude;
				}
				
			    public String latitude;

				public String getLatitude () {
					return this.latitude;
				}
				
			    public Integer id_restaurant;

				public Integer getId_restaurant () {
					return this.id_restaurant;
				}
				
			    public String code_restaurant;

				public String getCode_restaurant () {
					return this.code_restaurant;
				}
				
			    public String raison_sociale_restaurant;

				public String getRaison_sociale_restaurant () {
					return this.raison_sociale_restaurant;
				}
				
			    public Integer id_adresse_norm_restaurant;

				public Integer getId_adresse_norm_restaurant () {
					return this.id_adresse_norm_restaurant;
				}
				
			    public String numero_voie_restau;

				public String getNumero_voie_restau () {
					return this.numero_voie_restau;
				}
				
			    public String nom_voie_restau;

				public String getNom_voie_restau () {
					return this.nom_voie_restau;
				}
				
			    public String code_postal_restau;

				public String getCode_postal_restau () {
					return this.code_postal_restau;
				}
				
			    public String nom_ville_restau;

				public String getNom_ville_restau () {
					return this.nom_ville_restau;
				}
				
			    public String longitude_restau;

				public String getLongitude_restau () {
					return this.longitude_restau;
				}
				
			    public String latitude_restau;

				public String getLatitude_restau () {
					return this.latitude_restau;
				}
				
			    public Integer id_client;

				public Integer getId_client () {
					return this.id_client;
				}
				
			    public Integer id_livraison;

				public Integer getId_livraison () {
					return this.id_livraison;
				}
				
			    public Integer id_commande;

				public Integer getId_commande () {
					return this.id_commande;
				}
				
			    public Integer numero_commande;

				public Integer getNumero_commande () {
					return this.numero_commande;
				}
				
			    public java.util.Date date_commande;

				public java.util.Date getDate_commande () {
					return this.date_commande;
				}
				
			    public Float montant_total;

				public Float getMontant_total () {
					return this.montant_total;
				}
				
			    public Integer id_menu;

				public Integer getId_menu () {
					return this.id_menu;
				}
				
			    public String code_menu;

				public String getCode_menu () {
					return this.code_menu;
				}
				
			    public String libelle_menu;

				public String getLibelle_menu () {
					return this.libelle_menu;
				}
				
			    public Integer nombre_articles;

				public Integer getNombre_articles () {
					return this.nombre_articles;
				}
				
			    public Integer temps_theo_preparation;

				public Integer getTemps_theo_preparation () {
					return this.temps_theo_preparation;
				}
				
			    public Integer numero_livraison;

				public Integer getNumero_livraison () {
					return this.numero_livraison;
				}
				
			    public java.util.Date date_debut_livraison;

				public java.util.Date getDate_debut_livraison () {
					return this.date_debut_livraison;
				}
				
			    public java.util.Date date_fin_livraison;

				public java.util.Date getDate_fin_livraison () {
					return this.date_fin_livraison;
				}
				
			    public Integer id_livreur;

				public Integer getId_livreur () {
					return this.id_livreur;
				}
				
			    public String nom_livreur;

				public String getNom_livreur () {
					return this.nom_livreur;
				}
				
			    public String prenom_livreur;

				public String getPrenom_livreur () {
					return this.prenom_livreur;
				}
				
			    public Integer id_moyen_livraison;

				public Integer getId_moyen_livraison () {
					return this.id_moyen_livraison;
				}
				
			    public String code_moyen_livraison;

				public String getCode_moyen_livraison () {
					return this.code_moyen_livraison;
				}
				
			    public String libelle_moyen_livraison;

				public String getLibelle_moyen_livraison () {
					return this.libelle_moyen_livraison;
				}
				
			    public String nom_client;

				public String getNom_client () {
					return this.nom_client;
				}
				
			    public String prenom_client;

				public String getPrenom_client () {
					return this.prenom_client;
				}
				
			    public Integer id_preparation;

				public Integer getId_preparation () {
					return this.id_preparation;
				}
				
			    public java.util.Date date_debut_preparation;

				public java.util.Date getDate_debut_preparation () {
					return this.date_debut_preparation;
				}
				
			    public java.util.Date date_fin_preparation;

				public java.util.Date getDate_fin_preparation () {
					return this.date_fin_preparation;
				}
				
			    public Integer nombre_article_livres;

				public Integer getNombre_article_livres () {
					return this.nombre_article_livres;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.id_staging_dm2;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final ALIM_STAGINGStruct other = (ALIM_STAGINGStruct) obj;
		
						if (this.id_staging_dm2 != other.id_staging_dm2)
							return false;
					

		return true;
    }

	public void copyDataTo(ALIM_STAGINGStruct other) {

		other.id_staging_dm2 = this.id_staging_dm2;
	            other.id_adresse_norm_client = this.id_adresse_norm_client;
	            other.numero_voie = this.numero_voie;
	            other.nom_voie = this.nom_voie;
	            other.code_postal = this.code_postal;
	            other.nom_ville = this.nom_ville;
	            other.longitude = this.longitude;
	            other.latitude = this.latitude;
	            other.id_restaurant = this.id_restaurant;
	            other.code_restaurant = this.code_restaurant;
	            other.raison_sociale_restaurant = this.raison_sociale_restaurant;
	            other.id_adresse_norm_restaurant = this.id_adresse_norm_restaurant;
	            other.numero_voie_restau = this.numero_voie_restau;
	            other.nom_voie_restau = this.nom_voie_restau;
	            other.code_postal_restau = this.code_postal_restau;
	            other.nom_ville_restau = this.nom_ville_restau;
	            other.longitude_restau = this.longitude_restau;
	            other.latitude_restau = this.latitude_restau;
	            other.id_client = this.id_client;
	            other.id_livraison = this.id_livraison;
	            other.id_commande = this.id_commande;
	            other.numero_commande = this.numero_commande;
	            other.date_commande = this.date_commande;
	            other.montant_total = this.montant_total;
	            other.id_menu = this.id_menu;
	            other.code_menu = this.code_menu;
	            other.libelle_menu = this.libelle_menu;
	            other.nombre_articles = this.nombre_articles;
	            other.temps_theo_preparation = this.temps_theo_preparation;
	            other.numero_livraison = this.numero_livraison;
	            other.date_debut_livraison = this.date_debut_livraison;
	            other.date_fin_livraison = this.date_fin_livraison;
	            other.id_livreur = this.id_livreur;
	            other.nom_livreur = this.nom_livreur;
	            other.prenom_livreur = this.prenom_livreur;
	            other.id_moyen_livraison = this.id_moyen_livraison;
	            other.code_moyen_livraison = this.code_moyen_livraison;
	            other.libelle_moyen_livraison = this.libelle_moyen_livraison;
	            other.nom_client = this.nom_client;
	            other.prenom_client = this.prenom_client;
	            other.id_preparation = this.id_preparation;
	            other.date_debut_preparation = this.date_debut_preparation;
	            other.date_fin_preparation = this.date_fin_preparation;
	            other.nombre_article_livres = this.nombre_article_livres;
	            
	}

	public void copyKeysDataTo(ALIM_STAGINGStruct other) {

		other.id_staging_dm2 = this.id_staging_dm2;
	            	
	}



	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_DM2_A_ALIM_STAGING_DM2.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_DM2_A_ALIM_STAGING_DM2.length == 0) {
   					commonByteArray_ALIMENTATION_DM2_A_ALIM_STAGING_DM2 = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_DM2_A_ALIM_STAGING_DM2 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ALIMENTATION_DM2_A_ALIM_STAGING_DM2, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_DM2_A_ALIM_STAGING_DM2, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_DM2_A_ALIM_STAGING_DM2.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_DM2_A_ALIM_STAGING_DM2.length == 0) {
   					commonByteArray_ALIMENTATION_DM2_A_ALIM_STAGING_DM2 = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_DM2_A_ALIM_STAGING_DM2 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ALIMENTATION_DM2_A_ALIM_STAGING_DM2, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_DM2_A_ALIM_STAGING_DM2, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_DM2_A_ALIM_STAGING_DM2) {

        	try {

        		int length = 0;
		
			        this.id_staging_dm2 = dis.readInt();
					
						this.id_adresse_norm_client = readInteger(dis);
					
					this.numero_voie = readString(dis);
					
					this.nom_voie = readString(dis);
					
					this.code_postal = readString(dis);
					
					this.nom_ville = readString(dis);
					
					this.longitude = readString(dis);
					
					this.latitude = readString(dis);
					
						this.id_restaurant = readInteger(dis);
					
					this.code_restaurant = readString(dis);
					
					this.raison_sociale_restaurant = readString(dis);
					
						this.id_adresse_norm_restaurant = readInteger(dis);
					
					this.numero_voie_restau = readString(dis);
					
					this.nom_voie_restau = readString(dis);
					
					this.code_postal_restau = readString(dis);
					
					this.nom_ville_restau = readString(dis);
					
					this.longitude_restau = readString(dis);
					
					this.latitude_restau = readString(dis);
					
						this.id_client = readInteger(dis);
					
						this.id_livraison = readInteger(dis);
					
						this.id_commande = readInteger(dis);
					
						this.numero_commande = readInteger(dis);
					
					this.date_commande = readDate(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.montant_total = null;
           				} else {
           			    	this.montant_total = dis.readFloat();
           				}
					
						this.id_menu = readInteger(dis);
					
					this.code_menu = readString(dis);
					
					this.libelle_menu = readString(dis);
					
						this.nombre_articles = readInteger(dis);
					
						this.temps_theo_preparation = readInteger(dis);
					
						this.numero_livraison = readInteger(dis);
					
					this.date_debut_livraison = readDate(dis);
					
					this.date_fin_livraison = readDate(dis);
					
						this.id_livreur = readInteger(dis);
					
					this.nom_livreur = readString(dis);
					
					this.prenom_livreur = readString(dis);
					
						this.id_moyen_livraison = readInteger(dis);
					
					this.code_moyen_livraison = readString(dis);
					
					this.libelle_moyen_livraison = readString(dis);
					
					this.nom_client = readString(dis);
					
					this.prenom_client = readString(dis);
					
						this.id_preparation = readInteger(dis);
					
					this.date_debut_preparation = readDate(dis);
					
					this.date_fin_preparation = readDate(dis);
					
						this.nombre_article_livres = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_DM2_A_ALIM_STAGING_DM2) {

        	try {

        		int length = 0;
		
			        this.id_staging_dm2 = dis.readInt();
					
						this.id_adresse_norm_client = readInteger(dis);
					
					this.numero_voie = readString(dis);
					
					this.nom_voie = readString(dis);
					
					this.code_postal = readString(dis);
					
					this.nom_ville = readString(dis);
					
					this.longitude = readString(dis);
					
					this.latitude = readString(dis);
					
						this.id_restaurant = readInteger(dis);
					
					this.code_restaurant = readString(dis);
					
					this.raison_sociale_restaurant = readString(dis);
					
						this.id_adresse_norm_restaurant = readInteger(dis);
					
					this.numero_voie_restau = readString(dis);
					
					this.nom_voie_restau = readString(dis);
					
					this.code_postal_restau = readString(dis);
					
					this.nom_ville_restau = readString(dis);
					
					this.longitude_restau = readString(dis);
					
					this.latitude_restau = readString(dis);
					
						this.id_client = readInteger(dis);
					
						this.id_livraison = readInteger(dis);
					
						this.id_commande = readInteger(dis);
					
						this.numero_commande = readInteger(dis);
					
					this.date_commande = readDate(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.montant_total = null;
           				} else {
           			    	this.montant_total = dis.readFloat();
           				}
					
						this.id_menu = readInteger(dis);
					
					this.code_menu = readString(dis);
					
					this.libelle_menu = readString(dis);
					
						this.nombre_articles = readInteger(dis);
					
						this.temps_theo_preparation = readInteger(dis);
					
						this.numero_livraison = readInteger(dis);
					
					this.date_debut_livraison = readDate(dis);
					
					this.date_fin_livraison = readDate(dis);
					
						this.id_livreur = readInteger(dis);
					
					this.nom_livreur = readString(dis);
					
					this.prenom_livreur = readString(dis);
					
						this.id_moyen_livraison = readInteger(dis);
					
					this.code_moyen_livraison = readString(dis);
					
					this.libelle_moyen_livraison = readString(dis);
					
					this.nom_client = readString(dis);
					
					this.prenom_client = readString(dis);
					
						this.id_preparation = readInteger(dis);
					
					this.date_debut_preparation = readDate(dis);
					
					this.date_fin_preparation = readDate(dis);
					
						this.nombre_article_livres = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id_staging_dm2);
					
					// Integer
				
						writeInteger(this.id_adresse_norm_client,dos);
					
					// String
				
						writeString(this.numero_voie,dos);
					
					// String
				
						writeString(this.nom_voie,dos);
					
					// String
				
						writeString(this.code_postal,dos);
					
					// String
				
						writeString(this.nom_ville,dos);
					
					// String
				
						writeString(this.longitude,dos);
					
					// String
				
						writeString(this.latitude,dos);
					
					// Integer
				
						writeInteger(this.id_restaurant,dos);
					
					// String
				
						writeString(this.code_restaurant,dos);
					
					// String
				
						writeString(this.raison_sociale_restaurant,dos);
					
					// Integer
				
						writeInteger(this.id_adresse_norm_restaurant,dos);
					
					// String
				
						writeString(this.numero_voie_restau,dos);
					
					// String
				
						writeString(this.nom_voie_restau,dos);
					
					// String
				
						writeString(this.code_postal_restau,dos);
					
					// String
				
						writeString(this.nom_ville_restau,dos);
					
					// String
				
						writeString(this.longitude_restau,dos);
					
					// String
				
						writeString(this.latitude_restau,dos);
					
					// Integer
				
						writeInteger(this.id_client,dos);
					
					// Integer
				
						writeInteger(this.id_livraison,dos);
					
					// Integer
				
						writeInteger(this.id_commande,dos);
					
					// Integer
				
						writeInteger(this.numero_commande,dos);
					
					// java.util.Date
				
						writeDate(this.date_commande,dos);
					
					// Float
				
						if(this.montant_total == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.montant_total);
		            	}
					
					// Integer
				
						writeInteger(this.id_menu,dos);
					
					// String
				
						writeString(this.code_menu,dos);
					
					// String
				
						writeString(this.libelle_menu,dos);
					
					// Integer
				
						writeInteger(this.nombre_articles,dos);
					
					// Integer
				
						writeInteger(this.temps_theo_preparation,dos);
					
					// Integer
				
						writeInteger(this.numero_livraison,dos);
					
					// java.util.Date
				
						writeDate(this.date_debut_livraison,dos);
					
					// java.util.Date
				
						writeDate(this.date_fin_livraison,dos);
					
					// Integer
				
						writeInteger(this.id_livreur,dos);
					
					// String
				
						writeString(this.nom_livreur,dos);
					
					// String
				
						writeString(this.prenom_livreur,dos);
					
					// Integer
				
						writeInteger(this.id_moyen_livraison,dos);
					
					// String
				
						writeString(this.code_moyen_livraison,dos);
					
					// String
				
						writeString(this.libelle_moyen_livraison,dos);
					
					// String
				
						writeString(this.nom_client,dos);
					
					// String
				
						writeString(this.prenom_client,dos);
					
					// Integer
				
						writeInteger(this.id_preparation,dos);
					
					// java.util.Date
				
						writeDate(this.date_debut_preparation,dos);
					
					// java.util.Date
				
						writeDate(this.date_fin_preparation,dos);
					
					// Integer
				
						writeInteger(this.nombre_article_livres,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id_staging_dm2);
					
					// Integer
				
						writeInteger(this.id_adresse_norm_client,dos);
					
					// String
				
						writeString(this.numero_voie,dos);
					
					// String
				
						writeString(this.nom_voie,dos);
					
					// String
				
						writeString(this.code_postal,dos);
					
					// String
				
						writeString(this.nom_ville,dos);
					
					// String
				
						writeString(this.longitude,dos);
					
					// String
				
						writeString(this.latitude,dos);
					
					// Integer
				
						writeInteger(this.id_restaurant,dos);
					
					// String
				
						writeString(this.code_restaurant,dos);
					
					// String
				
						writeString(this.raison_sociale_restaurant,dos);
					
					// Integer
				
						writeInteger(this.id_adresse_norm_restaurant,dos);
					
					// String
				
						writeString(this.numero_voie_restau,dos);
					
					// String
				
						writeString(this.nom_voie_restau,dos);
					
					// String
				
						writeString(this.code_postal_restau,dos);
					
					// String
				
						writeString(this.nom_ville_restau,dos);
					
					// String
				
						writeString(this.longitude_restau,dos);
					
					// String
				
						writeString(this.latitude_restau,dos);
					
					// Integer
				
						writeInteger(this.id_client,dos);
					
					// Integer
				
						writeInteger(this.id_livraison,dos);
					
					// Integer
				
						writeInteger(this.id_commande,dos);
					
					// Integer
				
						writeInteger(this.numero_commande,dos);
					
					// java.util.Date
				
						writeDate(this.date_commande,dos);
					
					// Float
				
						if(this.montant_total == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.montant_total);
		            	}
					
					// Integer
				
						writeInteger(this.id_menu,dos);
					
					// String
				
						writeString(this.code_menu,dos);
					
					// String
				
						writeString(this.libelle_menu,dos);
					
					// Integer
				
						writeInteger(this.nombre_articles,dos);
					
					// Integer
				
						writeInteger(this.temps_theo_preparation,dos);
					
					// Integer
				
						writeInteger(this.numero_livraison,dos);
					
					// java.util.Date
				
						writeDate(this.date_debut_livraison,dos);
					
					// java.util.Date
				
						writeDate(this.date_fin_livraison,dos);
					
					// Integer
				
						writeInteger(this.id_livreur,dos);
					
					// String
				
						writeString(this.nom_livreur,dos);
					
					// String
				
						writeString(this.prenom_livreur,dos);
					
					// Integer
				
						writeInteger(this.id_moyen_livraison,dos);
					
					// String
				
						writeString(this.code_moyen_livraison,dos);
					
					// String
				
						writeString(this.libelle_moyen_livraison,dos);
					
					// String
				
						writeString(this.nom_client,dos);
					
					// String
				
						writeString(this.prenom_client,dos);
					
					// Integer
				
						writeInteger(this.id_preparation,dos);
					
					// java.util.Date
				
						writeDate(this.date_debut_preparation,dos);
					
					// java.util.Date
				
						writeDate(this.date_fin_preparation,dos);
					
					// Integer
				
						writeInteger(this.nombre_article_livres,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id_staging_dm2="+String.valueOf(id_staging_dm2));
		sb.append(",id_adresse_norm_client="+String.valueOf(id_adresse_norm_client));
		sb.append(",numero_voie="+numero_voie);
		sb.append(",nom_voie="+nom_voie);
		sb.append(",code_postal="+code_postal);
		sb.append(",nom_ville="+nom_ville);
		sb.append(",longitude="+longitude);
		sb.append(",latitude="+latitude);
		sb.append(",id_restaurant="+String.valueOf(id_restaurant));
		sb.append(",code_restaurant="+code_restaurant);
		sb.append(",raison_sociale_restaurant="+raison_sociale_restaurant);
		sb.append(",id_adresse_norm_restaurant="+String.valueOf(id_adresse_norm_restaurant));
		sb.append(",numero_voie_restau="+numero_voie_restau);
		sb.append(",nom_voie_restau="+nom_voie_restau);
		sb.append(",code_postal_restau="+code_postal_restau);
		sb.append(",nom_ville_restau="+nom_ville_restau);
		sb.append(",longitude_restau="+longitude_restau);
		sb.append(",latitude_restau="+latitude_restau);
		sb.append(",id_client="+String.valueOf(id_client));
		sb.append(",id_livraison="+String.valueOf(id_livraison));
		sb.append(",id_commande="+String.valueOf(id_commande));
		sb.append(",numero_commande="+String.valueOf(numero_commande));
		sb.append(",date_commande="+String.valueOf(date_commande));
		sb.append(",montant_total="+String.valueOf(montant_total));
		sb.append(",id_menu="+String.valueOf(id_menu));
		sb.append(",code_menu="+code_menu);
		sb.append(",libelle_menu="+libelle_menu);
		sb.append(",nombre_articles="+String.valueOf(nombre_articles));
		sb.append(",temps_theo_preparation="+String.valueOf(temps_theo_preparation));
		sb.append(",numero_livraison="+String.valueOf(numero_livraison));
		sb.append(",date_debut_livraison="+String.valueOf(date_debut_livraison));
		sb.append(",date_fin_livraison="+String.valueOf(date_fin_livraison));
		sb.append(",id_livreur="+String.valueOf(id_livreur));
		sb.append(",nom_livreur="+nom_livreur);
		sb.append(",prenom_livreur="+prenom_livreur);
		sb.append(",id_moyen_livraison="+String.valueOf(id_moyen_livraison));
		sb.append(",code_moyen_livraison="+code_moyen_livraison);
		sb.append(",libelle_moyen_livraison="+libelle_moyen_livraison);
		sb.append(",nom_client="+nom_client);
		sb.append(",prenom_client="+prenom_client);
		sb.append(",id_preparation="+String.valueOf(id_preparation));
		sb.append(",date_debut_preparation="+String.valueOf(date_debut_preparation));
		sb.append(",date_fin_preparation="+String.valueOf(date_fin_preparation));
		sb.append(",nombre_article_livres="+String.valueOf(nombre_article_livres));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(ALIM_STAGINGStruct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.id_staging_dm2, other.id_staging_dm2);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row2Struct implements routines.system.IPersistableRow<row2Struct> {
    final static byte[] commonByteArrayLock_ALIMENTATION_DM2_A_ALIM_STAGING_DM2 = new byte[0];
    static byte[] commonByteArray_ALIMENTATION_DM2_A_ALIM_STAGING_DM2 = new byte[0];

	
			    public BigDecimal ID_ADRESSE_NORM_CLIENT;

				public BigDecimal getID_ADRESSE_NORM_CLIENT () {
					return this.ID_ADRESSE_NORM_CLIENT;
				}
				
			    public String NUMERO_VOIE;

				public String getNUMERO_VOIE () {
					return this.NUMERO_VOIE;
				}
				
			    public String NOM_VOIE;

				public String getNOM_VOIE () {
					return this.NOM_VOIE;
				}
				
			    public String CODE_POSTAL;

				public String getCODE_POSTAL () {
					return this.CODE_POSTAL;
				}
				
			    public String NOM_VILLE;

				public String getNOM_VILLE () {
					return this.NOM_VILLE;
				}
				
			    public String LONGITUDE;

				public String getLONGITUDE () {
					return this.LONGITUDE;
				}
				
			    public String LATITUDE;

				public String getLATITUDE () {
					return this.LATITUDE;
				}
				
			    public BigDecimal ID_RESTAURANT;

				public BigDecimal getID_RESTAURANT () {
					return this.ID_RESTAURANT;
				}
				
			    public String CODE_RESTAURANT;

				public String getCODE_RESTAURANT () {
					return this.CODE_RESTAURANT;
				}
				
			    public String RAISON_SOCIALE_RESTAURANT;

				public String getRAISON_SOCIALE_RESTAURANT () {
					return this.RAISON_SOCIALE_RESTAURANT;
				}
				
			    public BigDecimal ID_ADRESSE_CLIENT;

				public BigDecimal getID_ADRESSE_CLIENT () {
					return this.ID_ADRESSE_CLIENT;
				}
				
			    public String ADRESSE_CLIENT;

				public String getADRESSE_CLIENT () {
					return this.ADRESSE_CLIENT;
				}
				
			    public BigDecimal ID_ADRESSE_RESTAURANT;

				public BigDecimal getID_ADRESSE_RESTAURANT () {
					return this.ID_ADRESSE_RESTAURANT;
				}
				
			    public String ADRESSE_RESTAURANT;

				public String getADRESSE_RESTAURANT () {
					return this.ADRESSE_RESTAURANT;
				}
				
			    public BigDecimal ID_ADRESSE_NORM_RESTAURANT;

				public BigDecimal getID_ADRESSE_NORM_RESTAURANT () {
					return this.ID_ADRESSE_NORM_RESTAURANT;
				}
				
			    public String NUMERO_VOIE_RESTAU;

				public String getNUMERO_VOIE_RESTAU () {
					return this.NUMERO_VOIE_RESTAU;
				}
				
			    public String NOM_VOIE_RESTAU;

				public String getNOM_VOIE_RESTAU () {
					return this.NOM_VOIE_RESTAU;
				}
				
			    public String CODE_POSTAL_RESTAU;

				public String getCODE_POSTAL_RESTAU () {
					return this.CODE_POSTAL_RESTAU;
				}
				
			    public String NOM_VILLE_RESTAU;

				public String getNOM_VILLE_RESTAU () {
					return this.NOM_VILLE_RESTAU;
				}
				
			    public String LONGITUDE_RESTAU;

				public String getLONGITUDE_RESTAU () {
					return this.LONGITUDE_RESTAU;
				}
				
			    public String LATITUDE_RESTAU;

				public String getLATITUDE_RESTAU () {
					return this.LATITUDE_RESTAU;
				}
				
			    public BigDecimal ID_CLIENT;

				public BigDecimal getID_CLIENT () {
					return this.ID_CLIENT;
				}
				
			    public BigDecimal ID_LIVRAISON;

				public BigDecimal getID_LIVRAISON () {
					return this.ID_LIVRAISON;
				}
				
			    public BigDecimal ID_COMMANDE;

				public BigDecimal getID_COMMANDE () {
					return this.ID_COMMANDE;
				}
				
			    public BigDecimal NUMERO_COMMANDE;

				public BigDecimal getNUMERO_COMMANDE () {
					return this.NUMERO_COMMANDE;
				}
				
			    public java.util.Date DATE_COMMANDE;

				public java.util.Date getDATE_COMMANDE () {
					return this.DATE_COMMANDE;
				}
				
			    public Float MONTANT_TOTAL;

				public Float getMONTANT_TOTAL () {
					return this.MONTANT_TOTAL;
				}
				
			    public BigDecimal ID_MENU;

				public BigDecimal getID_MENU () {
					return this.ID_MENU;
				}
				
			    public String CODE_MENU;

				public String getCODE_MENU () {
					return this.CODE_MENU;
				}
				
			    public String LIBELLE_MENU;

				public String getLIBELLE_MENU () {
					return this.LIBELLE_MENU;
				}
				
			    public BigDecimal NOMBRE_ARTICLES;

				public BigDecimal getNOMBRE_ARTICLES () {
					return this.NOMBRE_ARTICLES;
				}
				
			    public String TEMPS_THEO_PREPARATION;

				public String getTEMPS_THEO_PREPARATION () {
					return this.TEMPS_THEO_PREPARATION;
				}
				
			    public BigDecimal NUMERO_LIVRAISON;

				public BigDecimal getNUMERO_LIVRAISON () {
					return this.NUMERO_LIVRAISON;
				}
				
			    public java.util.Date DATE_DEBUT_LIVRAISON;

				public java.util.Date getDATE_DEBUT_LIVRAISON () {
					return this.DATE_DEBUT_LIVRAISON;
				}
				
			    public java.util.Date DATE_FIN_LIVRAISON;

				public java.util.Date getDATE_FIN_LIVRAISON () {
					return this.DATE_FIN_LIVRAISON;
				}
				
			    public BigDecimal NOMBRE_ARTICLE_LIVRES;

				public BigDecimal getNOMBRE_ARTICLE_LIVRES () {
					return this.NOMBRE_ARTICLE_LIVRES;
				}
				
			    public BigDecimal ID_LIVREUR;

				public BigDecimal getID_LIVREUR () {
					return this.ID_LIVREUR;
				}
				
			    public String NOM_LIVREUR;

				public String getNOM_LIVREUR () {
					return this.NOM_LIVREUR;
				}
				
			    public String PRENOM_LIVREUR;

				public String getPRENOM_LIVREUR () {
					return this.PRENOM_LIVREUR;
				}
				
			    public BigDecimal ID_MOYEN_LIVRAISON;

				public BigDecimal getID_MOYEN_LIVRAISON () {
					return this.ID_MOYEN_LIVRAISON;
				}
				
			    public String CODE_MOYEN_LIVRAISON;

				public String getCODE_MOYEN_LIVRAISON () {
					return this.CODE_MOYEN_LIVRAISON;
				}
				
			    public String LIBELLE_MOYEN_LIVRAISON;

				public String getLIBELLE_MOYEN_LIVRAISON () {
					return this.LIBELLE_MOYEN_LIVRAISON;
				}
				
			    public String NOM_CLIENT;

				public String getNOM_CLIENT () {
					return this.NOM_CLIENT;
				}
				
			    public String PRENOM_CLIENT;

				public String getPRENOM_CLIENT () {
					return this.PRENOM_CLIENT;
				}
				
			    public BigDecimal ID_PREPARATION;

				public BigDecimal getID_PREPARATION () {
					return this.ID_PREPARATION;
				}
				
			    public java.util.Date DATE_DEBUT_PREPARATION;

				public java.util.Date getDATE_DEBUT_PREPARATION () {
					return this.DATE_DEBUT_PREPARATION;
				}
				
			    public java.util.Date DATE_FIN_PREPARATION;

				public java.util.Date getDATE_FIN_PREPARATION () {
					return this.DATE_FIN_PREPARATION;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_DM2_A_ALIM_STAGING_DM2.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_DM2_A_ALIM_STAGING_DM2.length == 0) {
   					commonByteArray_ALIMENTATION_DM2_A_ALIM_STAGING_DM2 = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_DM2_A_ALIM_STAGING_DM2 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ALIMENTATION_DM2_A_ALIM_STAGING_DM2, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_DM2_A_ALIM_STAGING_DM2, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ALIMENTATION_DM2_A_ALIM_STAGING_DM2.length) {
				if(length < 1024 && commonByteArray_ALIMENTATION_DM2_A_ALIM_STAGING_DM2.length == 0) {
   					commonByteArray_ALIMENTATION_DM2_A_ALIM_STAGING_DM2 = new byte[1024];
				} else {
   					commonByteArray_ALIMENTATION_DM2_A_ALIM_STAGING_DM2 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ALIMENTATION_DM2_A_ALIM_STAGING_DM2, 0, length);
			strReturn = new String(commonByteArray_ALIMENTATION_DM2_A_ALIM_STAGING_DM2, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_DM2_A_ALIM_STAGING_DM2) {

        	try {

        		int length = 0;
		
						this.ID_ADRESSE_NORM_CLIENT = (BigDecimal) dis.readObject();
					
					this.NUMERO_VOIE = readString(dis);
					
					this.NOM_VOIE = readString(dis);
					
					this.CODE_POSTAL = readString(dis);
					
					this.NOM_VILLE = readString(dis);
					
					this.LONGITUDE = readString(dis);
					
					this.LATITUDE = readString(dis);
					
						this.ID_RESTAURANT = (BigDecimal) dis.readObject();
					
					this.CODE_RESTAURANT = readString(dis);
					
					this.RAISON_SOCIALE_RESTAURANT = readString(dis);
					
						this.ID_ADRESSE_CLIENT = (BigDecimal) dis.readObject();
					
					this.ADRESSE_CLIENT = readString(dis);
					
						this.ID_ADRESSE_RESTAURANT = (BigDecimal) dis.readObject();
					
					this.ADRESSE_RESTAURANT = readString(dis);
					
						this.ID_ADRESSE_NORM_RESTAURANT = (BigDecimal) dis.readObject();
					
					this.NUMERO_VOIE_RESTAU = readString(dis);
					
					this.NOM_VOIE_RESTAU = readString(dis);
					
					this.CODE_POSTAL_RESTAU = readString(dis);
					
					this.NOM_VILLE_RESTAU = readString(dis);
					
					this.LONGITUDE_RESTAU = readString(dis);
					
					this.LATITUDE_RESTAU = readString(dis);
					
						this.ID_CLIENT = (BigDecimal) dis.readObject();
					
						this.ID_LIVRAISON = (BigDecimal) dis.readObject();
					
						this.ID_COMMANDE = (BigDecimal) dis.readObject();
					
						this.NUMERO_COMMANDE = (BigDecimal) dis.readObject();
					
					this.DATE_COMMANDE = readDate(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.MONTANT_TOTAL = null;
           				} else {
           			    	this.MONTANT_TOTAL = dis.readFloat();
           				}
					
						this.ID_MENU = (BigDecimal) dis.readObject();
					
					this.CODE_MENU = readString(dis);
					
					this.LIBELLE_MENU = readString(dis);
					
						this.NOMBRE_ARTICLES = (BigDecimal) dis.readObject();
					
					this.TEMPS_THEO_PREPARATION = readString(dis);
					
						this.NUMERO_LIVRAISON = (BigDecimal) dis.readObject();
					
					this.DATE_DEBUT_LIVRAISON = readDate(dis);
					
					this.DATE_FIN_LIVRAISON = readDate(dis);
					
						this.NOMBRE_ARTICLE_LIVRES = (BigDecimal) dis.readObject();
					
						this.ID_LIVREUR = (BigDecimal) dis.readObject();
					
					this.NOM_LIVREUR = readString(dis);
					
					this.PRENOM_LIVREUR = readString(dis);
					
						this.ID_MOYEN_LIVRAISON = (BigDecimal) dis.readObject();
					
					this.CODE_MOYEN_LIVRAISON = readString(dis);
					
					this.LIBELLE_MOYEN_LIVRAISON = readString(dis);
					
					this.NOM_CLIENT = readString(dis);
					
					this.PRENOM_CLIENT = readString(dis);
					
						this.ID_PREPARATION = (BigDecimal) dis.readObject();
					
					this.DATE_DEBUT_PREPARATION = readDate(dis);
					
					this.DATE_FIN_PREPARATION = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ALIMENTATION_DM2_A_ALIM_STAGING_DM2) {

        	try {

        		int length = 0;
		
						this.ID_ADRESSE_NORM_CLIENT = (BigDecimal) dis.readObject();
					
					this.NUMERO_VOIE = readString(dis);
					
					this.NOM_VOIE = readString(dis);
					
					this.CODE_POSTAL = readString(dis);
					
					this.NOM_VILLE = readString(dis);
					
					this.LONGITUDE = readString(dis);
					
					this.LATITUDE = readString(dis);
					
						this.ID_RESTAURANT = (BigDecimal) dis.readObject();
					
					this.CODE_RESTAURANT = readString(dis);
					
					this.RAISON_SOCIALE_RESTAURANT = readString(dis);
					
						this.ID_ADRESSE_CLIENT = (BigDecimal) dis.readObject();
					
					this.ADRESSE_CLIENT = readString(dis);
					
						this.ID_ADRESSE_RESTAURANT = (BigDecimal) dis.readObject();
					
					this.ADRESSE_RESTAURANT = readString(dis);
					
						this.ID_ADRESSE_NORM_RESTAURANT = (BigDecimal) dis.readObject();
					
					this.NUMERO_VOIE_RESTAU = readString(dis);
					
					this.NOM_VOIE_RESTAU = readString(dis);
					
					this.CODE_POSTAL_RESTAU = readString(dis);
					
					this.NOM_VILLE_RESTAU = readString(dis);
					
					this.LONGITUDE_RESTAU = readString(dis);
					
					this.LATITUDE_RESTAU = readString(dis);
					
						this.ID_CLIENT = (BigDecimal) dis.readObject();
					
						this.ID_LIVRAISON = (BigDecimal) dis.readObject();
					
						this.ID_COMMANDE = (BigDecimal) dis.readObject();
					
						this.NUMERO_COMMANDE = (BigDecimal) dis.readObject();
					
					this.DATE_COMMANDE = readDate(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.MONTANT_TOTAL = null;
           				} else {
           			    	this.MONTANT_TOTAL = dis.readFloat();
           				}
					
						this.ID_MENU = (BigDecimal) dis.readObject();
					
					this.CODE_MENU = readString(dis);
					
					this.LIBELLE_MENU = readString(dis);
					
						this.NOMBRE_ARTICLES = (BigDecimal) dis.readObject();
					
					this.TEMPS_THEO_PREPARATION = readString(dis);
					
						this.NUMERO_LIVRAISON = (BigDecimal) dis.readObject();
					
					this.DATE_DEBUT_LIVRAISON = readDate(dis);
					
					this.DATE_FIN_LIVRAISON = readDate(dis);
					
						this.NOMBRE_ARTICLE_LIVRES = (BigDecimal) dis.readObject();
					
						this.ID_LIVREUR = (BigDecimal) dis.readObject();
					
					this.NOM_LIVREUR = readString(dis);
					
					this.PRENOM_LIVREUR = readString(dis);
					
						this.ID_MOYEN_LIVRAISON = (BigDecimal) dis.readObject();
					
					this.CODE_MOYEN_LIVRAISON = readString(dis);
					
					this.LIBELLE_MOYEN_LIVRAISON = readString(dis);
					
					this.NOM_CLIENT = readString(dis);
					
					this.PRENOM_CLIENT = readString(dis);
					
						this.ID_PREPARATION = (BigDecimal) dis.readObject();
					
					this.DATE_DEBUT_PREPARATION = readDate(dis);
					
					this.DATE_FIN_PREPARATION = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// BigDecimal
				
       			    	dos.writeObject(this.ID_ADRESSE_NORM_CLIENT);
					
					// String
				
						writeString(this.NUMERO_VOIE,dos);
					
					// String
				
						writeString(this.NOM_VOIE,dos);
					
					// String
				
						writeString(this.CODE_POSTAL,dos);
					
					// String
				
						writeString(this.NOM_VILLE,dos);
					
					// String
				
						writeString(this.LONGITUDE,dos);
					
					// String
				
						writeString(this.LATITUDE,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.ID_RESTAURANT);
					
					// String
				
						writeString(this.CODE_RESTAURANT,dos);
					
					// String
				
						writeString(this.RAISON_SOCIALE_RESTAURANT,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.ID_ADRESSE_CLIENT);
					
					// String
				
						writeString(this.ADRESSE_CLIENT,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.ID_ADRESSE_RESTAURANT);
					
					// String
				
						writeString(this.ADRESSE_RESTAURANT,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.ID_ADRESSE_NORM_RESTAURANT);
					
					// String
				
						writeString(this.NUMERO_VOIE_RESTAU,dos);
					
					// String
				
						writeString(this.NOM_VOIE_RESTAU,dos);
					
					// String
				
						writeString(this.CODE_POSTAL_RESTAU,dos);
					
					// String
				
						writeString(this.NOM_VILLE_RESTAU,dos);
					
					// String
				
						writeString(this.LONGITUDE_RESTAU,dos);
					
					// String
				
						writeString(this.LATITUDE_RESTAU,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.ID_CLIENT);
					
					// BigDecimal
				
       			    	dos.writeObject(this.ID_LIVRAISON);
					
					// BigDecimal
				
       			    	dos.writeObject(this.ID_COMMANDE);
					
					// BigDecimal
				
       			    	dos.writeObject(this.NUMERO_COMMANDE);
					
					// java.util.Date
				
						writeDate(this.DATE_COMMANDE,dos);
					
					// Float
				
						if(this.MONTANT_TOTAL == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.MONTANT_TOTAL);
		            	}
					
					// BigDecimal
				
       			    	dos.writeObject(this.ID_MENU);
					
					// String
				
						writeString(this.CODE_MENU,dos);
					
					// String
				
						writeString(this.LIBELLE_MENU,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.NOMBRE_ARTICLES);
					
					// String
				
						writeString(this.TEMPS_THEO_PREPARATION,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.NUMERO_LIVRAISON);
					
					// java.util.Date
				
						writeDate(this.DATE_DEBUT_LIVRAISON,dos);
					
					// java.util.Date
				
						writeDate(this.DATE_FIN_LIVRAISON,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.NOMBRE_ARTICLE_LIVRES);
					
					// BigDecimal
				
       			    	dos.writeObject(this.ID_LIVREUR);
					
					// String
				
						writeString(this.NOM_LIVREUR,dos);
					
					// String
				
						writeString(this.PRENOM_LIVREUR,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.ID_MOYEN_LIVRAISON);
					
					// String
				
						writeString(this.CODE_MOYEN_LIVRAISON,dos);
					
					// String
				
						writeString(this.LIBELLE_MOYEN_LIVRAISON,dos);
					
					// String
				
						writeString(this.NOM_CLIENT,dos);
					
					// String
				
						writeString(this.PRENOM_CLIENT,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.ID_PREPARATION);
					
					// java.util.Date
				
						writeDate(this.DATE_DEBUT_PREPARATION,dos);
					
					// java.util.Date
				
						writeDate(this.DATE_FIN_PREPARATION,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// BigDecimal
				
       			    	dos.writeObject(this.ID_ADRESSE_NORM_CLIENT);
					
					// String
				
						writeString(this.NUMERO_VOIE,dos);
					
					// String
				
						writeString(this.NOM_VOIE,dos);
					
					// String
				
						writeString(this.CODE_POSTAL,dos);
					
					// String
				
						writeString(this.NOM_VILLE,dos);
					
					// String
				
						writeString(this.LONGITUDE,dos);
					
					// String
				
						writeString(this.LATITUDE,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.ID_RESTAURANT);
					
					// String
				
						writeString(this.CODE_RESTAURANT,dos);
					
					// String
				
						writeString(this.RAISON_SOCIALE_RESTAURANT,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.ID_ADRESSE_CLIENT);
					
					// String
				
						writeString(this.ADRESSE_CLIENT,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.ID_ADRESSE_RESTAURANT);
					
					// String
				
						writeString(this.ADRESSE_RESTAURANT,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.ID_ADRESSE_NORM_RESTAURANT);
					
					// String
				
						writeString(this.NUMERO_VOIE_RESTAU,dos);
					
					// String
				
						writeString(this.NOM_VOIE_RESTAU,dos);
					
					// String
				
						writeString(this.CODE_POSTAL_RESTAU,dos);
					
					// String
				
						writeString(this.NOM_VILLE_RESTAU,dos);
					
					// String
				
						writeString(this.LONGITUDE_RESTAU,dos);
					
					// String
				
						writeString(this.LATITUDE_RESTAU,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.ID_CLIENT);
					
					// BigDecimal
				
       			    	dos.writeObject(this.ID_LIVRAISON);
					
					// BigDecimal
				
       			    	dos.writeObject(this.ID_COMMANDE);
					
					// BigDecimal
				
       			    	dos.writeObject(this.NUMERO_COMMANDE);
					
					// java.util.Date
				
						writeDate(this.DATE_COMMANDE,dos);
					
					// Float
				
						if(this.MONTANT_TOTAL == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.MONTANT_TOTAL);
		            	}
					
					// BigDecimal
				
       			    	dos.writeObject(this.ID_MENU);
					
					// String
				
						writeString(this.CODE_MENU,dos);
					
					// String
				
						writeString(this.LIBELLE_MENU,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.NOMBRE_ARTICLES);
					
					// String
				
						writeString(this.TEMPS_THEO_PREPARATION,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.NUMERO_LIVRAISON);
					
					// java.util.Date
				
						writeDate(this.DATE_DEBUT_LIVRAISON,dos);
					
					// java.util.Date
				
						writeDate(this.DATE_FIN_LIVRAISON,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.NOMBRE_ARTICLE_LIVRES);
					
					// BigDecimal
				
       			    	dos.writeObject(this.ID_LIVREUR);
					
					// String
				
						writeString(this.NOM_LIVREUR,dos);
					
					// String
				
						writeString(this.PRENOM_LIVREUR,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.ID_MOYEN_LIVRAISON);
					
					// String
				
						writeString(this.CODE_MOYEN_LIVRAISON,dos);
					
					// String
				
						writeString(this.LIBELLE_MOYEN_LIVRAISON,dos);
					
					// String
				
						writeString(this.NOM_CLIENT,dos);
					
					// String
				
						writeString(this.PRENOM_CLIENT,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.ID_PREPARATION);
					
					// java.util.Date
				
						writeDate(this.DATE_DEBUT_PREPARATION,dos);
					
					// java.util.Date
				
						writeDate(this.DATE_FIN_PREPARATION,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("ID_ADRESSE_NORM_CLIENT="+String.valueOf(ID_ADRESSE_NORM_CLIENT));
		sb.append(",NUMERO_VOIE="+NUMERO_VOIE);
		sb.append(",NOM_VOIE="+NOM_VOIE);
		sb.append(",CODE_POSTAL="+CODE_POSTAL);
		sb.append(",NOM_VILLE="+NOM_VILLE);
		sb.append(",LONGITUDE="+LONGITUDE);
		sb.append(",LATITUDE="+LATITUDE);
		sb.append(",ID_RESTAURANT="+String.valueOf(ID_RESTAURANT));
		sb.append(",CODE_RESTAURANT="+CODE_RESTAURANT);
		sb.append(",RAISON_SOCIALE_RESTAURANT="+RAISON_SOCIALE_RESTAURANT);
		sb.append(",ID_ADRESSE_CLIENT="+String.valueOf(ID_ADRESSE_CLIENT));
		sb.append(",ADRESSE_CLIENT="+ADRESSE_CLIENT);
		sb.append(",ID_ADRESSE_RESTAURANT="+String.valueOf(ID_ADRESSE_RESTAURANT));
		sb.append(",ADRESSE_RESTAURANT="+ADRESSE_RESTAURANT);
		sb.append(",ID_ADRESSE_NORM_RESTAURANT="+String.valueOf(ID_ADRESSE_NORM_RESTAURANT));
		sb.append(",NUMERO_VOIE_RESTAU="+NUMERO_VOIE_RESTAU);
		sb.append(",NOM_VOIE_RESTAU="+NOM_VOIE_RESTAU);
		sb.append(",CODE_POSTAL_RESTAU="+CODE_POSTAL_RESTAU);
		sb.append(",NOM_VILLE_RESTAU="+NOM_VILLE_RESTAU);
		sb.append(",LONGITUDE_RESTAU="+LONGITUDE_RESTAU);
		sb.append(",LATITUDE_RESTAU="+LATITUDE_RESTAU);
		sb.append(",ID_CLIENT="+String.valueOf(ID_CLIENT));
		sb.append(",ID_LIVRAISON="+String.valueOf(ID_LIVRAISON));
		sb.append(",ID_COMMANDE="+String.valueOf(ID_COMMANDE));
		sb.append(",NUMERO_COMMANDE="+String.valueOf(NUMERO_COMMANDE));
		sb.append(",DATE_COMMANDE="+String.valueOf(DATE_COMMANDE));
		sb.append(",MONTANT_TOTAL="+String.valueOf(MONTANT_TOTAL));
		sb.append(",ID_MENU="+String.valueOf(ID_MENU));
		sb.append(",CODE_MENU="+CODE_MENU);
		sb.append(",LIBELLE_MENU="+LIBELLE_MENU);
		sb.append(",NOMBRE_ARTICLES="+String.valueOf(NOMBRE_ARTICLES));
		sb.append(",TEMPS_THEO_PREPARATION="+TEMPS_THEO_PREPARATION);
		sb.append(",NUMERO_LIVRAISON="+String.valueOf(NUMERO_LIVRAISON));
		sb.append(",DATE_DEBUT_LIVRAISON="+String.valueOf(DATE_DEBUT_LIVRAISON));
		sb.append(",DATE_FIN_LIVRAISON="+String.valueOf(DATE_FIN_LIVRAISON));
		sb.append(",NOMBRE_ARTICLE_LIVRES="+String.valueOf(NOMBRE_ARTICLE_LIVRES));
		sb.append(",ID_LIVREUR="+String.valueOf(ID_LIVREUR));
		sb.append(",NOM_LIVREUR="+NOM_LIVREUR);
		sb.append(",PRENOM_LIVREUR="+PRENOM_LIVREUR);
		sb.append(",ID_MOYEN_LIVRAISON="+String.valueOf(ID_MOYEN_LIVRAISON));
		sb.append(",CODE_MOYEN_LIVRAISON="+CODE_MOYEN_LIVRAISON);
		sb.append(",LIBELLE_MOYEN_LIVRAISON="+LIBELLE_MOYEN_LIVRAISON);
		sb.append(",NOM_CLIENT="+NOM_CLIENT);
		sb.append(",PRENOM_CLIENT="+PRENOM_CLIENT);
		sb.append(",ID_PREPARATION="+String.valueOf(ID_PREPARATION));
		sb.append(",DATE_DEBUT_PREPARATION="+String.valueOf(DATE_DEBUT_PREPARATION));
		sb.append(",DATE_FIN_PREPARATION="+String.valueOf(DATE_FIN_PREPARATION));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row2Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tDBInput_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBInput_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row2Struct row2 = new row2Struct();
ALIM_STAGINGStruct ALIM_STAGING = new ALIM_STAGINGStruct();
row3Struct row3 = new row3Struct();






	
	/**
	 * [tFileArchive_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileArchive_1", false);
		start_Hash.put("tFileArchive_1", System.currentTimeMillis());
		
				tStatCatcher_1.addMessage("begin","tFileArchive_1");
				tStatCatcher_1Process(globalMap);
			
	
	currentComponent="tFileArchive_1";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row3");
					}
				
		int tos_count_tFileArchive_1 = 0;
		

 



/**
 * [tFileArchive_1 begin ] stop
 */



	
	/**
	 * [tDBOutput_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_2", false);
		start_Hash.put("tDBOutput_2", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_2";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"ALIM_STAGING");
					}
				
		int tos_count_tDBOutput_2 = 0;
		





String dbschema_tDBOutput_2 = null;
	dbschema_tDBOutput_2 = "dsid_liv_wrk";
	

String tableName_tDBOutput_2 = null;
if(dbschema_tDBOutput_2 == null || dbschema_tDBOutput_2.trim().length() == 0) {
	tableName_tDBOutput_2 = ("dm2_staging");
} else {
	tableName_tDBOutput_2 = dbschema_tDBOutput_2 + "\".\"" + ("dm2_staging");
}


int nb_line_tDBOutput_2 = 0;
int nb_line_update_tDBOutput_2 = 0;
int nb_line_inserted_tDBOutput_2 = 0;
int nb_line_deleted_tDBOutput_2 = 0;
int nb_line_rejected_tDBOutput_2 = 0;

int deletedCount_tDBOutput_2=0;
int updatedCount_tDBOutput_2=0;
int insertedCount_tDBOutput_2=0;
int rowsToCommitCount_tDBOutput_2=0;
int rejectedCount_tDBOutput_2=0;

boolean whetherReject_tDBOutput_2 = false;

java.sql.Connection conn_tDBOutput_2 = null;
String dbUser_tDBOutput_2 = null;

	
    java.lang.Class.forName("org.postgresql.Driver");
    
        String url_tDBOutput_2 = "jdbc:postgresql://"+"localhost"+":"+"5432"+"/"+"postgres";
    dbUser_tDBOutput_2 = "dsid_cc2_tos_rw";
 
	final String decryptedPassword_tDBOutput_2 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:4vIepml82wQ6jLU/MECVlxVI/HJJEivoSDTL5pKlBs0=");

    String dbPwd_tDBOutput_2 = decryptedPassword_tDBOutput_2;

    conn_tDBOutput_2 = java.sql.DriverManager.getConnection(url_tDBOutput_2,dbUser_tDBOutput_2,dbPwd_tDBOutput_2);
	
	resourceMap.put("conn_tDBOutput_2", conn_tDBOutput_2);
        conn_tDBOutput_2.setAutoCommit(false);
        int commitEvery_tDBOutput_2 = 10000;
        int commitCounter_tDBOutput_2 = 0;


   int batchSize_tDBOutput_2 = 10000;
   int batchSizeCounter_tDBOutput_2=0;

int count_tDBOutput_2=0;
            int rsTruncCountNumber_tDBOutput_2 = 0;
            try(java.sql.Statement stmtTruncCount_tDBOutput_2 = conn_tDBOutput_2.createStatement()) {
                try (java.sql.ResultSet rsTruncCount_tDBOutput_2 = stmtTruncCount_tDBOutput_2.executeQuery("SELECT COUNT(1) FROM \"" + tableName_tDBOutput_2 + "\"")) {
                    if(rsTruncCount_tDBOutput_2.next()) {
                        rsTruncCountNumber_tDBOutput_2 = rsTruncCount_tDBOutput_2.getInt(1);
                    }
                }
            }
            try (java.sql.Statement stmtTrunc_tDBOutput_2 = conn_tDBOutput_2.createStatement()) {
                stmtTrunc_tDBOutput_2.executeUpdate("TRUNCATE TABLE \"" + tableName_tDBOutput_2 + "\"");
                deletedCount_tDBOutput_2 += rsTruncCountNumber_tDBOutput_2;
            }
	    String insert_tDBOutput_2 = "INSERT INTO \"" + tableName_tDBOutput_2 + "\" (\"" + "id_staging_dm2" + "\",\"id_adresse_norm_client\",\"numero_voie\",\"nom_voie\",\"code_postal\",\"nom_ville\",\"longitude\",\"latitude\",\"id_restaurant\",\"code_restaurant\",\"raison_sociale_restaurant\",\"id_adresse_norm_restaurant\",\"numero_voie_restau\",\"nom_voie_restau\",\"code_postal_restau\",\"nom_ville_restau\",\"longitude_restau\",\"latitude_restau\",\"id_client\",\"id_livraison\",\"id_commande\",\"numero_commande\",\"date_commande\",\"montant_total\",\"id_menu\",\"code_menu\",\"libelle_menu\",\"nombre_articles\",\"temps_theo_preparation\",\"numero_livraison\",\"date_debut_livraison\",\"date_fin_livraison\",\"id_livreur\",\"nom_livreur\",\"prenom_livreur\",\"id_moyen_livraison\",\"code_moyen_livraison\",\"libelle_moyen_livraison\",\"nom_client\",\"prenom_client\",\"id_preparation\",\"date_debut_preparation\",\"date_fin_preparation\",\"nombre_article_livres\") VALUES (" + "nextval('dsid_liv_wrk.seq_id_staging_dm2')" + ",?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
	    
	    java.sql.PreparedStatement pstmt_tDBOutput_2 = conn_tDBOutput_2.prepareStatement(insert_tDBOutput_2);
	    resourceMap.put("pstmt_tDBOutput_2", pstmt_tDBOutput_2);
	    

 



/**
 * [tDBOutput_2 begin ] stop
 */



	
	/**
	 * [tMap_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tMap_1", false);
		start_Hash.put("tMap_1", System.currentTimeMillis());
		
				tStatCatcher_1.addMessage("begin","tMap_1");
				tStatCatcher_1Process(globalMap);
			
	
	currentComponent="tMap_1";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row2");
					}
				
		int tos_count_tMap_1 = 0;
		




// ###############################
// # Lookup's keys initialization
// ###############################        

// ###############################
// # Vars initialization
class  Var__tMap_1__Struct  {
}
Var__tMap_1__Struct Var__tMap_1 = new Var__tMap_1__Struct();
// ###############################

// ###############################
// # Outputs initialization
ALIM_STAGINGStruct ALIM_STAGING_tmp = new ALIM_STAGINGStruct();
// ###############################

        
        



        









 



/**
 * [tMap_1 begin ] stop
 */



	
	/**
	 * [tDBInput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBInput_1", false);
		start_Hash.put("tDBInput_1", System.currentTimeMillis());
		
				tStatCatcher_1.addMessage("begin","tDBInput_1");
				tStatCatcher_1Process(globalMap);
			
	
	currentComponent="tDBInput_1";

	
		int tos_count_tDBInput_1 = 0;
		
	


	
		    int nb_line_tDBInput_1 = 0;
		    java.sql.Connection conn_tDBInput_1 = null;
				String driverClass_tDBInput_1 = "oracle.jdbc.OracleDriver";
				java.lang.Class.forName(driverClass_tDBInput_1);
				
			String url_tDBInput_1 = null;
				url_tDBInput_1 = "jdbc:oracle:thin:@(description=(address=(protocol=tcp)(host=" + "" + ")(port=" + "1521" + "))(connect_data=(service_name=" + "XEPDB1" + ")))";

				String dbUser_tDBInput_1 = "DSID_LIV_OPE";

				

				 
	final String decryptedPassword_tDBInput_1 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:nkVtzMWuglPql/SwYRn5oUdAFGgjiX1pgQZIJ6bubZ0=");

				String dbPwd_tDBInput_1 = decryptedPassword_tDBInput_1;

				
					conn_tDBInput_1 = java.sql.DriverManager.getConnection(url_tDBInput_1,dbUser_tDBInput_1,dbPwd_tDBInput_1);
				java.sql.Statement stmtGetTZ_tDBInput_1 = conn_tDBInput_1.createStatement();
				java.sql.ResultSet rsGetTZ_tDBInput_1 = stmtGetTZ_tDBInput_1.executeQuery("select sessiontimezone from dual");
				String sessionTimezone_tDBInput_1 = java.util.TimeZone.getDefault().getID();
				while (rsGetTZ_tDBInput_1.next()) {
					sessionTimezone_tDBInput_1 = rsGetTZ_tDBInput_1.getString(1);
				}
                                if (!(conn_tDBInput_1 instanceof oracle.jdbc.OracleConnection) &&
                                        conn_tDBInput_1.isWrapperFor(oracle.jdbc.OracleConnection.class)) {
                                    if (conn_tDBInput_1.unwrap(oracle.jdbc.OracleConnection.class) != null) {
                                        ((oracle.jdbc.OracleConnection)conn_tDBInput_1.unwrap(oracle.jdbc.OracleConnection.class)).setSessionTimeZone(sessionTimezone_tDBInput_1);
                                    }
                                } else {
                                    ((oracle.jdbc.OracleConnection)conn_tDBInput_1).setSessionTimeZone(sessionTimezone_tDBInput_1);
                                }
		    
			java.sql.Statement stmt_tDBInput_1 = conn_tDBInput_1.createStatement();

		    String dbquery_tDBInput_1 = "SELECT \n  DSID_LIV_OPE.VUE_DM2.ID_ADRESSE_NORM_CLIENT, \n  DSID_LIV_OPE.VUE_DM2.NUMERO_VOIE, \n  DSID_LIV_OPE.VUE_DM2.NOM"
+"_VOIE, \n  DSID_LIV_OPE.VUE_DM2.CODE_POSTAL, \n  DSID_LIV_OPE.VUE_DM2.NOM_VILLE, \n  DSID_LIV_OPE.VUE_DM2.LONGITUDE, \n  DSI"
+"D_LIV_OPE.VUE_DM2.LATITUDE, \n  DSID_LIV_OPE.VUE_DM2.ID_RESTAURANT, \n  DSID_LIV_OPE.VUE_DM2.CODE_RESTAURANT, \n  DSID_LIV_"
+"OPE.VUE_DM2.RAISON_SOCIALE_RESTAURANT, \n  DSID_LIV_OPE.VUE_DM2.ID_ADRESSE_CLIENT, \n  DSID_LIV_OPE.VUE_DM2.ADRESSE_CLIENT"
+", \n  DSID_LIV_OPE.VUE_DM2.ID_ADRESSE_RESTAURANT, \n  DSID_LIV_OPE.VUE_DM2.ADRESSE_RESTAURANT, \n  DSID_LIV_OPE.VUE_DM2.ID_"
+"ADRESSE_NORM_RESTAURANT, \n  DSID_LIV_OPE.VUE_DM2.NUMERO_VOIE_RESTAU, \n  DSID_LIV_OPE.VUE_DM2.NOM_VOIE_RESTAU, \n  DSID_LI"
+"V_OPE.VUE_DM2.CODE_POSTAL_RESTAU, \n  DSID_LIV_OPE.VUE_DM2.NOM_VILLE_RESTAU, \n  DSID_LIV_OPE.VUE_DM2.LONGITUDE_RESTAU, \n "
+" DSID_LIV_OPE.VUE_DM2.LATITUDE_RESTAU, \n  DSID_LIV_OPE.VUE_DM2.ID_CLIENT, \n  DSID_LIV_OPE.VUE_DM2.ID_LIVRAISON, \n  DSID_"
+"LIV_OPE.VUE_DM2.ID_COMMANDE, \n  DSID_LIV_OPE.VUE_DM2.NUMERO_COMMANDE, \n  DSID_LIV_OPE.VUE_DM2.DATE_COMMANDE, \n  DSID_LIV"
+"_OPE.VUE_DM2.MONTANT_TOTAL, \n  DSID_LIV_OPE.VUE_DM2.ID_MENU, \n  DSID_LIV_OPE.VUE_DM2.CODE_MENU, \n  DSID_LIV_OPE.VUE_DM2."
+"LIBELLE_MENU, \n  DSID_LIV_OPE.VUE_DM2.NOMBRE_ARTICLES, \n  DSID_LIV_OPE.VUE_DM2.TEMPS_THEO_PREPARATION, \n  DSID_LIV_OPE.V"
+"UE_DM2.NUMERO_LIVRAISON, \n  DSID_LIV_OPE.VUE_DM2.DATE_DEBUT_LIVRAISON, \n  DSID_LIV_OPE.VUE_DM2.DATE_FIN_LIVRAISON, \n  DS"
+"ID_LIV_OPE.VUE_DM2.NOMBRE_ARTICLE_LIVRES, \n  DSID_LIV_OPE.VUE_DM2.ID_LIVREUR, \n  DSID_LIV_OPE.VUE_DM2.NOM_LIVREUR, \n  DS"
+"ID_LIV_OPE.VUE_DM2.PRENOM_LIVREUR, \n  DSID_LIV_OPE.VUE_DM2.ID_MOYEN_LIVRAISON, \n  DSID_LIV_OPE.VUE_DM2.CODE_MOYEN_LIVRAI"
+"SON, \n  DSID_LIV_OPE.VUE_DM2.LIBELLE_MOYEN_LIVRAISON, \n  DSID_LIV_OPE.VUE_DM2.NOM_CLIENT, \n  DSID_LIV_OPE.VUE_DM2.PRENOM"
+"_CLIENT, \n  DSID_LIV_OPE.VUE_DM2.ID_PREPARATION, \n  DSID_LIV_OPE.VUE_DM2.DATE_DEBUT_PREPARATION, \n  DSID_LIV_OPE.VUE_DM2"
+".DATE_FIN_PREPARATION\nFROM DSID_LIV_OPE.VUE_DM2";
		    

            	globalMap.put("tDBInput_1_QUERY",dbquery_tDBInput_1);
		    java.sql.ResultSet rs_tDBInput_1 = null;

		    try {
		    	rs_tDBInput_1 = stmt_tDBInput_1.executeQuery(dbquery_tDBInput_1);
		    	java.sql.ResultSetMetaData rsmd_tDBInput_1 = rs_tDBInput_1.getMetaData();
		    	int colQtyInRs_tDBInput_1 = rsmd_tDBInput_1.getColumnCount();

		    String tmpContent_tDBInput_1 = null;
		    
		    
		    while (rs_tDBInput_1.next()) {
		        nb_line_tDBInput_1++;
		        
							if(colQtyInRs_tDBInput_1 < 1) {
								row2.ID_ADRESSE_NORM_CLIENT = null;
							} else {
		                          
					if(rs_tDBInput_1.getObject(1) != null) {
						row2.ID_ADRESSE_NORM_CLIENT = rs_tDBInput_1.getBigDecimal(1);
					} else {
				
 	                	throw new RuntimeException("Null value in non-Nullable column");
					}
		                    }
							if(colQtyInRs_tDBInput_1 < 2) {
								row2.NUMERO_VOIE = null;
							} else {
	                         		
        	row2.NUMERO_VOIE = routines.system.JDBCUtil.getString(rs_tDBInput_1, 2, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 3) {
								row2.NOM_VOIE = null;
							} else {
	                         		
        	row2.NOM_VOIE = routines.system.JDBCUtil.getString(rs_tDBInput_1, 3, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 4) {
								row2.CODE_POSTAL = null;
							} else {
	                         		
        	row2.CODE_POSTAL = routines.system.JDBCUtil.getString(rs_tDBInput_1, 4, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 5) {
								row2.NOM_VILLE = null;
							} else {
	                         		
        	row2.NOM_VILLE = routines.system.JDBCUtil.getString(rs_tDBInput_1, 5, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 6) {
								row2.LONGITUDE = null;
							} else {
	                         		
        	row2.LONGITUDE = routines.system.JDBCUtil.getString(rs_tDBInput_1, 6, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 7) {
								row2.LATITUDE = null;
							} else {
	                         		
        	row2.LATITUDE = routines.system.JDBCUtil.getString(rs_tDBInput_1, 7, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 8) {
								row2.ID_RESTAURANT = null;
							} else {
		                          
					if(rs_tDBInput_1.getObject(8) != null) {
						row2.ID_RESTAURANT = rs_tDBInput_1.getBigDecimal(8);
					} else {
				
 	                	throw new RuntimeException("Null value in non-Nullable column");
					}
		                    }
							if(colQtyInRs_tDBInput_1 < 9) {
								row2.CODE_RESTAURANT = null;
							} else {
	                         		
        	row2.CODE_RESTAURANT = routines.system.JDBCUtil.getString(rs_tDBInput_1, 9, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 10) {
								row2.RAISON_SOCIALE_RESTAURANT = null;
							} else {
	                         		
        	row2.RAISON_SOCIALE_RESTAURANT = routines.system.JDBCUtil.getString(rs_tDBInput_1, 10, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 11) {
								row2.ID_ADRESSE_CLIENT = null;
							} else {
		                          
					if(rs_tDBInput_1.getObject(11) != null) {
						row2.ID_ADRESSE_CLIENT = rs_tDBInput_1.getBigDecimal(11);
					} else {
				
 	                	throw new RuntimeException("Null value in non-Nullable column");
					}
		                    }
							if(colQtyInRs_tDBInput_1 < 12) {
								row2.ADRESSE_CLIENT = null;
							} else {
	                         		
        	row2.ADRESSE_CLIENT = routines.system.JDBCUtil.getString(rs_tDBInput_1, 12, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 13) {
								row2.ID_ADRESSE_RESTAURANT = null;
							} else {
		                          
					if(rs_tDBInput_1.getObject(13) != null) {
						row2.ID_ADRESSE_RESTAURANT = rs_tDBInput_1.getBigDecimal(13);
					} else {
				
 	                	throw new RuntimeException("Null value in non-Nullable column");
					}
		                    }
							if(colQtyInRs_tDBInput_1 < 14) {
								row2.ADRESSE_RESTAURANT = null;
							} else {
	                         		
        	row2.ADRESSE_RESTAURANT = routines.system.JDBCUtil.getString(rs_tDBInput_1, 14, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 15) {
								row2.ID_ADRESSE_NORM_RESTAURANT = null;
							} else {
		                          
					if(rs_tDBInput_1.getObject(15) != null) {
						row2.ID_ADRESSE_NORM_RESTAURANT = rs_tDBInput_1.getBigDecimal(15);
					} else {
				
 	                	throw new RuntimeException("Null value in non-Nullable column");
					}
		                    }
							if(colQtyInRs_tDBInput_1 < 16) {
								row2.NUMERO_VOIE_RESTAU = null;
							} else {
	                         		
        	row2.NUMERO_VOIE_RESTAU = routines.system.JDBCUtil.getString(rs_tDBInput_1, 16, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 17) {
								row2.NOM_VOIE_RESTAU = null;
							} else {
	                         		
        	row2.NOM_VOIE_RESTAU = routines.system.JDBCUtil.getString(rs_tDBInput_1, 17, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 18) {
								row2.CODE_POSTAL_RESTAU = null;
							} else {
	                         		
        	row2.CODE_POSTAL_RESTAU = routines.system.JDBCUtil.getString(rs_tDBInput_1, 18, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 19) {
								row2.NOM_VILLE_RESTAU = null;
							} else {
	                         		
        	row2.NOM_VILLE_RESTAU = routines.system.JDBCUtil.getString(rs_tDBInput_1, 19, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 20) {
								row2.LONGITUDE_RESTAU = null;
							} else {
	                         		
        	row2.LONGITUDE_RESTAU = routines.system.JDBCUtil.getString(rs_tDBInput_1, 20, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 21) {
								row2.LATITUDE_RESTAU = null;
							} else {
	                         		
        	row2.LATITUDE_RESTAU = routines.system.JDBCUtil.getString(rs_tDBInput_1, 21, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 22) {
								row2.ID_CLIENT = null;
							} else {
		                          
					if(rs_tDBInput_1.getObject(22) != null) {
						row2.ID_CLIENT = rs_tDBInput_1.getBigDecimal(22);
					} else {
				
 	                	throw new RuntimeException("Null value in non-Nullable column");
					}
		                    }
							if(colQtyInRs_tDBInput_1 < 23) {
								row2.ID_LIVRAISON = null;
							} else {
		                          
					if(rs_tDBInput_1.getObject(23) != null) {
						row2.ID_LIVRAISON = rs_tDBInput_1.getBigDecimal(23);
					} else {
				
 	                	throw new RuntimeException("Null value in non-Nullable column");
					}
		                    }
							if(colQtyInRs_tDBInput_1 < 24) {
								row2.ID_COMMANDE = null;
							} else {
		                          
					if(rs_tDBInput_1.getObject(24) != null) {
						row2.ID_COMMANDE = rs_tDBInput_1.getBigDecimal(24);
					} else {
				
 	                	throw new RuntimeException("Null value in non-Nullable column");
					}
		                    }
							if(colQtyInRs_tDBInput_1 < 25) {
								row2.NUMERO_COMMANDE = null;
							} else {
		                          
					if(rs_tDBInput_1.getObject(25) != null) {
						row2.NUMERO_COMMANDE = rs_tDBInput_1.getBigDecimal(25);
					} else {
				
						row2.NUMERO_COMMANDE = null;
					}
		                    }
							if(colQtyInRs_tDBInput_1 < 26) {
								row2.DATE_COMMANDE = null;
							} else {
										
			row2.DATE_COMMANDE = routines.system.JDBCUtil.getDate(rs_tDBInput_1, 26);
		                    }
							if(colQtyInRs_tDBInput_1 < 27) {
								row2.MONTANT_TOTAL = null;
							} else {
		                          
					if(rs_tDBInput_1.getObject(27) != null) {
						row2.MONTANT_TOTAL = rs_tDBInput_1.getFloat(27);
					} else {
				
						row2.MONTANT_TOTAL = null;
					}
		                    }
							if(colQtyInRs_tDBInput_1 < 28) {
								row2.ID_MENU = null;
							} else {
		                          
					if(rs_tDBInput_1.getObject(28) != null) {
						row2.ID_MENU = rs_tDBInput_1.getBigDecimal(28);
					} else {
				
 	                	throw new RuntimeException("Null value in non-Nullable column");
					}
		                    }
							if(colQtyInRs_tDBInput_1 < 29) {
								row2.CODE_MENU = null;
							} else {
	                         		
        	row2.CODE_MENU = routines.system.JDBCUtil.getString(rs_tDBInput_1, 29, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 30) {
								row2.LIBELLE_MENU = null;
							} else {
	                         		
        	row2.LIBELLE_MENU = routines.system.JDBCUtil.getString(rs_tDBInput_1, 30, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 31) {
								row2.NOMBRE_ARTICLES = null;
							} else {
		                          
					if(rs_tDBInput_1.getObject(31) != null) {
						row2.NOMBRE_ARTICLES = rs_tDBInput_1.getBigDecimal(31);
					} else {
				
						row2.NOMBRE_ARTICLES = null;
					}
		                    }
							if(colQtyInRs_tDBInput_1 < 32) {
								row2.TEMPS_THEO_PREPARATION = null;
							} else {
	                         		
        	row2.TEMPS_THEO_PREPARATION = routines.system.JDBCUtil.getString(rs_tDBInput_1, 32, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 33) {
								row2.NUMERO_LIVRAISON = null;
							} else {
		                          
					if(rs_tDBInput_1.getObject(33) != null) {
						row2.NUMERO_LIVRAISON = rs_tDBInput_1.getBigDecimal(33);
					} else {
				
						row2.NUMERO_LIVRAISON = null;
					}
		                    }
							if(colQtyInRs_tDBInput_1 < 34) {
								row2.DATE_DEBUT_LIVRAISON = null;
							} else {
										
			row2.DATE_DEBUT_LIVRAISON = routines.system.JDBCUtil.getDate(rs_tDBInput_1, 34);
		                    }
							if(colQtyInRs_tDBInput_1 < 35) {
								row2.DATE_FIN_LIVRAISON = null;
							} else {
										
			row2.DATE_FIN_LIVRAISON = routines.system.JDBCUtil.getDate(rs_tDBInput_1, 35);
		                    }
							if(colQtyInRs_tDBInput_1 < 36) {
								row2.NOMBRE_ARTICLE_LIVRES = null;
							} else {
		                          
					if(rs_tDBInput_1.getObject(36) != null) {
						row2.NOMBRE_ARTICLE_LIVRES = rs_tDBInput_1.getBigDecimal(36);
					} else {
				
						row2.NOMBRE_ARTICLE_LIVRES = null;
					}
		                    }
							if(colQtyInRs_tDBInput_1 < 37) {
								row2.ID_LIVREUR = null;
							} else {
		                          
					if(rs_tDBInput_1.getObject(37) != null) {
						row2.ID_LIVREUR = rs_tDBInput_1.getBigDecimal(37);
					} else {
				
 	                	throw new RuntimeException("Null value in non-Nullable column");
					}
		                    }
							if(colQtyInRs_tDBInput_1 < 38) {
								row2.NOM_LIVREUR = null;
							} else {
	                         		
        	row2.NOM_LIVREUR = routines.system.JDBCUtil.getString(rs_tDBInput_1, 38, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 39) {
								row2.PRENOM_LIVREUR = null;
							} else {
	                         		
        	row2.PRENOM_LIVREUR = routines.system.JDBCUtil.getString(rs_tDBInput_1, 39, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 40) {
								row2.ID_MOYEN_LIVRAISON = null;
							} else {
		                          
					if(rs_tDBInput_1.getObject(40) != null) {
						row2.ID_MOYEN_LIVRAISON = rs_tDBInput_1.getBigDecimal(40);
					} else {
				
 	                	throw new RuntimeException("Null value in non-Nullable column");
					}
		                    }
							if(colQtyInRs_tDBInput_1 < 41) {
								row2.CODE_MOYEN_LIVRAISON = null;
							} else {
	                         		
        	row2.CODE_MOYEN_LIVRAISON = routines.system.JDBCUtil.getString(rs_tDBInput_1, 41, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 42) {
								row2.LIBELLE_MOYEN_LIVRAISON = null;
							} else {
	                         		
        	row2.LIBELLE_MOYEN_LIVRAISON = routines.system.JDBCUtil.getString(rs_tDBInput_1, 42, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 43) {
								row2.NOM_CLIENT = null;
							} else {
	                         		
        	row2.NOM_CLIENT = routines.system.JDBCUtil.getString(rs_tDBInput_1, 43, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 44) {
								row2.PRENOM_CLIENT = null;
							} else {
	                         		
        	row2.PRENOM_CLIENT = routines.system.JDBCUtil.getString(rs_tDBInput_1, 44, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 45) {
								row2.ID_PREPARATION = null;
							} else {
		                          
					if(rs_tDBInput_1.getObject(45) != null) {
						row2.ID_PREPARATION = rs_tDBInput_1.getBigDecimal(45);
					} else {
				
 	                	throw new RuntimeException("Null value in non-Nullable column");
					}
		                    }
							if(colQtyInRs_tDBInput_1 < 46) {
								row2.DATE_DEBUT_PREPARATION = null;
							} else {
										
			row2.DATE_DEBUT_PREPARATION = routines.system.JDBCUtil.getDate(rs_tDBInput_1, 46);
		                    }
							if(colQtyInRs_tDBInput_1 < 47) {
								row2.DATE_FIN_PREPARATION = null;
							} else {
										
			row2.DATE_FIN_PREPARATION = routines.system.JDBCUtil.getDate(rs_tDBInput_1, 47);
		                    }
					




 



/**
 * [tDBInput_1 begin ] stop
 */
	
	/**
	 * [tDBInput_1 main ] start
	 */

	

	
	
	currentComponent="tDBInput_1";

	

 


	tos_count_tDBInput_1++;

/**
 * [tDBInput_1 main ] stop
 */
	
	/**
	 * [tDBInput_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBInput_1";

	

 



/**
 * [tDBInput_1 process_data_begin ] stop
 */

	
	/**
	 * [tMap_1 main ] start
	 */

	

	
	
	currentComponent="tMap_1";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row2"
						
						);
					}
					

		
		
		boolean hasCasePrimitiveKeyWithNull_tMap_1 = false;
		

        // ###############################
        // # Input tables (lookups)
		  boolean rejectedInnerJoin_tMap_1 = false;
		  boolean mainRowRejected_tMap_1 = false;
            				    								  
		// ###############################
        { // start of Var scope
        
	        // ###############################
        	// # Vars tables
        
Var__tMap_1__Struct Var = Var__tMap_1;// ###############################
        // ###############################
        // # Output tables

ALIM_STAGING = null;


// # Output table : 'ALIM_STAGING'
ALIM_STAGING_tmp.id_staging_dm2 = 0;
ALIM_STAGING_tmp.id_adresse_norm_client = row2.ID_ADRESSE_NORM_CLIENT.intValue() ;
ALIM_STAGING_tmp.numero_voie = row2.NUMERO_VOIE;
ALIM_STAGING_tmp.nom_voie = row2.NOM_VOIE;
ALIM_STAGING_tmp.code_postal = row2.CODE_POSTAL;
ALIM_STAGING_tmp.nom_ville = row2.NOM_VILLE;
ALIM_STAGING_tmp.longitude = row2.LONGITUDE;
ALIM_STAGING_tmp.latitude = row2.LATITUDE;
ALIM_STAGING_tmp.id_restaurant = row2.ID_RESTAURANT.intValue();
ALIM_STAGING_tmp.code_restaurant = row2.CODE_RESTAURANT;
ALIM_STAGING_tmp.raison_sociale_restaurant = row2.RAISON_SOCIALE_RESTAURANT;
ALIM_STAGING_tmp.id_adresse_norm_restaurant = row2.ID_ADRESSE_NORM_RESTAURANT.intValue();
ALIM_STAGING_tmp.numero_voie_restau = row2.NUMERO_VOIE_RESTAU;
ALIM_STAGING_tmp.nom_voie_restau = row2.NOM_VOIE_RESTAU;
ALIM_STAGING_tmp.code_postal_restau = row2.CODE_POSTAL_RESTAU;
ALIM_STAGING_tmp.nom_ville_restau = row2.NOM_VILLE_RESTAU;
ALIM_STAGING_tmp.longitude_restau = row2.LONGITUDE_RESTAU;
ALIM_STAGING_tmp.latitude_restau = row2.LATITUDE_RESTAU;
ALIM_STAGING_tmp.id_client = row2.ID_CLIENT.intValue();
ALIM_STAGING_tmp.id_livraison = row2.ID_LIVRAISON.intValue();
ALIM_STAGING_tmp.id_commande = row2.ID_COMMANDE.intValue();
ALIM_STAGING_tmp.numero_commande = row2.NUMERO_COMMANDE.intValue();
ALIM_STAGING_tmp.date_commande = row2.DATE_COMMANDE;
ALIM_STAGING_tmp.montant_total = row2.MONTANT_TOTAL;
ALIM_STAGING_tmp.id_menu = row2.ID_MENU.intValue();
ALIM_STAGING_tmp.code_menu = row2.CODE_MENU;
ALIM_STAGING_tmp.libelle_menu = row2.LIBELLE_MENU;
ALIM_STAGING_tmp.nombre_articles = row2.NOMBRE_ARTICLES.intValue();
ALIM_STAGING_tmp.temps_theo_preparation = Integer.parseInt(row2.TEMPS_THEO_PREPARATION);
ALIM_STAGING_tmp.numero_livraison = row2.NUMERO_LIVRAISON.intValue();
ALIM_STAGING_tmp.date_debut_livraison = row2.DATE_DEBUT_LIVRAISON;
ALIM_STAGING_tmp.date_fin_livraison = row2.DATE_FIN_LIVRAISON;
ALIM_STAGING_tmp.id_livreur = row2.ID_LIVREUR.intValue();
ALIM_STAGING_tmp.nom_livreur = row2.NOM_LIVREUR;
ALIM_STAGING_tmp.prenom_livreur = row2.PRENOM_LIVREUR;
ALIM_STAGING_tmp.id_moyen_livraison = row2.ID_MOYEN_LIVRAISON.intValue();
ALIM_STAGING_tmp.code_moyen_livraison = row2.CODE_MOYEN_LIVRAISON;
ALIM_STAGING_tmp.libelle_moyen_livraison = row2.LIBELLE_MOYEN_LIVRAISON;
ALIM_STAGING_tmp.nom_client = row2.NOM_CLIENT;
ALIM_STAGING_tmp.prenom_client = row2.PRENOM_CLIENT;
ALIM_STAGING_tmp.id_preparation = row2.ID_PREPARATION.intValue();
ALIM_STAGING_tmp.date_debut_preparation = row2.DATE_DEBUT_PREPARATION;
ALIM_STAGING_tmp.date_fin_preparation = row2.DATE_FIN_PREPARATION;
ALIM_STAGING_tmp.nombre_article_livres = row2.NOMBRE_ARTICLE_LIVRES.intValue();
ALIM_STAGING = ALIM_STAGING_tmp;
// ###############################

} // end of Var scope

rejectedInnerJoin_tMap_1 = false;










 


	tos_count_tMap_1++;

/**
 * [tMap_1 main ] stop
 */
	
	/**
	 * [tMap_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tMap_1";

	

 



/**
 * [tMap_1 process_data_begin ] stop
 */
// Start of branch "ALIM_STAGING"
if(ALIM_STAGING != null) { 



	
	/**
	 * [tDBOutput_2 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"ALIM_STAGING"
						
						);
					}
					



            row3 = null;
        whetherReject_tDBOutput_2 = false;
                    if(ALIM_STAGING.id_adresse_norm_client == null) {
pstmt_tDBOutput_2.setNull(1, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_2.setInt(1, ALIM_STAGING.id_adresse_norm_client);
}

                    if(ALIM_STAGING.numero_voie == null) {
pstmt_tDBOutput_2.setNull(2, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(2, ALIM_STAGING.numero_voie);
}

                    if(ALIM_STAGING.nom_voie == null) {
pstmt_tDBOutput_2.setNull(3, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(3, ALIM_STAGING.nom_voie);
}

                    if(ALIM_STAGING.code_postal == null) {
pstmt_tDBOutput_2.setNull(4, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(4, ALIM_STAGING.code_postal);
}

                    if(ALIM_STAGING.nom_ville == null) {
pstmt_tDBOutput_2.setNull(5, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(5, ALIM_STAGING.nom_ville);
}

                    if(ALIM_STAGING.longitude == null) {
pstmt_tDBOutput_2.setNull(6, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(6, ALIM_STAGING.longitude);
}

                    if(ALIM_STAGING.latitude == null) {
pstmt_tDBOutput_2.setNull(7, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(7, ALIM_STAGING.latitude);
}

                    if(ALIM_STAGING.id_restaurant == null) {
pstmt_tDBOutput_2.setNull(8, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_2.setInt(8, ALIM_STAGING.id_restaurant);
}

                    if(ALIM_STAGING.code_restaurant == null) {
pstmt_tDBOutput_2.setNull(9, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(9, ALIM_STAGING.code_restaurant);
}

                    if(ALIM_STAGING.raison_sociale_restaurant == null) {
pstmt_tDBOutput_2.setNull(10, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(10, ALIM_STAGING.raison_sociale_restaurant);
}

                    if(ALIM_STAGING.id_adresse_norm_restaurant == null) {
pstmt_tDBOutput_2.setNull(11, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_2.setInt(11, ALIM_STAGING.id_adresse_norm_restaurant);
}

                    if(ALIM_STAGING.numero_voie_restau == null) {
pstmt_tDBOutput_2.setNull(12, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(12, ALIM_STAGING.numero_voie_restau);
}

                    if(ALIM_STAGING.nom_voie_restau == null) {
pstmt_tDBOutput_2.setNull(13, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(13, ALIM_STAGING.nom_voie_restau);
}

                    if(ALIM_STAGING.code_postal_restau == null) {
pstmt_tDBOutput_2.setNull(14, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(14, ALIM_STAGING.code_postal_restau);
}

                    if(ALIM_STAGING.nom_ville_restau == null) {
pstmt_tDBOutput_2.setNull(15, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(15, ALIM_STAGING.nom_ville_restau);
}

                    if(ALIM_STAGING.longitude_restau == null) {
pstmt_tDBOutput_2.setNull(16, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(16, ALIM_STAGING.longitude_restau);
}

                    if(ALIM_STAGING.latitude_restau == null) {
pstmt_tDBOutput_2.setNull(17, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(17, ALIM_STAGING.latitude_restau);
}

                    if(ALIM_STAGING.id_client == null) {
pstmt_tDBOutput_2.setNull(18, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_2.setInt(18, ALIM_STAGING.id_client);
}

                    if(ALIM_STAGING.id_livraison == null) {
pstmt_tDBOutput_2.setNull(19, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_2.setInt(19, ALIM_STAGING.id_livraison);
}

                    if(ALIM_STAGING.id_commande == null) {
pstmt_tDBOutput_2.setNull(20, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_2.setInt(20, ALIM_STAGING.id_commande);
}

                    if(ALIM_STAGING.numero_commande == null) {
pstmt_tDBOutput_2.setNull(21, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_2.setInt(21, ALIM_STAGING.numero_commande);
}

                    if(ALIM_STAGING.date_commande != null) {
pstmt_tDBOutput_2.setTimestamp(22, new java.sql.Timestamp(ALIM_STAGING.date_commande.getTime()));
} else {
pstmt_tDBOutput_2.setNull(22, java.sql.Types.TIMESTAMP);
}

                    if(ALIM_STAGING.montant_total == null) {
pstmt_tDBOutput_2.setNull(23, java.sql.Types.FLOAT);
} else {pstmt_tDBOutput_2.setFloat(23, ALIM_STAGING.montant_total);
}

                    if(ALIM_STAGING.id_menu == null) {
pstmt_tDBOutput_2.setNull(24, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_2.setInt(24, ALIM_STAGING.id_menu);
}

                    if(ALIM_STAGING.code_menu == null) {
pstmt_tDBOutput_2.setNull(25, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(25, ALIM_STAGING.code_menu);
}

                    if(ALIM_STAGING.libelle_menu == null) {
pstmt_tDBOutput_2.setNull(26, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(26, ALIM_STAGING.libelle_menu);
}

                    if(ALIM_STAGING.nombre_articles == null) {
pstmt_tDBOutput_2.setNull(27, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_2.setInt(27, ALIM_STAGING.nombre_articles);
}

                    if(ALIM_STAGING.temps_theo_preparation == null) {
pstmt_tDBOutput_2.setNull(28, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_2.setInt(28, ALIM_STAGING.temps_theo_preparation);
}

                    if(ALIM_STAGING.numero_livraison == null) {
pstmt_tDBOutput_2.setNull(29, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_2.setInt(29, ALIM_STAGING.numero_livraison);
}

                    if(ALIM_STAGING.date_debut_livraison != null) {
pstmt_tDBOutput_2.setTimestamp(30, new java.sql.Timestamp(ALIM_STAGING.date_debut_livraison.getTime()));
} else {
pstmt_tDBOutput_2.setNull(30, java.sql.Types.TIMESTAMP);
}

                    if(ALIM_STAGING.date_fin_livraison != null) {
pstmt_tDBOutput_2.setTimestamp(31, new java.sql.Timestamp(ALIM_STAGING.date_fin_livraison.getTime()));
} else {
pstmt_tDBOutput_2.setNull(31, java.sql.Types.TIMESTAMP);
}

                    if(ALIM_STAGING.id_livreur == null) {
pstmt_tDBOutput_2.setNull(32, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_2.setInt(32, ALIM_STAGING.id_livreur);
}

                    if(ALIM_STAGING.nom_livreur == null) {
pstmt_tDBOutput_2.setNull(33, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(33, ALIM_STAGING.nom_livreur);
}

                    if(ALIM_STAGING.prenom_livreur == null) {
pstmt_tDBOutput_2.setNull(34, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(34, ALIM_STAGING.prenom_livreur);
}

                    if(ALIM_STAGING.id_moyen_livraison == null) {
pstmt_tDBOutput_2.setNull(35, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_2.setInt(35, ALIM_STAGING.id_moyen_livraison);
}

                    if(ALIM_STAGING.code_moyen_livraison == null) {
pstmt_tDBOutput_2.setNull(36, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(36, ALIM_STAGING.code_moyen_livraison);
}

                    if(ALIM_STAGING.libelle_moyen_livraison == null) {
pstmt_tDBOutput_2.setNull(37, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(37, ALIM_STAGING.libelle_moyen_livraison);
}

                    if(ALIM_STAGING.nom_client == null) {
pstmt_tDBOutput_2.setNull(38, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(38, ALIM_STAGING.nom_client);
}

                    if(ALIM_STAGING.prenom_client == null) {
pstmt_tDBOutput_2.setNull(39, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(39, ALIM_STAGING.prenom_client);
}

                    if(ALIM_STAGING.id_preparation == null) {
pstmt_tDBOutput_2.setNull(40, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_2.setInt(40, ALIM_STAGING.id_preparation);
}

                    if(ALIM_STAGING.date_debut_preparation != null) {
pstmt_tDBOutput_2.setTimestamp(41, new java.sql.Timestamp(ALIM_STAGING.date_debut_preparation.getTime()));
} else {
pstmt_tDBOutput_2.setNull(41, java.sql.Types.TIMESTAMP);
}

                    if(ALIM_STAGING.date_fin_preparation != null) {
pstmt_tDBOutput_2.setTimestamp(42, new java.sql.Timestamp(ALIM_STAGING.date_fin_preparation.getTime()));
} else {
pstmt_tDBOutput_2.setNull(42, java.sql.Types.TIMESTAMP);
}

                    if(ALIM_STAGING.nombre_article_livres == null) {
pstmt_tDBOutput_2.setNull(43, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_2.setInt(43, ALIM_STAGING.nombre_article_livres);
}

			
    		pstmt_tDBOutput_2.addBatch();
    		nb_line_tDBOutput_2++;
    		  
    		  
    		  batchSizeCounter_tDBOutput_2++;
    		  
            if(!whetherReject_tDBOutput_2) {
                            row3 = new row3Struct();
                                row3.id_staging_dm2 = ALIM_STAGING.id_staging_dm2;
                                row3.id_adresse_norm_client = ALIM_STAGING.id_adresse_norm_client;
                                row3.numero_voie = ALIM_STAGING.numero_voie;
                                row3.nom_voie = ALIM_STAGING.nom_voie;
                                row3.code_postal = ALIM_STAGING.code_postal;
                                row3.nom_ville = ALIM_STAGING.nom_ville;
                                row3.longitude = ALIM_STAGING.longitude;
                                row3.latitude = ALIM_STAGING.latitude;
                                row3.id_restaurant = ALIM_STAGING.id_restaurant;
                                row3.code_restaurant = ALIM_STAGING.code_restaurant;
                                row3.raison_sociale_restaurant = ALIM_STAGING.raison_sociale_restaurant;
                                row3.id_adresse_norm_restaurant = ALIM_STAGING.id_adresse_norm_restaurant;
                                row3.numero_voie_restau = ALIM_STAGING.numero_voie_restau;
                                row3.nom_voie_restau = ALIM_STAGING.nom_voie_restau;
                                row3.code_postal_restau = ALIM_STAGING.code_postal_restau;
                                row3.nom_ville_restau = ALIM_STAGING.nom_ville_restau;
                                row3.longitude_restau = ALIM_STAGING.longitude_restau;
                                row3.latitude_restau = ALIM_STAGING.latitude_restau;
                                row3.id_client = ALIM_STAGING.id_client;
                                row3.id_livraison = ALIM_STAGING.id_livraison;
                                row3.id_commande = ALIM_STAGING.id_commande;
                                row3.numero_commande = ALIM_STAGING.numero_commande;
                                row3.date_commande = ALIM_STAGING.date_commande;
                                row3.montant_total = ALIM_STAGING.montant_total;
                                row3.id_menu = ALIM_STAGING.id_menu;
                                row3.code_menu = ALIM_STAGING.code_menu;
                                row3.libelle_menu = ALIM_STAGING.libelle_menu;
                                row3.nombre_articles = ALIM_STAGING.nombre_articles;
                                row3.temps_theo_preparation = ALIM_STAGING.temps_theo_preparation;
                                row3.numero_livraison = ALIM_STAGING.numero_livraison;
                                row3.date_debut_livraison = ALIM_STAGING.date_debut_livraison;
                                row3.date_fin_livraison = ALIM_STAGING.date_fin_livraison;
                                row3.id_livreur = ALIM_STAGING.id_livreur;
                                row3.nom_livreur = ALIM_STAGING.nom_livreur;
                                row3.prenom_livreur = ALIM_STAGING.prenom_livreur;
                                row3.id_moyen_livraison = ALIM_STAGING.id_moyen_livraison;
                                row3.code_moyen_livraison = ALIM_STAGING.code_moyen_livraison;
                                row3.libelle_moyen_livraison = ALIM_STAGING.libelle_moyen_livraison;
                                row3.nom_client = ALIM_STAGING.nom_client;
                                row3.prenom_client = ALIM_STAGING.prenom_client;
                                row3.id_preparation = ALIM_STAGING.id_preparation;
                                row3.date_debut_preparation = ALIM_STAGING.date_debut_preparation;
                                row3.date_fin_preparation = ALIM_STAGING.date_fin_preparation;
                                row3.nombre_article_livres = ALIM_STAGING.nombre_article_livres;
            }
    			if ((batchSize_tDBOutput_2 > 0) && (batchSize_tDBOutput_2 <= batchSizeCounter_tDBOutput_2)) {
                try {
						int countSum_tDBOutput_2 = 0;
						    
						for(int countEach_tDBOutput_2: pstmt_tDBOutput_2.executeBatch()) {
							countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
						}
				    	rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;
				    	
				    		insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
				    	
            	    	batchSizeCounter_tDBOutput_2 = 0;
                }catch (java.sql.BatchUpdateException e_tDBOutput_2){
globalMap.put("tDBOutput_2_ERROR_MESSAGE",e_tDBOutput_2.getMessage());
				    	java.sql.SQLException ne_tDBOutput_2 = e_tDBOutput_2.getNextException(),sqle_tDBOutput_2=null;
				    	String errormessage_tDBOutput_2;
						if (ne_tDBOutput_2 != null) {
							// build new exception to provide the original cause
							sqle_tDBOutput_2 = new java.sql.SQLException(e_tDBOutput_2.getMessage() + "\ncaused by: " + ne_tDBOutput_2.getMessage(), ne_tDBOutput_2.getSQLState(), ne_tDBOutput_2.getErrorCode(), ne_tDBOutput_2);
							errormessage_tDBOutput_2 = sqle_tDBOutput_2.getMessage();
						}else{
							errormessage_tDBOutput_2 = e_tDBOutput_2.getMessage();
						}
				    	
				    	int countSum_tDBOutput_2 = 0;
						for(int countEach_tDBOutput_2: e_tDBOutput_2.getUpdateCounts()) {
							countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
						}
						rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;
						
				    		insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
				    	
				    	System.err.println(errormessage_tDBOutput_2);
				    	
					}
    			}
    		
    		    commitCounter_tDBOutput_2++;
                if(commitEvery_tDBOutput_2 <= commitCounter_tDBOutput_2) {
                if ((batchSize_tDBOutput_2 > 0) && (batchSizeCounter_tDBOutput_2 > 0)) {
                try {
                		int countSum_tDBOutput_2 = 0;
                		    
						for(int countEach_tDBOutput_2: pstmt_tDBOutput_2.executeBatch()) {
							countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
						}
            	    	rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;
            	    	
            	    		insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
            	    	
                batchSizeCounter_tDBOutput_2 = 0;
               }catch (java.sql.BatchUpdateException e_tDBOutput_2){
globalMap.put("tDBOutput_2_ERROR_MESSAGE",e_tDBOutput_2.getMessage());
			    	java.sql.SQLException ne_tDBOutput_2 = e_tDBOutput_2.getNextException(),sqle_tDBOutput_2=null;
			    	String errormessage_tDBOutput_2;
					if (ne_tDBOutput_2 != null) {
						// build new exception to provide the original cause
						sqle_tDBOutput_2 = new java.sql.SQLException(e_tDBOutput_2.getMessage() + "\ncaused by: " + ne_tDBOutput_2.getMessage(), ne_tDBOutput_2.getSQLState(), ne_tDBOutput_2.getErrorCode(), ne_tDBOutput_2);
						errormessage_tDBOutput_2 = sqle_tDBOutput_2.getMessage();
					}else{
						errormessage_tDBOutput_2 = e_tDBOutput_2.getMessage();
					}
			    	
			    	int countSum_tDBOutput_2 = 0;
					for(int countEach_tDBOutput_2: e_tDBOutput_2.getUpdateCounts()) {
						countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
					}
					rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;
					
			    		insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
			    	
			    	System.err.println(errormessage_tDBOutput_2);
			    	
				}
            }
                    if(rowsToCommitCount_tDBOutput_2 != 0){
                    	
                    }
                    conn_tDBOutput_2.commit();
                    if(rowsToCommitCount_tDBOutput_2 != 0){
                    	
                    	rowsToCommitCount_tDBOutput_2 = 0;
                    }
                    commitCounter_tDBOutput_2=0;
                }

 


	tos_count_tDBOutput_2++;

/**
 * [tDBOutput_2 main ] stop
 */
	
	/**
	 * [tDBOutput_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";

	

 



/**
 * [tDBOutput_2 process_data_begin ] stop
 */
// Start of branch "row3"
if(row3 != null) { 



	
	/**
	 * [tFileArchive_1 main ] start
	 */

	

	
	
	currentComponent="tFileArchive_1";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row3"
						
						);
					}
					

	

		String sourceFile_tFileArchive_1 = "C:/CC2/Groupe1/5_DATA_IN";
	

    if (java.nio.file.Files.notExists(java.nio.file.Paths.get(sourceFile_tFileArchive_1), java.nio.file.LinkOption.NOFOLLOW_LINKS)){
        throw new java.io.FileNotFoundException(sourceFile_tFileArchive_1 + " (The system cannot find the path specified)");
    }

    String zipFile_tFileArchive_1 = "C:/CC2/Groupe1/6_DATA_IN_ZIP/sources.zip";
    
    com.talend.compress.zip.Zip zip_tFileArchive_1 = new com.talend.compress.zip.Zip(sourceFile_tFileArchive_1, zipFile_tFileArchive_1);
    zip_tFileArchive_1.setOverwriteExistTargetZip(true);
	zip_tFileArchive_1.setMakeTargetDir(false);
	zip_tFileArchive_1.setCompressLevel(4);
	zip_tFileArchive_1.setArchiveFormat("zip");
	zip_tFileArchive_1.setAllFiles(true);
	
	
	   zip_tFileArchive_1.setContainSubDir(true);
	   zip_tFileArchive_1.setEncoding("ISO-8859-15");
	   zip_tFileArchive_1.setZip64Mode("ASNEEDED");
	   zip_tFileArchive_1.setEncrypted(false);
		        
	   
	    
	    
	final String decryptedPassword_tFileArchive_1 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:oeigk3cLYIOBjceIKQKX6fQ0imkg30IxfIyl3g==");
	    
	   zip_tFileArchive_1.setPassword(decryptedPassword_tFileArchive_1);
	   
	      zip_tFileArchive_1.setUseZip4jEncryption(true);
	      zip_tFileArchive_1.setEncryptionMethod(net.lingala.zip4j.util.Zip4jConstants.ENC_METHOD_STANDARD);
	      
  
  
   globalMap.put("tFileArchive_1_ARCHIVE_FILEPATH",zipFile_tFileArchive_1);
   
   globalMap.put("tFileArchive_1_ARCHIVE_FILENAME", new java.io.File(zipFile_tFileArchive_1).getName());

   zip_tFileArchive_1.doZip();


 


	tos_count_tFileArchive_1++;

/**
 * [tFileArchive_1 main ] stop
 */
	
	/**
	 * [tFileArchive_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFileArchive_1";

	

 



/**
 * [tFileArchive_1 process_data_begin ] stop
 */
	
	/**
	 * [tFileArchive_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tFileArchive_1";

	

 



/**
 * [tFileArchive_1 process_data_end ] stop
 */

} // End of branch "row3"




	
	/**
	 * [tDBOutput_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";

	

 



/**
 * [tDBOutput_2 process_data_end ] stop
 */

} // End of branch "ALIM_STAGING"




	
	/**
	 * [tMap_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tMap_1";

	

 



/**
 * [tMap_1 process_data_end ] stop
 */



	
	/**
	 * [tDBInput_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBInput_1";

	

 



/**
 * [tDBInput_1 process_data_end ] stop
 */
	
	/**
	 * [tDBInput_1 end ] start
	 */

	

	
	
	currentComponent="tDBInput_1";

	

}
}finally{
	if (rs_tDBInput_1 != null) {
		rs_tDBInput_1.close();
	}
	if (stmt_tDBInput_1 != null) {
		stmt_tDBInput_1.close();
	}
	if(conn_tDBInput_1 != null && !conn_tDBInput_1.isClosed()) {
	
			conn_tDBInput_1.close();
			
			if("com.mysql.cj.jdbc.Driver".equals((String)globalMap.get("driverClass_"))
			    && routines.system.BundleUtils.inOSGi()) {
			        Class.forName("com.mysql.cj.jdbc.AbandonedConnectionCleanupThread").
			            getMethod("checkedShutdown").invoke(null, (Object[]) null);
			}
			
	}
	
}

globalMap.put("tDBInput_1_NB_LINE",nb_line_tDBInput_1);
 

ok_Hash.put("tDBInput_1", true);
end_Hash.put("tDBInput_1", System.currentTimeMillis());

tStatCatcher_1.addMessage("end","tDBInput_1", end_Hash.get("tDBInput_1")-start_Hash.get("tDBInput_1"));
tStatCatcher_1Process(globalMap);



/**
 * [tDBInput_1 end ] stop
 */

	
	/**
	 * [tMap_1 end ] start
	 */

	

	
	
	currentComponent="tMap_1";

	


// ###############################
// # Lookup hashes releasing
// ###############################      





				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row2");
			  	}
			  	
 

ok_Hash.put("tMap_1", true);
end_Hash.put("tMap_1", System.currentTimeMillis());

tStatCatcher_1.addMessage("end","tMap_1", end_Hash.get("tMap_1")-start_Hash.get("tMap_1"));
tStatCatcher_1Process(globalMap);



/**
 * [tMap_1 end ] stop
 */

	
	/**
	 * [tDBOutput_2 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";

	



	    try {
				int countSum_tDBOutput_2 = 0;
				if (pstmt_tDBOutput_2 != null && batchSizeCounter_tDBOutput_2 > 0) {
						
					for(int countEach_tDBOutput_2: pstmt_tDBOutput_2.executeBatch()) {
						countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
					}
					rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;
						
				}
		    	
		    		insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
		    	
	    }catch (java.sql.BatchUpdateException e_tDBOutput_2){
globalMap.put("tDBOutput_2_ERROR_MESSAGE",e_tDBOutput_2.getMessage());
	    	java.sql.SQLException ne_tDBOutput_2 = e_tDBOutput_2.getNextException(),sqle_tDBOutput_2=null;
	    	String errormessage_tDBOutput_2;
			if (ne_tDBOutput_2 != null) {
				// build new exception to provide the original cause
				sqle_tDBOutput_2 = new java.sql.SQLException(e_tDBOutput_2.getMessage() + "\ncaused by: " + ne_tDBOutput_2.getMessage(), ne_tDBOutput_2.getSQLState(), ne_tDBOutput_2.getErrorCode(), ne_tDBOutput_2);
				errormessage_tDBOutput_2 = sqle_tDBOutput_2.getMessage();
			}else{
				errormessage_tDBOutput_2 = e_tDBOutput_2.getMessage();
			}
	    	
	    	int countSum_tDBOutput_2 = 0;
			for(int countEach_tDBOutput_2: e_tDBOutput_2.getUpdateCounts()) {
				countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
			}
			rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;
			
	    		insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
	    	
	    	System.err.println(errormessage_tDBOutput_2);
	    	
		}
	    
        if(pstmt_tDBOutput_2 != null) {
        		
            pstmt_tDBOutput_2.close();
            resourceMap.remove("pstmt_tDBOutput_2");
        }
    resourceMap.put("statementClosed_tDBOutput_2", true);
			if(rowsToCommitCount_tDBOutput_2 != 0){
				
			}
			conn_tDBOutput_2.commit();
			if(rowsToCommitCount_tDBOutput_2 != 0){
				
				rowsToCommitCount_tDBOutput_2 = 0;
			}
			commitCounter_tDBOutput_2 = 0;
		
    	conn_tDBOutput_2 .close();
    	
    	resourceMap.put("finish_tDBOutput_2", true);
    	

	nb_line_deleted_tDBOutput_2=nb_line_deleted_tDBOutput_2+ deletedCount_tDBOutput_2;
	nb_line_update_tDBOutput_2=nb_line_update_tDBOutput_2 + updatedCount_tDBOutput_2;
	nb_line_inserted_tDBOutput_2=nb_line_inserted_tDBOutput_2 + insertedCount_tDBOutput_2;
	nb_line_rejected_tDBOutput_2=nb_line_rejected_tDBOutput_2 + rejectedCount_tDBOutput_2;
	
        globalMap.put("tDBOutput_2_NB_LINE",nb_line_tDBOutput_2);
        globalMap.put("tDBOutput_2_NB_LINE_UPDATED",nb_line_update_tDBOutput_2);
        globalMap.put("tDBOutput_2_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_2);
        globalMap.put("tDBOutput_2_NB_LINE_DELETED",nb_line_deleted_tDBOutput_2);
        globalMap.put("tDBOutput_2_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_2);
    

	


				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"ALIM_STAGING");
			  	}
			  	
 

ok_Hash.put("tDBOutput_2", true);
end_Hash.put("tDBOutput_2", System.currentTimeMillis());




/**
 * [tDBOutput_2 end ] stop
 */

	
	/**
	 * [tFileArchive_1 end ] start
	 */

	

	
	
	currentComponent="tFileArchive_1";

	

				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row3");
			  	}
			  	
 

ok_Hash.put("tFileArchive_1", true);
end_Hash.put("tFileArchive_1", System.currentTimeMillis());

tStatCatcher_1.addMessage("end","tFileArchive_1", end_Hash.get("tFileArchive_1")-start_Hash.get("tFileArchive_1"));
tStatCatcher_1Process(globalMap);



/**
 * [tFileArchive_1 end ] stop
 */









				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBInput_1 finally ] start
	 */

	

	
	
	currentComponent="tDBInput_1";

	

 



/**
 * [tDBInput_1 finally ] stop
 */

	
	/**
	 * [tMap_1 finally ] start
	 */

	

	
	
	currentComponent="tMap_1";

	

 



/**
 * [tMap_1 finally ] stop
 */

	
	/**
	 * [tDBOutput_2 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";

	



    try {
    if (resourceMap.get("statementClosed_tDBOutput_2") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_2 = null;
                if ((pstmtToClose_tDBOutput_2 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_2")) != null) {
                    pstmtToClose_tDBOutput_2.close();
                }
    }
    } finally {
        if(resourceMap.get("finish_tDBOutput_2") == null){
            java.sql.Connection ctn_tDBOutput_2 = null;
            if((ctn_tDBOutput_2 = (java.sql.Connection)resourceMap.get("conn_tDBOutput_2")) != null){
                try {
                    ctn_tDBOutput_2.close();
                } catch (java.sql.SQLException sqlEx_tDBOutput_2) {
                    String errorMessage_tDBOutput_2 = "failed to close the connection in tDBOutput_2 :" + sqlEx_tDBOutput_2.getMessage();
                    System.err.println(errorMessage_tDBOutput_2);
                }
            }
        }
    }
 



/**
 * [tDBOutput_2 finally ] stop
 */

	
	/**
	 * [tFileArchive_1 finally ] start
	 */

	

	
	
	currentComponent="tFileArchive_1";

	

 



/**
 * [tFileArchive_1 finally ] stop
 */









				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBInput_1_SUBPROCESS_STATE", 1);
	}
	
    public String resuming_logs_dir_path = null;
    public String resuming_checkpoint_path = null;
    public String parent_part_launcher = null;
    private String resumeEntryMethodName = null;
    private boolean globalResumeTicket = false;

    public boolean watch = false;
    // portStats is null, it means don't execute the statistics
    public Integer portStats = null;
    public int portTraces = 4334;
    public String clientHost;
    public String defaultClientHost = "localhost";
    public String contextStr = "Default";
    public boolean isDefaultContext = true;
    public String pid = "0";
    public String rootPid = null;
    public String fatherPid = null;
    public String fatherNode = null;
    public long startTime = 0;
    public boolean isChildJob = false;
    public String log4jLevel = "";
    
    private boolean enableLogStash;

    private boolean execStat = true;

    private ThreadLocal<java.util.Map<String, String>> threadLocal = new ThreadLocal<java.util.Map<String, String>>() {
        protected java.util.Map<String, String> initialValue() {
            java.util.Map<String,String> threadRunResultMap = new java.util.HashMap<String, String>();
            threadRunResultMap.put("errorCode", null);
            threadRunResultMap.put("status", "");
            return threadRunResultMap;
        };
    };


    protected PropertiesWithType context_param = new PropertiesWithType();
    public java.util.Map<String, Object> parentContextMap = new java.util.HashMap<String, Object>();

    public String status= "";
    

    public static void main(String[] args){
        final A_ALIM_STAGING_DM2 A_ALIM_STAGING_DM2Class = new A_ALIM_STAGING_DM2();

        int exitCode = A_ALIM_STAGING_DM2Class.runJobInTOS(args);

        System.exit(exitCode);
    }


    public String[][] runJob(String[] args) {

        int exitCode = runJobInTOS(args);
        String[][] bufferValue = new String[][] { { Integer.toString(exitCode) } };

        return bufferValue;
    }

    public boolean hastBufferOutputComponent() {
		boolean hastBufferOutput = false;
    	
        return hastBufferOutput;
    }

    public int runJobInTOS(String[] args) {
	   	// reset status
	   	status = "";
	   	
        String lastStr = "";
        for (String arg : args) {
            if (arg.equalsIgnoreCase("--context_param")) {
                lastStr = arg;
            } else if (lastStr.equals("")) {
                evalParam(arg);
            } else {
                evalParam(lastStr + " " + arg);
                lastStr = "";
            }
        }
        enableLogStash = "true".equalsIgnoreCase(System.getProperty("audit.enabled"));

    	
    	

        if(clientHost == null) {
            clientHost = defaultClientHost;
        }

        if(pid == null || "0".equals(pid)) {
            pid = TalendString.getAsciiRandomString(6);
        }

        if (rootPid==null) {
            rootPid = pid;
        }
        if (fatherPid==null) {
            fatherPid = pid;
        }else{
            isChildJob = true;
        }

        if (portStats != null) {
            // portStats = -1; //for testing
            if (portStats < 0 || portStats > 65535) {
                // issue:10869, the portStats is invalid, so this client socket can't open
                System.err.println("The statistics socket port " + portStats + " is invalid.");
                execStat = false;
            }
        } else {
            execStat = false;
        }
        boolean inOSGi = routines.system.BundleUtils.inOSGi();

        if (inOSGi) {
            java.util.Dictionary<String, Object> jobProperties = routines.system.BundleUtils.getJobProperties(jobName);

            if (jobProperties != null && jobProperties.get("context") != null) {
                contextStr = (String)jobProperties.get("context");
            }
        }

        try {
            //call job/subjob with an existing context, like: --context=production. if without this parameter, there will use the default context instead.
            java.io.InputStream inContext = A_ALIM_STAGING_DM2.class.getClassLoader().getResourceAsStream("alimentation_dm2/a_alim_staging_dm2_0_1/contexts/" + contextStr + ".properties");
            if (inContext == null) {
                inContext = A_ALIM_STAGING_DM2.class.getClassLoader().getResourceAsStream("config/contexts/" + contextStr + ".properties");
            }
            if (inContext != null) {
                try {
                    //defaultProps is in order to keep the original context value
                    if(context != null && context.isEmpty()) {
	                defaultProps.load(inContext);
	                context = new ContextProperties(defaultProps);
                    }
                } finally {
                    inContext.close();
                }
            } else if (!isDefaultContext) {
                //print info and job continue to run, for case: context_param is not empty.
                System.err.println("Could not find the context " + contextStr);
            }

            if(!context_param.isEmpty()) {
                context.putAll(context_param);
				//set types for params from parentJobs
				for (Object key: context_param.keySet()){
					String context_key = key.toString();
					String context_type = context_param.getContextType(context_key);
					context.setContextType(context_key, context_type);

				}
            }
            class ContextProcessing {
                private void processContext_0() {
                } 
                public void processAllContext() {
                        processContext_0();
                }
            }

            new ContextProcessing().processAllContext();
        } catch (java.io.IOException ie) {
            System.err.println("Could not load context "+contextStr);
            ie.printStackTrace();
        }

        // get context value from parent directly
        if (parentContextMap != null && !parentContextMap.isEmpty()) {
        }

        //Resume: init the resumeUtil
        resumeEntryMethodName = ResumeUtil.getResumeEntryMethodName(resuming_checkpoint_path);
        resumeUtil = new ResumeUtil(resuming_logs_dir_path, isChildJob, rootPid);
        resumeUtil.initCommonInfo(pid, rootPid, fatherPid, projectName, jobName, contextStr, jobVersion);

		List<String> parametersToEncrypt = new java.util.ArrayList<String>();
        //Resume: jobStart
        resumeUtil.addLog("JOB_STARTED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","","","",resumeUtil.convertToJsonText(context,parametersToEncrypt));

if(execStat) {
    try {
        runStat.openSocket(!isChildJob);
        runStat.setAllPID(rootPid, fatherPid, pid, jobName);
        runStat.startThreadStat(clientHost, portStats);
        runStat.updateStatOnJob(RunStat.JOBSTART, fatherNode);
    } catch (java.io.IOException ioException) {
        ioException.printStackTrace();
    }
}



	
	    java.util.concurrent.ConcurrentHashMap<Object, Object> concurrentHashMap = new java.util.concurrent.ConcurrentHashMap<Object, Object>();
	    globalMap.put("concurrentHashMap", concurrentHashMap);
	

    long startUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
    long endUsedMemory = 0;
    long end = 0;

    startTime = System.currentTimeMillis();
        tStatCatcher_1.addMessage("begin");


this.globalResumeTicket = true;//to run tPreJob




        try {
            tStatCatcher_1Process(globalMap);
        } catch (java.lang.Exception e) {
            e.printStackTrace();
        }

this.globalResumeTicket = false;//to run others jobs

try {
errorCode = null;tDBInput_1Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tDBInput_1) {
globalMap.put("tDBInput_1_SUBPROCESS_STATE", -1);

e_tDBInput_1.printStackTrace();

}

this.globalResumeTicket = true;//to run tPostJob




        end = System.currentTimeMillis();

        if (watch) {
            System.out.println((end-startTime)+" milliseconds");
        }

        endUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        if (false) {
            System.out.println((endUsedMemory - startUsedMemory) + " bytes memory increase when running : A_ALIM_STAGING_DM2");
        }
        tStatCatcher_1.addMessage(status==""?"end":status, (end-startTime));
        try {
            tStatCatcher_1Process(globalMap);
        } catch (java.lang.Exception e) {
            e.printStackTrace();
        }



if (execStat) {
    runStat.updateStatOnJob(RunStat.JOBEND, fatherNode);
    runStat.stopThreadStat();
}
    int returnCode = 0;


    if(errorCode == null) {
         returnCode = status != null && status.equals("failure") ? 1 : 0;
    } else {
         returnCode = errorCode.intValue();
    }
    resumeUtil.addLog("JOB_ENDED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","" + returnCode,"","","");

    return returnCode;

  }

    // only for OSGi env
    public void destroy() {


    }














    private java.util.Map<String, Object> getSharedConnections4REST() {
        java.util.Map<String, Object> connections = new java.util.HashMap<String, Object>();






        return connections;
    }

    private void evalParam(String arg) {
        if (arg.startsWith("--resuming_logs_dir_path")) {
            resuming_logs_dir_path = arg.substring(25);
        } else if (arg.startsWith("--resuming_checkpoint_path")) {
            resuming_checkpoint_path = arg.substring(27);
        } else if (arg.startsWith("--parent_part_launcher")) {
            parent_part_launcher = arg.substring(23);
        } else if (arg.startsWith("--watch")) {
            watch = true;
        } else if (arg.startsWith("--stat_port=")) {
            String portStatsStr = arg.substring(12);
            if (portStatsStr != null && !portStatsStr.equals("null")) {
                portStats = Integer.parseInt(portStatsStr);
            }
        } else if (arg.startsWith("--trace_port=")) {
            portTraces = Integer.parseInt(arg.substring(13));
        } else if (arg.startsWith("--client_host=")) {
            clientHost = arg.substring(14);
        } else if (arg.startsWith("--context=")) {
            contextStr = arg.substring(10);
            isDefaultContext = false;
        } else if (arg.startsWith("--father_pid=")) {
            fatherPid = arg.substring(13);
        } else if (arg.startsWith("--root_pid=")) {
            rootPid = arg.substring(11);
        } else if (arg.startsWith("--father_node=")) {
            fatherNode = arg.substring(14);
        } else if (arg.startsWith("--pid=")) {
            pid = arg.substring(6);
        } else if (arg.startsWith("--context_type")) {
            String keyValue = arg.substring(15);
			int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.setContextType(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.setContextType(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }

            }

		} else if (arg.startsWith("--context_param")) {
            String keyValue = arg.substring(16);
            int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.put(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.put(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }
            }
        } else if (arg.startsWith("--log4jLevel=")) {
            log4jLevel = arg.substring(13);
		} else if (arg.startsWith("--audit.enabled") && arg.contains("=")) {//for trunjob call
		    final int equal = arg.indexOf('=');
			final String key = arg.substring("--".length(), equal);
			System.setProperty(key, arg.substring(equal + 1));
		}
    }
    
    private static final String NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY = "<TALEND_NULL>";

    private final String[][] escapeChars = {
        {"\\\\","\\"},{"\\n","\n"},{"\\'","\'"},{"\\r","\r"},
        {"\\f","\f"},{"\\b","\b"},{"\\t","\t"}
        };
    private String replaceEscapeChars (String keyValue) {

		if (keyValue == null || ("").equals(keyValue.trim())) {
			return keyValue;
		}

		StringBuilder result = new StringBuilder();
		int currIndex = 0;
		while (currIndex < keyValue.length()) {
			int index = -1;
			// judege if the left string includes escape chars
			for (String[] strArray : escapeChars) {
				index = keyValue.indexOf(strArray[0],currIndex);
				if (index>=0) {

					result.append(keyValue.substring(currIndex, index + strArray[0].length()).replace(strArray[0], strArray[1]));
					currIndex = index + strArray[0].length();
					break;
				}
			}
			// if the left string doesn't include escape chars, append the left into the result
			if (index < 0) {
				result.append(keyValue.substring(currIndex));
				currIndex = currIndex + keyValue.length();
			}
		}

		return result.toString();
    }

    public Integer getErrorCode() {
        return errorCode;
    }


    public String getStatus() {
        return status;
    }

    ResumeUtil resumeUtil = null;
}
/************************************************************************************************
 *     205991 characters generated by Talend Open Studio for Data Integration 
 *     on the 18 janvier 2024 à 23:29:02 CET
 ************************************************************************************************/