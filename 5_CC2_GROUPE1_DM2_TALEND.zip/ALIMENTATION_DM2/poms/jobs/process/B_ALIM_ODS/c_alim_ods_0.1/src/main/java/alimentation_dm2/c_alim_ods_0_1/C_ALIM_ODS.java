// ============================================================================
//
// Copyright (c) 2006-2015, Talend SA
//
// Ce code source a été automatiquement généré par_Talend Open Studio for Data Integration
// / Soumis à la Licence Apache, Version 2.0 (la "Licence") ;
// votre utilisation de ce fichier doit respecter les termes de la Licence.
// Vous pouvez obtenir une copie de la Licence sur
// http://www.apache.org/licenses/LICENSE-2.0
// 
// Sauf lorsqu'explicitement prévu par la loi en vigueur ou accepté par écrit, le logiciel
// distribué sous la Licence est distribué "TEL QUEL",
// SANS GARANTIE OU CONDITION D'AUCUNE SORTE, expresse ou implicite.
// Consultez la Licence pour connaître la terminologie spécifique régissant les autorisations et
// les limites prévues par la Licence.

package alimentation_dm2.c_alim_ods_0_1;

import routines.Numeric;
import routines.DataOperation;
import routines.TalendDataGenerator;
import routines.TalendStringUtil;
import routines.TalendString;
import routines.StringHandling;
import routines.Relational;
import routines.TalendDate;
import routines.Mathematical;
import routines.system.*;
import routines.system.api.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.math.BigDecimal;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.util.Comparator;

//the import part of tJava_1
//import java.util.List;

@SuppressWarnings("unused")

/**
 * Job: C_ALIM_ODS Purpose: <br>
 * Description: <br>
 * 
 * @author user@talend.com
 * @version 8.0.1.20211109_1610
 * @status
 */
public class C_ALIM_ODS implements TalendJob {

	protected static void logIgnoredError(String message, Throwable cause) {
		System.err.println(message);
		if (cause != null) {
			cause.printStackTrace();
		}

	}

	public final Object obj = new Object();

	// for transmiting parameters purpose
	private Object valueObject = null;

	public Object getValueObject() {
		return this.valueObject;
	}

	public void setValueObject(Object valueObject) {
		this.valueObject = valueObject;
	}

	private final static String defaultCharset = java.nio.charset.Charset.defaultCharset().name();

	private final static String utf8Charset = "UTF-8";

	// contains type for every context property
	public class PropertiesWithType extends java.util.Properties {
		private static final long serialVersionUID = 1L;
		private java.util.Map<String, String> propertyTypes = new java.util.HashMap<>();

		public PropertiesWithType(java.util.Properties properties) {
			super(properties);
		}

		public PropertiesWithType() {
			super();
		}

		public void setContextType(String key, String type) {
			propertyTypes.put(key, type);
		}

		public String getContextType(String key) {
			return propertyTypes.get(key);
		}
	}

	// create and load default properties
	private java.util.Properties defaultProps = new java.util.Properties();

	// create application properties with default
	public class ContextProperties extends PropertiesWithType {

		private static final long serialVersionUID = 1L;

		public ContextProperties(java.util.Properties properties) {
			super(properties);
		}

		public ContextProperties() {
			super();
		}

		public void synchronizeContext() {

		}

		// if the stored or passed value is "<TALEND_NULL>" string, it mean null
		public String getStringValue(String key) {
			String origin_value = this.getProperty(key);
			if (NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY.equals(origin_value)) {
				return null;
			}
			return origin_value;
		}

	}

	protected ContextProperties context = new ContextProperties(); // will be instanciated by MS.

	public ContextProperties getContext() {
		return this.context;
	}

	private final String jobVersion = "0.1";
	private final String jobName = "C_ALIM_ODS";
	private final String projectName = "ALIMENTATION_DM2";
	public Integer errorCode = null;
	private String currentComponent = "";

	private final java.util.Map<String, Object> globalMap = new java.util.HashMap<String, Object>();
	private final static java.util.Map<String, Object> junitGlobalMap = new java.util.HashMap<String, Object>();

	private final java.util.Map<String, Long> start_Hash = new java.util.HashMap<String, Long>();
	private final java.util.Map<String, Long> end_Hash = new java.util.HashMap<String, Long>();
	private final java.util.Map<String, Boolean> ok_Hash = new java.util.HashMap<String, Boolean>();
	public final java.util.List<String[]> globalBuffer = new java.util.ArrayList<String[]>();

	private RunStat runStat = new RunStat();

	// OSGi DataSource
	private final static String KEY_DB_DATASOURCES = "KEY_DB_DATASOURCES";

	private final static String KEY_DB_DATASOURCES_RAW = "KEY_DB_DATASOURCES_RAW";

	public void setDataSources(java.util.Map<String, javax.sql.DataSource> dataSources) {
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		for (java.util.Map.Entry<String, javax.sql.DataSource> dataSourceEntry : dataSources.entrySet()) {
			talendDataSources.put(dataSourceEntry.getKey(),
					new routines.system.TalendDataSource(dataSourceEntry.getValue()));
		}
		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}

	public void setDataSourceReferences(List serviceReferences) throws Exception {

		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		java.util.Map<String, javax.sql.DataSource> dataSources = new java.util.HashMap<String, javax.sql.DataSource>();

		for (java.util.Map.Entry<String, javax.sql.DataSource> entry : BundleUtils
				.getServices(serviceReferences, javax.sql.DataSource.class).entrySet()) {
			dataSources.put(entry.getKey(), entry.getValue());
			talendDataSources.put(entry.getKey(), new routines.system.TalendDataSource(entry.getValue()));
		}

		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}

	StatCatcherUtils tStatCatcher_1 = new StatCatcherUtils("_dgXnYLPyEe658dUMRTZXjw", "0.1");

	private final java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
	private final java.io.PrintStream errorMessagePS = new java.io.PrintStream(new java.io.BufferedOutputStream(baos));

	public String getExceptionStackTrace() {
		if ("failure".equals(this.getStatus())) {
			errorMessagePS.flush();
			return baos.toString();
		}
		return null;
	}

	private Exception exception;

	public Exception getException() {
		if ("failure".equals(this.getStatus())) {
			return this.exception;
		}
		return null;
	}

	private class TalendException extends Exception {

		private static final long serialVersionUID = 1L;

		private java.util.Map<String, Object> globalMap = null;
		private Exception e = null;
		private String currentComponent = null;
		private String virtualComponentName = null;

		public void setVirtualComponentName(String virtualComponentName) {
			this.virtualComponentName = virtualComponentName;
		}

		private TalendException(Exception e, String errorComponent, final java.util.Map<String, Object> globalMap) {
			this.currentComponent = errorComponent;
			this.globalMap = globalMap;
			this.e = e;
		}

		public Exception getException() {
			return this.e;
		}

		public String getCurrentComponent() {
			return this.currentComponent;
		}

		public String getExceptionCauseMessage(Exception e) {
			Throwable cause = e;
			String message = null;
			int i = 10;
			while (null != cause && 0 < i--) {
				message = cause.getMessage();
				if (null == message) {
					cause = cause.getCause();
				} else {
					break;
				}
			}
			if (null == message) {
				message = e.getClass().getName();
			}
			return message;
		}

		@Override
		public void printStackTrace() {
			if (!(e instanceof TalendException || e instanceof TDieException)) {
				if (virtualComponentName != null && currentComponent.indexOf(virtualComponentName + "_") == 0) {
					globalMap.put(virtualComponentName + "_ERROR_MESSAGE", getExceptionCauseMessage(e));
				}
				globalMap.put(currentComponent + "_ERROR_MESSAGE", getExceptionCauseMessage(e));
				System.err.println("Exception in component " + currentComponent + " (" + jobName + ")");
			}
			if (!(e instanceof TDieException)) {
				if (e instanceof TalendException) {
					e.printStackTrace();
				} else {
					e.printStackTrace();
					e.printStackTrace(errorMessagePS);
					C_ALIM_ODS.this.exception = e;
				}
			}
			if (!(e instanceof TalendException)) {
				try {
					for (java.lang.reflect.Method m : this.getClass().getEnclosingClass().getMethods()) {
						if (m.getName().compareTo(currentComponent + "_error") == 0) {
							m.invoke(C_ALIM_ODS.this, new Object[] { e, currentComponent, globalMap });
							break;
						}
					}

					if (!(e instanceof TDieException)) {
					}
				} catch (Exception e) {
					this.e.printStackTrace();
				}
			}
		}
	}

	public void tDBRow_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		tStatCatcher_1.addMessage("failure", errorComponent,
				end_Hash.get(errorComponent) - start_Hash.get(errorComponent));
		tStatCatcher_1Process(globalMap);

		status = "failure";

		tDBRow_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBInput_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		tStatCatcher_1.addMessage("failure", errorComponent,
				end_Hash.get(errorComponent) - start_Hash.get(errorComponent));
		tStatCatcher_1Process(globalMap);

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tUniqRow_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tLogRow_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tJava_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		tStatCatcher_1.addMessage("failure", errorComponent,
				end_Hash.get(errorComponent) - start_Hash.get(errorComponent));
		tStatCatcher_1Process(globalMap);

		status = "failure";

		tJava_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tExtractJSONFields_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		tStatCatcher_1.addMessage("failure", errorComponent,
				end_Hash.get(errorComponent) - start_Hash.get(errorComponent));
		tStatCatcher_1Process(globalMap);

		status = "failure";

		tExtractJSONFields_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBOutput_2_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		tStatCatcher_1.addMessage("failure", errorComponent,
				end_Hash.get(errorComponent) - start_Hash.get(errorComponent));
		tStatCatcher_1Process(globalMap);

		status = "failure";

		tDBOutput_2_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tStatCatcher_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tStatCatcher_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBOutput_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tStatCatcher_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBRow_1_onSubJobError(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tDBInput_1_onSubJobError(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tJava_1_onSubJobError(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tExtractJSONFields_1_onSubJobError(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tDBOutput_2_onSubJobError(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tStatCatcher_1_onSubJobError(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tDBRow_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tDBRow_1_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				/**
				 * [tDBRow_1 begin ] start
				 */

				ok_Hash.put("tDBRow_1", false);
				start_Hash.put("tDBRow_1", System.currentTimeMillis());

				tStatCatcher_1.addMessage("begin", "tDBRow_1");
				tStatCatcher_1Process(globalMap);

				currentComponent = "tDBRow_1";

				int tos_count_tDBRow_1 = 0;

				java.sql.Connection conn_tDBRow_1 = null;
				String query_tDBRow_1 = "";
				boolean whetherReject_tDBRow_1 = false;
				String driverClass_tDBRow_1 = "org.postgresql.Driver";
				java.lang.Class jdbcclazz_tDBRow_1 = java.lang.Class.forName(driverClass_tDBRow_1);

				String url_tDBRow_1 = "jdbc:postgresql://" + "localhost" + ":" + "5432" + "/" + "postgres";

				String dbUser_tDBRow_1 = "dsid_cc2_tos_rw";

				final String decryptedPassword_tDBRow_1 = routines.system.PasswordEncryptUtil
						.decryptPassword("enc:routine.encryption.key.v1:WFTWn940UcHwhSWSgbke2mBmEIomz3XFxD/M73X7PaA=");

				String dbPwd_tDBRow_1 = decryptedPassword_tDBRow_1;

				conn_tDBRow_1 = java.sql.DriverManager.getConnection(url_tDBRow_1, dbUser_tDBRow_1, dbPwd_tDBRow_1);

				resourceMap.put("conn_tDBRow_1", conn_tDBRow_1);
				if (conn_tDBRow_1.getAutoCommit()) {

					conn_tDBRow_1.setAutoCommit(false);

				}
				int commitEvery_tDBRow_1 = 10000;
				int commitCounter_tDBRow_1 = 0;

				java.sql.Statement stmt_tDBRow_1 = conn_tDBRow_1.createStatement();
				resourceMap.put("stmt_tDBRow_1", stmt_tDBRow_1);

				/**
				 * [tDBRow_1 begin ] stop
				 */

				/**
				 * [tDBRow_1 main ] start
				 */

				currentComponent = "tDBRow_1";

				query_tDBRow_1 = "TRUNCATE TABLE dsid_liv_wrk.dm2_ods";
				whetherReject_tDBRow_1 = false;
				globalMap.put("tDBRow_1_QUERY", query_tDBRow_1);
				try {
					stmt_tDBRow_1.execute(query_tDBRow_1);

				} catch (java.lang.Exception e) {
					whetherReject_tDBRow_1 = true;

					System.err.print(e.getMessage());
					globalMap.put("tDBRow_1_ERROR_MESSAGE", e.getMessage());

				}

				if (!whetherReject_tDBRow_1) {

				}

				commitCounter_tDBRow_1++;
				if (commitEvery_tDBRow_1 <= commitCounter_tDBRow_1) {

					conn_tDBRow_1.commit();

					commitCounter_tDBRow_1 = 0;
				}

				tos_count_tDBRow_1++;

				/**
				 * [tDBRow_1 main ] stop
				 */

				/**
				 * [tDBRow_1 process_data_begin ] start
				 */

				currentComponent = "tDBRow_1";

				/**
				 * [tDBRow_1 process_data_begin ] stop
				 */

				/**
				 * [tDBRow_1 process_data_end ] start
				 */

				currentComponent = "tDBRow_1";

				/**
				 * [tDBRow_1 process_data_end ] stop
				 */

				/**
				 * [tDBRow_1 end ] start
				 */

				currentComponent = "tDBRow_1";

				stmt_tDBRow_1.close();
				resourceMap.remove("stmt_tDBRow_1");
				resourceMap.put("statementClosed_tDBRow_1", true);
				if (commitEvery_tDBRow_1 > commitCounter_tDBRow_1) {

					conn_tDBRow_1.commit();

					commitCounter_tDBRow_1 = 0;

				}
				conn_tDBRow_1.close();

				if ("com.mysql.cj.jdbc.Driver".equals((String) globalMap.get("driverClass_"))
						&& routines.system.BundleUtils.inOSGi()) {
					Class.forName("com.mysql.cj.jdbc.AbandonedConnectionCleanupThread").getMethod("checkedShutdown")
							.invoke(null, (Object[]) null);
				}

				resourceMap.put("finish_tDBRow_1", true);

				ok_Hash.put("tDBRow_1", true);
				end_Hash.put("tDBRow_1", System.currentTimeMillis());

				tStatCatcher_1.addMessage("end", "tDBRow_1", end_Hash.get("tDBRow_1") - start_Hash.get("tDBRow_1"));
				tStatCatcher_1Process(globalMap);
				if (execStat) {
					runStat.updateStatOnConnection("OnComponentOk1", 0, "ok");
				}
				tDBInput_1Process(globalMap);

				/**
				 * [tDBRow_1 end ] stop
				 */
			} // end the resume

		} catch (java.lang.Exception e) {

			TalendException te = new TalendException(e, currentComponent, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			try {

				/**
				 * [tDBRow_1 finally ] start
				 */

				currentComponent = "tDBRow_1";

				try {
					if (resourceMap.get("statementClosed_tDBRow_1") == null) {
						java.sql.Statement stmtToClose_tDBRow_1 = null;
						if ((stmtToClose_tDBRow_1 = (java.sql.Statement) resourceMap.remove("stmt_tDBRow_1")) != null) {
							stmtToClose_tDBRow_1.close();
						}
					}
				} finally {
					if (resourceMap.get("finish_tDBRow_1") == null) {
						java.sql.Connection ctn_tDBRow_1 = null;
						if ((ctn_tDBRow_1 = (java.sql.Connection) resourceMap.get("conn_tDBRow_1")) != null) {
							try {
								ctn_tDBRow_1.close();
							} catch (java.sql.SQLException sqlEx_tDBRow_1) {
								String errorMessage_tDBRow_1 = "failed to close the connection in tDBRow_1 :"
										+ sqlEx_tDBRow_1.getMessage();
								System.err.println(errorMessage_tDBRow_1);
							}
						}
					}
				}

				/**
				 * [tDBRow_1 finally ] stop
				 */
			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tDBRow_1_SUBPROCESS_STATE", 1);
	}

	public static class row7Struct implements routines.system.IPersistableRow<row7Struct> {
		final static byte[] commonByteArrayLock_ALIMENTATION_DM2_C_ALIM_ODS = new byte[0];
		static byte[] commonByteArray_ALIMENTATION_DM2_C_ALIM_ODS = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public int id_staging_dm2;

		public int getId_staging_dm2() {
			return this.id_staging_dm2;
		}

		public Integer id_adresse_norm_client;

		public Integer getId_adresse_norm_client() {
			return this.id_adresse_norm_client;
		}

		public String numero_voie;

		public String getNumero_voie() {
			return this.numero_voie;
		}

		public String nom_voie;

		public String getNom_voie() {
			return this.nom_voie;
		}

		public String code_postal;

		public String getCode_postal() {
			return this.code_postal;
		}

		public String nom_ville;

		public String getNom_ville() {
			return this.nom_ville;
		}

		public String longitude;

		public String getLongitude() {
			return this.longitude;
		}

		public String latitude;

		public String getLatitude() {
			return this.latitude;
		}

		public Integer id_restaurant;

		public Integer getId_restaurant() {
			return this.id_restaurant;
		}

		public String code_restaurant;

		public String getCode_restaurant() {
			return this.code_restaurant;
		}

		public String raison_sociale_restaurant;

		public String getRaison_sociale_restaurant() {
			return this.raison_sociale_restaurant;
		}

		public Integer id_adresse_norm_restaurant;

		public Integer getId_adresse_norm_restaurant() {
			return this.id_adresse_norm_restaurant;
		}

		public String numero_voie_restau;

		public String getNumero_voie_restau() {
			return this.numero_voie_restau;
		}

		public String nom_voie_restau;

		public String getNom_voie_restau() {
			return this.nom_voie_restau;
		}

		public String code_postal_restau;

		public String getCode_postal_restau() {
			return this.code_postal_restau;
		}

		public String nom_ville_restau;

		public String getNom_ville_restau() {
			return this.nom_ville_restau;
		}

		public String longitude_restau;

		public String getLongitude_restau() {
			return this.longitude_restau;
		}

		public String latitude_restau;

		public String getLatitude_restau() {
			return this.latitude_restau;
		}

		public Integer id_client;

		public Integer getId_client() {
			return this.id_client;
		}

		public Integer id_livraison;

		public Integer getId_livraison() {
			return this.id_livraison;
		}

		public Integer id_commande;

		public Integer getId_commande() {
			return this.id_commande;
		}

		public Integer numero_commande;

		public Integer getNumero_commande() {
			return this.numero_commande;
		}

		public java.util.Date date_commande;

		public java.util.Date getDate_commande() {
			return this.date_commande;
		}

		public Float montant_total;

		public Float getMontant_total() {
			return this.montant_total;
		}

		public Integer id_menu;

		public Integer getId_menu() {
			return this.id_menu;
		}

		public String code_menu;

		public String getCode_menu() {
			return this.code_menu;
		}

		public String libelle_menu;

		public String getLibelle_menu() {
			return this.libelle_menu;
		}

		public Integer nombre_articles;

		public Integer getNombre_articles() {
			return this.nombre_articles;
		}

		public Integer temps_theo_preparation;

		public Integer getTemps_theo_preparation() {
			return this.temps_theo_preparation;
		}

		public Integer numero_livraison;

		public Integer getNumero_livraison() {
			return this.numero_livraison;
		}

		public java.util.Date date_debut_livraison;

		public java.util.Date getDate_debut_livraison() {
			return this.date_debut_livraison;
		}

		public java.util.Date date_fin_livraison;

		public java.util.Date getDate_fin_livraison() {
			return this.date_fin_livraison;
		}

		public Integer id_livreur;

		public Integer getId_livreur() {
			return this.id_livreur;
		}

		public String nom_livreur;

		public String getNom_livreur() {
			return this.nom_livreur;
		}

		public String prenom_livreur;

		public String getPrenom_livreur() {
			return this.prenom_livreur;
		}

		public Integer id_moyen_livraison;

		public Integer getId_moyen_livraison() {
			return this.id_moyen_livraison;
		}

		public String code_moyen_livraison;

		public String getCode_moyen_livraison() {
			return this.code_moyen_livraison;
		}

		public String libelle_moyen_livraison;

		public String getLibelle_moyen_livraison() {
			return this.libelle_moyen_livraison;
		}

		public String nom_client;

		public String getNom_client() {
			return this.nom_client;
		}

		public String prenom_client;

		public String getPrenom_client() {
			return this.prenom_client;
		}

		public Integer id_preparation;

		public Integer getId_preparation() {
			return this.id_preparation;
		}

		public java.util.Date date_debut_preparation;

		public java.util.Date getDate_debut_preparation() {
			return this.date_debut_preparation;
		}

		public java.util.Date date_fin_preparation;

		public java.util.Date getDate_fin_preparation() {
			return this.date_fin_preparation;
		}

		public Integer nombre_article_livres;

		public Integer getNombre_article_livres() {
			return this.nombre_article_livres;
		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + (int) this.id_staging_dm2;

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final row7Struct other = (row7Struct) obj;

			if (this.id_staging_dm2 != other.id_staging_dm2)
				return false;

			return true;
		}

		public void copyDataTo(row7Struct other) {

			other.id_staging_dm2 = this.id_staging_dm2;
			other.id_adresse_norm_client = this.id_adresse_norm_client;
			other.numero_voie = this.numero_voie;
			other.nom_voie = this.nom_voie;
			other.code_postal = this.code_postal;
			other.nom_ville = this.nom_ville;
			other.longitude = this.longitude;
			other.latitude = this.latitude;
			other.id_restaurant = this.id_restaurant;
			other.code_restaurant = this.code_restaurant;
			other.raison_sociale_restaurant = this.raison_sociale_restaurant;
			other.id_adresse_norm_restaurant = this.id_adresse_norm_restaurant;
			other.numero_voie_restau = this.numero_voie_restau;
			other.nom_voie_restau = this.nom_voie_restau;
			other.code_postal_restau = this.code_postal_restau;
			other.nom_ville_restau = this.nom_ville_restau;
			other.longitude_restau = this.longitude_restau;
			other.latitude_restau = this.latitude_restau;
			other.id_client = this.id_client;
			other.id_livraison = this.id_livraison;
			other.id_commande = this.id_commande;
			other.numero_commande = this.numero_commande;
			other.date_commande = this.date_commande;
			other.montant_total = this.montant_total;
			other.id_menu = this.id_menu;
			other.code_menu = this.code_menu;
			other.libelle_menu = this.libelle_menu;
			other.nombre_articles = this.nombre_articles;
			other.temps_theo_preparation = this.temps_theo_preparation;
			other.numero_livraison = this.numero_livraison;
			other.date_debut_livraison = this.date_debut_livraison;
			other.date_fin_livraison = this.date_fin_livraison;
			other.id_livreur = this.id_livreur;
			other.nom_livreur = this.nom_livreur;
			other.prenom_livreur = this.prenom_livreur;
			other.id_moyen_livraison = this.id_moyen_livraison;
			other.code_moyen_livraison = this.code_moyen_livraison;
			other.libelle_moyen_livraison = this.libelle_moyen_livraison;
			other.nom_client = this.nom_client;
			other.prenom_client = this.prenom_client;
			other.id_preparation = this.id_preparation;
			other.date_debut_preparation = this.date_debut_preparation;
			other.date_fin_preparation = this.date_fin_preparation;
			other.nombre_article_livres = this.nombre_article_livres;

		}

		public void copyKeysDataTo(row7Struct other) {

			other.id_staging_dm2 = this.id_staging_dm2;

		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_ALIMENTATION_DM2_C_ALIM_ODS.length) {
					if (length < 1024 && commonByteArray_ALIMENTATION_DM2_C_ALIM_ODS.length == 0) {
						commonByteArray_ALIMENTATION_DM2_C_ALIM_ODS = new byte[1024];
					} else {
						commonByteArray_ALIMENTATION_DM2_C_ALIM_ODS = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_ALIMENTATION_DM2_C_ALIM_ODS, 0, length);
				strReturn = new String(commonByteArray_ALIMENTATION_DM2_C_ALIM_ODS, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_ALIMENTATION_DM2_C_ALIM_ODS.length) {
					if (length < 1024 && commonByteArray_ALIMENTATION_DM2_C_ALIM_ODS.length == 0) {
						commonByteArray_ALIMENTATION_DM2_C_ALIM_ODS = new byte[1024];
					} else {
						commonByteArray_ALIMENTATION_DM2_C_ALIM_ODS = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_ALIMENTATION_DM2_C_ALIM_ODS, 0, length);
				strReturn = new String(commonByteArray_ALIMENTATION_DM2_C_ALIM_ODS, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_ALIMENTATION_DM2_C_ALIM_ODS) {

				try {

					int length = 0;

					this.id_staging_dm2 = dis.readInt();

					this.id_adresse_norm_client = readInteger(dis);

					this.numero_voie = readString(dis);

					this.nom_voie = readString(dis);

					this.code_postal = readString(dis);

					this.nom_ville = readString(dis);

					this.longitude = readString(dis);

					this.latitude = readString(dis);

					this.id_restaurant = readInteger(dis);

					this.code_restaurant = readString(dis);

					this.raison_sociale_restaurant = readString(dis);

					this.id_adresse_norm_restaurant = readInteger(dis);

					this.numero_voie_restau = readString(dis);

					this.nom_voie_restau = readString(dis);

					this.code_postal_restau = readString(dis);

					this.nom_ville_restau = readString(dis);

					this.longitude_restau = readString(dis);

					this.latitude_restau = readString(dis);

					this.id_client = readInteger(dis);

					this.id_livraison = readInteger(dis);

					this.id_commande = readInteger(dis);

					this.numero_commande = readInteger(dis);

					this.date_commande = readDate(dis);

					length = dis.readByte();
					if (length == -1) {
						this.montant_total = null;
					} else {
						this.montant_total = dis.readFloat();
					}

					this.id_menu = readInteger(dis);

					this.code_menu = readString(dis);

					this.libelle_menu = readString(dis);

					this.nombre_articles = readInteger(dis);

					this.temps_theo_preparation = readInteger(dis);

					this.numero_livraison = readInteger(dis);

					this.date_debut_livraison = readDate(dis);

					this.date_fin_livraison = readDate(dis);

					this.id_livreur = readInteger(dis);

					this.nom_livreur = readString(dis);

					this.prenom_livreur = readString(dis);

					this.id_moyen_livraison = readInteger(dis);

					this.code_moyen_livraison = readString(dis);

					this.libelle_moyen_livraison = readString(dis);

					this.nom_client = readString(dis);

					this.prenom_client = readString(dis);

					this.id_preparation = readInteger(dis);

					this.date_debut_preparation = readDate(dis);

					this.date_fin_preparation = readDate(dis);

					this.nombre_article_livres = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_ALIMENTATION_DM2_C_ALIM_ODS) {

				try {

					int length = 0;

					this.id_staging_dm2 = dis.readInt();

					this.id_adresse_norm_client = readInteger(dis);

					this.numero_voie = readString(dis);

					this.nom_voie = readString(dis);

					this.code_postal = readString(dis);

					this.nom_ville = readString(dis);

					this.longitude = readString(dis);

					this.latitude = readString(dis);

					this.id_restaurant = readInteger(dis);

					this.code_restaurant = readString(dis);

					this.raison_sociale_restaurant = readString(dis);

					this.id_adresse_norm_restaurant = readInteger(dis);

					this.numero_voie_restau = readString(dis);

					this.nom_voie_restau = readString(dis);

					this.code_postal_restau = readString(dis);

					this.nom_ville_restau = readString(dis);

					this.longitude_restau = readString(dis);

					this.latitude_restau = readString(dis);

					this.id_client = readInteger(dis);

					this.id_livraison = readInteger(dis);

					this.id_commande = readInteger(dis);

					this.numero_commande = readInteger(dis);

					this.date_commande = readDate(dis);

					length = dis.readByte();
					if (length == -1) {
						this.montant_total = null;
					} else {
						this.montant_total = dis.readFloat();
					}

					this.id_menu = readInteger(dis);

					this.code_menu = readString(dis);

					this.libelle_menu = readString(dis);

					this.nombre_articles = readInteger(dis);

					this.temps_theo_preparation = readInteger(dis);

					this.numero_livraison = readInteger(dis);

					this.date_debut_livraison = readDate(dis);

					this.date_fin_livraison = readDate(dis);

					this.id_livreur = readInteger(dis);

					this.nom_livreur = readString(dis);

					this.prenom_livreur = readString(dis);

					this.id_moyen_livraison = readInteger(dis);

					this.code_moyen_livraison = readString(dis);

					this.libelle_moyen_livraison = readString(dis);

					this.nom_client = readString(dis);

					this.prenom_client = readString(dis);

					this.id_preparation = readInteger(dis);

					this.date_debut_preparation = readDate(dis);

					this.date_fin_preparation = readDate(dis);

					this.nombre_article_livres = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// int

				dos.writeInt(this.id_staging_dm2);

				// Integer

				writeInteger(this.id_adresse_norm_client, dos);

				// String

				writeString(this.numero_voie, dos);

				// String

				writeString(this.nom_voie, dos);

				// String

				writeString(this.code_postal, dos);

				// String

				writeString(this.nom_ville, dos);

				// String

				writeString(this.longitude, dos);

				// String

				writeString(this.latitude, dos);

				// Integer

				writeInteger(this.id_restaurant, dos);

				// String

				writeString(this.code_restaurant, dos);

				// String

				writeString(this.raison_sociale_restaurant, dos);

				// Integer

				writeInteger(this.id_adresse_norm_restaurant, dos);

				// String

				writeString(this.numero_voie_restau, dos);

				// String

				writeString(this.nom_voie_restau, dos);

				// String

				writeString(this.code_postal_restau, dos);

				// String

				writeString(this.nom_ville_restau, dos);

				// String

				writeString(this.longitude_restau, dos);

				// String

				writeString(this.latitude_restau, dos);

				// Integer

				writeInteger(this.id_client, dos);

				// Integer

				writeInteger(this.id_livraison, dos);

				// Integer

				writeInteger(this.id_commande, dos);

				// Integer

				writeInteger(this.numero_commande, dos);

				// java.util.Date

				writeDate(this.date_commande, dos);

				// Float

				if (this.montant_total == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.montant_total);
				}

				// Integer

				writeInteger(this.id_menu, dos);

				// String

				writeString(this.code_menu, dos);

				// String

				writeString(this.libelle_menu, dos);

				// Integer

				writeInteger(this.nombre_articles, dos);

				// Integer

				writeInteger(this.temps_theo_preparation, dos);

				// Integer

				writeInteger(this.numero_livraison, dos);

				// java.util.Date

				writeDate(this.date_debut_livraison, dos);

				// java.util.Date

				writeDate(this.date_fin_livraison, dos);

				// Integer

				writeInteger(this.id_livreur, dos);

				// String

				writeString(this.nom_livreur, dos);

				// String

				writeString(this.prenom_livreur, dos);

				// Integer

				writeInteger(this.id_moyen_livraison, dos);

				// String

				writeString(this.code_moyen_livraison, dos);

				// String

				writeString(this.libelle_moyen_livraison, dos);

				// String

				writeString(this.nom_client, dos);

				// String

				writeString(this.prenom_client, dos);

				// Integer

				writeInteger(this.id_preparation, dos);

				// java.util.Date

				writeDate(this.date_debut_preparation, dos);

				// java.util.Date

				writeDate(this.date_fin_preparation, dos);

				// Integer

				writeInteger(this.nombre_article_livres, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// int

				dos.writeInt(this.id_staging_dm2);

				// Integer

				writeInteger(this.id_adresse_norm_client, dos);

				// String

				writeString(this.numero_voie, dos);

				// String

				writeString(this.nom_voie, dos);

				// String

				writeString(this.code_postal, dos);

				// String

				writeString(this.nom_ville, dos);

				// String

				writeString(this.longitude, dos);

				// String

				writeString(this.latitude, dos);

				// Integer

				writeInteger(this.id_restaurant, dos);

				// String

				writeString(this.code_restaurant, dos);

				// String

				writeString(this.raison_sociale_restaurant, dos);

				// Integer

				writeInteger(this.id_adresse_norm_restaurant, dos);

				// String

				writeString(this.numero_voie_restau, dos);

				// String

				writeString(this.nom_voie_restau, dos);

				// String

				writeString(this.code_postal_restau, dos);

				// String

				writeString(this.nom_ville_restau, dos);

				// String

				writeString(this.longitude_restau, dos);

				// String

				writeString(this.latitude_restau, dos);

				// Integer

				writeInteger(this.id_client, dos);

				// Integer

				writeInteger(this.id_livraison, dos);

				// Integer

				writeInteger(this.id_commande, dos);

				// Integer

				writeInteger(this.numero_commande, dos);

				// java.util.Date

				writeDate(this.date_commande, dos);

				// Float

				if (this.montant_total == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.montant_total);
				}

				// Integer

				writeInteger(this.id_menu, dos);

				// String

				writeString(this.code_menu, dos);

				// String

				writeString(this.libelle_menu, dos);

				// Integer

				writeInteger(this.nombre_articles, dos);

				// Integer

				writeInteger(this.temps_theo_preparation, dos);

				// Integer

				writeInteger(this.numero_livraison, dos);

				// java.util.Date

				writeDate(this.date_debut_livraison, dos);

				// java.util.Date

				writeDate(this.date_fin_livraison, dos);

				// Integer

				writeInteger(this.id_livreur, dos);

				// String

				writeString(this.nom_livreur, dos);

				// String

				writeString(this.prenom_livreur, dos);

				// Integer

				writeInteger(this.id_moyen_livraison, dos);

				// String

				writeString(this.code_moyen_livraison, dos);

				// String

				writeString(this.libelle_moyen_livraison, dos);

				// String

				writeString(this.nom_client, dos);

				// String

				writeString(this.prenom_client, dos);

				// Integer

				writeInteger(this.id_preparation, dos);

				// java.util.Date

				writeDate(this.date_debut_preparation, dos);

				// java.util.Date

				writeDate(this.date_fin_preparation, dos);

				// Integer

				writeInteger(this.nombre_article_livres, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("id_staging_dm2=" + String.valueOf(id_staging_dm2));
			sb.append(",id_adresse_norm_client=" + String.valueOf(id_adresse_norm_client));
			sb.append(",numero_voie=" + numero_voie);
			sb.append(",nom_voie=" + nom_voie);
			sb.append(",code_postal=" + code_postal);
			sb.append(",nom_ville=" + nom_ville);
			sb.append(",longitude=" + longitude);
			sb.append(",latitude=" + latitude);
			sb.append(",id_restaurant=" + String.valueOf(id_restaurant));
			sb.append(",code_restaurant=" + code_restaurant);
			sb.append(",raison_sociale_restaurant=" + raison_sociale_restaurant);
			sb.append(",id_adresse_norm_restaurant=" + String.valueOf(id_adresse_norm_restaurant));
			sb.append(",numero_voie_restau=" + numero_voie_restau);
			sb.append(",nom_voie_restau=" + nom_voie_restau);
			sb.append(",code_postal_restau=" + code_postal_restau);
			sb.append(",nom_ville_restau=" + nom_ville_restau);
			sb.append(",longitude_restau=" + longitude_restau);
			sb.append(",latitude_restau=" + latitude_restau);
			sb.append(",id_client=" + String.valueOf(id_client));
			sb.append(",id_livraison=" + String.valueOf(id_livraison));
			sb.append(",id_commande=" + String.valueOf(id_commande));
			sb.append(",numero_commande=" + String.valueOf(numero_commande));
			sb.append(",date_commande=" + String.valueOf(date_commande));
			sb.append(",montant_total=" + String.valueOf(montant_total));
			sb.append(",id_menu=" + String.valueOf(id_menu));
			sb.append(",code_menu=" + code_menu);
			sb.append(",libelle_menu=" + libelle_menu);
			sb.append(",nombre_articles=" + String.valueOf(nombre_articles));
			sb.append(",temps_theo_preparation=" + String.valueOf(temps_theo_preparation));
			sb.append(",numero_livraison=" + String.valueOf(numero_livraison));
			sb.append(",date_debut_livraison=" + String.valueOf(date_debut_livraison));
			sb.append(",date_fin_livraison=" + String.valueOf(date_fin_livraison));
			sb.append(",id_livreur=" + String.valueOf(id_livreur));
			sb.append(",nom_livreur=" + nom_livreur);
			sb.append(",prenom_livreur=" + prenom_livreur);
			sb.append(",id_moyen_livraison=" + String.valueOf(id_moyen_livraison));
			sb.append(",code_moyen_livraison=" + code_moyen_livraison);
			sb.append(",libelle_moyen_livraison=" + libelle_moyen_livraison);
			sb.append(",nom_client=" + nom_client);
			sb.append(",prenom_client=" + prenom_client);
			sb.append(",id_preparation=" + String.valueOf(id_preparation));
			sb.append(",date_debut_preparation=" + String.valueOf(date_debut_preparation));
			sb.append(",date_fin_preparation=" + String.valueOf(date_fin_preparation));
			sb.append(",nombre_article_livres=" + String.valueOf(nombre_article_livres));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row7Struct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.id_staging_dm2, other.id_staging_dm2);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row2Struct implements routines.system.IPersistableRow<row2Struct> {
		final static byte[] commonByteArrayLock_ALIMENTATION_DM2_C_ALIM_ODS = new byte[0];
		static byte[] commonByteArray_ALIMENTATION_DM2_C_ALIM_ODS = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public int id_staging_dm2;

		public int getId_staging_dm2() {
			return this.id_staging_dm2;
		}

		public Integer id_adresse_norm_client;

		public Integer getId_adresse_norm_client() {
			return this.id_adresse_norm_client;
		}

		public String numero_voie;

		public String getNumero_voie() {
			return this.numero_voie;
		}

		public String nom_voie;

		public String getNom_voie() {
			return this.nom_voie;
		}

		public String code_postal;

		public String getCode_postal() {
			return this.code_postal;
		}

		public String nom_ville;

		public String getNom_ville() {
			return this.nom_ville;
		}

		public String longitude;

		public String getLongitude() {
			return this.longitude;
		}

		public String latitude;

		public String getLatitude() {
			return this.latitude;
		}

		public Integer id_restaurant;

		public Integer getId_restaurant() {
			return this.id_restaurant;
		}

		public String code_restaurant;

		public String getCode_restaurant() {
			return this.code_restaurant;
		}

		public String raison_sociale_restaurant;

		public String getRaison_sociale_restaurant() {
			return this.raison_sociale_restaurant;
		}

		public Integer id_adresse_norm_restaurant;

		public Integer getId_adresse_norm_restaurant() {
			return this.id_adresse_norm_restaurant;
		}

		public String numero_voie_restau;

		public String getNumero_voie_restau() {
			return this.numero_voie_restau;
		}

		public String nom_voie_restau;

		public String getNom_voie_restau() {
			return this.nom_voie_restau;
		}

		public String code_postal_restau;

		public String getCode_postal_restau() {
			return this.code_postal_restau;
		}

		public String nom_ville_restau;

		public String getNom_ville_restau() {
			return this.nom_ville_restau;
		}

		public String longitude_restau;

		public String getLongitude_restau() {
			return this.longitude_restau;
		}

		public String latitude_restau;

		public String getLatitude_restau() {
			return this.latitude_restau;
		}

		public Integer id_client;

		public Integer getId_client() {
			return this.id_client;
		}

		public Integer id_livraison;

		public Integer getId_livraison() {
			return this.id_livraison;
		}

		public Integer id_commande;

		public Integer getId_commande() {
			return this.id_commande;
		}

		public Integer numero_commande;

		public Integer getNumero_commande() {
			return this.numero_commande;
		}

		public java.util.Date date_commande;

		public java.util.Date getDate_commande() {
			return this.date_commande;
		}

		public Float montant_total;

		public Float getMontant_total() {
			return this.montant_total;
		}

		public Integer id_menu;

		public Integer getId_menu() {
			return this.id_menu;
		}

		public String code_menu;

		public String getCode_menu() {
			return this.code_menu;
		}

		public String libelle_menu;

		public String getLibelle_menu() {
			return this.libelle_menu;
		}

		public Integer nombre_articles;

		public Integer getNombre_articles() {
			return this.nombre_articles;
		}

		public Integer temps_theo_preparation;

		public Integer getTemps_theo_preparation() {
			return this.temps_theo_preparation;
		}

		public Integer numero_livraison;

		public Integer getNumero_livraison() {
			return this.numero_livraison;
		}

		public java.util.Date date_debut_livraison;

		public java.util.Date getDate_debut_livraison() {
			return this.date_debut_livraison;
		}

		public java.util.Date date_fin_livraison;

		public java.util.Date getDate_fin_livraison() {
			return this.date_fin_livraison;
		}

		public Integer id_livreur;

		public Integer getId_livreur() {
			return this.id_livreur;
		}

		public String nom_livreur;

		public String getNom_livreur() {
			return this.nom_livreur;
		}

		public String prenom_livreur;

		public String getPrenom_livreur() {
			return this.prenom_livreur;
		}

		public Integer id_moyen_livraison;

		public Integer getId_moyen_livraison() {
			return this.id_moyen_livraison;
		}

		public String code_moyen_livraison;

		public String getCode_moyen_livraison() {
			return this.code_moyen_livraison;
		}

		public String libelle_moyen_livraison;

		public String getLibelle_moyen_livraison() {
			return this.libelle_moyen_livraison;
		}

		public String nom_client;

		public String getNom_client() {
			return this.nom_client;
		}

		public String prenom_client;

		public String getPrenom_client() {
			return this.prenom_client;
		}

		public Integer id_preparation;

		public Integer getId_preparation() {
			return this.id_preparation;
		}

		public java.util.Date date_debut_preparation;

		public java.util.Date getDate_debut_preparation() {
			return this.date_debut_preparation;
		}

		public java.util.Date date_fin_preparation;

		public java.util.Date getDate_fin_preparation() {
			return this.date_fin_preparation;
		}

		public Integer nombre_article_livres;

		public Integer getNombre_article_livres() {
			return this.nombre_article_livres;
		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + (int) this.id_staging_dm2;

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final row2Struct other = (row2Struct) obj;

			if (this.id_staging_dm2 != other.id_staging_dm2)
				return false;

			return true;
		}

		public void copyDataTo(row2Struct other) {

			other.id_staging_dm2 = this.id_staging_dm2;
			other.id_adresse_norm_client = this.id_adresse_norm_client;
			other.numero_voie = this.numero_voie;
			other.nom_voie = this.nom_voie;
			other.code_postal = this.code_postal;
			other.nom_ville = this.nom_ville;
			other.longitude = this.longitude;
			other.latitude = this.latitude;
			other.id_restaurant = this.id_restaurant;
			other.code_restaurant = this.code_restaurant;
			other.raison_sociale_restaurant = this.raison_sociale_restaurant;
			other.id_adresse_norm_restaurant = this.id_adresse_norm_restaurant;
			other.numero_voie_restau = this.numero_voie_restau;
			other.nom_voie_restau = this.nom_voie_restau;
			other.code_postal_restau = this.code_postal_restau;
			other.nom_ville_restau = this.nom_ville_restau;
			other.longitude_restau = this.longitude_restau;
			other.latitude_restau = this.latitude_restau;
			other.id_client = this.id_client;
			other.id_livraison = this.id_livraison;
			other.id_commande = this.id_commande;
			other.numero_commande = this.numero_commande;
			other.date_commande = this.date_commande;
			other.montant_total = this.montant_total;
			other.id_menu = this.id_menu;
			other.code_menu = this.code_menu;
			other.libelle_menu = this.libelle_menu;
			other.nombre_articles = this.nombre_articles;
			other.temps_theo_preparation = this.temps_theo_preparation;
			other.numero_livraison = this.numero_livraison;
			other.date_debut_livraison = this.date_debut_livraison;
			other.date_fin_livraison = this.date_fin_livraison;
			other.id_livreur = this.id_livreur;
			other.nom_livreur = this.nom_livreur;
			other.prenom_livreur = this.prenom_livreur;
			other.id_moyen_livraison = this.id_moyen_livraison;
			other.code_moyen_livraison = this.code_moyen_livraison;
			other.libelle_moyen_livraison = this.libelle_moyen_livraison;
			other.nom_client = this.nom_client;
			other.prenom_client = this.prenom_client;
			other.id_preparation = this.id_preparation;
			other.date_debut_preparation = this.date_debut_preparation;
			other.date_fin_preparation = this.date_fin_preparation;
			other.nombre_article_livres = this.nombre_article_livres;

		}

		public void copyKeysDataTo(row2Struct other) {

			other.id_staging_dm2 = this.id_staging_dm2;

		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_ALIMENTATION_DM2_C_ALIM_ODS.length) {
					if (length < 1024 && commonByteArray_ALIMENTATION_DM2_C_ALIM_ODS.length == 0) {
						commonByteArray_ALIMENTATION_DM2_C_ALIM_ODS = new byte[1024];
					} else {
						commonByteArray_ALIMENTATION_DM2_C_ALIM_ODS = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_ALIMENTATION_DM2_C_ALIM_ODS, 0, length);
				strReturn = new String(commonByteArray_ALIMENTATION_DM2_C_ALIM_ODS, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_ALIMENTATION_DM2_C_ALIM_ODS.length) {
					if (length < 1024 && commonByteArray_ALIMENTATION_DM2_C_ALIM_ODS.length == 0) {
						commonByteArray_ALIMENTATION_DM2_C_ALIM_ODS = new byte[1024];
					} else {
						commonByteArray_ALIMENTATION_DM2_C_ALIM_ODS = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_ALIMENTATION_DM2_C_ALIM_ODS, 0, length);
				strReturn = new String(commonByteArray_ALIMENTATION_DM2_C_ALIM_ODS, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_ALIMENTATION_DM2_C_ALIM_ODS) {

				try {

					int length = 0;

					this.id_staging_dm2 = dis.readInt();

					this.id_adresse_norm_client = readInteger(dis);

					this.numero_voie = readString(dis);

					this.nom_voie = readString(dis);

					this.code_postal = readString(dis);

					this.nom_ville = readString(dis);

					this.longitude = readString(dis);

					this.latitude = readString(dis);

					this.id_restaurant = readInteger(dis);

					this.code_restaurant = readString(dis);

					this.raison_sociale_restaurant = readString(dis);

					this.id_adresse_norm_restaurant = readInteger(dis);

					this.numero_voie_restau = readString(dis);

					this.nom_voie_restau = readString(dis);

					this.code_postal_restau = readString(dis);

					this.nom_ville_restau = readString(dis);

					this.longitude_restau = readString(dis);

					this.latitude_restau = readString(dis);

					this.id_client = readInteger(dis);

					this.id_livraison = readInteger(dis);

					this.id_commande = readInteger(dis);

					this.numero_commande = readInteger(dis);

					this.date_commande = readDate(dis);

					length = dis.readByte();
					if (length == -1) {
						this.montant_total = null;
					} else {
						this.montant_total = dis.readFloat();
					}

					this.id_menu = readInteger(dis);

					this.code_menu = readString(dis);

					this.libelle_menu = readString(dis);

					this.nombre_articles = readInteger(dis);

					this.temps_theo_preparation = readInteger(dis);

					this.numero_livraison = readInteger(dis);

					this.date_debut_livraison = readDate(dis);

					this.date_fin_livraison = readDate(dis);

					this.id_livreur = readInteger(dis);

					this.nom_livreur = readString(dis);

					this.prenom_livreur = readString(dis);

					this.id_moyen_livraison = readInteger(dis);

					this.code_moyen_livraison = readString(dis);

					this.libelle_moyen_livraison = readString(dis);

					this.nom_client = readString(dis);

					this.prenom_client = readString(dis);

					this.id_preparation = readInteger(dis);

					this.date_debut_preparation = readDate(dis);

					this.date_fin_preparation = readDate(dis);

					this.nombre_article_livres = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_ALIMENTATION_DM2_C_ALIM_ODS) {

				try {

					int length = 0;

					this.id_staging_dm2 = dis.readInt();

					this.id_adresse_norm_client = readInteger(dis);

					this.numero_voie = readString(dis);

					this.nom_voie = readString(dis);

					this.code_postal = readString(dis);

					this.nom_ville = readString(dis);

					this.longitude = readString(dis);

					this.latitude = readString(dis);

					this.id_restaurant = readInteger(dis);

					this.code_restaurant = readString(dis);

					this.raison_sociale_restaurant = readString(dis);

					this.id_adresse_norm_restaurant = readInteger(dis);

					this.numero_voie_restau = readString(dis);

					this.nom_voie_restau = readString(dis);

					this.code_postal_restau = readString(dis);

					this.nom_ville_restau = readString(dis);

					this.longitude_restau = readString(dis);

					this.latitude_restau = readString(dis);

					this.id_client = readInteger(dis);

					this.id_livraison = readInteger(dis);

					this.id_commande = readInteger(dis);

					this.numero_commande = readInteger(dis);

					this.date_commande = readDate(dis);

					length = dis.readByte();
					if (length == -1) {
						this.montant_total = null;
					} else {
						this.montant_total = dis.readFloat();
					}

					this.id_menu = readInteger(dis);

					this.code_menu = readString(dis);

					this.libelle_menu = readString(dis);

					this.nombre_articles = readInteger(dis);

					this.temps_theo_preparation = readInteger(dis);

					this.numero_livraison = readInteger(dis);

					this.date_debut_livraison = readDate(dis);

					this.date_fin_livraison = readDate(dis);

					this.id_livreur = readInteger(dis);

					this.nom_livreur = readString(dis);

					this.prenom_livreur = readString(dis);

					this.id_moyen_livraison = readInteger(dis);

					this.code_moyen_livraison = readString(dis);

					this.libelle_moyen_livraison = readString(dis);

					this.nom_client = readString(dis);

					this.prenom_client = readString(dis);

					this.id_preparation = readInteger(dis);

					this.date_debut_preparation = readDate(dis);

					this.date_fin_preparation = readDate(dis);

					this.nombre_article_livres = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// int

				dos.writeInt(this.id_staging_dm2);

				// Integer

				writeInteger(this.id_adresse_norm_client, dos);

				// String

				writeString(this.numero_voie, dos);

				// String

				writeString(this.nom_voie, dos);

				// String

				writeString(this.code_postal, dos);

				// String

				writeString(this.nom_ville, dos);

				// String

				writeString(this.longitude, dos);

				// String

				writeString(this.latitude, dos);

				// Integer

				writeInteger(this.id_restaurant, dos);

				// String

				writeString(this.code_restaurant, dos);

				// String

				writeString(this.raison_sociale_restaurant, dos);

				// Integer

				writeInteger(this.id_adresse_norm_restaurant, dos);

				// String

				writeString(this.numero_voie_restau, dos);

				// String

				writeString(this.nom_voie_restau, dos);

				// String

				writeString(this.code_postal_restau, dos);

				// String

				writeString(this.nom_ville_restau, dos);

				// String

				writeString(this.longitude_restau, dos);

				// String

				writeString(this.latitude_restau, dos);

				// Integer

				writeInteger(this.id_client, dos);

				// Integer

				writeInteger(this.id_livraison, dos);

				// Integer

				writeInteger(this.id_commande, dos);

				// Integer

				writeInteger(this.numero_commande, dos);

				// java.util.Date

				writeDate(this.date_commande, dos);

				// Float

				if (this.montant_total == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.montant_total);
				}

				// Integer

				writeInteger(this.id_menu, dos);

				// String

				writeString(this.code_menu, dos);

				// String

				writeString(this.libelle_menu, dos);

				// Integer

				writeInteger(this.nombre_articles, dos);

				// Integer

				writeInteger(this.temps_theo_preparation, dos);

				// Integer

				writeInteger(this.numero_livraison, dos);

				// java.util.Date

				writeDate(this.date_debut_livraison, dos);

				// java.util.Date

				writeDate(this.date_fin_livraison, dos);

				// Integer

				writeInteger(this.id_livreur, dos);

				// String

				writeString(this.nom_livreur, dos);

				// String

				writeString(this.prenom_livreur, dos);

				// Integer

				writeInteger(this.id_moyen_livraison, dos);

				// String

				writeString(this.code_moyen_livraison, dos);

				// String

				writeString(this.libelle_moyen_livraison, dos);

				// String

				writeString(this.nom_client, dos);

				// String

				writeString(this.prenom_client, dos);

				// Integer

				writeInteger(this.id_preparation, dos);

				// java.util.Date

				writeDate(this.date_debut_preparation, dos);

				// java.util.Date

				writeDate(this.date_fin_preparation, dos);

				// Integer

				writeInteger(this.nombre_article_livres, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// int

				dos.writeInt(this.id_staging_dm2);

				// Integer

				writeInteger(this.id_adresse_norm_client, dos);

				// String

				writeString(this.numero_voie, dos);

				// String

				writeString(this.nom_voie, dos);

				// String

				writeString(this.code_postal, dos);

				// String

				writeString(this.nom_ville, dos);

				// String

				writeString(this.longitude, dos);

				// String

				writeString(this.latitude, dos);

				// Integer

				writeInteger(this.id_restaurant, dos);

				// String

				writeString(this.code_restaurant, dos);

				// String

				writeString(this.raison_sociale_restaurant, dos);

				// Integer

				writeInteger(this.id_adresse_norm_restaurant, dos);

				// String

				writeString(this.numero_voie_restau, dos);

				// String

				writeString(this.nom_voie_restau, dos);

				// String

				writeString(this.code_postal_restau, dos);

				// String

				writeString(this.nom_ville_restau, dos);

				// String

				writeString(this.longitude_restau, dos);

				// String

				writeString(this.latitude_restau, dos);

				// Integer

				writeInteger(this.id_client, dos);

				// Integer

				writeInteger(this.id_livraison, dos);

				// Integer

				writeInteger(this.id_commande, dos);

				// Integer

				writeInteger(this.numero_commande, dos);

				// java.util.Date

				writeDate(this.date_commande, dos);

				// Float

				if (this.montant_total == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.montant_total);
				}

				// Integer

				writeInteger(this.id_menu, dos);

				// String

				writeString(this.code_menu, dos);

				// String

				writeString(this.libelle_menu, dos);

				// Integer

				writeInteger(this.nombre_articles, dos);

				// Integer

				writeInteger(this.temps_theo_preparation, dos);

				// Integer

				writeInteger(this.numero_livraison, dos);

				// java.util.Date

				writeDate(this.date_debut_livraison, dos);

				// java.util.Date

				writeDate(this.date_fin_livraison, dos);

				// Integer

				writeInteger(this.id_livreur, dos);

				// String

				writeString(this.nom_livreur, dos);

				// String

				writeString(this.prenom_livreur, dos);

				// Integer

				writeInteger(this.id_moyen_livraison, dos);

				// String

				writeString(this.code_moyen_livraison, dos);

				// String

				writeString(this.libelle_moyen_livraison, dos);

				// String

				writeString(this.nom_client, dos);

				// String

				writeString(this.prenom_client, dos);

				// Integer

				writeInteger(this.id_preparation, dos);

				// java.util.Date

				writeDate(this.date_debut_preparation, dos);

				// java.util.Date

				writeDate(this.date_fin_preparation, dos);

				// Integer

				writeInteger(this.nombre_article_livres, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("id_staging_dm2=" + String.valueOf(id_staging_dm2));
			sb.append(",id_adresse_norm_client=" + String.valueOf(id_adresse_norm_client));
			sb.append(",numero_voie=" + numero_voie);
			sb.append(",nom_voie=" + nom_voie);
			sb.append(",code_postal=" + code_postal);
			sb.append(",nom_ville=" + nom_ville);
			sb.append(",longitude=" + longitude);
			sb.append(",latitude=" + latitude);
			sb.append(",id_restaurant=" + String.valueOf(id_restaurant));
			sb.append(",code_restaurant=" + code_restaurant);
			sb.append(",raison_sociale_restaurant=" + raison_sociale_restaurant);
			sb.append(",id_adresse_norm_restaurant=" + String.valueOf(id_adresse_norm_restaurant));
			sb.append(",numero_voie_restau=" + numero_voie_restau);
			sb.append(",nom_voie_restau=" + nom_voie_restau);
			sb.append(",code_postal_restau=" + code_postal_restau);
			sb.append(",nom_ville_restau=" + nom_ville_restau);
			sb.append(",longitude_restau=" + longitude_restau);
			sb.append(",latitude_restau=" + latitude_restau);
			sb.append(",id_client=" + String.valueOf(id_client));
			sb.append(",id_livraison=" + String.valueOf(id_livraison));
			sb.append(",id_commande=" + String.valueOf(id_commande));
			sb.append(",numero_commande=" + String.valueOf(numero_commande));
			sb.append(",date_commande=" + String.valueOf(date_commande));
			sb.append(",montant_total=" + String.valueOf(montant_total));
			sb.append(",id_menu=" + String.valueOf(id_menu));
			sb.append(",code_menu=" + code_menu);
			sb.append(",libelle_menu=" + libelle_menu);
			sb.append(",nombre_articles=" + String.valueOf(nombre_articles));
			sb.append(",temps_theo_preparation=" + String.valueOf(temps_theo_preparation));
			sb.append(",numero_livraison=" + String.valueOf(numero_livraison));
			sb.append(",date_debut_livraison=" + String.valueOf(date_debut_livraison));
			sb.append(",date_fin_livraison=" + String.valueOf(date_fin_livraison));
			sb.append(",id_livreur=" + String.valueOf(id_livreur));
			sb.append(",nom_livreur=" + nom_livreur);
			sb.append(",prenom_livreur=" + prenom_livreur);
			sb.append(",id_moyen_livraison=" + String.valueOf(id_moyen_livraison));
			sb.append(",code_moyen_livraison=" + code_moyen_livraison);
			sb.append(",libelle_moyen_livraison=" + libelle_moyen_livraison);
			sb.append(",nom_client=" + nom_client);
			sb.append(",prenom_client=" + prenom_client);
			sb.append(",id_preparation=" + String.valueOf(id_preparation));
			sb.append(",date_debut_preparation=" + String.valueOf(date_debut_preparation));
			sb.append(",date_fin_preparation=" + String.valueOf(date_fin_preparation));
			sb.append(",nombre_article_livres=" + String.valueOf(nombre_article_livres));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row2Struct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.id_staging_dm2, other.id_staging_dm2);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void tDBInput_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tDBInput_1_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				row2Struct row2 = new row2Struct();
				row7Struct row7 = new row7Struct();

				/**
				 * [tLogRow_1 begin ] start
				 */

				ok_Hash.put("tLogRow_1", false);
				start_Hash.put("tLogRow_1", System.currentTimeMillis());

				currentComponent = "tLogRow_1";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "row7");
				}

				int tos_count_tLogRow_1 = 0;

				///////////////////////

				final String OUTPUT_FIELD_SEPARATOR_tLogRow_1 = "|";
				java.io.PrintStream consoleOut_tLogRow_1 = null;

				StringBuilder strBuffer_tLogRow_1 = null;
				int nb_line_tLogRow_1 = 0;
///////////////////////    			

				/**
				 * [tLogRow_1 begin ] stop
				 */

				/**
				 * [tUniqRow_1 begin ] start
				 */

				ok_Hash.put("tUniqRow_1", false);
				start_Hash.put("tUniqRow_1", System.currentTimeMillis());

				currentComponent = "tUniqRow_1";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "row2");
				}

				int tos_count_tUniqRow_1 = 0;

				class KeyStruct_tUniqRow_1 {

					private static final int DEFAULT_HASHCODE = 1;
					private static final int PRIME = 31;
					private int hashCode = DEFAULT_HASHCODE;
					public boolean hashCodeDirty = true;

					Integer id_adresse_norm_client;
					String numero_voie;
					String nom_voie;
					String code_postal;
					String nom_ville;
					String longitude;
					String latitude;
					Integer id_restaurant;
					String code_restaurant;
					String raison_sociale_restaurant;
					Integer id_adresse_norm_restaurant;
					String numero_voie_restau;
					String nom_voie_restau;
					String code_postal_restau;
					String nom_ville_restau;
					String longitude_restau;
					String latitude_restau;
					Integer id_client;
					Integer id_livraison;
					Integer id_commande;
					Integer numero_commande;
					java.util.Date date_commande;
					Float montant_total;
					Integer id_menu;
					String code_menu;
					String libelle_menu;
					Integer nombre_articles;
					Integer temps_theo_preparation;
					Integer numero_livraison;
					java.util.Date date_debut_livraison;
					java.util.Date date_fin_livraison;
					Integer id_livreur;
					String nom_livreur;
					String prenom_livreur;
					Integer id_moyen_livraison;
					String code_moyen_livraison;
					String libelle_moyen_livraison;
					String nom_client;
					String prenom_client;
					Integer id_preparation;
					java.util.Date date_debut_preparation;
					java.util.Date date_fin_preparation;
					Integer nombre_article_livres;

					@Override
					public int hashCode() {
						if (this.hashCodeDirty) {
							final int prime = PRIME;
							int result = DEFAULT_HASHCODE;

							result = prime * result + ((this.id_adresse_norm_client == null) ? 0
									: this.id_adresse_norm_client.hashCode());

							result = prime * result + ((this.numero_voie == null) ? 0 : this.numero_voie.hashCode());

							result = prime * result + ((this.nom_voie == null) ? 0 : this.nom_voie.hashCode());

							result = prime * result + ((this.code_postal == null) ? 0 : this.code_postal.hashCode());

							result = prime * result + ((this.nom_ville == null) ? 0 : this.nom_ville.hashCode());

							result = prime * result + ((this.longitude == null) ? 0 : this.longitude.hashCode());

							result = prime * result + ((this.latitude == null) ? 0 : this.latitude.hashCode());

							result = prime * result
									+ ((this.id_restaurant == null) ? 0 : this.id_restaurant.hashCode());

							result = prime * result
									+ ((this.code_restaurant == null) ? 0 : this.code_restaurant.hashCode());

							result = prime * result + ((this.raison_sociale_restaurant == null) ? 0
									: this.raison_sociale_restaurant.hashCode());

							result = prime * result + ((this.id_adresse_norm_restaurant == null) ? 0
									: this.id_adresse_norm_restaurant.hashCode());

							result = prime * result
									+ ((this.numero_voie_restau == null) ? 0 : this.numero_voie_restau.hashCode());

							result = prime * result
									+ ((this.nom_voie_restau == null) ? 0 : this.nom_voie_restau.hashCode());

							result = prime * result
									+ ((this.code_postal_restau == null) ? 0 : this.code_postal_restau.hashCode());

							result = prime * result
									+ ((this.nom_ville_restau == null) ? 0 : this.nom_ville_restau.hashCode());

							result = prime * result
									+ ((this.longitude_restau == null) ? 0 : this.longitude_restau.hashCode());

							result = prime * result
									+ ((this.latitude_restau == null) ? 0 : this.latitude_restau.hashCode());

							result = prime * result + ((this.id_client == null) ? 0 : this.id_client.hashCode());

							result = prime * result + ((this.id_livraison == null) ? 0 : this.id_livraison.hashCode());

							result = prime * result + ((this.id_commande == null) ? 0 : this.id_commande.hashCode());

							result = prime * result
									+ ((this.numero_commande == null) ? 0 : this.numero_commande.hashCode());

							result = prime * result
									+ ((this.date_commande == null) ? 0 : this.date_commande.hashCode());

							result = prime * result
									+ ((this.montant_total == null) ? 0 : this.montant_total.hashCode());

							result = prime * result + ((this.id_menu == null) ? 0 : this.id_menu.hashCode());

							result = prime * result + ((this.code_menu == null) ? 0 : this.code_menu.hashCode());

							result = prime * result + ((this.libelle_menu == null) ? 0 : this.libelle_menu.hashCode());

							result = prime * result
									+ ((this.nombre_articles == null) ? 0 : this.nombre_articles.hashCode());

							result = prime * result + ((this.temps_theo_preparation == null) ? 0
									: this.temps_theo_preparation.hashCode());

							result = prime * result
									+ ((this.numero_livraison == null) ? 0 : this.numero_livraison.hashCode());

							result = prime * result
									+ ((this.date_debut_livraison == null) ? 0 : this.date_debut_livraison.hashCode());

							result = prime * result
									+ ((this.date_fin_livraison == null) ? 0 : this.date_fin_livraison.hashCode());

							result = prime * result + ((this.id_livreur == null) ? 0 : this.id_livreur.hashCode());

							result = prime * result + ((this.nom_livreur == null) ? 0 : this.nom_livreur.hashCode());

							result = prime * result
									+ ((this.prenom_livreur == null) ? 0 : this.prenom_livreur.hashCode());

							result = prime * result
									+ ((this.id_moyen_livraison == null) ? 0 : this.id_moyen_livraison.hashCode());

							result = prime * result
									+ ((this.code_moyen_livraison == null) ? 0 : this.code_moyen_livraison.hashCode());

							result = prime * result + ((this.libelle_moyen_livraison == null) ? 0
									: this.libelle_moyen_livraison.hashCode());

							result = prime * result + ((this.nom_client == null) ? 0 : this.nom_client.hashCode());

							result = prime * result
									+ ((this.prenom_client == null) ? 0 : this.prenom_client.hashCode());

							result = prime * result
									+ ((this.id_preparation == null) ? 0 : this.id_preparation.hashCode());

							result = prime * result + ((this.date_debut_preparation == null) ? 0
									: this.date_debut_preparation.hashCode());

							result = prime * result
									+ ((this.date_fin_preparation == null) ? 0 : this.date_fin_preparation.hashCode());

							result = prime * result + ((this.nombre_article_livres == null) ? 0
									: this.nombre_article_livres.hashCode());

							this.hashCode = result;
							this.hashCodeDirty = false;
						}
						return this.hashCode;
					}

					@Override
					public boolean equals(Object obj) {
						if (this == obj)
							return true;
						if (obj == null)
							return false;
						if (getClass() != obj.getClass())
							return false;
						final KeyStruct_tUniqRow_1 other = (KeyStruct_tUniqRow_1) obj;

						if (this.id_adresse_norm_client == null) {
							if (other.id_adresse_norm_client != null)
								return false;

						} else if (!this.id_adresse_norm_client.equals(other.id_adresse_norm_client))

							return false;

						if (this.numero_voie == null) {
							if (other.numero_voie != null)
								return false;

						} else if (!this.numero_voie.equals(other.numero_voie))

							return false;

						if (this.nom_voie == null) {
							if (other.nom_voie != null)
								return false;

						} else if (!this.nom_voie.equals(other.nom_voie))

							return false;

						if (this.code_postal == null) {
							if (other.code_postal != null)
								return false;

						} else if (!this.code_postal.equals(other.code_postal))

							return false;

						if (this.nom_ville == null) {
							if (other.nom_ville != null)
								return false;

						} else if (!this.nom_ville.equals(other.nom_ville))

							return false;

						if (this.longitude == null) {
							if (other.longitude != null)
								return false;

						} else if (!this.longitude.equals(other.longitude))

							return false;

						if (this.latitude == null) {
							if (other.latitude != null)
								return false;

						} else if (!this.latitude.equals(other.latitude))

							return false;

						if (this.id_restaurant == null) {
							if (other.id_restaurant != null)
								return false;

						} else if (!this.id_restaurant.equals(other.id_restaurant))

							return false;

						if (this.code_restaurant == null) {
							if (other.code_restaurant != null)
								return false;

						} else if (!this.code_restaurant.equals(other.code_restaurant))

							return false;

						if (this.raison_sociale_restaurant == null) {
							if (other.raison_sociale_restaurant != null)
								return false;

						} else if (!this.raison_sociale_restaurant.equals(other.raison_sociale_restaurant))

							return false;

						if (this.id_adresse_norm_restaurant == null) {
							if (other.id_adresse_norm_restaurant != null)
								return false;

						} else if (!this.id_adresse_norm_restaurant.equals(other.id_adresse_norm_restaurant))

							return false;

						if (this.numero_voie_restau == null) {
							if (other.numero_voie_restau != null)
								return false;

						} else if (!this.numero_voie_restau.equals(other.numero_voie_restau))

							return false;

						if (this.nom_voie_restau == null) {
							if (other.nom_voie_restau != null)
								return false;

						} else if (!this.nom_voie_restau.equals(other.nom_voie_restau))

							return false;

						if (this.code_postal_restau == null) {
							if (other.code_postal_restau != null)
								return false;

						} else if (!this.code_postal_restau.equals(other.code_postal_restau))

							return false;

						if (this.nom_ville_restau == null) {
							if (other.nom_ville_restau != null)
								return false;

						} else if (!this.nom_ville_restau.equals(other.nom_ville_restau))

							return false;

						if (this.longitude_restau == null) {
							if (other.longitude_restau != null)
								return false;

						} else if (!this.longitude_restau.equals(other.longitude_restau))

							return false;

						if (this.latitude_restau == null) {
							if (other.latitude_restau != null)
								return false;

						} else if (!this.latitude_restau.equals(other.latitude_restau))

							return false;

						if (this.id_client == null) {
							if (other.id_client != null)
								return false;

						} else if (!this.id_client.equals(other.id_client))

							return false;

						if (this.id_livraison == null) {
							if (other.id_livraison != null)
								return false;

						} else if (!this.id_livraison.equals(other.id_livraison))

							return false;

						if (this.id_commande == null) {
							if (other.id_commande != null)
								return false;

						} else if (!this.id_commande.equals(other.id_commande))

							return false;

						if (this.numero_commande == null) {
							if (other.numero_commande != null)
								return false;

						} else if (!this.numero_commande.equals(other.numero_commande))

							return false;

						if (this.date_commande == null) {
							if (other.date_commande != null)
								return false;

						} else if (!this.date_commande.equals(other.date_commande))

							return false;

						if (this.montant_total == null) {
							if (other.montant_total != null)
								return false;

						} else if (!this.montant_total.equals(other.montant_total))

							return false;

						if (this.id_menu == null) {
							if (other.id_menu != null)
								return false;

						} else if (!this.id_menu.equals(other.id_menu))

							return false;

						if (this.code_menu == null) {
							if (other.code_menu != null)
								return false;

						} else if (!this.code_menu.equals(other.code_menu))

							return false;

						if (this.libelle_menu == null) {
							if (other.libelle_menu != null)
								return false;

						} else if (!this.libelle_menu.equals(other.libelle_menu))

							return false;

						if (this.nombre_articles == null) {
							if (other.nombre_articles != null)
								return false;

						} else if (!this.nombre_articles.equals(other.nombre_articles))

							return false;

						if (this.temps_theo_preparation == null) {
							if (other.temps_theo_preparation != null)
								return false;

						} else if (!this.temps_theo_preparation.equals(other.temps_theo_preparation))

							return false;

						if (this.numero_livraison == null) {
							if (other.numero_livraison != null)
								return false;

						} else if (!this.numero_livraison.equals(other.numero_livraison))

							return false;

						if (this.date_debut_livraison == null) {
							if (other.date_debut_livraison != null)
								return false;

						} else if (!this.date_debut_livraison.equals(other.date_debut_livraison))

							return false;

						if (this.date_fin_livraison == null) {
							if (other.date_fin_livraison != null)
								return false;

						} else if (!this.date_fin_livraison.equals(other.date_fin_livraison))

							return false;

						if (this.id_livreur == null) {
							if (other.id_livreur != null)
								return false;

						} else if (!this.id_livreur.equals(other.id_livreur))

							return false;

						if (this.nom_livreur == null) {
							if (other.nom_livreur != null)
								return false;

						} else if (!this.nom_livreur.equals(other.nom_livreur))

							return false;

						if (this.prenom_livreur == null) {
							if (other.prenom_livreur != null)
								return false;

						} else if (!this.prenom_livreur.equals(other.prenom_livreur))

							return false;

						if (this.id_moyen_livraison == null) {
							if (other.id_moyen_livraison != null)
								return false;

						} else if (!this.id_moyen_livraison.equals(other.id_moyen_livraison))

							return false;

						if (this.code_moyen_livraison == null) {
							if (other.code_moyen_livraison != null)
								return false;

						} else if (!this.code_moyen_livraison.equals(other.code_moyen_livraison))

							return false;

						if (this.libelle_moyen_livraison == null) {
							if (other.libelle_moyen_livraison != null)
								return false;

						} else if (!this.libelle_moyen_livraison.equals(other.libelle_moyen_livraison))

							return false;

						if (this.nom_client == null) {
							if (other.nom_client != null)
								return false;

						} else if (!this.nom_client.equals(other.nom_client))

							return false;

						if (this.prenom_client == null) {
							if (other.prenom_client != null)
								return false;

						} else if (!this.prenom_client.equals(other.prenom_client))

							return false;

						if (this.id_preparation == null) {
							if (other.id_preparation != null)
								return false;

						} else if (!this.id_preparation.equals(other.id_preparation))

							return false;

						if (this.date_debut_preparation == null) {
							if (other.date_debut_preparation != null)
								return false;

						} else if (!this.date_debut_preparation.equals(other.date_debut_preparation))

							return false;

						if (this.date_fin_preparation == null) {
							if (other.date_fin_preparation != null)
								return false;

						} else if (!this.date_fin_preparation.equals(other.date_fin_preparation))

							return false;

						if (this.nombre_article_livres == null) {
							if (other.nombre_article_livres != null)
								return false;

						} else if (!this.nombre_article_livres.equals(other.nombre_article_livres))

							return false;

						return true;
					}

				}

				int nb_uniques_tUniqRow_1 = 0;
				int nb_duplicates_tUniqRow_1 = 0;
				KeyStruct_tUniqRow_1 finder_tUniqRow_1 = new KeyStruct_tUniqRow_1();
				java.util.Set<KeyStruct_tUniqRow_1> keystUniqRow_1 = new java.util.HashSet<KeyStruct_tUniqRow_1>();

				/**
				 * [tUniqRow_1 begin ] stop
				 */

				/**
				 * [tDBInput_1 begin ] start
				 */

				ok_Hash.put("tDBInput_1", false);
				start_Hash.put("tDBInput_1", System.currentTimeMillis());

				tStatCatcher_1.addMessage("begin", "tDBInput_1");
				tStatCatcher_1Process(globalMap);

				currentComponent = "tDBInput_1";

				int tos_count_tDBInput_1 = 0;

				int nb_line_tDBInput_1 = 0;
				java.sql.Connection conn_tDBInput_1 = null;
				String driverClass_tDBInput_1 = "org.postgresql.Driver";
				java.lang.Class jdbcclazz_tDBInput_1 = java.lang.Class.forName(driverClass_tDBInput_1);
				String dbUser_tDBInput_1 = "dsid_cc2_tos_rw";

				final String decryptedPassword_tDBInput_1 = routines.system.PasswordEncryptUtil
						.decryptPassword("enc:routine.encryption.key.v1:5PYbGey8b0Xx6jecOAPNx50nsxtMafzbn6bHXOTevhQ=");

				String dbPwd_tDBInput_1 = decryptedPassword_tDBInput_1;

				String url_tDBInput_1 = "jdbc:postgresql://" + "localhost" + ":" + "5432" + "/" + "postgres";

				conn_tDBInput_1 = java.sql.DriverManager.getConnection(url_tDBInput_1, dbUser_tDBInput_1,
						dbPwd_tDBInput_1);

				conn_tDBInput_1.setAutoCommit(false);

				java.sql.Statement stmt_tDBInput_1 = conn_tDBInput_1.createStatement();

				String dbquery_tDBInput_1 = "SELECT \n  \"dsid_liv_wrk\".\"dm2_staging\".\"id_staging_dm2\", \n  \"dsid_liv_wrk\".\"dm2_staging\".\"id_adresse_norm_cl"
						+ "ient\", \n  \"dsid_liv_wrk\".\"dm2_staging\".\"numero_voie\", \n  \"dsid_liv_wrk\".\"dm2_staging\".\"nom_voie\", \n  \"dsid"
						+ "_liv_wrk\".\"dm2_staging\".\"code_postal\", \n  \"dsid_liv_wrk\".\"dm2_staging\".\"nom_ville\", \n  \"dsid_liv_wrk\".\"dm2"
						+ "_staging\".\"longitude\", \n  \"dsid_liv_wrk\".\"dm2_staging\".\"latitude\", \n  \"dsid_liv_wrk\".\"dm2_staging\".\"id_res"
						+ "taurant\", \n  \"dsid_liv_wrk\".\"dm2_staging\".\"code_restaurant\", \n  \"dsid_liv_wrk\".\"dm2_staging\".\"raison_sociale"
						+ "_restaurant\", \n  \"dsid_liv_wrk\".\"dm2_staging\".\"id_adresse_norm_restaurant\", \n  \"dsid_liv_wrk\".\"dm2_staging\"."
						+ "\"numero_voie_restau\", \n  \"dsid_liv_wrk\".\"dm2_staging\".\"nom_voie_restau\", \n  \"dsid_liv_wrk\".\"dm2_staging\".\"c"
						+ "ode_postal_restau\", \n  \"dsid_liv_wrk\".\"dm2_staging\".\"nom_ville_restau\", \n  \"dsid_liv_wrk\".\"dm2_staging\".\"lon"
						+ "gitude_restau\", \n  \"dsid_liv_wrk\".\"dm2_staging\".\"latitude_restau\", \n  \"dsid_liv_wrk\".\"dm2_staging\".\"id_clien"
						+ "t\", \n  \"dsid_liv_wrk\".\"dm2_staging\".\"id_livraison\", \n  \"dsid_liv_wrk\".\"dm2_staging\".\"id_commande\", \n  \"dsi"
						+ "d_liv_wrk\".\"dm2_staging\".\"numero_commande\", \n  \"dsid_liv_wrk\".\"dm2_staging\".\"date_commande\", \n  \"dsid_liv_wr"
						+ "k\".\"dm2_staging\".\"montant_total\", \n  \"dsid_liv_wrk\".\"dm2_staging\".\"id_menu\", \n  \"dsid_liv_wrk\".\"dm2_stagin"
						+ "g\".\"code_menu\", \n  \"dsid_liv_wrk\".\"dm2_staging\".\"libelle_menu\", \n  \"dsid_liv_wrk\".\"dm2_staging\".\"nombre_ar"
						+ "ticles\", \n  \"dsid_liv_wrk\".\"dm2_staging\".\"temps_theo_preparation\", \n  \"dsid_liv_wrk\".\"dm2_staging\".\"numero_l"
						+ "ivraison\", \n  \"dsid_liv_wrk\".\"dm2_staging\".\"date_debut_livraison\", \n  \"dsid_liv_wrk\".\"dm2_staging\".\"date_fin"
						+ "_livraison\", \n  \"dsid_liv_wrk\".\"dm2_staging\".\"id_livreur\", \n  \"dsid_liv_wrk\".\"dm2_staging\".\"nom_livreur\", \n"
						+ "  \"dsid_liv_wrk\".\"dm2_staging\".\"prenom_livreur\", \n  \"dsid_liv_wrk\".\"dm2_staging\".\"id_moyen_livraison\", \n  \""
						+ "dsid_liv_wrk\".\"dm2_staging\".\"code_moyen_livraison\", \n  \"dsid_liv_wrk\".\"dm2_staging\".\"libelle_moyen_livraison\""
						+ ", \n  \"dsid_liv_wrk\".\"dm2_staging\".\"nom_client\", \n  \"dsid_liv_wrk\".\"dm2_staging\".\"prenom_client\", \n  \"dsid_l"
						+ "iv_wrk\".\"dm2_staging\".\"id_preparation\", \n  \"dsid_liv_wrk\".\"dm2_staging\".\"date_debut_preparation\", \n  \"dsid_l"
						+ "iv_wrk\".\"dm2_staging\".\"date_fin_preparation\", \n  \"dsid_liv_wrk\".\"dm2_staging\".\"nombre_article_livres\"\nFROM \""
						+ "dsid_liv_wrk\".\"dm2_staging\"";

				globalMap.put("tDBInput_1_QUERY", dbquery_tDBInput_1);
				java.sql.ResultSet rs_tDBInput_1 = null;

				try {
					rs_tDBInput_1 = stmt_tDBInput_1.executeQuery(dbquery_tDBInput_1);
					java.sql.ResultSetMetaData rsmd_tDBInput_1 = rs_tDBInput_1.getMetaData();
					int colQtyInRs_tDBInput_1 = rsmd_tDBInput_1.getColumnCount();

					String tmpContent_tDBInput_1 = null;

					while (rs_tDBInput_1.next()) {
						nb_line_tDBInput_1++;

						if (colQtyInRs_tDBInput_1 < 1) {
							row2.id_staging_dm2 = 0;
						} else {

							row2.id_staging_dm2 = rs_tDBInput_1.getInt(1);
							if (rs_tDBInput_1.wasNull()) {
								throw new RuntimeException("Null value in non-Nullable column");
							}
						}
						if (colQtyInRs_tDBInput_1 < 2) {
							row2.id_adresse_norm_client = null;
						} else {

							row2.id_adresse_norm_client = rs_tDBInput_1.getInt(2);
							if (rs_tDBInput_1.wasNull()) {
								row2.id_adresse_norm_client = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 3) {
							row2.numero_voie = null;
						} else {

							row2.numero_voie = routines.system.JDBCUtil.getString(rs_tDBInput_1, 3, false);
						}
						if (colQtyInRs_tDBInput_1 < 4) {
							row2.nom_voie = null;
						} else {

							row2.nom_voie = routines.system.JDBCUtil.getString(rs_tDBInput_1, 4, false);
						}
						if (colQtyInRs_tDBInput_1 < 5) {
							row2.code_postal = null;
						} else {

							row2.code_postal = routines.system.JDBCUtil.getString(rs_tDBInput_1, 5, false);
						}
						if (colQtyInRs_tDBInput_1 < 6) {
							row2.nom_ville = null;
						} else {

							row2.nom_ville = routines.system.JDBCUtil.getString(rs_tDBInput_1, 6, false);
						}
						if (colQtyInRs_tDBInput_1 < 7) {
							row2.longitude = null;
						} else {

							row2.longitude = routines.system.JDBCUtil.getString(rs_tDBInput_1, 7, false);
						}
						if (colQtyInRs_tDBInput_1 < 8) {
							row2.latitude = null;
						} else {

							row2.latitude = routines.system.JDBCUtil.getString(rs_tDBInput_1, 8, false);
						}
						if (colQtyInRs_tDBInput_1 < 9) {
							row2.id_restaurant = null;
						} else {

							row2.id_restaurant = rs_tDBInput_1.getInt(9);
							if (rs_tDBInput_1.wasNull()) {
								row2.id_restaurant = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 10) {
							row2.code_restaurant = null;
						} else {

							row2.code_restaurant = routines.system.JDBCUtil.getString(rs_tDBInput_1, 10, false);
						}
						if (colQtyInRs_tDBInput_1 < 11) {
							row2.raison_sociale_restaurant = null;
						} else {

							row2.raison_sociale_restaurant = routines.system.JDBCUtil.getString(rs_tDBInput_1, 11,
									false);
						}
						if (colQtyInRs_tDBInput_1 < 12) {
							row2.id_adresse_norm_restaurant = null;
						} else {

							row2.id_adresse_norm_restaurant = rs_tDBInput_1.getInt(12);
							if (rs_tDBInput_1.wasNull()) {
								row2.id_adresse_norm_restaurant = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 13) {
							row2.numero_voie_restau = null;
						} else {

							row2.numero_voie_restau = routines.system.JDBCUtil.getString(rs_tDBInput_1, 13, false);
						}
						if (colQtyInRs_tDBInput_1 < 14) {
							row2.nom_voie_restau = null;
						} else {

							row2.nom_voie_restau = routines.system.JDBCUtil.getString(rs_tDBInput_1, 14, false);
						}
						if (colQtyInRs_tDBInput_1 < 15) {
							row2.code_postal_restau = null;
						} else {

							row2.code_postal_restau = routines.system.JDBCUtil.getString(rs_tDBInput_1, 15, false);
						}
						if (colQtyInRs_tDBInput_1 < 16) {
							row2.nom_ville_restau = null;
						} else {

							row2.nom_ville_restau = routines.system.JDBCUtil.getString(rs_tDBInput_1, 16, false);
						}
						if (colQtyInRs_tDBInput_1 < 17) {
							row2.longitude_restau = null;
						} else {

							row2.longitude_restau = routines.system.JDBCUtil.getString(rs_tDBInput_1, 17, false);
						}
						if (colQtyInRs_tDBInput_1 < 18) {
							row2.latitude_restau = null;
						} else {

							row2.latitude_restau = routines.system.JDBCUtil.getString(rs_tDBInput_1, 18, false);
						}
						if (colQtyInRs_tDBInput_1 < 19) {
							row2.id_client = null;
						} else {

							row2.id_client = rs_tDBInput_1.getInt(19);
							if (rs_tDBInput_1.wasNull()) {
								row2.id_client = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 20) {
							row2.id_livraison = null;
						} else {

							row2.id_livraison = rs_tDBInput_1.getInt(20);
							if (rs_tDBInput_1.wasNull()) {
								row2.id_livraison = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 21) {
							row2.id_commande = null;
						} else {

							row2.id_commande = rs_tDBInput_1.getInt(21);
							if (rs_tDBInput_1.wasNull()) {
								row2.id_commande = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 22) {
							row2.numero_commande = null;
						} else {

							row2.numero_commande = rs_tDBInput_1.getInt(22);
							if (rs_tDBInput_1.wasNull()) {
								row2.numero_commande = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 23) {
							row2.date_commande = null;
						} else {

							row2.date_commande = routines.system.JDBCUtil.getDate(rs_tDBInput_1, 23);
						}
						if (colQtyInRs_tDBInput_1 < 24) {
							row2.montant_total = null;
						} else {

							row2.montant_total = rs_tDBInput_1.getFloat(24);
							if (rs_tDBInput_1.wasNull()) {
								row2.montant_total = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 25) {
							row2.id_menu = null;
						} else {

							row2.id_menu = rs_tDBInput_1.getInt(25);
							if (rs_tDBInput_1.wasNull()) {
								row2.id_menu = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 26) {
							row2.code_menu = null;
						} else {

							row2.code_menu = routines.system.JDBCUtil.getString(rs_tDBInput_1, 26, false);
						}
						if (colQtyInRs_tDBInput_1 < 27) {
							row2.libelle_menu = null;
						} else {

							row2.libelle_menu = routines.system.JDBCUtil.getString(rs_tDBInput_1, 27, false);
						}
						if (colQtyInRs_tDBInput_1 < 28) {
							row2.nombre_articles = null;
						} else {

							row2.nombre_articles = rs_tDBInput_1.getInt(28);
							if (rs_tDBInput_1.wasNull()) {
								row2.nombre_articles = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 29) {
							row2.temps_theo_preparation = null;
						} else {

							row2.temps_theo_preparation = rs_tDBInput_1.getInt(29);
							if (rs_tDBInput_1.wasNull()) {
								row2.temps_theo_preparation = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 30) {
							row2.numero_livraison = null;
						} else {

							row2.numero_livraison = rs_tDBInput_1.getInt(30);
							if (rs_tDBInput_1.wasNull()) {
								row2.numero_livraison = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 31) {
							row2.date_debut_livraison = null;
						} else {

							row2.date_debut_livraison = routines.system.JDBCUtil.getDate(rs_tDBInput_1, 31);
						}
						if (colQtyInRs_tDBInput_1 < 32) {
							row2.date_fin_livraison = null;
						} else {

							row2.date_fin_livraison = routines.system.JDBCUtil.getDate(rs_tDBInput_1, 32);
						}
						if (colQtyInRs_tDBInput_1 < 33) {
							row2.id_livreur = null;
						} else {

							row2.id_livreur = rs_tDBInput_1.getInt(33);
							if (rs_tDBInput_1.wasNull()) {
								row2.id_livreur = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 34) {
							row2.nom_livreur = null;
						} else {

							row2.nom_livreur = routines.system.JDBCUtil.getString(rs_tDBInput_1, 34, false);
						}
						if (colQtyInRs_tDBInput_1 < 35) {
							row2.prenom_livreur = null;
						} else {

							row2.prenom_livreur = routines.system.JDBCUtil.getString(rs_tDBInput_1, 35, false);
						}
						if (colQtyInRs_tDBInput_1 < 36) {
							row2.id_moyen_livraison = null;
						} else {

							row2.id_moyen_livraison = rs_tDBInput_1.getInt(36);
							if (rs_tDBInput_1.wasNull()) {
								row2.id_moyen_livraison = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 37) {
							row2.code_moyen_livraison = null;
						} else {

							row2.code_moyen_livraison = routines.system.JDBCUtil.getString(rs_tDBInput_1, 37, false);
						}
						if (colQtyInRs_tDBInput_1 < 38) {
							row2.libelle_moyen_livraison = null;
						} else {

							row2.libelle_moyen_livraison = routines.system.JDBCUtil.getString(rs_tDBInput_1, 38, false);
						}
						if (colQtyInRs_tDBInput_1 < 39) {
							row2.nom_client = null;
						} else {

							row2.nom_client = routines.system.JDBCUtil.getString(rs_tDBInput_1, 39, false);
						}
						if (colQtyInRs_tDBInput_1 < 40) {
							row2.prenom_client = null;
						} else {

							row2.prenom_client = routines.system.JDBCUtil.getString(rs_tDBInput_1, 40, false);
						}
						if (colQtyInRs_tDBInput_1 < 41) {
							row2.id_preparation = null;
						} else {

							row2.id_preparation = rs_tDBInput_1.getInt(41);
							if (rs_tDBInput_1.wasNull()) {
								row2.id_preparation = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 42) {
							row2.date_debut_preparation = null;
						} else {

							row2.date_debut_preparation = routines.system.JDBCUtil.getDate(rs_tDBInput_1, 42);
						}
						if (colQtyInRs_tDBInput_1 < 43) {
							row2.date_fin_preparation = null;
						} else {

							row2.date_fin_preparation = routines.system.JDBCUtil.getDate(rs_tDBInput_1, 43);
						}
						if (colQtyInRs_tDBInput_1 < 44) {
							row2.nombre_article_livres = null;
						} else {

							row2.nombre_article_livres = rs_tDBInput_1.getInt(44);
							if (rs_tDBInput_1.wasNull()) {
								row2.nombre_article_livres = null;
							}
						}

						/**
						 * [tDBInput_1 begin ] stop
						 */

						/**
						 * [tDBInput_1 main ] start
						 */

						currentComponent = "tDBInput_1";

						tos_count_tDBInput_1++;

						/**
						 * [tDBInput_1 main ] stop
						 */

						/**
						 * [tDBInput_1 process_data_begin ] start
						 */

						currentComponent = "tDBInput_1";

						/**
						 * [tDBInput_1 process_data_begin ] stop
						 */

						/**
						 * [tUniqRow_1 main ] start
						 */

						currentComponent = "tUniqRow_1";

						if (execStat) {
							runStat.updateStatOnConnection(iterateId, 1, 1

									, "row2"

							);
						}

						row7 = null;
						finder_tUniqRow_1.id_adresse_norm_client = row2.id_adresse_norm_client;
						if (row2.numero_voie == null) {
							finder_tUniqRow_1.numero_voie = null;
						} else {
							finder_tUniqRow_1.numero_voie = row2.numero_voie.toLowerCase();
						}
						if (row2.nom_voie == null) {
							finder_tUniqRow_1.nom_voie = null;
						} else {
							finder_tUniqRow_1.nom_voie = row2.nom_voie.toLowerCase();
						}
						if (row2.code_postal == null) {
							finder_tUniqRow_1.code_postal = null;
						} else {
							finder_tUniqRow_1.code_postal = row2.code_postal.toLowerCase();
						}
						if (row2.nom_ville == null) {
							finder_tUniqRow_1.nom_ville = null;
						} else {
							finder_tUniqRow_1.nom_ville = row2.nom_ville.toLowerCase();
						}
						if (row2.longitude == null) {
							finder_tUniqRow_1.longitude = null;
						} else {
							finder_tUniqRow_1.longitude = row2.longitude.toLowerCase();
						}
						if (row2.latitude == null) {
							finder_tUniqRow_1.latitude = null;
						} else {
							finder_tUniqRow_1.latitude = row2.latitude.toLowerCase();
						}
						finder_tUniqRow_1.id_restaurant = row2.id_restaurant;
						if (row2.code_restaurant == null) {
							finder_tUniqRow_1.code_restaurant = null;
						} else {
							finder_tUniqRow_1.code_restaurant = row2.code_restaurant.toLowerCase();
						}
						if (row2.raison_sociale_restaurant == null) {
							finder_tUniqRow_1.raison_sociale_restaurant = null;
						} else {
							finder_tUniqRow_1.raison_sociale_restaurant = row2.raison_sociale_restaurant.toLowerCase();
						}
						finder_tUniqRow_1.id_adresse_norm_restaurant = row2.id_adresse_norm_restaurant;
						if (row2.numero_voie_restau == null) {
							finder_tUniqRow_1.numero_voie_restau = null;
						} else {
							finder_tUniqRow_1.numero_voie_restau = row2.numero_voie_restau.toLowerCase();
						}
						if (row2.nom_voie_restau == null) {
							finder_tUniqRow_1.nom_voie_restau = null;
						} else {
							finder_tUniqRow_1.nom_voie_restau = row2.nom_voie_restau.toLowerCase();
						}
						if (row2.code_postal_restau == null) {
							finder_tUniqRow_1.code_postal_restau = null;
						} else {
							finder_tUniqRow_1.code_postal_restau = row2.code_postal_restau.toLowerCase();
						}
						if (row2.nom_ville_restau == null) {
							finder_tUniqRow_1.nom_ville_restau = null;
						} else {
							finder_tUniqRow_1.nom_ville_restau = row2.nom_ville_restau.toLowerCase();
						}
						if (row2.longitude_restau == null) {
							finder_tUniqRow_1.longitude_restau = null;
						} else {
							finder_tUniqRow_1.longitude_restau = row2.longitude_restau.toLowerCase();
						}
						if (row2.latitude_restau == null) {
							finder_tUniqRow_1.latitude_restau = null;
						} else {
							finder_tUniqRow_1.latitude_restau = row2.latitude_restau.toLowerCase();
						}
						finder_tUniqRow_1.id_client = row2.id_client;
						finder_tUniqRow_1.id_livraison = row2.id_livraison;
						finder_tUniqRow_1.id_commande = row2.id_commande;
						finder_tUniqRow_1.numero_commande = row2.numero_commande;
						finder_tUniqRow_1.date_commande = row2.date_commande;
						finder_tUniqRow_1.montant_total = row2.montant_total;
						finder_tUniqRow_1.id_menu = row2.id_menu;
						if (row2.code_menu == null) {
							finder_tUniqRow_1.code_menu = null;
						} else {
							finder_tUniqRow_1.code_menu = row2.code_menu.toLowerCase();
						}
						if (row2.libelle_menu == null) {
							finder_tUniqRow_1.libelle_menu = null;
						} else {
							finder_tUniqRow_1.libelle_menu = row2.libelle_menu.toLowerCase();
						}
						finder_tUniqRow_1.nombre_articles = row2.nombre_articles;
						finder_tUniqRow_1.temps_theo_preparation = row2.temps_theo_preparation;
						finder_tUniqRow_1.numero_livraison = row2.numero_livraison;
						finder_tUniqRow_1.date_debut_livraison = row2.date_debut_livraison;
						finder_tUniqRow_1.date_fin_livraison = row2.date_fin_livraison;
						finder_tUniqRow_1.id_livreur = row2.id_livreur;
						if (row2.nom_livreur == null) {
							finder_tUniqRow_1.nom_livreur = null;
						} else {
							finder_tUniqRow_1.nom_livreur = row2.nom_livreur.toLowerCase();
						}
						if (row2.prenom_livreur == null) {
							finder_tUniqRow_1.prenom_livreur = null;
						} else {
							finder_tUniqRow_1.prenom_livreur = row2.prenom_livreur.toLowerCase();
						}
						finder_tUniqRow_1.id_moyen_livraison = row2.id_moyen_livraison;
						if (row2.code_moyen_livraison == null) {
							finder_tUniqRow_1.code_moyen_livraison = null;
						} else {
							finder_tUniqRow_1.code_moyen_livraison = row2.code_moyen_livraison.toLowerCase();
						}
						if (row2.libelle_moyen_livraison == null) {
							finder_tUniqRow_1.libelle_moyen_livraison = null;
						} else {
							finder_tUniqRow_1.libelle_moyen_livraison = row2.libelle_moyen_livraison.toLowerCase();
						}
						if (row2.nom_client == null) {
							finder_tUniqRow_1.nom_client = null;
						} else {
							finder_tUniqRow_1.nom_client = row2.nom_client.toLowerCase();
						}
						if (row2.prenom_client == null) {
							finder_tUniqRow_1.prenom_client = null;
						} else {
							finder_tUniqRow_1.prenom_client = row2.prenom_client.toLowerCase();
						}
						finder_tUniqRow_1.id_preparation = row2.id_preparation;
						finder_tUniqRow_1.date_debut_preparation = row2.date_debut_preparation;
						finder_tUniqRow_1.date_fin_preparation = row2.date_fin_preparation;
						finder_tUniqRow_1.nombre_article_livres = row2.nombre_article_livres;
						finder_tUniqRow_1.hashCodeDirty = true;
						if (!keystUniqRow_1.contains(finder_tUniqRow_1)) {
							KeyStruct_tUniqRow_1 new_tUniqRow_1 = new KeyStruct_tUniqRow_1();

							new_tUniqRow_1.id_adresse_norm_client = row2.id_adresse_norm_client;
							if (row2.numero_voie == null) {
								new_tUniqRow_1.numero_voie = null;
							} else {
								new_tUniqRow_1.numero_voie = row2.numero_voie.toLowerCase();
							}
							if (row2.nom_voie == null) {
								new_tUniqRow_1.nom_voie = null;
							} else {
								new_tUniqRow_1.nom_voie = row2.nom_voie.toLowerCase();
							}
							if (row2.code_postal == null) {
								new_tUniqRow_1.code_postal = null;
							} else {
								new_tUniqRow_1.code_postal = row2.code_postal.toLowerCase();
							}
							if (row2.nom_ville == null) {
								new_tUniqRow_1.nom_ville = null;
							} else {
								new_tUniqRow_1.nom_ville = row2.nom_ville.toLowerCase();
							}
							if (row2.longitude == null) {
								new_tUniqRow_1.longitude = null;
							} else {
								new_tUniqRow_1.longitude = row2.longitude.toLowerCase();
							}
							if (row2.latitude == null) {
								new_tUniqRow_1.latitude = null;
							} else {
								new_tUniqRow_1.latitude = row2.latitude.toLowerCase();
							}
							new_tUniqRow_1.id_restaurant = row2.id_restaurant;
							if (row2.code_restaurant == null) {
								new_tUniqRow_1.code_restaurant = null;
							} else {
								new_tUniqRow_1.code_restaurant = row2.code_restaurant.toLowerCase();
							}
							if (row2.raison_sociale_restaurant == null) {
								new_tUniqRow_1.raison_sociale_restaurant = null;
							} else {
								new_tUniqRow_1.raison_sociale_restaurant = row2.raison_sociale_restaurant.toLowerCase();
							}
							new_tUniqRow_1.id_adresse_norm_restaurant = row2.id_adresse_norm_restaurant;
							if (row2.numero_voie_restau == null) {
								new_tUniqRow_1.numero_voie_restau = null;
							} else {
								new_tUniqRow_1.numero_voie_restau = row2.numero_voie_restau.toLowerCase();
							}
							if (row2.nom_voie_restau == null) {
								new_tUniqRow_1.nom_voie_restau = null;
							} else {
								new_tUniqRow_1.nom_voie_restau = row2.nom_voie_restau.toLowerCase();
							}
							if (row2.code_postal_restau == null) {
								new_tUniqRow_1.code_postal_restau = null;
							} else {
								new_tUniqRow_1.code_postal_restau = row2.code_postal_restau.toLowerCase();
							}
							if (row2.nom_ville_restau == null) {
								new_tUniqRow_1.nom_ville_restau = null;
							} else {
								new_tUniqRow_1.nom_ville_restau = row2.nom_ville_restau.toLowerCase();
							}
							if (row2.longitude_restau == null) {
								new_tUniqRow_1.longitude_restau = null;
							} else {
								new_tUniqRow_1.longitude_restau = row2.longitude_restau.toLowerCase();
							}
							if (row2.latitude_restau == null) {
								new_tUniqRow_1.latitude_restau = null;
							} else {
								new_tUniqRow_1.latitude_restau = row2.latitude_restau.toLowerCase();
							}
							new_tUniqRow_1.id_client = row2.id_client;
							new_tUniqRow_1.id_livraison = row2.id_livraison;
							new_tUniqRow_1.id_commande = row2.id_commande;
							new_tUniqRow_1.numero_commande = row2.numero_commande;
							new_tUniqRow_1.date_commande = row2.date_commande;
							new_tUniqRow_1.montant_total = row2.montant_total;
							new_tUniqRow_1.id_menu = row2.id_menu;
							if (row2.code_menu == null) {
								new_tUniqRow_1.code_menu = null;
							} else {
								new_tUniqRow_1.code_menu = row2.code_menu.toLowerCase();
							}
							if (row2.libelle_menu == null) {
								new_tUniqRow_1.libelle_menu = null;
							} else {
								new_tUniqRow_1.libelle_menu = row2.libelle_menu.toLowerCase();
							}
							new_tUniqRow_1.nombre_articles = row2.nombre_articles;
							new_tUniqRow_1.temps_theo_preparation = row2.temps_theo_preparation;
							new_tUniqRow_1.numero_livraison = row2.numero_livraison;
							new_tUniqRow_1.date_debut_livraison = row2.date_debut_livraison;
							new_tUniqRow_1.date_fin_livraison = row2.date_fin_livraison;
							new_tUniqRow_1.id_livreur = row2.id_livreur;
							if (row2.nom_livreur == null) {
								new_tUniqRow_1.nom_livreur = null;
							} else {
								new_tUniqRow_1.nom_livreur = row2.nom_livreur.toLowerCase();
							}
							if (row2.prenom_livreur == null) {
								new_tUniqRow_1.prenom_livreur = null;
							} else {
								new_tUniqRow_1.prenom_livreur = row2.prenom_livreur.toLowerCase();
							}
							new_tUniqRow_1.id_moyen_livraison = row2.id_moyen_livraison;
							if (row2.code_moyen_livraison == null) {
								new_tUniqRow_1.code_moyen_livraison = null;
							} else {
								new_tUniqRow_1.code_moyen_livraison = row2.code_moyen_livraison.toLowerCase();
							}
							if (row2.libelle_moyen_livraison == null) {
								new_tUniqRow_1.libelle_moyen_livraison = null;
							} else {
								new_tUniqRow_1.libelle_moyen_livraison = row2.libelle_moyen_livraison.toLowerCase();
							}
							if (row2.nom_client == null) {
								new_tUniqRow_1.nom_client = null;
							} else {
								new_tUniqRow_1.nom_client = row2.nom_client.toLowerCase();
							}
							if (row2.prenom_client == null) {
								new_tUniqRow_1.prenom_client = null;
							} else {
								new_tUniqRow_1.prenom_client = row2.prenom_client.toLowerCase();
							}
							new_tUniqRow_1.id_preparation = row2.id_preparation;
							new_tUniqRow_1.date_debut_preparation = row2.date_debut_preparation;
							new_tUniqRow_1.date_fin_preparation = row2.date_fin_preparation;
							new_tUniqRow_1.nombre_article_livres = row2.nombre_article_livres;

							keystUniqRow_1.add(new_tUniqRow_1);
							nb_uniques_tUniqRow_1++;
						} else {
							if (row7 == null) {

								row7 = new row7Struct();
							}
							row7.id_staging_dm2 = row2.id_staging_dm2;
							row7.id_adresse_norm_client = row2.id_adresse_norm_client;
							row7.numero_voie = row2.numero_voie;
							row7.nom_voie = row2.nom_voie;
							row7.code_postal = row2.code_postal;
							row7.nom_ville = row2.nom_ville;
							row7.longitude = row2.longitude;
							row7.latitude = row2.latitude;
							row7.id_restaurant = row2.id_restaurant;
							row7.code_restaurant = row2.code_restaurant;
							row7.raison_sociale_restaurant = row2.raison_sociale_restaurant;
							row7.id_adresse_norm_restaurant = row2.id_adresse_norm_restaurant;
							row7.numero_voie_restau = row2.numero_voie_restau;
							row7.nom_voie_restau = row2.nom_voie_restau;
							row7.code_postal_restau = row2.code_postal_restau;
							row7.nom_ville_restau = row2.nom_ville_restau;
							row7.longitude_restau = row2.longitude_restau;
							row7.latitude_restau = row2.latitude_restau;
							row7.id_client = row2.id_client;
							row7.id_livraison = row2.id_livraison;
							row7.id_commande = row2.id_commande;
							row7.numero_commande = row2.numero_commande;
							row7.date_commande = row2.date_commande;
							row7.montant_total = row2.montant_total;
							row7.id_menu = row2.id_menu;
							row7.code_menu = row2.code_menu;
							row7.libelle_menu = row2.libelle_menu;
							row7.nombre_articles = row2.nombre_articles;
							row7.temps_theo_preparation = row2.temps_theo_preparation;
							row7.numero_livraison = row2.numero_livraison;
							row7.date_debut_livraison = row2.date_debut_livraison;
							row7.date_fin_livraison = row2.date_fin_livraison;
							row7.id_livreur = row2.id_livreur;
							row7.nom_livreur = row2.nom_livreur;
							row7.prenom_livreur = row2.prenom_livreur;
							row7.id_moyen_livraison = row2.id_moyen_livraison;
							row7.code_moyen_livraison = row2.code_moyen_livraison;
							row7.libelle_moyen_livraison = row2.libelle_moyen_livraison;
							row7.nom_client = row2.nom_client;
							row7.prenom_client = row2.prenom_client;
							row7.id_preparation = row2.id_preparation;
							row7.date_debut_preparation = row2.date_debut_preparation;
							row7.date_fin_preparation = row2.date_fin_preparation;
							row7.nombre_article_livres = row2.nombre_article_livres;
							nb_duplicates_tUniqRow_1++;
						}

						tos_count_tUniqRow_1++;

						/**
						 * [tUniqRow_1 main ] stop
						 */

						/**
						 * [tUniqRow_1 process_data_begin ] start
						 */

						currentComponent = "tUniqRow_1";

						/**
						 * [tUniqRow_1 process_data_begin ] stop
						 */
// Start of branch "row7"
						if (row7 != null) {

							/**
							 * [tLogRow_1 main ] start
							 */

							currentComponent = "tLogRow_1";

							if (execStat) {
								runStat.updateStatOnConnection(iterateId, 1, 1

										, "row7"

								);
							}

///////////////////////		

							strBuffer_tLogRow_1 = new StringBuilder();

							strBuffer_tLogRow_1.append(String.valueOf(row7.id_staging_dm2));

							strBuffer_tLogRow_1.append("|");

							if (row7.id_adresse_norm_client != null) { //

								strBuffer_tLogRow_1.append(String.valueOf(row7.id_adresse_norm_client));

							} //

							strBuffer_tLogRow_1.append("|");

							if (row7.numero_voie != null) { //

								strBuffer_tLogRow_1.append(String.valueOf(row7.numero_voie));

							} //

							strBuffer_tLogRow_1.append("|");

							if (row7.nom_voie != null) { //

								strBuffer_tLogRow_1.append(String.valueOf(row7.nom_voie));

							} //

							strBuffer_tLogRow_1.append("|");

							if (row7.code_postal != null) { //

								strBuffer_tLogRow_1.append(String.valueOf(row7.code_postal));

							} //

							strBuffer_tLogRow_1.append("|");

							if (row7.nom_ville != null) { //

								strBuffer_tLogRow_1.append(String.valueOf(row7.nom_ville));

							} //

							strBuffer_tLogRow_1.append("|");

							if (row7.longitude != null) { //

								strBuffer_tLogRow_1.append(String.valueOf(row7.longitude));

							} //

							strBuffer_tLogRow_1.append("|");

							if (row7.latitude != null) { //

								strBuffer_tLogRow_1.append(String.valueOf(row7.latitude));

							} //

							strBuffer_tLogRow_1.append("|");

							if (row7.id_restaurant != null) { //

								strBuffer_tLogRow_1.append(String.valueOf(row7.id_restaurant));

							} //

							strBuffer_tLogRow_1.append("|");

							if (row7.code_restaurant != null) { //

								strBuffer_tLogRow_1.append(String.valueOf(row7.code_restaurant));

							} //

							strBuffer_tLogRow_1.append("|");

							if (row7.raison_sociale_restaurant != null) { //

								strBuffer_tLogRow_1.append(String.valueOf(row7.raison_sociale_restaurant));

							} //

							strBuffer_tLogRow_1.append("|");

							if (row7.id_adresse_norm_restaurant != null) { //

								strBuffer_tLogRow_1.append(String.valueOf(row7.id_adresse_norm_restaurant));

							} //

							strBuffer_tLogRow_1.append("|");

							if (row7.numero_voie_restau != null) { //

								strBuffer_tLogRow_1.append(String.valueOf(row7.numero_voie_restau));

							} //

							strBuffer_tLogRow_1.append("|");

							if (row7.nom_voie_restau != null) { //

								strBuffer_tLogRow_1.append(String.valueOf(row7.nom_voie_restau));

							} //

							strBuffer_tLogRow_1.append("|");

							if (row7.code_postal_restau != null) { //

								strBuffer_tLogRow_1.append(String.valueOf(row7.code_postal_restau));

							} //

							strBuffer_tLogRow_1.append("|");

							if (row7.nom_ville_restau != null) { //

								strBuffer_tLogRow_1.append(String.valueOf(row7.nom_ville_restau));

							} //

							strBuffer_tLogRow_1.append("|");

							if (row7.longitude_restau != null) { //

								strBuffer_tLogRow_1.append(String.valueOf(row7.longitude_restau));

							} //

							strBuffer_tLogRow_1.append("|");

							if (row7.latitude_restau != null) { //

								strBuffer_tLogRow_1.append(String.valueOf(row7.latitude_restau));

							} //

							strBuffer_tLogRow_1.append("|");

							if (row7.id_client != null) { //

								strBuffer_tLogRow_1.append(String.valueOf(row7.id_client));

							} //

							strBuffer_tLogRow_1.append("|");

							if (row7.id_livraison != null) { //

								strBuffer_tLogRow_1.append(String.valueOf(row7.id_livraison));

							} //

							strBuffer_tLogRow_1.append("|");

							if (row7.id_commande != null) { //

								strBuffer_tLogRow_1.append(String.valueOf(row7.id_commande));

							} //

							strBuffer_tLogRow_1.append("|");

							if (row7.numero_commande != null) { //

								strBuffer_tLogRow_1.append(String.valueOf(row7.numero_commande));

							} //

							strBuffer_tLogRow_1.append("|");

							if (row7.date_commande != null) { //

								strBuffer_tLogRow_1
										.append(FormatterUtils.format_Date(row7.date_commande, "dd-MM-yyyy"));

							} //

							strBuffer_tLogRow_1.append("|");

							if (row7.montant_total != null) { //

								strBuffer_tLogRow_1.append(FormatterUtils.formatUnwithE(row7.montant_total));

							} //

							strBuffer_tLogRow_1.append("|");

							if (row7.id_menu != null) { //

								strBuffer_tLogRow_1.append(String.valueOf(row7.id_menu));

							} //

							strBuffer_tLogRow_1.append("|");

							if (row7.code_menu != null) { //

								strBuffer_tLogRow_1.append(String.valueOf(row7.code_menu));

							} //

							strBuffer_tLogRow_1.append("|");

							if (row7.libelle_menu != null) { //

								strBuffer_tLogRow_1.append(String.valueOf(row7.libelle_menu));

							} //

							strBuffer_tLogRow_1.append("|");

							if (row7.nombre_articles != null) { //

								strBuffer_tLogRow_1.append(String.valueOf(row7.nombre_articles));

							} //

							strBuffer_tLogRow_1.append("|");

							if (row7.temps_theo_preparation != null) { //

								strBuffer_tLogRow_1.append(String.valueOf(row7.temps_theo_preparation));

							} //

							strBuffer_tLogRow_1.append("|");

							if (row7.numero_livraison != null) { //

								strBuffer_tLogRow_1.append(String.valueOf(row7.numero_livraison));

							} //

							strBuffer_tLogRow_1.append("|");

							if (row7.date_debut_livraison != null) { //

								strBuffer_tLogRow_1.append(
										FormatterUtils.format_Date(row7.date_debut_livraison, "dd-MM-yyyy HH:mm"));

							} //

							strBuffer_tLogRow_1.append("|");

							if (row7.date_fin_livraison != null) { //

								strBuffer_tLogRow_1.append(
										FormatterUtils.format_Date(row7.date_fin_livraison, "dd-MM-yyyy HH:mm"));

							} //

							strBuffer_tLogRow_1.append("|");

							if (row7.id_livreur != null) { //

								strBuffer_tLogRow_1.append(String.valueOf(row7.id_livreur));

							} //

							strBuffer_tLogRow_1.append("|");

							if (row7.nom_livreur != null) { //

								strBuffer_tLogRow_1.append(String.valueOf(row7.nom_livreur));

							} //

							strBuffer_tLogRow_1.append("|");

							if (row7.prenom_livreur != null) { //

								strBuffer_tLogRow_1.append(String.valueOf(row7.prenom_livreur));

							} //

							strBuffer_tLogRow_1.append("|");

							if (row7.id_moyen_livraison != null) { //

								strBuffer_tLogRow_1.append(String.valueOf(row7.id_moyen_livraison));

							} //

							strBuffer_tLogRow_1.append("|");

							if (row7.code_moyen_livraison != null) { //

								strBuffer_tLogRow_1.append(String.valueOf(row7.code_moyen_livraison));

							} //

							strBuffer_tLogRow_1.append("|");

							if (row7.libelle_moyen_livraison != null) { //

								strBuffer_tLogRow_1.append(String.valueOf(row7.libelle_moyen_livraison));

							} //

							strBuffer_tLogRow_1.append("|");

							if (row7.nom_client != null) { //

								strBuffer_tLogRow_1.append(String.valueOf(row7.nom_client));

							} //

							strBuffer_tLogRow_1.append("|");

							if (row7.prenom_client != null) { //

								strBuffer_tLogRow_1.append(String.valueOf(row7.prenom_client));

							} //

							strBuffer_tLogRow_1.append("|");

							if (row7.id_preparation != null) { //

								strBuffer_tLogRow_1.append(String.valueOf(row7.id_preparation));

							} //

							strBuffer_tLogRow_1.append("|");

							if (row7.date_debut_preparation != null) { //

								strBuffer_tLogRow_1.append(
										FormatterUtils.format_Date(row7.date_debut_preparation, "dd-MM-yyyy HH:mm"));

							} //

							strBuffer_tLogRow_1.append("|");

							if (row7.date_fin_preparation != null) { //

								strBuffer_tLogRow_1.append(
										FormatterUtils.format_Date(row7.date_fin_preparation, "dd-MM-yyyy HH:mm"));

							} //

							strBuffer_tLogRow_1.append("|");

							if (row7.nombre_article_livres != null) { //

								strBuffer_tLogRow_1.append(String.valueOf(row7.nombre_article_livres));

							} //

							if (globalMap.get("tLogRow_CONSOLE") != null) {
								consoleOut_tLogRow_1 = (java.io.PrintStream) globalMap.get("tLogRow_CONSOLE");
							} else {
								consoleOut_tLogRow_1 = new java.io.PrintStream(
										new java.io.BufferedOutputStream(System.out));
								globalMap.put("tLogRow_CONSOLE", consoleOut_tLogRow_1);
							}
							consoleOut_tLogRow_1.println(strBuffer_tLogRow_1.toString());
							consoleOut_tLogRow_1.flush();
							nb_line_tLogRow_1++;
//////

//////                    

///////////////////////    			

							tos_count_tLogRow_1++;

							/**
							 * [tLogRow_1 main ] stop
							 */

							/**
							 * [tLogRow_1 process_data_begin ] start
							 */

							currentComponent = "tLogRow_1";

							/**
							 * [tLogRow_1 process_data_begin ] stop
							 */

							/**
							 * [tLogRow_1 process_data_end ] start
							 */

							currentComponent = "tLogRow_1";

							/**
							 * [tLogRow_1 process_data_end ] stop
							 */

						} // End of branch "row7"

						/**
						 * [tUniqRow_1 process_data_end ] start
						 */

						currentComponent = "tUniqRow_1";

						/**
						 * [tUniqRow_1 process_data_end ] stop
						 */

						/**
						 * [tDBInput_1 process_data_end ] start
						 */

						currentComponent = "tDBInput_1";

						/**
						 * [tDBInput_1 process_data_end ] stop
						 */

						/**
						 * [tDBInput_1 end ] start
						 */

						currentComponent = "tDBInput_1";

					}
				} finally {
					if (rs_tDBInput_1 != null) {
						rs_tDBInput_1.close();
					}
					if (stmt_tDBInput_1 != null) {
						stmt_tDBInput_1.close();
					}
					if (conn_tDBInput_1 != null && !conn_tDBInput_1.isClosed()) {

						conn_tDBInput_1.commit();

						conn_tDBInput_1.close();

						if ("com.mysql.cj.jdbc.Driver".equals((String) globalMap.get("driverClass_"))
								&& routines.system.BundleUtils.inOSGi()) {
							Class.forName("com.mysql.cj.jdbc.AbandonedConnectionCleanupThread")
									.getMethod("checkedShutdown").invoke(null, (Object[]) null);
						}

					}

				}
				globalMap.put("tDBInput_1_NB_LINE", nb_line_tDBInput_1);

				ok_Hash.put("tDBInput_1", true);
				end_Hash.put("tDBInput_1", System.currentTimeMillis());

				tStatCatcher_1.addMessage("end", "tDBInput_1",
						end_Hash.get("tDBInput_1") - start_Hash.get("tDBInput_1"));
				tStatCatcher_1Process(globalMap);

				/**
				 * [tDBInput_1 end ] stop
				 */

				/**
				 * [tUniqRow_1 end ] start
				 */

				currentComponent = "tUniqRow_1";

				globalMap.put("tUniqRow_1_NB_UNIQUES", nb_uniques_tUniqRow_1);
				globalMap.put("tUniqRow_1_NB_DUPLICATES", nb_duplicates_tUniqRow_1);

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "row2");
				}

				ok_Hash.put("tUniqRow_1", true);
				end_Hash.put("tUniqRow_1", System.currentTimeMillis());

				/**
				 * [tUniqRow_1 end ] stop
				 */

				/**
				 * [tLogRow_1 end ] start
				 */

				currentComponent = "tLogRow_1";

//////
//////
				globalMap.put("tLogRow_1_NB_LINE", nb_line_tLogRow_1);

///////////////////////    			

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "row7");
				}

				ok_Hash.put("tLogRow_1", true);
				end_Hash.put("tLogRow_1", System.currentTimeMillis());

				/**
				 * [tLogRow_1 end ] stop
				 */

			} // end the resume

		} catch (java.lang.Exception e) {

			TalendException te = new TalendException(e, currentComponent, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			try {

				/**
				 * [tDBInput_1 finally ] start
				 */

				currentComponent = "tDBInput_1";

				/**
				 * [tDBInput_1 finally ] stop
				 */

				/**
				 * [tUniqRow_1 finally ] start
				 */

				currentComponent = "tUniqRow_1";

				/**
				 * [tUniqRow_1 finally ] stop
				 */

				/**
				 * [tLogRow_1 finally ] start
				 */

				currentComponent = "tLogRow_1";

				/**
				 * [tLogRow_1 finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tDBInput_1_SUBPROCESS_STATE", 1);
	}

	public void tJava_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tJava_1_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				/**
				 * [tJava_1 begin ] start
				 */

				ok_Hash.put("tJava_1", false);
				start_Hash.put("tJava_1", System.currentTimeMillis());

				tStatCatcher_1.addMessage("begin", "tJava_1");
				tStatCatcher_1Process(globalMap);

				currentComponent = "tJava_1";

				int tos_count_tJava_1 = 0;

				/**
				 * [tJava_1 begin ] stop
				 */

				/**
				 * [tJava_1 main ] start
				 */

				currentComponent = "tJava_1";

				tos_count_tJava_1++;

				/**
				 * [tJava_1 main ] stop
				 */

				/**
				 * [tJava_1 process_data_begin ] start
				 */

				currentComponent = "tJava_1";

				/**
				 * [tJava_1 process_data_begin ] stop
				 */

				/**
				 * [tJava_1 process_data_end ] start
				 */

				currentComponent = "tJava_1";

				/**
				 * [tJava_1 process_data_end ] stop
				 */

				/**
				 * [tJava_1 end ] start
				 */

				currentComponent = "tJava_1";

				ok_Hash.put("tJava_1", true);
				end_Hash.put("tJava_1", System.currentTimeMillis());

				tStatCatcher_1.addMessage("end", "tJava_1", end_Hash.get("tJava_1") - start_Hash.get("tJava_1"));
				tStatCatcher_1Process(globalMap);

				/**
				 * [tJava_1 end ] stop
				 */
			} // end the resume

		} catch (java.lang.Exception e) {

			TalendException te = new TalendException(e, currentComponent, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			try {

				/**
				 * [tJava_1 finally ] start
				 */

				currentComponent = "tJava_1";

				/**
				 * [tJava_1 finally ] stop
				 */
			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tJava_1_SUBPROCESS_STATE", 1);
	}

	public void tExtractJSONFields_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tExtractJSONFields_1_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				/**
				 * [tExtractJSONFields_1 begin ] start
				 */

				ok_Hash.put("tExtractJSONFields_1", false);
				start_Hash.put("tExtractJSONFields_1", System.currentTimeMillis());

				tStatCatcher_1.addMessage("begin", "tExtractJSONFields_1");
				tStatCatcher_1Process(globalMap);

				currentComponent = "tExtractJSONFields_1";

				int tos_count_tExtractJSONFields_1 = 0;

				int nb_line_tExtractJSONFields_1 = 0;
				String jsonStr_tExtractJSONFields_1 = "";

				class JsonPathCache_tExtractJSONFields_1 {
					final java.util.Map<String, com.jayway.jsonpath.JsonPath> jsonPathString2compiledJsonPath = new java.util.HashMap<String, com.jayway.jsonpath.JsonPath>();

					public com.jayway.jsonpath.JsonPath getCompiledJsonPath(String jsonPath) {
						if (jsonPathString2compiledJsonPath.containsKey(jsonPath)) {
							return jsonPathString2compiledJsonPath.get(jsonPath);
						} else {
							com.jayway.jsonpath.JsonPath compiledLoopPath = com.jayway.jsonpath.JsonPath
									.compile(jsonPath);
							jsonPathString2compiledJsonPath.put(jsonPath, compiledLoopPath);
							return compiledLoopPath;
						}
					}
				}

				JsonPathCache_tExtractJSONFields_1 jsonPathCache_tExtractJSONFields_1 = new JsonPathCache_tExtractJSONFields_1();

				/**
				 * [tExtractJSONFields_1 begin ] stop
				 */

				/**
				 * [tExtractJSONFields_1 main ] start
				 */

				currentComponent = "tExtractJSONFields_1";

				tos_count_tExtractJSONFields_1++;

				/**
				 * [tExtractJSONFields_1 main ] stop
				 */

				/**
				 * [tExtractJSONFields_1 process_data_begin ] start
				 */

				currentComponent = "tExtractJSONFields_1";

				/**
				 * [tExtractJSONFields_1 process_data_begin ] stop
				 */

				/**
				 * [tExtractJSONFields_1 process_data_end ] start
				 */

				currentComponent = "tExtractJSONFields_1";

				/**
				 * [tExtractJSONFields_1 process_data_end ] stop
				 */

				/**
				 * [tExtractJSONFields_1 end ] start
				 */

				currentComponent = "tExtractJSONFields_1";

				globalMap.put("tExtractJSONFields_1_NB_LINE", nb_line_tExtractJSONFields_1);

				ok_Hash.put("tExtractJSONFields_1", true);
				end_Hash.put("tExtractJSONFields_1", System.currentTimeMillis());

				tStatCatcher_1.addMessage("end", "tExtractJSONFields_1",
						end_Hash.get("tExtractJSONFields_1") - start_Hash.get("tExtractJSONFields_1"));
				tStatCatcher_1Process(globalMap);

				/**
				 * [tExtractJSONFields_1 end ] stop
				 */
			} // end the resume

		} catch (java.lang.Exception e) {

			TalendException te = new TalendException(e, currentComponent, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			try {

				/**
				 * [tExtractJSONFields_1 finally ] start
				 */

				currentComponent = "tExtractJSONFields_1";

				/**
				 * [tExtractJSONFields_1 finally ] stop
				 */
			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tExtractJSONFields_1_SUBPROCESS_STATE", 1);
	}

	public void tDBOutput_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tDBOutput_2_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				/**
				 * [tDBOutput_2 begin ] start
				 */

				ok_Hash.put("tDBOutput_2", false);
				start_Hash.put("tDBOutput_2", System.currentTimeMillis());

				tStatCatcher_1.addMessage("begin", "tDBOutput_2");
				tStatCatcher_1Process(globalMap);

				currentComponent = "tDBOutput_2";

				int tos_count_tDBOutput_2 = 0;

				String dbschema_tDBOutput_2 = null;
				dbschema_tDBOutput_2 = "dsid_liv_wrk";

				String tableName_tDBOutput_2 = null;
				if (dbschema_tDBOutput_2 == null || dbschema_tDBOutput_2.trim().length() == 0) {
					tableName_tDBOutput_2 = ("dm2_ods");
				} else {
					tableName_tDBOutput_2 = dbschema_tDBOutput_2 + "\".\"" + ("dm2_ods");
				}

				int nb_line_tDBOutput_2 = 0;
				int nb_line_update_tDBOutput_2 = 0;
				int nb_line_inserted_tDBOutput_2 = 0;
				int nb_line_deleted_tDBOutput_2 = 0;
				int nb_line_rejected_tDBOutput_2 = 0;

				int deletedCount_tDBOutput_2 = 0;
				int updatedCount_tDBOutput_2 = 0;
				int insertedCount_tDBOutput_2 = 0;
				int rowsToCommitCount_tDBOutput_2 = 0;
				int rejectedCount_tDBOutput_2 = 0;

				boolean whetherReject_tDBOutput_2 = false;

				java.sql.Connection conn_tDBOutput_2 = null;
				String dbUser_tDBOutput_2 = null;

				java.lang.Class.forName("org.postgresql.Driver");

				String url_tDBOutput_2 = "jdbc:postgresql://" + "localhost" + ":" + "5432" + "/" + "postgres";
				dbUser_tDBOutput_2 = "dsid_cc2_tos_rw";

				final String decryptedPassword_tDBOutput_2 = routines.system.PasswordEncryptUtil
						.decryptPassword("enc:routine.encryption.key.v1:jYi2LRsHBE+vala2XynB3Nd9TYIFFoL9yjwv7HWzR1A=");

				String dbPwd_tDBOutput_2 = decryptedPassword_tDBOutput_2;

				conn_tDBOutput_2 = java.sql.DriverManager.getConnection(url_tDBOutput_2, dbUser_tDBOutput_2,
						dbPwd_tDBOutput_2);

				resourceMap.put("conn_tDBOutput_2", conn_tDBOutput_2);
				conn_tDBOutput_2.setAutoCommit(false);
				int commitEvery_tDBOutput_2 = 10000;
				int commitCounter_tDBOutput_2 = 0;

				int batchSize_tDBOutput_2 = 10000;
				int batchSizeCounter_tDBOutput_2 = 0;

				int count_tDBOutput_2 = 0;
				String insert_tDBOutput_2 = "INSERT INTO \"" + tableName_tDBOutput_2 + "\" (\"" + "id_ods_dm2"
						+ "\",\"id_adresse_norm_client\",\"numero_voie\",\"nom_voie\",\"code_postal\",\"nom_ville\",\"longitude\",\"latitude\",\"id_restaurant\",\"code_restaurant\",\"raison_sociale_restaurant\",\"id_adresse_norm_restaurant\",\"numero_voie_restau\",\"nom_voie_restau\",\"code_postal_restau\",\"nom_ville_restau\",\"longitude_restau\",\"latitude_restau\",\"id_client\",\"id_livraison\",\"id_commande\",\"numero_commande\",\"date_commande\",\"montant_total\",\"id_menu\",\"code_menu\",\"libelle_menu\",\"nombre_articles\",\"temps_theo_preparation\",\"numero_livraison\",\"date_debut_livraison\",\"date_fin_livraison\",\"id_livreur\",\"nom_livreur\",\"prenom_livreur\",\"id_moyen_livraison\",\"code_moyen_livraison\",\"libelle_moyen_livraison\",\"nom_client\",\"prenom_client\",\"id_preparation\",\"date_debut_preparation\",\"date_fin_preparation\",\"temps_livraison\",\"nombre_article_livres\",\"remuneration_livreur\") VALUES ("
						+ "nextval('dsid_liv_wrk.seq_id_ods_dm2')"
						+ ",?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

				java.sql.PreparedStatement pstmt_tDBOutput_2 = conn_tDBOutput_2.prepareStatement(insert_tDBOutput_2);
				resourceMap.put("pstmt_tDBOutput_2", pstmt_tDBOutput_2);

				/**
				 * [tDBOutput_2 begin ] stop
				 */

				/**
				 * [tDBOutput_2 main ] start
				 */

				currentComponent = "tDBOutput_2";

				tos_count_tDBOutput_2++;

				/**
				 * [tDBOutput_2 main ] stop
				 */

				/**
				 * [tDBOutput_2 process_data_begin ] start
				 */

				currentComponent = "tDBOutput_2";

				/**
				 * [tDBOutput_2 process_data_begin ] stop
				 */

				/**
				 * [tDBOutput_2 process_data_end ] start
				 */

				currentComponent = "tDBOutput_2";

				/**
				 * [tDBOutput_2 process_data_end ] stop
				 */

				/**
				 * [tDBOutput_2 end ] start
				 */

				currentComponent = "tDBOutput_2";

				try {
					int countSum_tDBOutput_2 = 0;
					if (pstmt_tDBOutput_2 != null && batchSizeCounter_tDBOutput_2 > 0) {

						for (int countEach_tDBOutput_2 : pstmt_tDBOutput_2.executeBatch()) {
							countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
						}
						rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;

					}

					insertedCount_tDBOutput_2 += countSum_tDBOutput_2;

				} catch (java.sql.BatchUpdateException e_tDBOutput_2) {
					globalMap.put("tDBOutput_2_ERROR_MESSAGE", e_tDBOutput_2.getMessage());
					java.sql.SQLException ne_tDBOutput_2 = e_tDBOutput_2.getNextException(), sqle_tDBOutput_2 = null;
					String errormessage_tDBOutput_2;
					if (ne_tDBOutput_2 != null) {
						// build new exception to provide the original cause
						sqle_tDBOutput_2 = new java.sql.SQLException(
								e_tDBOutput_2.getMessage() + "\ncaused by: " + ne_tDBOutput_2.getMessage(),
								ne_tDBOutput_2.getSQLState(), ne_tDBOutput_2.getErrorCode(), ne_tDBOutput_2);
						errormessage_tDBOutput_2 = sqle_tDBOutput_2.getMessage();
					} else {
						errormessage_tDBOutput_2 = e_tDBOutput_2.getMessage();
					}

					int countSum_tDBOutput_2 = 0;
					for (int countEach_tDBOutput_2 : e_tDBOutput_2.getUpdateCounts()) {
						countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
					}
					rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;

					insertedCount_tDBOutput_2 += countSum_tDBOutput_2;

					System.err.println(errormessage_tDBOutput_2);

				}

				if (pstmt_tDBOutput_2 != null) {

					pstmt_tDBOutput_2.close();
					resourceMap.remove("pstmt_tDBOutput_2");
				}
				resourceMap.put("statementClosed_tDBOutput_2", true);
				if (rowsToCommitCount_tDBOutput_2 != 0) {

				}
				conn_tDBOutput_2.commit();
				if (rowsToCommitCount_tDBOutput_2 != 0) {

					rowsToCommitCount_tDBOutput_2 = 0;
				}
				commitCounter_tDBOutput_2 = 0;

				conn_tDBOutput_2.close();

				resourceMap.put("finish_tDBOutput_2", true);

				nb_line_deleted_tDBOutput_2 = nb_line_deleted_tDBOutput_2 + deletedCount_tDBOutput_2;
				nb_line_update_tDBOutput_2 = nb_line_update_tDBOutput_2 + updatedCount_tDBOutput_2;
				nb_line_inserted_tDBOutput_2 = nb_line_inserted_tDBOutput_2 + insertedCount_tDBOutput_2;
				nb_line_rejected_tDBOutput_2 = nb_line_rejected_tDBOutput_2 + rejectedCount_tDBOutput_2;

				globalMap.put("tDBOutput_2_NB_LINE", nb_line_tDBOutput_2);
				globalMap.put("tDBOutput_2_NB_LINE_UPDATED", nb_line_update_tDBOutput_2);
				globalMap.put("tDBOutput_2_NB_LINE_INSERTED", nb_line_inserted_tDBOutput_2);
				globalMap.put("tDBOutput_2_NB_LINE_DELETED", nb_line_deleted_tDBOutput_2);
				globalMap.put("tDBOutput_2_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_2);

				ok_Hash.put("tDBOutput_2", true);
				end_Hash.put("tDBOutput_2", System.currentTimeMillis());

				tStatCatcher_1.addMessage("end", "tDBOutput_2",
						end_Hash.get("tDBOutput_2") - start_Hash.get("tDBOutput_2"));
				tStatCatcher_1Process(globalMap);

				/**
				 * [tDBOutput_2 end ] stop
				 */
			} // end the resume

		} catch (java.lang.Exception e) {

			TalendException te = new TalendException(e, currentComponent, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			try {

				/**
				 * [tDBOutput_2 finally ] start
				 */

				currentComponent = "tDBOutput_2";

				try {
					if (resourceMap.get("statementClosed_tDBOutput_2") == null) {
						java.sql.PreparedStatement pstmtToClose_tDBOutput_2 = null;
						if ((pstmtToClose_tDBOutput_2 = (java.sql.PreparedStatement) resourceMap
								.remove("pstmt_tDBOutput_2")) != null) {
							pstmtToClose_tDBOutput_2.close();
						}
					}
				} finally {
					if (resourceMap.get("finish_tDBOutput_2") == null) {
						java.sql.Connection ctn_tDBOutput_2 = null;
						if ((ctn_tDBOutput_2 = (java.sql.Connection) resourceMap.get("conn_tDBOutput_2")) != null) {
							try {
								ctn_tDBOutput_2.close();
							} catch (java.sql.SQLException sqlEx_tDBOutput_2) {
								String errorMessage_tDBOutput_2 = "failed to close the connection in tDBOutput_2 :"
										+ sqlEx_tDBOutput_2.getMessage();
								System.err.println(errorMessage_tDBOutput_2);
							}
						}
					}
				}

				/**
				 * [tDBOutput_2 finally ] stop
				 */
			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tDBOutput_2_SUBPROCESS_STATE", 1);
	}

	public static class row1Struct implements routines.system.IPersistableRow<row1Struct> {
		final static byte[] commonByteArrayLock_ALIMENTATION_DM2_C_ALIM_ODS = new byte[0];
		static byte[] commonByteArray_ALIMENTATION_DM2_C_ALIM_ODS = new byte[0];

		public java.util.Date moment;

		public java.util.Date getMoment() {
			return this.moment;
		}

		public String pid;

		public String getPid() {
			return this.pid;
		}

		public String father_pid;

		public String getFather_pid() {
			return this.father_pid;
		}

		public String root_pid;

		public String getRoot_pid() {
			return this.root_pid;
		}

		public Long system_pid;

		public Long getSystem_pid() {
			return this.system_pid;
		}

		public String project;

		public String getProject() {
			return this.project;
		}

		public String job;

		public String getJob() {
			return this.job;
		}

		public String job_repository_id;

		public String getJob_repository_id() {
			return this.job_repository_id;
		}

		public String job_version;

		public String getJob_version() {
			return this.job_version;
		}

		public String context;

		public String getContext() {
			return this.context;
		}

		public String origin;

		public String getOrigin() {
			return this.origin;
		}

		public String message_type;

		public String getMessage_type() {
			return this.message_type;
		}

		public String message;

		public String getMessage() {
			return this.message;
		}

		public Long duration;

		public Long getDuration() {
			return this.duration;
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_ALIMENTATION_DM2_C_ALIM_ODS.length) {
					if (length < 1024 && commonByteArray_ALIMENTATION_DM2_C_ALIM_ODS.length == 0) {
						commonByteArray_ALIMENTATION_DM2_C_ALIM_ODS = new byte[1024];
					} else {
						commonByteArray_ALIMENTATION_DM2_C_ALIM_ODS = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_ALIMENTATION_DM2_C_ALIM_ODS, 0, length);
				strReturn = new String(commonByteArray_ALIMENTATION_DM2_C_ALIM_ODS, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_ALIMENTATION_DM2_C_ALIM_ODS.length) {
					if (length < 1024 && commonByteArray_ALIMENTATION_DM2_C_ALIM_ODS.length == 0) {
						commonByteArray_ALIMENTATION_DM2_C_ALIM_ODS = new byte[1024];
					} else {
						commonByteArray_ALIMENTATION_DM2_C_ALIM_ODS = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_ALIMENTATION_DM2_C_ALIM_ODS, 0, length);
				strReturn = new String(commonByteArray_ALIMENTATION_DM2_C_ALIM_ODS, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_ALIMENTATION_DM2_C_ALIM_ODS) {

				try {

					int length = 0;

					this.moment = readDate(dis);

					this.pid = readString(dis);

					this.father_pid = readString(dis);

					this.root_pid = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.system_pid = null;
					} else {
						this.system_pid = dis.readLong();
					}

					this.project = readString(dis);

					this.job = readString(dis);

					this.job_repository_id = readString(dis);

					this.job_version = readString(dis);

					this.context = readString(dis);

					this.origin = readString(dis);

					this.message_type = readString(dis);

					this.message = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.duration = null;
					} else {
						this.duration = dis.readLong();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_ALIMENTATION_DM2_C_ALIM_ODS) {

				try {

					int length = 0;

					this.moment = readDate(dis);

					this.pid = readString(dis);

					this.father_pid = readString(dis);

					this.root_pid = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.system_pid = null;
					} else {
						this.system_pid = dis.readLong();
					}

					this.project = readString(dis);

					this.job = readString(dis);

					this.job_repository_id = readString(dis);

					this.job_version = readString(dis);

					this.context = readString(dis);

					this.origin = readString(dis);

					this.message_type = readString(dis);

					this.message = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.duration = null;
					} else {
						this.duration = dis.readLong();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// java.util.Date

				writeDate(this.moment, dos);

				// String

				writeString(this.pid, dos);

				// String

				writeString(this.father_pid, dos);

				// String

				writeString(this.root_pid, dos);

				// Long

				if (this.system_pid == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.system_pid);
				}

				// String

				writeString(this.project, dos);

				// String

				writeString(this.job, dos);

				// String

				writeString(this.job_repository_id, dos);

				// String

				writeString(this.job_version, dos);

				// String

				writeString(this.context, dos);

				// String

				writeString(this.origin, dos);

				// String

				writeString(this.message_type, dos);

				// String

				writeString(this.message, dos);

				// Long

				if (this.duration == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.duration);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// java.util.Date

				writeDate(this.moment, dos);

				// String

				writeString(this.pid, dos);

				// String

				writeString(this.father_pid, dos);

				// String

				writeString(this.root_pid, dos);

				// Long

				if (this.system_pid == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.system_pid);
				}

				// String

				writeString(this.project, dos);

				// String

				writeString(this.job, dos);

				// String

				writeString(this.job_repository_id, dos);

				// String

				writeString(this.job_version, dos);

				// String

				writeString(this.context, dos);

				// String

				writeString(this.origin, dos);

				// String

				writeString(this.message_type, dos);

				// String

				writeString(this.message, dos);

				// Long

				if (this.duration == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.duration);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("moment=" + String.valueOf(moment));
			sb.append(",pid=" + pid);
			sb.append(",father_pid=" + father_pid);
			sb.append(",root_pid=" + root_pid);
			sb.append(",system_pid=" + String.valueOf(system_pid));
			sb.append(",project=" + project);
			sb.append(",job=" + job);
			sb.append(",job_repository_id=" + job_repository_id);
			sb.append(",job_version=" + job_version);
			sb.append(",context=" + context);
			sb.append(",origin=" + origin);
			sb.append(",message_type=" + message_type);
			sb.append(",message=" + message);
			sb.append(",duration=" + String.valueOf(duration));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row1Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void tStatCatcher_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tStatCatcher_1_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				row1Struct row1 = new row1Struct();

				/**
				 * [tDBOutput_1 begin ] start
				 */

				ok_Hash.put("tDBOutput_1", false);
				start_Hash.put("tDBOutput_1", System.currentTimeMillis());

				currentComponent = "tDBOutput_1";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "row1");
				}

				int tos_count_tDBOutput_1 = 0;

				String dbschema_tDBOutput_1 = null;
				dbschema_tDBOutput_1 = "dsid_liv_met";

				String tableName_tDBOutput_1 = null;
				if (dbschema_tDBOutput_1 == null || dbschema_tDBOutput_1.trim().length() == 0) {
					tableName_tDBOutput_1 = ("JOB_STATS");
				} else {
					tableName_tDBOutput_1 = dbschema_tDBOutput_1 + "\".\"" + ("JOB_STATS");
				}

				int nb_line_tDBOutput_1 = 0;
				int nb_line_update_tDBOutput_1 = 0;
				int nb_line_inserted_tDBOutput_1 = 0;
				int nb_line_deleted_tDBOutput_1 = 0;
				int nb_line_rejected_tDBOutput_1 = 0;

				int deletedCount_tDBOutput_1 = 0;
				int updatedCount_tDBOutput_1 = 0;
				int insertedCount_tDBOutput_1 = 0;
				int rowsToCommitCount_tDBOutput_1 = 0;
				int rejectedCount_tDBOutput_1 = 0;

				boolean whetherReject_tDBOutput_1 = false;

				java.sql.Connection conn_tDBOutput_1 = null;
				String dbUser_tDBOutput_1 = null;

				java.lang.Class.forName("org.postgresql.Driver");

				String url_tDBOutput_1 = "jdbc:postgresql://" + "localhost" + ":" + "5432" + "/" + "postgres";
				dbUser_tDBOutput_1 = "dsid_cc2_tos_rw";

				final String decryptedPassword_tDBOutput_1 = routines.system.PasswordEncryptUtil
						.decryptPassword("enc:routine.encryption.key.v1:GkQi29V38Euahyf8EKaxsPZ6Zva/+5ROxoshuIQs9sU=");

				String dbPwd_tDBOutput_1 = decryptedPassword_tDBOutput_1;

				conn_tDBOutput_1 = java.sql.DriverManager.getConnection(url_tDBOutput_1, dbUser_tDBOutput_1,
						dbPwd_tDBOutput_1);

				resourceMap.put("conn_tDBOutput_1", conn_tDBOutput_1);
				conn_tDBOutput_1.setAutoCommit(false);
				int commitEvery_tDBOutput_1 = 10000;
				int commitCounter_tDBOutput_1 = 0;

				int batchSize_tDBOutput_1 = 10000;
				int batchSizeCounter_tDBOutput_1 = 0;

				int count_tDBOutput_1 = 0;
				String insert_tDBOutput_1 = "INSERT INTO \"" + tableName_tDBOutput_1
						+ "\" (\"moment\",\"pid\",\"father_pid\",\"root_pid\",\"system_pid\",\"project\",\"job\",\"job_repository_id\",\"job_version\",\"context\",\"origin\",\"message_type\",\"message\",\"duration\") VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

				java.sql.PreparedStatement pstmt_tDBOutput_1 = conn_tDBOutput_1.prepareStatement(insert_tDBOutput_1);
				resourceMap.put("pstmt_tDBOutput_1", pstmt_tDBOutput_1);

				/**
				 * [tDBOutput_1 begin ] stop
				 */

				/**
				 * [tStatCatcher_1 begin ] start
				 */

				ok_Hash.put("tStatCatcher_1", false);
				start_Hash.put("tStatCatcher_1", System.currentTimeMillis());

				currentComponent = "tStatCatcher_1";

				int tos_count_tStatCatcher_1 = 0;

				for (StatCatcherUtils.StatCatcherMessage scm : tStatCatcher_1.getMessages()) {
					row1.pid = pid;
					row1.root_pid = rootPid;
					row1.father_pid = fatherPid;
					row1.project = projectName;
					row1.job = jobName;
					row1.context = contextStr;
					row1.origin = (scm.getOrigin() == null || scm.getOrigin().length() < 1 ? null : scm.getOrigin());
					row1.message = scm.getMessage();
					row1.duration = scm.getDuration();
					row1.moment = scm.getMoment();
					row1.message_type = scm.getMessageType();
					row1.job_version = scm.getJobVersion();
					row1.job_repository_id = scm.getJobId();
					row1.system_pid = scm.getSystemPid();

					/**
					 * [tStatCatcher_1 begin ] stop
					 */

					/**
					 * [tStatCatcher_1 main ] start
					 */

					currentComponent = "tStatCatcher_1";

					tos_count_tStatCatcher_1++;

					/**
					 * [tStatCatcher_1 main ] stop
					 */

					/**
					 * [tStatCatcher_1 process_data_begin ] start
					 */

					currentComponent = "tStatCatcher_1";

					/**
					 * [tStatCatcher_1 process_data_begin ] stop
					 */

					/**
					 * [tDBOutput_1 main ] start
					 */

					currentComponent = "tDBOutput_1";

					if (execStat) {
						runStat.updateStatOnConnection(iterateId, 1, 1

								, "row1"

						);
					}

					whetherReject_tDBOutput_1 = false;
					if (row1.moment != null) {
						pstmt_tDBOutput_1.setTimestamp(1, new java.sql.Timestamp(row1.moment.getTime()));
					} else {
						pstmt_tDBOutput_1.setNull(1, java.sql.Types.TIMESTAMP);
					}

					if (row1.pid == null) {
						pstmt_tDBOutput_1.setNull(2, java.sql.Types.VARCHAR);
					} else {
						pstmt_tDBOutput_1.setString(2, row1.pid);
					}

					if (row1.father_pid == null) {
						pstmt_tDBOutput_1.setNull(3, java.sql.Types.VARCHAR);
					} else {
						pstmt_tDBOutput_1.setString(3, row1.father_pid);
					}

					if (row1.root_pid == null) {
						pstmt_tDBOutput_1.setNull(4, java.sql.Types.VARCHAR);
					} else {
						pstmt_tDBOutput_1.setString(4, row1.root_pid);
					}

					if (row1.system_pid == null) {
						pstmt_tDBOutput_1.setNull(5, java.sql.Types.INTEGER);
					} else {
						pstmt_tDBOutput_1.setLong(5, row1.system_pid);
					}

					if (row1.project == null) {
						pstmt_tDBOutput_1.setNull(6, java.sql.Types.VARCHAR);
					} else {
						pstmt_tDBOutput_1.setString(6, row1.project);
					}

					if (row1.job == null) {
						pstmt_tDBOutput_1.setNull(7, java.sql.Types.VARCHAR);
					} else {
						pstmt_tDBOutput_1.setString(7, row1.job);
					}

					if (row1.job_repository_id == null) {
						pstmt_tDBOutput_1.setNull(8, java.sql.Types.VARCHAR);
					} else {
						pstmt_tDBOutput_1.setString(8, row1.job_repository_id);
					}

					if (row1.job_version == null) {
						pstmt_tDBOutput_1.setNull(9, java.sql.Types.VARCHAR);
					} else {
						pstmt_tDBOutput_1.setString(9, row1.job_version);
					}

					if (row1.context == null) {
						pstmt_tDBOutput_1.setNull(10, java.sql.Types.VARCHAR);
					} else {
						pstmt_tDBOutput_1.setString(10, row1.context);
					}

					if (row1.origin == null) {
						pstmt_tDBOutput_1.setNull(11, java.sql.Types.VARCHAR);
					} else {
						pstmt_tDBOutput_1.setString(11, row1.origin);
					}

					if (row1.message_type == null) {
						pstmt_tDBOutput_1.setNull(12, java.sql.Types.VARCHAR);
					} else {
						pstmt_tDBOutput_1.setString(12, row1.message_type);
					}

					if (row1.message == null) {
						pstmt_tDBOutput_1.setNull(13, java.sql.Types.VARCHAR);
					} else {
						pstmt_tDBOutput_1.setString(13, row1.message);
					}

					if (row1.duration == null) {
						pstmt_tDBOutput_1.setNull(14, java.sql.Types.INTEGER);
					} else {
						pstmt_tDBOutput_1.setLong(14, row1.duration);
					}

					pstmt_tDBOutput_1.addBatch();
					nb_line_tDBOutput_1++;

					batchSizeCounter_tDBOutput_1++;

					if ((batchSize_tDBOutput_1 > 0) && (batchSize_tDBOutput_1 <= batchSizeCounter_tDBOutput_1)) {
						try {
							int countSum_tDBOutput_1 = 0;

							for (int countEach_tDBOutput_1 : pstmt_tDBOutput_1.executeBatch()) {
								countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
							}
							rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;

							insertedCount_tDBOutput_1 += countSum_tDBOutput_1;

							batchSizeCounter_tDBOutput_1 = 0;
						} catch (java.sql.BatchUpdateException e_tDBOutput_1) {
							globalMap.put("tDBOutput_1_ERROR_MESSAGE", e_tDBOutput_1.getMessage());
							java.sql.SQLException ne_tDBOutput_1 = e_tDBOutput_1.getNextException(),
									sqle_tDBOutput_1 = null;
							String errormessage_tDBOutput_1;
							if (ne_tDBOutput_1 != null) {
								// build new exception to provide the original cause
								sqle_tDBOutput_1 = new java.sql.SQLException(
										e_tDBOutput_1.getMessage() + "\ncaused by: " + ne_tDBOutput_1.getMessage(),
										ne_tDBOutput_1.getSQLState(), ne_tDBOutput_1.getErrorCode(), ne_tDBOutput_1);
								errormessage_tDBOutput_1 = sqle_tDBOutput_1.getMessage();
							} else {
								errormessage_tDBOutput_1 = e_tDBOutput_1.getMessage();
							}

							int countSum_tDBOutput_1 = 0;
							for (int countEach_tDBOutput_1 : e_tDBOutput_1.getUpdateCounts()) {
								countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
							}
							rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;

							insertedCount_tDBOutput_1 += countSum_tDBOutput_1;

							System.err.println(errormessage_tDBOutput_1);

						}
					}

					commitCounter_tDBOutput_1++;
					if (commitEvery_tDBOutput_1 <= commitCounter_tDBOutput_1) {
						if ((batchSize_tDBOutput_1 > 0) && (batchSizeCounter_tDBOutput_1 > 0)) {
							try {
								int countSum_tDBOutput_1 = 0;

								for (int countEach_tDBOutput_1 : pstmt_tDBOutput_1.executeBatch()) {
									countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
								}
								rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;

								insertedCount_tDBOutput_1 += countSum_tDBOutput_1;

								batchSizeCounter_tDBOutput_1 = 0;
							} catch (java.sql.BatchUpdateException e_tDBOutput_1) {
								globalMap.put("tDBOutput_1_ERROR_MESSAGE", e_tDBOutput_1.getMessage());
								java.sql.SQLException ne_tDBOutput_1 = e_tDBOutput_1.getNextException(),
										sqle_tDBOutput_1 = null;
								String errormessage_tDBOutput_1;
								if (ne_tDBOutput_1 != null) {
									// build new exception to provide the original cause
									sqle_tDBOutput_1 = new java.sql.SQLException(
											e_tDBOutput_1.getMessage() + "\ncaused by: " + ne_tDBOutput_1.getMessage(),
											ne_tDBOutput_1.getSQLState(), ne_tDBOutput_1.getErrorCode(),
											ne_tDBOutput_1);
									errormessage_tDBOutput_1 = sqle_tDBOutput_1.getMessage();
								} else {
									errormessage_tDBOutput_1 = e_tDBOutput_1.getMessage();
								}

								int countSum_tDBOutput_1 = 0;
								for (int countEach_tDBOutput_1 : e_tDBOutput_1.getUpdateCounts()) {
									countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
								}
								rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;

								insertedCount_tDBOutput_1 += countSum_tDBOutput_1;

								System.err.println(errormessage_tDBOutput_1);

							}
						}
						if (rowsToCommitCount_tDBOutput_1 != 0) {

						}
						conn_tDBOutput_1.commit();
						if (rowsToCommitCount_tDBOutput_1 != 0) {

							rowsToCommitCount_tDBOutput_1 = 0;
						}
						commitCounter_tDBOutput_1 = 0;
					}

					tos_count_tDBOutput_1++;

					/**
					 * [tDBOutput_1 main ] stop
					 */

					/**
					 * [tDBOutput_1 process_data_begin ] start
					 */

					currentComponent = "tDBOutput_1";

					/**
					 * [tDBOutput_1 process_data_begin ] stop
					 */

					/**
					 * [tDBOutput_1 process_data_end ] start
					 */

					currentComponent = "tDBOutput_1";

					/**
					 * [tDBOutput_1 process_data_end ] stop
					 */

					/**
					 * [tStatCatcher_1 process_data_end ] start
					 */

					currentComponent = "tStatCatcher_1";

					/**
					 * [tStatCatcher_1 process_data_end ] stop
					 */

					/**
					 * [tStatCatcher_1 end ] start
					 */

					currentComponent = "tStatCatcher_1";

				}

				ok_Hash.put("tStatCatcher_1", true);
				end_Hash.put("tStatCatcher_1", System.currentTimeMillis());

				/**
				 * [tStatCatcher_1 end ] stop
				 */

				/**
				 * [tDBOutput_1 end ] start
				 */

				currentComponent = "tDBOutput_1";

				try {
					int countSum_tDBOutput_1 = 0;
					if (pstmt_tDBOutput_1 != null && batchSizeCounter_tDBOutput_1 > 0) {

						for (int countEach_tDBOutput_1 : pstmt_tDBOutput_1.executeBatch()) {
							countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
						}
						rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;

					}

					insertedCount_tDBOutput_1 += countSum_tDBOutput_1;

				} catch (java.sql.BatchUpdateException e_tDBOutput_1) {
					globalMap.put("tDBOutput_1_ERROR_MESSAGE", e_tDBOutput_1.getMessage());
					java.sql.SQLException ne_tDBOutput_1 = e_tDBOutput_1.getNextException(), sqle_tDBOutput_1 = null;
					String errormessage_tDBOutput_1;
					if (ne_tDBOutput_1 != null) {
						// build new exception to provide the original cause
						sqle_tDBOutput_1 = new java.sql.SQLException(
								e_tDBOutput_1.getMessage() + "\ncaused by: " + ne_tDBOutput_1.getMessage(),
								ne_tDBOutput_1.getSQLState(), ne_tDBOutput_1.getErrorCode(), ne_tDBOutput_1);
						errormessage_tDBOutput_1 = sqle_tDBOutput_1.getMessage();
					} else {
						errormessage_tDBOutput_1 = e_tDBOutput_1.getMessage();
					}

					int countSum_tDBOutput_1 = 0;
					for (int countEach_tDBOutput_1 : e_tDBOutput_1.getUpdateCounts()) {
						countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
					}
					rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;

					insertedCount_tDBOutput_1 += countSum_tDBOutput_1;

					System.err.println(errormessage_tDBOutput_1);

				}

				if (pstmt_tDBOutput_1 != null) {

					pstmt_tDBOutput_1.close();
					resourceMap.remove("pstmt_tDBOutput_1");
				}
				resourceMap.put("statementClosed_tDBOutput_1", true);
				if (rowsToCommitCount_tDBOutput_1 != 0) {

				}
				conn_tDBOutput_1.commit();
				if (rowsToCommitCount_tDBOutput_1 != 0) {

					rowsToCommitCount_tDBOutput_1 = 0;
				}
				commitCounter_tDBOutput_1 = 0;

				conn_tDBOutput_1.close();

				resourceMap.put("finish_tDBOutput_1", true);

				nb_line_deleted_tDBOutput_1 = nb_line_deleted_tDBOutput_1 + deletedCount_tDBOutput_1;
				nb_line_update_tDBOutput_1 = nb_line_update_tDBOutput_1 + updatedCount_tDBOutput_1;
				nb_line_inserted_tDBOutput_1 = nb_line_inserted_tDBOutput_1 + insertedCount_tDBOutput_1;
				nb_line_rejected_tDBOutput_1 = nb_line_rejected_tDBOutput_1 + rejectedCount_tDBOutput_1;

				globalMap.put("tDBOutput_1_NB_LINE", nb_line_tDBOutput_1);
				globalMap.put("tDBOutput_1_NB_LINE_UPDATED", nb_line_update_tDBOutput_1);
				globalMap.put("tDBOutput_1_NB_LINE_INSERTED", nb_line_inserted_tDBOutput_1);
				globalMap.put("tDBOutput_1_NB_LINE_DELETED", nb_line_deleted_tDBOutput_1);
				globalMap.put("tDBOutput_1_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_1);

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "row1");
				}

				ok_Hash.put("tDBOutput_1", true);
				end_Hash.put("tDBOutput_1", System.currentTimeMillis());

				/**
				 * [tDBOutput_1 end ] stop
				 */

			} // end the resume

		} catch (java.lang.Exception e) {

			TalendException te = new TalendException(e, currentComponent, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			try {

				/**
				 * [tStatCatcher_1 finally ] start
				 */

				currentComponent = "tStatCatcher_1";

				/**
				 * [tStatCatcher_1 finally ] stop
				 */

				/**
				 * [tDBOutput_1 finally ] start
				 */

				currentComponent = "tDBOutput_1";

				try {
					if (resourceMap.get("statementClosed_tDBOutput_1") == null) {
						java.sql.PreparedStatement pstmtToClose_tDBOutput_1 = null;
						if ((pstmtToClose_tDBOutput_1 = (java.sql.PreparedStatement) resourceMap
								.remove("pstmt_tDBOutput_1")) != null) {
							pstmtToClose_tDBOutput_1.close();
						}
					}
				} finally {
					if (resourceMap.get("finish_tDBOutput_1") == null) {
						java.sql.Connection ctn_tDBOutput_1 = null;
						if ((ctn_tDBOutput_1 = (java.sql.Connection) resourceMap.get("conn_tDBOutput_1")) != null) {
							try {
								ctn_tDBOutput_1.close();
							} catch (java.sql.SQLException sqlEx_tDBOutput_1) {
								String errorMessage_tDBOutput_1 = "failed to close the connection in tDBOutput_1 :"
										+ sqlEx_tDBOutput_1.getMessage();
								System.err.println(errorMessage_tDBOutput_1);
							}
						}
					}
				}

				/**
				 * [tDBOutput_1 finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tStatCatcher_1_SUBPROCESS_STATE", 1);
	}

	public String resuming_logs_dir_path = null;
	public String resuming_checkpoint_path = null;
	public String parent_part_launcher = null;
	private String resumeEntryMethodName = null;
	private boolean globalResumeTicket = false;

	public boolean watch = false;
	// portStats is null, it means don't execute the statistics
	public Integer portStats = null;
	public int portTraces = 4334;
	public String clientHost;
	public String defaultClientHost = "localhost";
	public String contextStr = "Default";
	public boolean isDefaultContext = true;
	public String pid = "0";
	public String rootPid = null;
	public String fatherPid = null;
	public String fatherNode = null;
	public long startTime = 0;
	public boolean isChildJob = false;
	public String log4jLevel = "";

	private boolean enableLogStash;

	private boolean execStat = true;

	private ThreadLocal<java.util.Map<String, String>> threadLocal = new ThreadLocal<java.util.Map<String, String>>() {
		protected java.util.Map<String, String> initialValue() {
			java.util.Map<String, String> threadRunResultMap = new java.util.HashMap<String, String>();
			threadRunResultMap.put("errorCode", null);
			threadRunResultMap.put("status", "");
			return threadRunResultMap;
		};
	};

	protected PropertiesWithType context_param = new PropertiesWithType();
	public java.util.Map<String, Object> parentContextMap = new java.util.HashMap<String, Object>();

	public String status = "";

	public static void main(String[] args) {
		final C_ALIM_ODS C_ALIM_ODSClass = new C_ALIM_ODS();

		int exitCode = C_ALIM_ODSClass.runJobInTOS(args);

		System.exit(exitCode);
	}

	public String[][] runJob(String[] args) {

		int exitCode = runJobInTOS(args);
		String[][] bufferValue = new String[][] { { Integer.toString(exitCode) } };

		return bufferValue;
	}

	public boolean hastBufferOutputComponent() {
		boolean hastBufferOutput = false;

		return hastBufferOutput;
	}

	public int runJobInTOS(String[] args) {
		// reset status
		status = "";

		String lastStr = "";
		for (String arg : args) {
			if (arg.equalsIgnoreCase("--context_param")) {
				lastStr = arg;
			} else if (lastStr.equals("")) {
				evalParam(arg);
			} else {
				evalParam(lastStr + " " + arg);
				lastStr = "";
			}
		}
		enableLogStash = "true".equalsIgnoreCase(System.getProperty("audit.enabled"));

		if (clientHost == null) {
			clientHost = defaultClientHost;
		}

		if (pid == null || "0".equals(pid)) {
			pid = TalendString.getAsciiRandomString(6);
		}

		if (rootPid == null) {
			rootPid = pid;
		}
		if (fatherPid == null) {
			fatherPid = pid;
		} else {
			isChildJob = true;
		}

		if (portStats != null) {
			// portStats = -1; //for testing
			if (portStats < 0 || portStats > 65535) {
				// issue:10869, the portStats is invalid, so this client socket can't open
				System.err.println("The statistics socket port " + portStats + " is invalid.");
				execStat = false;
			}
		} else {
			execStat = false;
		}
		boolean inOSGi = routines.system.BundleUtils.inOSGi();

		if (inOSGi) {
			java.util.Dictionary<String, Object> jobProperties = routines.system.BundleUtils.getJobProperties(jobName);

			if (jobProperties != null && jobProperties.get("context") != null) {
				contextStr = (String) jobProperties.get("context");
			}
		}

		try {
			// call job/subjob with an existing context, like: --context=production. if
			// without this parameter, there will use the default context instead.
			java.io.InputStream inContext = C_ALIM_ODS.class.getClassLoader()
					.getResourceAsStream("alimentation_dm2/c_alim_ods_0_1/contexts/" + contextStr + ".properties");
			if (inContext == null) {
				inContext = C_ALIM_ODS.class.getClassLoader()
						.getResourceAsStream("config/contexts/" + contextStr + ".properties");
			}
			if (inContext != null) {
				try {
					// defaultProps is in order to keep the original context value
					if (context != null && context.isEmpty()) {
						defaultProps.load(inContext);
						context = new ContextProperties(defaultProps);
					}
				} finally {
					inContext.close();
				}
			} else if (!isDefaultContext) {
				// print info and job continue to run, for case: context_param is not empty.
				System.err.println("Could not find the context " + contextStr);
			}

			if (!context_param.isEmpty()) {
				context.putAll(context_param);
				// set types for params from parentJobs
				for (Object key : context_param.keySet()) {
					String context_key = key.toString();
					String context_type = context_param.getContextType(context_key);
					context.setContextType(context_key, context_type);

				}
			}
			class ContextProcessing {
				private void processContext_0() {
				}

				public void processAllContext() {
					processContext_0();
				}
			}

			new ContextProcessing().processAllContext();
		} catch (java.io.IOException ie) {
			System.err.println("Could not load context " + contextStr);
			ie.printStackTrace();
		}

		// get context value from parent directly
		if (parentContextMap != null && !parentContextMap.isEmpty()) {
		}

		// Resume: init the resumeUtil
		resumeEntryMethodName = ResumeUtil.getResumeEntryMethodName(resuming_checkpoint_path);
		resumeUtil = new ResumeUtil(resuming_logs_dir_path, isChildJob, rootPid);
		resumeUtil.initCommonInfo(pid, rootPid, fatherPid, projectName, jobName, contextStr, jobVersion);

		List<String> parametersToEncrypt = new java.util.ArrayList<String>();
		// Resume: jobStart
		resumeUtil.addLog("JOB_STARTED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "",
				"", "", "", "", resumeUtil.convertToJsonText(context, parametersToEncrypt));

		if (execStat) {
			try {
				runStat.openSocket(!isChildJob);
				runStat.setAllPID(rootPid, fatherPid, pid, jobName);
				runStat.startThreadStat(clientHost, portStats);
				runStat.updateStatOnJob(RunStat.JOBSTART, fatherNode);
			} catch (java.io.IOException ioException) {
				ioException.printStackTrace();
			}
		}

		java.util.concurrent.ConcurrentHashMap<Object, Object> concurrentHashMap = new java.util.concurrent.ConcurrentHashMap<Object, Object>();
		globalMap.put("concurrentHashMap", concurrentHashMap);

		long startUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
		long endUsedMemory = 0;
		long end = 0;

		startTime = System.currentTimeMillis();
		tStatCatcher_1.addMessage("begin");

		this.globalResumeTicket = true;// to run tPreJob

		try {
			tStatCatcher_1Process(globalMap);
		} catch (java.lang.Exception e) {
			e.printStackTrace();
		}

		this.globalResumeTicket = false;// to run others jobs

		try {
			errorCode = null;
			tDBRow_1Process(globalMap);
			if (!"failure".equals(status)) {
				status = "end";
			}
		} catch (TalendException e_tDBRow_1) {
			globalMap.put("tDBRow_1_SUBPROCESS_STATE", -1);

			e_tDBRow_1.printStackTrace();

		}
		try {
			errorCode = null;
			tJava_1Process(globalMap);
			if (!"failure".equals(status)) {
				status = "end";
			}
		} catch (TalendException e_tJava_1) {
			globalMap.put("tJava_1_SUBPROCESS_STATE", -1);

			e_tJava_1.printStackTrace();

		}

		this.globalResumeTicket = true;// to run tPostJob

		end = System.currentTimeMillis();

		if (watch) {
			System.out.println((end - startTime) + " milliseconds");
		}

		endUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
		if (false) {
			System.out.println((endUsedMemory - startUsedMemory) + " bytes memory increase when running : C_ALIM_ODS");
		}
		tStatCatcher_1.addMessage(status == "" ? "end" : status, (end - startTime));
		try {
			tStatCatcher_1Process(globalMap);
		} catch (java.lang.Exception e) {
			e.printStackTrace();
		}

		if (execStat) {
			runStat.updateStatOnJob(RunStat.JOBEND, fatherNode);
			runStat.stopThreadStat();
		}
		int returnCode = 0;

		if (errorCode == null) {
			returnCode = status != null && status.equals("failure") ? 1 : 0;
		} else {
			returnCode = errorCode.intValue();
		}
		resumeUtil.addLog("JOB_ENDED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "",
				"" + returnCode, "", "", "");

		return returnCode;

	}

	// only for OSGi env
	public void destroy() {

	}

	private java.util.Map<String, Object> getSharedConnections4REST() {
		java.util.Map<String, Object> connections = new java.util.HashMap<String, Object>();

		return connections;
	}

	private void evalParam(String arg) {
		if (arg.startsWith("--resuming_logs_dir_path")) {
			resuming_logs_dir_path = arg.substring(25);
		} else if (arg.startsWith("--resuming_checkpoint_path")) {
			resuming_checkpoint_path = arg.substring(27);
		} else if (arg.startsWith("--parent_part_launcher")) {
			parent_part_launcher = arg.substring(23);
		} else if (arg.startsWith("--watch")) {
			watch = true;
		} else if (arg.startsWith("--stat_port=")) {
			String portStatsStr = arg.substring(12);
			if (portStatsStr != null && !portStatsStr.equals("null")) {
				portStats = Integer.parseInt(portStatsStr);
			}
		} else if (arg.startsWith("--trace_port=")) {
			portTraces = Integer.parseInt(arg.substring(13));
		} else if (arg.startsWith("--client_host=")) {
			clientHost = arg.substring(14);
		} else if (arg.startsWith("--context=")) {
			contextStr = arg.substring(10);
			isDefaultContext = false;
		} else if (arg.startsWith("--father_pid=")) {
			fatherPid = arg.substring(13);
		} else if (arg.startsWith("--root_pid=")) {
			rootPid = arg.substring(11);
		} else if (arg.startsWith("--father_node=")) {
			fatherNode = arg.substring(14);
		} else if (arg.startsWith("--pid=")) {
			pid = arg.substring(6);
		} else if (arg.startsWith("--context_type")) {
			String keyValue = arg.substring(15);
			int index = -1;
			if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
				if (fatherPid == null) {
					context_param.setContextType(keyValue.substring(0, index),
							replaceEscapeChars(keyValue.substring(index + 1)));
				} else { // the subjob won't escape the especial chars
					context_param.setContextType(keyValue.substring(0, index), keyValue.substring(index + 1));
				}

			}

		} else if (arg.startsWith("--context_param")) {
			String keyValue = arg.substring(16);
			int index = -1;
			if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
				if (fatherPid == null) {
					context_param.put(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
				} else { // the subjob won't escape the especial chars
					context_param.put(keyValue.substring(0, index), keyValue.substring(index + 1));
				}
			}
		} else if (arg.startsWith("--log4jLevel=")) {
			log4jLevel = arg.substring(13);
		} else if (arg.startsWith("--audit.enabled") && arg.contains("=")) {// for trunjob call
			final int equal = arg.indexOf('=');
			final String key = arg.substring("--".length(), equal);
			System.setProperty(key, arg.substring(equal + 1));
		}
	}

	private static final String NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY = "<TALEND_NULL>";

	private final String[][] escapeChars = { { "\\\\", "\\" }, { "\\n", "\n" }, { "\\'", "\'" }, { "\\r", "\r" },
			{ "\\f", "\f" }, { "\\b", "\b" }, { "\\t", "\t" } };

	private String replaceEscapeChars(String keyValue) {

		if (keyValue == null || ("").equals(keyValue.trim())) {
			return keyValue;
		}

		StringBuilder result = new StringBuilder();
		int currIndex = 0;
		while (currIndex < keyValue.length()) {
			int index = -1;
			// judege if the left string includes escape chars
			for (String[] strArray : escapeChars) {
				index = keyValue.indexOf(strArray[0], currIndex);
				if (index >= 0) {

					result.append(keyValue.substring(currIndex, index + strArray[0].length()).replace(strArray[0],
							strArray[1]));
					currIndex = index + strArray[0].length();
					break;
				}
			}
			// if the left string doesn't include escape chars, append the left into the
			// result
			if (index < 0) {
				result.append(keyValue.substring(currIndex));
				currIndex = currIndex + keyValue.length();
			}
		}

		return result.toString();
	}

	public Integer getErrorCode() {
		return errorCode;
	}

	public String getStatus() {
		return status;
	}

	ResumeUtil resumeUtil = null;
}
/************************************************************************************************
 * 212051 characters generated by Talend Open Studio for Data Integration on the
 * 18 janvier 2024 à 23:09:01 CET
 ************************************************************************************************/